<?php
/**
 * Installation du système d'authentification et gestion entreprise
 * Tables: users, roles, permissions, wallets, transactions
 */

require_once 'config/database.php';

try {
    $pdo = getDB();
    
    // Table: roles
    $pdo->exec("CREATE TABLE IF NOT EXISTS roles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) UNIQUE NOT NULL,
        display_name VARCHAR(100) NOT NULL,
        description TEXT,
        permissions JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_name (name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    // Table: users
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        full_name VARCHAR(255) NOT NULL,
        phone VARCHAR(50),
        company VARCHAR(255),
        role_id INT DEFAULT 3,
        status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
        email_verified BOOLEAN DEFAULT FALSE,
        last_login DATETIME,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (role_id) REFERENCES roles(id),
        INDEX idx_email (email),
        INDEX idx_status (status),
        INDEX idx_role_id (role_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    // Table: wallets
    $pdo->exec("CREATE TABLE IF NOT EXISTS wallets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNIQUE NOT NULL,
        balance DECIMAL(10, 2) DEFAULT 0.00,
        currency VARCHAR(3) DEFAULT 'EUR',
        status ENUM('active', 'frozen', 'closed') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        INDEX idx_user_id (user_id),
        INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    // Table: transactions
    $pdo->exec("CREATE TABLE IF NOT EXISTS transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        wallet_id INT NOT NULL,
        type ENUM('credit', 'debit', 'refund', 'fee') NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        balance_before DECIMAL(10, 2) NOT NULL,
        balance_after DECIMAL(10, 2) NOT NULL,
        description TEXT,
        reference VARCHAR(100),
        order_id VARCHAR(100),
        status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'completed',
        created_by INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (wallet_id) REFERENCES wallets(id) ON DELETE CASCADE,
        FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_wallet_id (wallet_id),
        INDEX idx_type (type),
        INDEX idx_status (status),
        INDEX idx_created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    // Table: sessions (pour gérer les sessions utilisateur)
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_sessions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        session_token VARCHAR(255) UNIQUE NOT NULL,
        ip_address VARCHAR(45),
        user_agent TEXT,
        expires_at DATETIME NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        INDEX idx_user_id (user_id),
        INDEX idx_session_token (session_token),
        INDEX idx_expires_at (expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    // Insérer les rôles par défaut
    $pdo->exec("INSERT IGNORE INTO roles (id, name, display_name, description, permissions) VALUES
        (1, 'super_admin', 'Super Administrateur', 'Accès complet au système', '{\"all\": true}'),
        (2, 'admin', 'Administrateur', 'Gestion des utilisateurs et commandes', '{\"manage_users\": true, \"manage_orders\": true, \"view_reports\": true}'),
        (3, 'client', 'Client', 'Utilisateur standard avec wallet', '{\"create_orders\": true, \"view_wallet\": true}'),
        (4, 'employee', 'Employé', 'Gestion des commandes uniquement', '{\"manage_orders\": true, \"view_orders\": true}')
    ");
    
    // Créer un compte admin par défaut
    $adminPassword = password_hash('admin123', PASSWORD_BCRYPT);
    $pdo->exec("INSERT IGNORE INTO users (id, email, password, full_name, role_id, status, email_verified) VALUES
        (1, 'admin@digiservices.com', '$adminPassword', 'Administrateur', 1, 'active', 1)
    ");
    
    // Créer un wallet pour l'admin
    $pdo->exec("INSERT IGNORE INTO wallets (user_id, balance, status) VALUES
        (1, 0.00, 'active')
    ");
    
    echo json_encode([
        'success' => true,
        'message' => '✅ Système d\'authentification installé avec succès!',
        'tables' => [
            'roles',
            'users',
            'wallets',
            'transactions',
            'user_sessions'
        ],
        'default_admin' => [
            'email' => 'admin@digiservices.com',
            'password' => 'admin123',
            'note' => '⚠️ Changez ce mot de passe après la première connexion!'
        ]
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Erreur lors de l\'installation: ' . $e->getMessage()
    ]);
}
