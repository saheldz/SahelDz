<?php
/**
 * Page de changement de mot de passe
 */
require_once 'config/auth-check.php';
require_once 'config/database.php';

$pdo = getDB();
$user = $GLOBALS['current_user'];

$success_message = '';
$error_message = '';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validations
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error_message = 'Tous les champs sont obligatoires.';
    } elseif ($new_password !== $confirm_password) {
        $error_message = 'Les nouveaux mots de passe ne correspondent pas.';
    } elseif (strlen($new_password) < 6) {
        $error_message = 'Le nouveau mot de passe doit contenir au moins 6 caractères.';
    } else {
        // Vérifier le mot de passe actuel
        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$user['id']]);
        $userData = $stmt->fetch();
        
        if (!password_verify($current_password, $userData['password'])) {
            $error_message = 'Le mot de passe actuel est incorrect.';
        } else {
            // Mettre à jour le mot de passe
            $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            
            if ($stmt->execute([$new_password_hash, $user['id']])) {
                $success_message = 'Votre mot de passe a été changé avec succès!';
                
                // Optionnel: Déconnecter l'utilisateur et le forcer à se reconnecter
                // session_destroy();
                // header('Location: /login.html?message=password_changed');
                // exit;
            } else {
                $error_message = 'Erreur lors du changement de mot de passe. Veuillez réessayer.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Changer le mot de passe - DigiServices</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .gradient-bg { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
    </style>
</head>
<body class="h-full bg-gray-50">
    <?php include 'config/impersonation-banner.php'; ?>
    
    <div class="min-h-full">
        <!-- Header -->
        <div class="gradient-bg">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex items-center justify-between h-16">
                    <div class="flex items-center">
                        <a href="<?php echo $user['role'] === 'client' ? '/html/client-app.php' : '/html/1a.php'; ?>" class="text-white hover:text-gray-200 flex items-center">
                            <span class="text-2xl mr-2">←</span>
                            <span class="font-semibold">Retour</span>
                        </a>
                    </div>
                    <h1 class="text-xl font-bold text-white">🔐 Changer le mot de passe</h1>
                    <div class="w-24"></div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <!-- Messages -->
            <?php if ($success_message): ?>
                <div class="mb-6 bg-green-50 border-l-4 border-green-500 p-4 rounded-lg">
                    <div class="flex items-center">
                        <span class="text-2xl mr-3">✅</span>
                        <div>
                            <p class="text-green-700 font-medium"><?php echo htmlspecialchars($success_message); ?></p>
                            <p class="text-green-600 text-sm mt-1">Vous pouvez maintenant utiliser votre nouveau mot de passe pour vous connecter.</p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
                <div class="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded-lg">
                    <div class="flex items-center">
                        <span class="text-2xl mr-3">❌</span>
                        <p class="text-red-700 font-medium"><?php echo htmlspecialchars($error_message); ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Password Change Card -->
            <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                <div class="gradient-bg px-6 py-8">
                    <div class="flex items-center justify-center">
                        <div class="text-center text-white">
                            <div class="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                                <span class="text-4xl">🔐</span>
                            </div>
                            <h2 class="text-2xl font-bold">Modifier votre mot de passe</h2>
                            <p class="text-purple-100 mt-2">Assurez-vous de choisir un mot de passe sécurisé</p>
                        </div>
                    </div>
                </div>

                <form method="POST" class="p-6" id="password-form">
                    <div class="space-y-6">
                        <!-- Mot de passe actuel -->
                        <div>
                            <label for="current_password" class="block text-sm font-medium text-gray-700 mb-2">
                                🔒 Mot de passe actuel <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <input 
                                    type="password" 
                                    id="current_password" 
                                    name="current_password" 
                                    required
                                    class="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
                                    placeholder="Entrez votre mot de passe actuel"
                                >
                                <button 
                                    type="button" 
                                    onclick="togglePasswordVisibility('current_password')"
                                    class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                                >
                                    <span id="current_password_icon">👁️</span>
                                </button>
                            </div>
                        </div>

                        <!-- Nouveau mot de passe -->
                        <div>
                            <label for="new_password" class="block text-sm font-medium text-gray-700 mb-2">
                                🆕 Nouveau mot de passe <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <input 
                                    type="password" 
                                    id="new_password" 
                                    name="new_password" 
                                    required
                                    minlength="6"
                                    class="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
                                    placeholder="Minimum 6 caractères"
                                    oninput="checkPasswordStrength()"
                                >
                                <button 
                                    type="button" 
                                    onclick="togglePasswordVisibility('new_password')"
                                    class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                                >
                                    <span id="new_password_icon">👁️</span>
                                </button>
                            </div>
                            
                            <!-- Password Strength Indicator -->
                            <div id="password-strength" class="mt-2 hidden">
                                <div class="flex items-center gap-2">
                                    <div class="flex-1 bg-gray-200 rounded-full h-2 overflow-hidden">
                                        <div id="strength-bar" class="h-full transition-all duration-300 rounded-full"></div>
                                    </div>
                                    <span id="strength-text" class="text-sm font-medium"></span>
                                </div>
                            </div>
                            
                            <p class="text-xs text-gray-500 mt-2">
                                💡 Conseil: Utilisez au moins 8 caractères avec des lettres, chiffres et symboles
                            </p>
                        </div>

                        <!-- Confirmer le mot de passe -->
                        <div>
                            <label for="confirm_password" class="block text-sm font-medium text-gray-700 mb-2">
                                ✅ Confirmer le nouveau mot de passe <span class="text-red-500">*</span>
                            </label>
                            <div class="relative">
                                <input 
                                    type="password" 
                                    id="confirm_password" 
                                    name="confirm_password" 
                                    required
                                    class="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
                                    placeholder="Retapez votre nouveau mot de passe"
                                    oninput="checkPasswordMatch()"
                                >
                                <button 
                                    type="button" 
                                    onclick="togglePasswordVisibility('confirm_password')"
                                    class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                                >
                                    <span id="confirm_password_icon">👁️</span>
                                </button>
                            </div>
                            <p id="match-message" class="text-sm mt-2 hidden"></p>
                        </div>

                        <!-- Conseils de sécurité -->
                        <div class="bg-blue-50 rounded-lg p-4">
                            <h3 class="font-semibold text-blue-800 mb-2 flex items-center">
                                <span class="mr-2">ℹ️</span>
                                Conseils de sécurité
                            </h3>
                            <ul class="text-sm text-blue-700 space-y-1">
                                <li>• Utilisez au moins 8 caractères</li>
                                <li>• Mélangez lettres majuscules et minuscules</li>
                                <li>• Incluez des chiffres et des symboles</li>
                                <li>• Évitez les informations personnelles évidentes</li>
                                <li>• N'utilisez pas le même mot de passe partout</li>
                            </ul>
                        </div>

                        <!-- Boutons d'action -->
                        <div class="flex gap-4 pt-4">
                            <button 
                                type="submit"
                                class="flex-1 gradient-bg text-white py-3 px-6 rounded-lg font-semibold hover:opacity-90 transition-opacity"
                            >
                                🔐 Changer le mot de passe
                            </button>
                            
                            <a 
                                href="/settings.php"
                                class="flex-1 bg-gray-200 text-gray-700 py-3 px-6 rounded-lg font-semibold hover:bg-gray-300 transition-colors text-center"
                            >
                                Annuler
                            </a>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Quick Links -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                <a href="/settings.php" class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center text-2xl">
                            ⚙️
                        </div>
                        <div class="ml-4">
                            <h3 class="font-semibold text-gray-800">Paramètres du compte</h3>
                            <p class="text-sm text-gray-600">Modifier vos informations</p>
                        </div>
                    </div>
                </a>

                <a href="<?php echo $user['role'] === 'client' ? '/html/client-app.php' : '/html/1a.php'; ?>" class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center text-2xl">
                            🏠
                        </div>
                        <div class="ml-4">
                            <h3 class="font-semibold text-gray-800">Tableau de bord</h3>
                            <p class="text-sm text-gray-600">Retour à l'accueil</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <script>
        function togglePasswordVisibility(fieldId) {
            const field = document.getElementById(fieldId);
            const icon = document.getElementById(fieldId + '_icon');
            
            if (field.type === 'password') {
                field.type = 'text';
                icon.textContent = '🙈';
            } else {
                field.type = 'password';
                icon.textContent = '👁️';
            }
        }

        function checkPasswordStrength() {
            const password = document.getElementById('new_password').value;
            const strengthDiv = document.getElementById('password-strength');
            const strengthBar = document.getElementById('strength-bar');
            const strengthText = document.getElementById('strength-text');
            
            if (password.length === 0) {
                strengthDiv.classList.add('hidden');
                return;
            }
            
            strengthDiv.classList.remove('hidden');
            
            let strength = 0;
            
            // Length check
            if (password.length >= 8) strength += 25;
            if (password.length >= 12) strength += 25;
            
            // Character variety checks
            if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength += 20;
            if (/\d/.test(password)) strength += 15;
            if (/[^a-zA-Z0-9]/.test(password)) strength += 15;
            
            // Update bar and text
            let color, text;
            if (strength < 40) {
                color = 'bg-red-500';
                text = 'Faible';
            } else if (strength < 70) {
                color = 'bg-yellow-500';
                text = 'Moyen';
            } else {
                color = 'bg-green-500';
                text = 'Fort';
            }
            
            strengthBar.className = `h-full transition-all duration-300 rounded-full ${color}`;
            strengthBar.style.width = strength + '%';
            strengthText.textContent = text;
            strengthText.className = `text-sm font-medium ${color.replace('bg-', 'text-')}`;
        }

        function checkPasswordMatch() {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const matchMessage = document.getElementById('match-message');
            
            if (confirmPassword.length === 0) {
                matchMessage.classList.add('hidden');
                return;
            }
            
            matchMessage.classList.remove('hidden');
            
            if (newPassword === confirmPassword) {
                matchMessage.textContent = '✅ Les mots de passe correspondent';
                matchMessage.className = 'text-sm mt-2 text-green-600';
            } else {
                matchMessage.textContent = '❌ Les mots de passe ne correspondent pas';
                matchMessage.className = 'text-sm mt-2 text-red-600';
            }
        }

        // Form validation before submit
        document.getElementById('password-form').addEventListener('submit', function(e) {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (newPassword !== confirmPassword) {
                e.preventDefault();
                alert('❌ Les mots de passe ne correspondent pas. Veuillez vérifier.');
                return false;
            }
            
            if (newPassword.length < 6) {
                e.preventDefault();
                alert('❌ Le mot de passe doit contenir au moins 6 caractères.');
                return false;
            }
        });
    </script>
</body>
</html>
