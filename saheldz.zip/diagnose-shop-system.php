<?php
/**
 * Diagnostic du système boutique
 */
require_once 'config/database.php';
require_once 'config/auth-check.php';

$pdo = getDB();

echo "<!DOCTYPE html><html><head><title>Diagnostic Boutique</title>";
echo "<style>body{font-family:monospace;padding:20px;background:#f5f5f5;}";
echo ".success{color:green;} .error{color:red;} .info{color:blue;}";
echo "h2{background:#333;color:white;padding:10px;margin-top:20px;}";
echo "pre{background:white;padding:10px;border:1px solid #ddd;}</style></head><body>";

echo "<h1>🔍 Diagnostic Système Boutique</h1>";

// 1. Vérifier les tables
echo "<h2>1️⃣ Vérification des Tables</h2>";

$tables = ['shop_items', 'shop_categories', 'product_stock', 'orders', 'wallet_transactions'];
foreach ($tables as $table) {
    try {
        $stmt = $pdo->query("SELECT COUNT(*) FROM $table");
        $count = $stmt->fetchColumn();
        echo "<div class='success'>✅ Table '$table' existe : $count lignes</div>";
    } catch (PDOException $e) {
        echo "<div class='error'>❌ Table '$table' : " . $e->getMessage() . "</div>";
    }
}

// 2. Vérifier les produits
echo "<h2>2️⃣ Produits dans shop_items</h2>";
try {
    $stmt = $pdo->query("SELECT * FROM shop_items WHERE type = 'product' LIMIT 5");
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<pre>" . json_encode($items, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
} catch (PDOException $e) {
    echo "<div class='error'>❌ Erreur : " . $e->getMessage() . "</div>";
}

// 3. Vérifier le stock
echo "<h2>3️⃣ Stock Disponible (product_stock)</h2>";
try {
    $stmt = $pdo->query("
        SELECT ps.*, i.name as item_name 
        FROM product_stock ps 
        JOIN shop_items i ON ps.item_id = i.id 
        ORDER BY ps.id DESC 
        LIMIT 10
    ");
    $stock = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<pre>" . json_encode($stock, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
    
    // Compteur par statut
    $stmt = $pdo->query("
        SELECT status, COUNT(*) as count 
        FROM product_stock 
        GROUP BY status
    ");
    $counts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<h3>Statistiques Stock :</h3>";
    foreach ($counts as $count) {
        $icon = $count['status'] === 'available' ? '✅' : '❌';
        echo "<div>$icon {$count['status']}: {$count['count']}</div>";
    }
} catch (PDOException $e) {
    echo "<div class='error'>❌ Erreur : " . $e->getMessage() . "</div>";
}

// 4. Vérifier les dernières commandes
echo "<h2>4️⃣ Dernières Commandes (orders)</h2>";
try {
    $stmt = $pdo->query("
        SELECT o.*, i.name as item_name, i.type as item_type
        FROM orders o 
        LEFT JOIN shop_items i ON o.item_id = i.id 
        ORDER BY o.created_at DESC 
        LIMIT 10
    ");
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<pre>" . json_encode($orders, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "</pre>";
} catch (PDOException $e) {
    echo "<div class='error'>❌ Erreur : " . $e->getMessage() . "</div>";
}

// 5. Vérifier quelle API est utilisée
echo "<h2>5️⃣ Vérification des Fichiers API</h2>";

$apiFiles = [
    'api/shop.php' => 'Ancienne API',
    'api/shop-dynamic.php' => 'Nouvelle API avec stock'
];

foreach ($apiFiles as $file => $desc) {
    if (file_exists($file)) {
        $size = filesize($file);
        $modified = date('Y-m-d H:i:s', filemtime($file));
        echo "<div class='success'>✅ $file ($desc) - $size bytes - Modifié: $modified</div>";
        
        // Lire les 50 premières lignes pour voir les fonctions
        $content = file_get_contents($file);
        if (strpos($content, 'product_stock') !== false) {
            echo "<div class='success'>  → Contient 'product_stock' (gestion stock)</div>";
        }
        if (strpos($content, 'create_order') !== false) {
            echo "<div class='success'>  → Contient 'create_order'</div>";
        }
    } else {
        echo "<div class='error'>❌ $file ($desc) - INTROUVABLE</div>";
    }
}

// 6. Vérifier client-app.php
echo "<h2>6️⃣ Quelle API utilise client-app.php ?</h2>";
if (file_exists('html/client-app.php')) {
    $content = file_get_contents('html/client-app.php');
    
    if (strpos($content, 'api/shop-dynamic.php') !== false) {
        echo "<div class='success'>✅ client-app.php utilise shop-dynamic.php (CORRECT)</div>";
    } elseif (strpos($content, 'api/shop.php') !== false) {
        echo "<div class='error'>❌ client-app.php utilise ENCORE shop.php (ANCIEN)</div>";
        echo "<div class='error'>👉 IL FAUT LE CHANGER VERS shop-dynamic.php !</div>";
    } else {
        echo "<div class='info'>⚠️ Impossible de détecter quelle API est utilisée</div>";
    }
} else {
    echo "<div class='error'>❌ html/client-app.php introuvable</div>";
}

// 7. Test de connexion à l'API
echo "<h2>7️⃣ Test API shop-dynamic.php</h2>";
echo "<div class='info'>Testons si l'API répond correctement...</div>";

$testData = [
    'action' => 'get_items',
    'type' => 'product'
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://saheldz.mpsdash.com/api/shop-dynamic.php?' . http_build_query($testData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "<div>HTTP Code: $httpCode</div>";
if ($httpCode === 200) {
    echo "<div class='success'>✅ API répond correctement</div>";
    $data = json_decode($response, true);
    if ($data && isset($data['items'])) {
        echo "<div class='success'>✅ API retourne " . count($data['items']) . " produits</div>";
    }
} else {
    echo "<div class='error'>❌ API ne répond pas correctement</div>";
}

echo "<h2>✅ Diagnostic Terminé</h2>";
echo "<p><a href='/admin-shop.php'>← Retour Admin Shop</a></p>";
echo "</body></html>";
?>
