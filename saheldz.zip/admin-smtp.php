<?php
/**
 * Configuration SMTP - Admin
 */
require_once 'config/auth-check.php';

if (!isAdmin()) {
    header('Location: /index.php');
    exit;
}

require_once 'config/database.php';
$pdo = getDB();

// Créer la table si elle n'existe pas
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS smtp_config (
        id INT PRIMARY KEY AUTO_INCREMENT,
        smtp_host VARCHAR(255) NOT NULL DEFAULT '',
        smtp_port INT NOT NULL DEFAULT 587,
        smtp_username VARCHAR(255) NOT NULL DEFAULT '',
        smtp_password VARCHAR(255) DEFAULT '',
        smtp_encryption VARCHAR(10) DEFAULT 'tls',
        from_email VARCHAR(255) DEFAULT '',
        from_name VARCHAR(255) DEFAULT 'DigiServices',
        email_verification_enabled TINYINT DEFAULT 0,
        send_welcome_email TINYINT DEFAULT 1,
        notify_project_updates TINYINT DEFAULT 1,
        notify_wallet_transactions TINYINT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
} catch (PDOException $e) {
    // Table existe déjà
}

// Récupérer la configuration actuelle
try {
    $stmt = $pdo->query("SELECT * FROM smtp_config LIMIT 1");
    $config = $stmt->fetch() ?: [];
} catch (PDOException $e) {
    $config = [];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuration SMTP - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    
    <nav class="bg-gradient-to-r from-purple-600 to-blue-600 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <a href="/admin-dashboard.php" class="text-white hover:text-purple-200">← Dashboard</a>
                    <h1 class="text-2xl font-bold text-white">📧 Configuration SMTP</h1>
                </div>
                <button onclick="logout()" class="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg">
                    🚪 Déconnexion
                </button>
            </div>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto px-4 py-8">
        
        <!-- Status Card -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <div id="smtp-status-icon" class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                        <span class="text-3xl">📧</span>
                    </div>
                    <div>
                        <h2 class="text-xl font-bold text-gray-800">Statut SMTP</h2>
                        <p id="smtp-status-text" class="text-gray-600">Configuration non testée</p>
                    </div>
                </div>
                <button onclick="testSMTP()" class="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                    🧪 Tester la connexion
                </button>
            </div>
        </div>

        <!-- Tabs -->
        <div class="bg-white rounded-xl shadow-lg mb-6">
            <div class="flex border-b">
                <button onclick="showTab('config')" id="tab-config" class="flex-1 px-6 py-4 font-semibold border-b-2 border-purple-600 text-purple-600">
                    ⚙️ Configuration
                </button>
                <button onclick="showTab('auth')" id="tab-auth" class="flex-1 px-6 py-4 font-semibold text-gray-500 hover:text-gray-700">
                    🔐 Authentification
                </button>
                <button onclick="showTab('templates')" id="tab-templates" class="flex-1 px-6 py-4 font-semibold text-gray-500 hover:text-gray-700">
                    📝 Templates Email
                </button>
            </div>
        </div>

        <!-- Tab: Configuration SMTP -->
        <div id="content-config" class="tab-content bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold mb-6">Configuration du serveur SMTP</h3>
            
            <form id="smtp-form" onsubmit="saveSMTPConfig(event)" class="space-y-4">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Serveur SMTP *</label>
                        <input type="text" name="smtp_host" id="smtp_host" required
                               value="<?php echo htmlspecialchars($config['smtp_host'] ?? ''); ?>"
                               placeholder="smtp.gmail.com"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Port *</label>
                        <input type="number" name="smtp_port" id="smtp_port" required
                               value="<?php echo htmlspecialchars($config['smtp_port'] ?? '587'); ?>"
                               placeholder="587"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Nom d'utilisateur / Email *</label>
                    <input type="email" name="smtp_username" id="smtp_username" required
                           value="<?php echo htmlspecialchars($config['smtp_username'] ?? ''); ?>"
                           placeholder="votre-email@exemple.com"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                </div>

                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Mot de passe SMTP *</label>
                    <input type="password" name="smtp_password" id="smtp_password"
                           value="<?php echo htmlspecialchars($config['smtp_password'] ?? ''); ?>"
                           placeholder="••••••••"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                    <p class="text-xs text-gray-500 mt-1">Laissez vide pour conserver le mot de passe actuel</p>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Chiffrement</label>
                        <select name="smtp_encryption" id="smtp_encryption" 
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                            <option value="tls" <?php echo ($config['smtp_encryption'] ?? 'tls') === 'tls' ? 'selected' : ''; ?>>TLS (recommandé)</option>
                            <option value="ssl" <?php echo ($config['smtp_encryption'] ?? '') === 'ssl' ? 'selected' : ''; ?>>SSL</option>
                            <option value="" <?php echo empty($config['smtp_encryption']) ? 'selected' : ''; ?>>Aucun</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Email expéditeur</label>
                        <input type="email" name="from_email" id="from_email"
                               value="<?php echo htmlspecialchars($config['from_email'] ?? ''); ?>"
                               placeholder="noreply@exemple.com"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Nom de l'expéditeur</label>
                    <input type="text" name="from_name" id="from_name"
                           value="<?php echo htmlspecialchars($config['from_name'] ?? 'DigiServices'); ?>"
                           placeholder="DigiServices"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                </div>

                <!-- Guides rapides -->
                <div class="bg-blue-50 border-l-4 border-blue-500 p-4 rounded mt-6">
                    <h4 class="font-bold text-blue-900 mb-2">📖 Guides de configuration</h4>
                    <div class="space-y-2 text-sm text-blue-900">
                        <details class="cursor-pointer">
                            <summary class="font-semibold">Gmail</summary>
                            <div class="mt-2 ml-4 space-y-1">
                                <p>• Serveur: smtp.gmail.com</p>
                                <p>• Port: 587</p>
                                <p>• Chiffrement: TLS</p>
                                <p>• <a href="https://support.google.com/mail/answer/185833" target="_blank" class="underline">Créer un mot de passe d'application</a></p>
                            </div>
                        </details>
                        <details class="cursor-pointer">
                            <summary class="font-semibold">Outlook / Office 365</summary>
                            <div class="mt-2 ml-4 space-y-1">
                                <p>• Serveur: smtp.office365.com</p>
                                <p>• Port: 587</p>
                                <p>• Chiffrement: TLS</p>
                            </div>
                        </details>
                        <details class="cursor-pointer">
                            <summary class="font-semibold">SendGrid</summary>
                            <div class="mt-2 ml-4 space-y-1">
                                <p>• Serveur: smtp.sendgrid.net</p>
                                <p>• Port: 587</p>
                                <p>• Username: apikey</p>
                                <p>• Password: [Votre clé API]</p>
                            </div>
                        </details>
                    </div>
                </div>

                <button type="submit" class="w-full bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors">
                    💾 Enregistrer la configuration
                </button>
            </form>
        </div>

        <!-- Tab: Authentification -->
        <div id="content-auth" class="tab-content hidden bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold mb-6">Paramètres d'authentification par email</h3>
            
            <form id="auth-form" onsubmit="saveAuthSettings(event)" class="space-y-6">
                <div class="bg-purple-50 border-2 border-purple-200 rounded-lg p-4">
                    <label class="flex items-start gap-3 cursor-pointer">
                        <input type="checkbox" name="email_verification_enabled" id="email_verification_enabled"
                               <?php echo ($config['email_verification_enabled'] ?? 0) ? 'checked' : ''; ?>
                               class="w-5 h-5 text-purple-600 mt-1">
                        <div>
                            <span class="font-semibold text-purple-900">✅ Activer la vérification par email</span>
                            <p class="text-sm text-purple-700 mt-1">
                                Les nouveaux utilisateurs devront confirmer leur email avant de pouvoir se connecter
                            </p>
                        </div>
                    </label>
                </div>

                <div class="bg-blue-50 border-2 border-blue-200 rounded-lg p-4">
                    <label class="flex items-start gap-3 cursor-pointer">
                        <input type="checkbox" name="send_welcome_email" id="send_welcome_email"
                               <?php echo ($config['send_welcome_email'] ?? 1) ? 'checked' : ''; ?>
                               class="w-5 h-5 text-blue-600 mt-1">
                        <div>
                            <span class="font-semibold text-blue-900">📧 Email de bienvenue</span>
                            <p class="text-sm text-blue-700 mt-1">
                                Envoyer automatiquement un email de bienvenue aux nouveaux inscrits
                            </p>
                        </div>
                    </label>
                </div>

                <div class="bg-green-50 border-2 border-green-200 rounded-lg p-4">
                    <label class="flex items-start gap-3 cursor-pointer">
                        <input type="checkbox" name="notify_project_updates" id="notify_project_updates"
                               <?php echo ($config['notify_project_updates'] ?? 1) ? 'checked' : ''; ?>
                               class="w-5 h-5 text-green-600 mt-1">
                        <div>
                            <span class="font-semibold text-green-900">📦 Notifications projets</span>
                            <p class="text-sm text-green-700 mt-1">
                                Notifier les clients par email des mises à jour de leurs projets
                            </p>
                        </div>
                    </label>
                </div>

                <div class="bg-yellow-50 border-2 border-yellow-200 rounded-lg p-4">
                    <label class="flex items-start gap-3 cursor-pointer">
                        <input type="checkbox" name="notify_wallet_transactions" id="notify_wallet_transactions"
                               <?php echo ($config['notify_wallet_transactions'] ?? 1) ? 'checked' : ''; ?>
                               class="w-5 h-5 text-yellow-600 mt-1">
                        <div>
                            <span class="font-semibold text-yellow-900">💰 Notifications wallet</span>
                            <p class="text-sm text-yellow-700 mt-1">
                                Notifier les utilisateurs des transactions sur leur wallet
                            </p>
                        </div>
                    </label>
                </div>

                <button type="submit" class="w-full bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors">
                    💾 Enregistrer les paramètres
                </button>
            </form>
        </div>

        <!-- Tab: Templates -->
        <div id="content-templates" class="tab-content hidden bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-xl font-bold mb-6">Templates d'emails</h3>
            
            <div class="space-y-4">
                <div class="border-2 border-gray-200 rounded-lg p-4">
                    <div class="flex justify-between items-start mb-2">
                        <div>
                            <h4 class="font-bold text-gray-800">Email de vérification</h4>
                            <p class="text-sm text-gray-600">Envoyé lors de l'inscription</p>
                        </div>
                        <button onclick="editTemplate('verification')" class="bg-purple-100 text-purple-700 px-4 py-2 rounded-lg hover:bg-purple-200">
                            ✏️ Éditer
                        </button>
                    </div>
                </div>

                <div class="border-2 border-gray-200 rounded-lg p-4">
                    <div class="flex justify-between items-start mb-2">
                        <div>
                            <h4 class="font-bold text-gray-800">Email de bienvenue</h4>
                            <p class="text-sm text-gray-600">Après vérification du compte</p>
                        </div>
                        <button onclick="editTemplate('welcome')" class="bg-purple-100 text-purple-700 px-4 py-2 rounded-lg hover:bg-purple-200">
                            ✏️ Éditer
                        </button>
                    </div>
                </div>

                <div class="border-2 border-gray-200 rounded-lg p-4">
                    <div class="flex justify-between items-start mb-2">
                        <div>
                            <h4 class="font-bold text-gray-800">Notification projet</h4>
                            <p class="text-sm text-gray-600">Mise à jour ou fichiers disponibles</p>
                        </div>
                        <button onclick="editTemplate('project')" class="bg-purple-100 text-purple-700 px-4 py-2 rounded-lg hover:bg-purple-200">
                            ✏️ Éditer
                        </button>
                    </div>
                </div>

                <div class="border-2 border-gray-200 rounded-lg p-4">
                    <div class="flex justify-between items-start mb-2">
                        <div>
                            <h4 class="font-bold text-gray-800">Notification wallet</h4>
                            <p class="text-sm text-gray-600">Transaction effectuée</p>
                        </div>
                        <button onclick="editTemplate('wallet')" class="bg-purple-100 text-purple-700 px-4 py-2 rounded-lg hover:bg-purple-200">
                            ✏️ Éditer
                        </button>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Notification -->
    <div id="notification" class="hidden fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50"></div>

    <script>
        // Sauvegarder la configuration SMTP
        async function saveSMTPConfig(e) {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            formData.append('action', 'save_smtp_config');
            
            try {
                const response = await fetch('/api/smtp.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showNotification('✅ Configuration SMTP enregistrée !', 'success');
                } else {
                    showNotification('❌ ' + result.error, 'error');
                }
            } catch (error) {
                showNotification('❌ Erreur lors de l\'enregistrement', 'error');
            }
        }

        // Sauvegarder les paramètres d'authentification
        async function saveAuthSettings(e) {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            formData.append('action', 'save_auth_settings');
            
            try {
                const response = await fetch('/api/smtp.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showNotification('✅ Paramètres enregistrés !', 'success');
                } else {
                    showNotification('❌ ' + result.error, 'error');
                }
            } catch (error) {
                showNotification('❌ Erreur lors de l\'enregistrement', 'error');
            }
        }

        // Tester la connexion SMTP
        async function testSMTP() {
            showNotification('⏳ Test SMTP en cours...', 'info');
            
            const formData = new FormData();
            formData.append('action', 'test_smtp');
            
            try {
                const response = await fetch('/api/smtp.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                const statusIcon = document.getElementById('smtp-status-icon');
                const statusText = document.getElementById('smtp-status-text');
                
                if (result.success) {
                    statusIcon.innerHTML = '<span class="text-3xl">✅</span>';
                    statusIcon.className = 'w-16 h-16 bg-green-100 rounded-full flex items-center justify-center';
                    statusText.textContent = 'SMTP configuré et fonctionnel';
                    showNotification('✅ Test SMTP réussi ! Email envoyé.', 'success');
                } else {
                    statusIcon.innerHTML = '<span class="text-3xl">❌</span>';
                    statusIcon.className = 'w-16 h-16 bg-red-100 rounded-full flex items-center justify-center';
                    statusText.textContent = 'Échec de la connexion SMTP';
                    showNotification('❌ ' + result.error, 'error');
                }
            } catch (error) {
                showNotification('❌ Erreur lors du test', 'error');
            }
        }

        // Éditer un template
        function editTemplate(type) {
            window.location.href = `/admin-email-template.php?type=${type}`;
        }

        // Tabs
        function showTab(tab) {
            document.querySelectorAll('.tab-content').forEach(c => c.classList.add('hidden'));
            document.querySelectorAll('[id^="tab-"]').forEach(b => {
                b.classList.remove('border-purple-600', 'text-purple-600');
                b.classList.add('text-gray-500');
            });
            
            document.getElementById(`content-${tab}`).classList.remove('hidden');
            const activeBtn = document.getElementById(`tab-${tab}`);
            activeBtn.classList.add('border-purple-600', 'text-purple-600');
            activeBtn.classList.remove('text-gray-500');
        }

        // Déconnexion
        async function logout() {
            const formData = new FormData();
            formData.append('action', 'logout');
            await fetch('/api/auth.php', { method: 'POST', body: formData });
            window.location.href = '/login.html';
        }

        // Notification
        function showNotification(message, type) {
            const notification = document.getElementById('notification');
            const colors = {
                success: 'border-green-500 bg-green-50',
                error: 'border-red-500 bg-red-50',
                info: 'border-blue-500 bg-blue-50'
            };
            
            notification.className = `fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50 ${colors[type]}`;
            notification.textContent = message;
            notification.classList.remove('hidden');
            
            setTimeout(() => notification.classList.add('hidden'), 5000);
        }
    </script>
</body>
</html>
