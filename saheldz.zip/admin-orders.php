<?php
require_once 'config/auth-check.php';
if (!isAdmin()) { header('Location: /index.php'); exit; }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion Commandes - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <nav class="bg-gradient-to-r from-purple-600 to-blue-600 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <a href="/admin-dashboard.php" class="text-white hover:text-purple-200">← Dashboard</a>
            <h1 class="text-2xl font-bold text-white">📦 Gestion Commandes</h1>
            <button onclick="logout()" class="bg-white/10 text-white px-4 py-2 rounded-lg">Déconnexion</button>
        </div>
    </nav>
    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="bg-white rounded-xl shadow-lg p-8 text-center">
            <div class="text-6xl mb-4">🚧</div>
            <h2 class="text-2xl font-bold mb-2">En développement</h2>
            <p class="text-gray-600 mb-6">Cette fonctionnalité sera bientôt disponible</p>
            <a href="/admin-dashboard.php" class="bg-purple-600 text-white px-6 py-3 rounded-lg inline-block hover:bg-purple-700">← Retour au Dashboard</a>
        </div>
    </div>
    <script>
        async function logout() {
            const formData = new FormData();
            formData.append('action', 'logout');
            await fetch('/api/auth.php', { method: 'POST', body: formData });
            window.location.href = '/login.html';
        }
    </script>
</body>
</html>
