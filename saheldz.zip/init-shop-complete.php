<?php
// Script complet d'initialisation de la boutique
require_once 'config/database.php';

echo "=== INITIALISATION COMPLÈTE DE LA BOUTIQUE ===\n\n";

try {
    // 1. Vérifier les tables
    echo "1. Vérification des tables...\n";
    $tables = ['shop_categories', 'shop_items', 'product_stock', 'orders'];
    foreach ($tables as $table) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            echo "  ✅ Table $table existe\n";
        } else {
            echo "  ❌ Table $table MANQUANTE\n";
        }
    }
    
    // 2. Vérifier les produits existants
    echo "\n2. Vérification des produits existants...\n";
    $stmt = $pdo->query("SELECT COUNT(*) FROM shop_items");
    $count = $stmt->fetchColumn();
    echo "  Nombre de produits: $count\n";
    
    if ($count == 0) {
        echo "\n3. Création des catégories...\n";
        
        // Catégories
        $categories = [
            ['Produits Digitaux', 'digital-products', 'Codes et licences digitales'],
            ['Services', 'services', 'Services professionnels']
        ];
        
        $categoryIds = [];
        foreach ($categories as $cat) {
            $stmt = $pdo->prepare("
                INSERT INTO shop_categories (name, slug, description)
                VALUES (?, ?, ?)
                ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)
            ");
            $stmt->execute($cat);
            $categoryIds[$cat[1]] = $pdo->lastInsertId();
            echo "  ✅ Catégorie: {$cat[0]}\n";
        }
        
        echo "\n4. Création des produits...\n";
        
        // Produits
        $products = [
            [
                'name' => 'Branding PRO',
                'description' => 'Package complet de branding professionnel',
                'price' => 50,
                'type' => 'product',
                'category_id' => $categoryIds['digital-products']
            ],
            [
                'name' => 'Design Logo',
                'description' => 'Création de logo personnalisé',
                'price' => 30,
                'type' => 'product',
                'category_id' => $categoryIds['digital-products']
            ],
            [
                'name' => 'Site Web Basic',
                'description' => 'Site web vitrine professionnel',
                'price' => 100,
                'type' => 'product',
                'category_id' => $categoryIds['digital-products']
            ],
            [
                'name' => 'Consultation Marketing',
                'description' => 'Séance de consultation marketing (1h)',
                'price' => 40,
                'type' => 'service',
                'category_id' => $categoryIds['services']
            ]
        ];
        
        $productIds = [];
        foreach ($products as $product) {
            $stmt = $pdo->prepare("
                INSERT INTO shop_items (name, description, price, type, category_id, status)
                VALUES (?, ?, ?, ?, ?, 'available')
            ");
            $stmt->execute([
                $product['name'],
                $product['description'],
                $product['price'],
                $product['type'],
                $product['category_id']
            ]);
            $productId = $pdo->lastInsertId();
            $productIds[] = ['id' => $productId, 'name' => $product['name'], 'type' => $product['type']];
            echo "  ✅ Produit: {$product['name']} (ID: $productId)\n";
        }
        
        echo "\n5. Ajout de stock pour les produits digitaux...\n";
        
        foreach ($productIds as $product) {
            if ($product['type'] === 'product') {
                echo "\n  Produit: {$product['name']}\n";
                for ($i = 1; $i <= 50; $i++) {
                    $code = 'CODE-' . strtoupper(bin2hex(random_bytes(8)));
                    $key = "🎁 CODE DIGITAL - {$product['name']}\n\n";
                    $key .= "📋 Instructions d'utilisation:\n";
                    $key .= "1. Conservez ce code en lieu sûr\n";
                    $key .= "2. Contactez le support pour activer: support@example.com\n";
                    $key .= "3. Validité: 12 mois\n\n";
                    $key .= "🔒 Ce code est unique et ne peut être utilisé qu'une seule fois.";
                    
                    $stmt = $pdo->prepare("
                        INSERT INTO product_stock (item_id, product_code, product_key, status)
                        VALUES (?, ?, ?, 'available')
                    ");
                    $stmt->execute([$product['id'], $code, $key]);
                }
                echo "    ✅ 50 codes ajoutés\n";
            }
        }
    } else {
        echo "\n3. Les produits existent déjà. Ajout de stock supplémentaire...\n";
        
        $stmt = $pdo->query("SELECT id, name, type FROM shop_items WHERE type = 'product' AND status = 'available'");
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($products as $product) {
            // Vérifier stock actuel
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM product_stock WHERE item_id = ? AND status = 'available'");
            $stmt->execute([$product['id']]);
            $currentStock = $stmt->fetchColumn();
            
            echo "\n  {$product['name']} - Stock actuel: $currentStock\n";
            
            if ($currentStock < 10) {
                $toAdd = 50 - $currentStock;
                echo "    Ajout de $toAdd codes...\n";
                
                for ($i = 1; $i <= $toAdd; $i++) {
                    $code = 'CODE-' . strtoupper(bin2hex(random_bytes(8)));
                    $key = "🎁 CODE DIGITAL - {$product['name']}\n\n📋 Instructions d'utilisation:\n1. Conservez ce code\n2. Contact: support@example.com\n3. Validité: 12 mois";
                    
                    $stmt = $pdo->prepare("
                        INSERT INTO product_stock (item_id, product_code, product_key, status)
                        VALUES (?, ?, ?, 'available')
                    ");
                    $stmt->execute([$product['id'], $code, $key]);
                }
                echo "    ✅ $toAdd codes ajoutés\n";
            } else {
                echo "    ✅ Stock suffisant\n";
            }
        }
    }
    
    // 6. Résumé final
    echo "\n6. RÉSUMÉ FINAL\n";
    echo "================\n";
    
    $stmt = $pdo->query("
        SELECT 
            si.id,
            si.name,
            si.type,
            si.price,
            COUNT(ps.id) as total_stock,
            SUM(CASE WHEN ps.status = 'available' THEN 1 ELSE 0 END) as available_stock
        FROM shop_items si
        LEFT JOIN product_stock ps ON si.id = ps.item_id
        WHERE si.status = 'available'
        GROUP BY si.id
    ");
    $summary = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($summary as $item) {
        echo "\n📦 {$item['name']} ({$item['type']}) - {$item['price']}€\n";
        if ($item['type'] === 'product') {
            echo "   Stock: {$item['available_stock']} disponibles / {$item['total_stock']} total\n";
        } else {
            echo "   Service (pas de stock)\n";
        }
    }
    
    echo "\n✅ BOUTIQUE INITIALISÉE AVEC SUCCÈS !\n";
    echo "\nVous pouvez maintenant tester les achats sur: https://saheldz.mpsdash.com\n";
    
} catch (Exception $e) {
    echo "\n❌ ERREUR: " . $e->getMessage() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}
?>
