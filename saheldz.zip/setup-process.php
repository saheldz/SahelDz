<?php
/**
 * Traitement de l'installation
 */

header('Content-Type: application/json');

// Récupérer les données JSON
$input = file_get_contents('php://input');
$data = json_decode($input, true);

$action = $data['action'] ?? '';

switch ($action) {
    case 'test_db':
        testDatabaseConnection($data);
        break;
    case 'install':
        installSystem($data);
        break;
    default:
        echo json_encode(['success' => false, 'error' => 'Action invalide']);
}

/**
 * Tester la connexion à la base de données
 */
function testDatabaseConnection($data) {
    try {
        $pdo = new PDO(
            "mysql:host=" . $data['host'],
            $data['user'],
            $data['pass']
        );
        
        // Essayer de créer la base si elle n'existe pas
        $pdo->exec("CREATE DATABASE IF NOT EXISTS " . $data['name'] . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        
        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * Installer le système complet
 */
function installSystem($data) {
    try {
        // Créer le fichier de configuration database.php
        $dbConfig = "<?php\n";
        $dbConfig .= "/**\n * Configuration de la base de données\n */\n\n";
        $dbConfig .= "define('DB_HOST', '" . $data['db']['host'] . "');\n";
        $dbConfig .= "define('DB_NAME', '" . $data['db']['name'] . "');\n";
        $dbConfig .= "define('DB_USER', '" . $data['db']['user'] . "');\n";
        $dbConfig .= "define('DB_PASS', '" . addslashes($data['db']['pass']) . "');\n\n";
        $dbConfig .= file_get_contents('config/database.php.template');
        
        if (!file_exists('config')) {
            mkdir('config', 0755, true);
        }
        
        file_put_contents('config/database.php', $dbConfig);
        
        // Connexion à la DB
        require_once 'config/database.php';
        $pdo = getDB();
        
        // Créer les tables principales
        createMainTables($pdo);
        
        // Créer les tables d'authentification
        createAuthTables($pdo);
        
        // Créer le compte admin
        $hashedPassword = password_hash($data['admin']['password'], PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("INSERT INTO users (email, password, full_name, role_id, status, email_verified) VALUES (?, ?, ?, 1, 'active', 1)");
        $stmt->execute([
            $data['admin']['email'],
            $hashedPassword,
            $data['admin']['full_name']
        ]);
        
        $adminId = $pdo->lastInsertId();
        
        // Créer wallet pour l'admin
        $stmt = $pdo->prepare("INSERT INTO wallets (user_id, balance, status) VALUES (?, 0.00, 'active')");
        $stmt->execute([$adminId]);
        
        // Créer le fichier .installed
        file_put_contents('config/.installed', date('Y-m-d H:i:s'));
        
        echo json_encode([
            'success' => true,
            'message' => 'Installation terminée avec succès!'
        ]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * Créer les tables principales
 */
function createMainTables($pdo) {
    // Table: clients
    $pdo->exec("CREATE TABLE IF NOT EXISTS clients (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255),
        phone VARCHAR(50),
        company VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    
    // Table: orders
    $pdo->exec("CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        client_id INT,
        type VARCHAR(50),
        status VARCHAR(50),
        total DECIMAL(10,2),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (client_id) REFERENCES clients(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    
    // Table: branding_projects
    $pdo->exec("CREATE TABLE IF NOT EXISTS branding_projects (
        id INT AUTO_INCREMENT PRIMARY KEY,
        client_id INT,
        project_name VARCHAR(255),
        status VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (client_id) REFERENCES clients(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    
    // Table: project_files
    $pdo->exec("CREATE TABLE IF NOT EXISTS project_files (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT,
        file_name VARCHAR(255),
        file_path VARCHAR(500),
        file_type VARCHAR(100),
        file_size BIGINT,
        file_category VARCHAR(50),
        thumbnail_path VARCHAR(500),
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (project_id) REFERENCES branding_projects(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    
    // Table: categories
    $pdo->exec("CREATE TABLE IF NOT EXISTS categories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        type VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

/**
 * Créer les tables d'authentification
 */
function createAuthTables($pdo) {
    // Table: roles
    $pdo->exec("CREATE TABLE IF NOT EXISTS roles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) UNIQUE NOT NULL,
        display_name VARCHAR(100) NOT NULL,
        description TEXT,
        permissions JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_name (name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    // Table: users
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        full_name VARCHAR(255) NOT NULL,
        phone VARCHAR(50),
        company VARCHAR(255),
        profile_picture VARCHAR(255),
        preferred_currency VARCHAR(3) DEFAULT 'EUR',
        language VARCHAR(5) DEFAULT 'fr',
        theme VARCHAR(20) DEFAULT 'light',
        role_id INT DEFAULT 3,
        status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
        email_verified BOOLEAN DEFAULT FALSE,
        last_login DATETIME,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (role_id) REFERENCES roles(id),
        INDEX idx_email (email),
        INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    // Table: wallets
    $pdo->exec("CREATE TABLE IF NOT EXISTS wallets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNIQUE NOT NULL,
        balance DECIMAL(10, 2) DEFAULT 0.00,
        currency VARCHAR(3) DEFAULT 'EUR',
        status ENUM('active', 'frozen', 'closed') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        INDEX idx_user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    // Table: transactions
    $pdo->exec("CREATE TABLE IF NOT EXISTS transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        wallet_id INT NOT NULL,
        type ENUM('credit', 'debit', 'refund', 'fee') NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        balance_before DECIMAL(10, 2) NOT NULL,
        balance_after DECIMAL(10, 2) NOT NULL,
        description TEXT,
        reference VARCHAR(100),
        order_id VARCHAR(100),
        status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'completed',
        created_by INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (wallet_id) REFERENCES wallets(id) ON DELETE CASCADE,
        INDEX idx_wallet_id (wallet_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    // Table: user_sessions
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_sessions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        session_token VARCHAR(255) UNIQUE NOT NULL,
        ip_address VARCHAR(45),
        user_agent TEXT,
        expires_at DATETIME NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        INDEX idx_session_token (session_token)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    // Insérer les rôles par défaut
    $pdo->exec("INSERT IGNORE INTO roles (id, name, display_name, description, permissions) VALUES
        (1, 'super_admin', 'Super Administrateur', 'Accès complet au système', '{\"all\": true}'),
        (2, 'admin', 'Administrateur', 'Gestion des utilisateurs et commandes', '{\"manage_users\": true, \"manage_orders\": true, \"view_reports\": true}'),
        (3, 'client', 'Client', 'Utilisateur standard avec wallet', '{\"create_orders\": true, \"view_wallet\": true}'),
        (4, 'employee', 'Employé', 'Gestion des commandes uniquement', '{\"manage_orders\": true, \"view_orders\": true}')
    ");
}
