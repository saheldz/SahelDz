<?php
/**
 * Fix Catégorie - Diagnostic et Réparation Automatique
 * Ouvrez ce fichier dans votre navigateur
 */

require_once 'config/database.php';

header('Content-Type: text/html; charset=UTF-8');

echo '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Fix Catégorie - Diagnostic</title>
    <style>
        body { font-family: Arial; max-width: 1200px; margin: 20px auto; padding: 20px; background: #f5f5f5; }
        .box { background: white; padding: 20px; margin: 10px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .success { color: #22c55e; font-weight: bold; }
        .error { color: #ef4444; font-weight: bold; }
        .warning { color: #f59e0b; font-weight: bold; }
        .info { color: #3b82f6; font-weight: bold; }
        pre { background: #f9fafb; padding: 10px; border-radius: 4px; overflow-x: auto; }
        button { background: #3b82f6; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background: #2563eb; }
        .step { border-left: 4px solid #3b82f6; padding-left: 15px; margin: 15px 0; }
    </style>
</head>
<body>';

echo '<h1>🔧 Diagnostic et Réparation - Système de Catégories</h1>';

try {
    $pdo = getDB();
    echo '<div class="box"><p class="success">✅ Connexion à la base de données: OK</p></div>';
    
    // ÉTAPE 1: Vérifier si la table existe
    echo '<div class="box step">';
    echo '<h2>📋 Étape 1: Vérification de la table shop_categories</h2>';
    
    $stmt = $pdo->query("SHOW TABLES LIKE 'shop_categories'");
    if ($stmt->rowCount() > 0) {
        echo '<p class="success">✅ Table shop_categories existe</p>';
        
        // Vérifier la structure
        echo '<h3>Structure actuelle:</h3>';
        $columns = $pdo->query("DESCRIBE shop_categories")->fetchAll(PDO::FETCH_ASSOC);
        echo '<pre>';
        foreach ($columns as $col) {
            echo $col['Field'] . ' - ' . $col['Type'] . ' - ' . $col['Null'] . ' - ' . $col['Key'] . "\n";
        }
        echo '</pre>';
        
        // Vérifier les colonnes requises
        $requiredColumns = ['id', 'name', 'slug', 'icon', 'type'];
        $existingColumns = array_column($columns, 'Field');
        $missingColumns = array_diff($requiredColumns, $existingColumns);
        
        if (empty($missingColumns)) {
            echo '<p class="success">✅ Toutes les colonnes requises sont présentes</p>';
        } else {
            echo '<p class="error">❌ Colonnes manquantes: ' . implode(', ', $missingColumns) . '</p>';
            echo '<p class="info">Ajout des colonnes manquantes...</p>';
            
            // Ajouter les colonnes manquantes
            foreach ($missingColumns as $col) {
                try {
                    switch($col) {
                        case 'slug':
                            $pdo->exec("ALTER TABLE shop_categories ADD COLUMN slug VARCHAR(255) NOT NULL UNIQUE AFTER name");
                            echo '<p class="success">✅ Colonne slug ajoutée</p>';
                            break;
                        case 'icon':
                            $pdo->exec("ALTER TABLE shop_categories ADD COLUMN icon VARCHAR(50) DEFAULT '📦'");
                            echo '<p class="success">✅ Colonne icon ajoutée</p>';
                            break;
                        case 'type':
                            $pdo->exec("ALTER TABLE shop_categories ADD COLUMN type ENUM('service', 'product') DEFAULT 'product'");
                            echo '<p class="success">✅ Colonne type ajoutée</p>';
                            break;
                    }
                } catch (Exception $e) {
                    echo '<p class="error">❌ Erreur ajout ' . $col . ': ' . $e->getMessage() . '</p>';
                }
            }
        }
        
    } else {
        echo '<p class="error">❌ Table shop_categories n\'existe pas</p>';
        echo '<p class="info">Création de la table...</p>';
        
        $pdo->exec("
            CREATE TABLE shop_categories (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                slug VARCHAR(255) NOT NULL UNIQUE,
                type ENUM('service', 'product') DEFAULT 'product',
                icon VARCHAR(50) DEFAULT '📦',
                description TEXT,
                parent_id INT DEFAULT NULL,
                is_active TINYINT(1) DEFAULT 1,
                sort_order INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_type (type),
                INDEX idx_parent (parent_id),
                INDEX idx_active (is_active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        echo '<p class="success">✅ Table créée avec succès</p>';
    }
    echo '</div>';
    
    // ÉTAPE 2: Vérifier les autres tables
    echo '<div class="box step">';
    echo '<h2>📦 Étape 2: Vérification des tables liées</h2>';
    
    $tables = ['shop_items', 'product_stock'];
    foreach ($tables as $table) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            echo '<p class="success">✅ Table ' . $table . ' existe</p>';
        } else {
            echo '<p class="warning">⚠️ Table ' . $table . ' manquante (optionnelle pour les catégories)</p>';
        }
    }
    echo '</div>';
    
    // ÉTAPE 3: Tester l'API
    echo '<div class="box step">';
    echo '<h2>🧪 Étape 3: Test de l\'API shop-dynamic.php</h2>';
    
    // Simuler une requête à l'API
    $_GET['action'] = 'getCategories';
    ob_start();
    include 'api/shop-dynamic.php';
    $apiResponse = ob_get_clean();
    
    $data = json_decode($apiResponse, true);
    if ($data && isset($data['success']) && $data['success']) {
        echo '<p class="success">✅ API fonctionne correctement</p>';
        echo '<p>Nombre de catégories: <strong>' . count($data['categories']) . '</strong></p>';
        
        if (!empty($data['categories'])) {
            echo '<h3>Catégories existantes:</h3>';
            echo '<pre>';
            foreach ($data['categories'] as $cat) {
                echo $cat['icon'] . ' ' . $cat['name'] . ' (ID: ' . $cat['id'] . ")\n";
            }
            echo '</pre>';
        }
    } else {
        echo '<p class="error">❌ Erreur API: ' . ($data['error'] ?? 'Inconnue') . '</p>';
    }
    echo '</div>';
    
    // ÉTAPE 4: Test de création
    echo '<div class="box step">';
    echo '<h2>🚀 Étape 4: Test de création de catégorie</h2>';
    
    // Tester la création
    $testName = 'Test Auto ' . time();
    $testSlug = 'test-auto-' . time();
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO shop_categories (name, slug, type, icon)
            VALUES (?, ?, 'product', '🧪')
        ");
        $stmt->execute([$testName, $testSlug]);
        $newId = $pdo->lastInsertId();
        
        echo '<p class="success">✅ Test de création réussi!</p>';
        echo '<p>Catégorie créée: <strong>' . $testName . '</strong> (ID: ' . $newId . ')</p>';
        
        // Nettoyer le test
        $pdo->exec("DELETE FROM shop_categories WHERE id = $newId");
        echo '<p class="info">ℹ️ Catégorie de test supprimée automatiquement</p>';
        
    } catch (Exception $e) {
        echo '<p class="error">❌ Erreur lors du test: ' . $e->getMessage() . '</p>';
    }
    echo '</div>';
    
    // RÉSULTAT FINAL
    echo '<div class="box" style="background: #22c55e; color: white;">';
    echo '<h2>🎉 Diagnostic Terminé</h2>';
    echo '<p><strong>Résultat:</strong> Le système de catégories devrait maintenant fonctionner correctement!</p>';
    echo '<p>Vous pouvez maintenant:</p>';
    echo '<ul>';
    echo '<li>✅ Ouvrir html/1a.php dans votre navigateur</li>';
    echo '<li>✅ Aller dans "Produits Digitaux"</li>';
    echo '<li>✅ Cliquer sur "+ Nouvelle" pour créer une catégorie</li>';
    echo '<li>✅ L\'erreur devrait être résolue</li>';
    echo '</ul>';
    echo '</div>';
    
} catch (Exception $e) {
    echo '<div class="box" style="background: #ef4444; color: white;">';
    echo '<h2>❌ Erreur Critique</h2>';
    echo '<p>' . $e->getMessage() . '</p>';
    echo '<pre>' . $e->getTraceAsString() . '</pre>';
    echo '</div>';
}

echo '<div class="box">';
echo '<h2>📝 Prochaines Étapes</h2>';
echo '<ol>';
echo '<li>Fermez cette page</li>';
echo '<li>Ouvrez votre site: <code>html/1a.php</code></li>';
echo '<li>Testez la création de catégorie dans "Produits Digitaux"</li>';
echo '<li>Si l\'erreur persiste, copiez le message d\'erreur exact</li>';
echo '</ol>';
echo '</div>';

echo '</body></html>';
?>
