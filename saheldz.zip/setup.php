<?php
/**
 * Page d'installation initiale
 * Configure la DB et crée le premier admin
 */

// Vérifier si déjà installé
if (file_exists('config/.installed')) {
    header('Location: /index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Installation - DigiServices</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-purple-600 to-blue-500 min-h-screen flex items-center justify-center p-4">
    
    <div class="max-w-2xl w-full">
        <!-- Progress -->
        <div id="progress" class="mb-8 hidden">
            <div class="bg-white rounded-lg p-4 shadow-lg">
                <div class="flex items-center gap-3 mb-2">
                    <div class="animate-spin rounded-full h-6 w-6 border-4 border-purple-600 border-t-transparent"></div>
                    <span class="font-semibold text-gray-800" id="progress-text">Installation en cours...</span>
                </div>
                <div class="w-full bg-gray-200 rounded-full h-2">
                    <div id="progress-bar" class="bg-purple-600 h-2 rounded-full transition-all duration-500" style="width: 0%"></div>
                </div>
            </div>
        </div>

        <!-- Card principale -->
        <div id="setup-card" class="bg-white rounded-2xl shadow-2xl overflow-hidden">
            <!-- Header -->
            <div class="bg-gradient-to-r from-purple-600 to-blue-500 p-8 text-white">
                <h1 class="text-4xl font-bold mb-2">🚀 DigiServices</h1>
                <p class="text-purple-100">Bienvenue ! Configurons votre système</p>
            </div>

            <!-- Contenu -->
            <div class="p-8">
                <div id="step-1">
                    <h2 class="text-2xl font-bold text-gray-800 mb-4">Étape 1 : Configuration Base de Données</h2>
                    <p class="text-gray-600 mb-6">Entrez les informations de connexion à votre base de données MySQL</p>
                    
                    <form id="db-form" class="space-y-4">
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Hôte de la base de données</label>
                            <input type="text" name="db_host" value="127.0.0.1" required
                                   class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none">
                            <p class="text-xs text-gray-500 mt-1">Généralement: 127.0.0.1 ou localhost</p>
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Nom de la base de données</label>
                            <input type="text" name="db_name" value="digiservices_db" required
                                   class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none">
                        </div>

                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Utilisateur</label>
                                <input type="text" name="db_user" value="root" required
                                       class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none">
                            </div>

                            <div>
                                <label class="block text-sm font-semibold text-gray-700 mb-2">Mot de passe</label>
                                <input type="password" name="db_pass"
                                       class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none">
                                <p class="text-xs text-gray-500 mt-1">Laisser vide si aucun</p>
                            </div>
                        </div>

                        <button type="submit" class="w-full bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors shadow-lg mt-6">
                            Tester la connexion et continuer →
                        </button>
                    </form>
                </div>

                <div id="step-2" class="hidden">
                    <h2 class="text-2xl font-bold text-gray-800 mb-4">Étape 2 : Compte Administrateur</h2>
                    <p class="text-gray-600 mb-6">Créez votre compte administrateur principal</p>
                    
                    <form id="admin-form" class="space-y-4">
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Nom complet</label>
                            <input type="text" name="full_name" required
                                   class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none">
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Email</label>
                            <input type="email" name="email" required
                                   class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none">
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Mot de passe</label>
                            <input type="password" name="password" required minlength="6"
                                   class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none">
                            <p class="text-xs text-gray-500 mt-1">Minimum 6 caractères</p>
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Confirmer le mot de passe</label>
                            <input type="password" name="password_confirm" required minlength="6"
                                   class="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none">
                        </div>

                        <button type="submit" class="w-full bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors shadow-lg mt-6">
                            Installer le système →
                        </button>
                    </form>
                </div>

                <div id="step-3" class="hidden text-center">
                    <div class="mb-6">
                        <div class="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <span class="text-4xl">✅</span>
                        </div>
                        <h2 class="text-2xl font-bold text-gray-800 mb-2">Installation réussie !</h2>
                        <p class="text-gray-600">Votre système DigiServices est prêt à l'emploi</p>
                    </div>

                    <div class="bg-blue-50 border-2 border-blue-200 rounded-lg p-4 mb-6">
                        <p class="text-sm font-semibold text-blue-800 mb-2">📋 Récapitulatif</p>
                        <ul class="text-sm text-blue-700 space-y-1">
                            <li>✅ Base de données configurée</li>
                            <li>✅ 15 tables créées</li>
                            <li>✅ 4 rôles par défaut</li>
                            <li>✅ Compte administrateur créé</li>
                            <li>✅ Système sécurisé</li>
                        </ul>
                    </div>

                    <button onclick="window.location.href='/login.html'" class="w-full bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors shadow-lg">
                        Accéder à la connexion →
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        let dbConfig = {};

        // Étape 1: Tester la connexion DB
        document.getElementById('db-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            dbConfig = {
                host: formData.get('db_host'),
                name: formData.get('db_name'),
                user: formData.get('db_user'),
                pass: formData.get('db_pass')
            };

            showProgress('Test de connexion à la base de données...', 20);

            try {
                const response = await fetch('/setup-process.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({action: 'test_db', ...dbConfig})
                });

                const result = await response.json();

                if (result.success) {
                    updateProgress('Connexion réussie!', 40);
                    setTimeout(() => {
                        hideProgress();
                        document.getElementById('step-1').classList.add('hidden');
                        document.getElementById('step-2').classList.remove('hidden');
                    }, 500);
                } else {
                    hideProgress();
                    alert('❌ Erreur: ' + result.error);
                }
            } catch (error) {
                hideProgress();
                alert('❌ Erreur de connexion au serveur');
            }
        });

        // Étape 2: Créer admin et installer
        document.getElementById('admin-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            
            // Vérifier que les mots de passe correspondent
            if (formData.get('password') !== formData.get('password_confirm')) {
                alert('❌ Les mots de passe ne correspondent pas');
                return;
            }

            showProgress('Installation du système...', 50);

            try {
                const response = await fetch('/setup-process.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        action: 'install',
                        db: dbConfig,
                        admin: {
                            full_name: formData.get('full_name'),
                            email: formData.get('email'),
                            password: formData.get('password')
                        }
                    })
                });

                const result = await response.json();

                if (result.success) {
                    updateProgress('Installation terminée!', 100);
                    setTimeout(() => {
                        hideProgress();
                        document.getElementById('step-2').classList.add('hidden');
                        document.getElementById('step-3').classList.remove('hidden');
                    }, 500);
                } else {
                    hideProgress();
                    alert('❌ Erreur: ' + result.error);
                }
            } catch (error) {
                hideProgress();
                alert('❌ Erreur de connexion au serveur');
            }
        });

        // Fonctions d'aide
        function showProgress(text, percent) {
            document.getElementById('progress').classList.remove('hidden');
            document.getElementById('progress-text').textContent = text;
            document.getElementById('progress-bar').style.width = percent + '%';
        }

        function updateProgress(text, percent) {
            document.getElementById('progress-text').textContent = text;
            document.getElementById('progress-bar').style.width = percent + '%';
        }

        function hideProgress() {
            document.getElementById('progress').classList.add('hidden');
        }
    </script>
</body>
</html>
