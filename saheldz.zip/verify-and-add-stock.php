<?php
require_once 'config/database.php';

header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html>";
echo "<html><head><meta charset='UTF-8'><title>Vérification Stock</title>";
echo "<style>
body { font-family: Arial; padding: 20px; background: #f5f5f5; }
.box { background: white; padding: 20px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #4CAF50; }
.error { border-left-color: #f44336; }
.warning { border-left-color: #ff9800; }
h2 { color: #333; }
pre { background: #f5f5f5; padding: 10px; border-radius: 4px; overflow-x: auto; }
.success { color: #4CAF50; }
.fail { color: #f44336; }
table { width: 100%; border-collapse: collapse; margin: 10px 0; }
th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
th { background-color: #4CAF50; color: white; }
button { background: #4CAF50; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; margin: 5px; }
button:hover { background: #45a049; }
</style></head><body>";

echo "<h1>🔍 Vérification et Ajout de Stock</h1>";

try {
    // 1. Vérifier les produits
    echo "<div class='box'>";
    echo "<h2>1️⃣ Produits Disponibles</h2>";
    $stmt = $pdo->query("SELECT * FROM shop_items WHERE status = 'available'");
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($items) > 0) {
        echo "<table>";
        echo "<tr><th>ID</th><th>Nom</th><th>Type</th><th>Prix</th></tr>";
        foreach ($items as $item) {
            echo "<tr>";
            echo "<td>{$item['id']}</td>";
            echo "<td>{$item['name']}</td>";
            echo "<td>{$item['type']}</td>";
            echo "<td>{$item['price']}€</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p class='fail'>❌ Aucun produit disponible</p>";
    }
    echo "</div>";

    // 2. Vérifier le stock pour chaque produit
    echo "<div class='box'>";
    echo "<h2>2️⃣ État du Stock</h2>";
    
    foreach ($items as $item) {
        if ($item['type'] === 'product') {
            $stmt = $pdo->prepare("
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available,
                    SUM(CASE WHEN status = 'sold' THEN 1 ELSE 0 END) as sold
                FROM product_stock 
                WHERE item_id = ?
            ");
            $stmt->execute([$item['id']]);
            $stock = $stmt->fetch(PDO::FETCH_ASSOC);
            
            echo "<div style='margin: 10px 0; padding: 10px; background: #f9f9f9; border-radius: 4px;'>";
            echo "<strong>{$item['name']}</strong> (ID: {$item['id']})<br>";
            echo "Total codes: {$stock['total']} | ";
            echo "<span class='success'>Disponibles: {$stock['available']}</span> | ";
            echo "Vendus: {$stock['sold']}";
            
            if ($stock['available'] == 0) {
                echo "<br><span class='fail'>⚠️ RUPTURE DE STOCK</span>";
                echo "<br><button onclick='addStock({$item['id']}, \"{$item['name']}\")'>➕ Ajouter 10 codes</button>";
            }
            echo "</div>";
        }
    }
    echo "</div>";

    // 3. Action d'ajout de stock
    if (isset($_POST['add_stock'])) {
        $item_id = $_POST['item_id'];
        $quantity = $_POST['quantity'];
        
        echo "<div class='box'>";
        echo "<h2>➕ Ajout de Stock</h2>";
        
        $added = 0;
        for ($i = 1; $i <= $quantity; $i++) {
            $code = 'CODE-' . strtoupper(bin2hex(random_bytes(8)));
            $key = 'Instructions pour utiliser ce code...';
            
            $stmt = $pdo->prepare("
                INSERT INTO product_stock (item_id, product_code, product_key, status)
                VALUES (?, ?, ?, 'available')
            ");
            if ($stmt->execute([$item_id, $code, $key])) {
                $added++;
            }
        }
        
        echo "<p class='success'>✅ {$added} codes ajoutés avec succès !</p>";
        echo "<script>setTimeout(() => window.location.reload(), 2000);</script>";
        echo "</div>";
    }

    // 4. Dernières commandes
    echo "<div class='box'>";
    echo "<h2>3️⃣ Dernières Commandes</h2>";
    $stmt = $pdo->query("
        SELECT o.*, u.name as user_name, u.email
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.id
        ORDER BY o.created_at DESC
        LIMIT 10
    ");
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($orders) > 0) {
        echo "<table>";
        echo "<tr><th>N° Commande</th><th>Client</th><th>Produit</th><th>Prix</th><th>Statut</th><th>Date</th></tr>";
        foreach ($orders as $order) {
            echo "<tr>";
            echo "<td>{$order['order_number']}</td>";
            echo "<td>{$order['user_name']}<br><small>{$order['email']}</small></td>";
            echo "<td>{$order['item_name']}</td>";
            echo "<td>{$order['price']}€</td>";
            echo "<td>{$order['status']}</td>";
            echo "<td>" . date('d/m/Y H:i', strtotime($order['created_at'])) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>Aucune commande</p>";
    }
    echo "</div>";

} catch (Exception $e) {
    echo "<div class='box error'>";
    echo "<h2>❌ Erreur</h2>";
    echo "<p>" . $e->getMessage() . "</p>";
    echo "</div>";
}

echo "<script>
function addStock(itemId, itemName) {
    if (confirm('Ajouter 10 codes pour le produit: ' + itemName + ' ?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type='hidden' name='add_stock' value='1'>
            <input type='hidden' name='item_id' value='${itemId}'>
            <input type='hidden' name='quantity' value='10'>
        `;
        document.body.appendChild(form);
        form.submit();
    }
}
</script>";

echo "</body></html>";
?>
