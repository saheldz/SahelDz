<?php
/**
 * Test de création de commande
 */

require_once 'config/database.php';
require_once 'config/auth-check.php';

$pdo = getDB();

echo "=== TEST CREATION COMMANDE ===\n\n";

try {
    $user_id = $_SESSION['user_id'];
    echo "1. User ID: $user_id\n";
    
    // Vérifier le wallet
    $stmt = $pdo->prepare("SELECT * FROM wallets WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $wallet = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($wallet) {
        echo "2. Wallet trouvé: balance = {$wallet['balance']}€\n";
    } else {
        echo "2. ❌ ERREUR: Wallet non trouvé pour user_id $user_id\n";
        echo "   Solution: Créer un wallet pour cet utilisateur\n";
        
        // Créer le wallet
        $stmt = $pdo->prepare("INSERT INTO wallets (user_id, balance, currency, status) VALUES (?, 0, 'EUR', 'active')");
        $stmt->execute([$user_id]);
        echo "   ✅ Wallet créé avec succès\n";
    }
    
    // Vérifier un produit
    $stmt = $pdo->query("SELECT * FROM shop_items WHERE status = 'available' LIMIT 1");
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($item) {
        echo "3. Produit test trouvé: {$item['name']} - {$item['price']}€\n";
    } else {
        echo "3. ❌ ERREUR: Aucun produit disponible\n";
    }
    
    // Vérifier la table orders
    $stmt = $pdo->query("SHOW TABLES LIKE 'orders'");
    if ($stmt->rowCount() > 0) {
        echo "4. ✅ Table 'orders' existe\n";
    } else {
        echo "4. ❌ ERREUR: Table 'orders' n'existe pas\n";
    }
    
    // Vérifier la table wallet_transactions
    $stmt = $pdo->query("SHOW TABLES LIKE 'wallet_transactions'");
    if ($stmt->rowCount() > 0) {
        echo "5. ✅ Table 'wallet_transactions' existe\n";
    } else {
        echo "5. ❌ ERREUR: Table 'wallet_transactions' n'existe pas\n";
        echo "   Solution: Créer la table wallet_transactions\n";
        
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS wallet_transactions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                type ENUM('credit', 'debit') NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_user (user_id),
                INDEX idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        echo "   ✅ Table 'wallet_transactions' créée\n";
    }
    
    echo "\n=== DIAGNOSTIC TERMINE ===\n";
    echo "\nSi toutes les tables existent et le wallet est créé, essayez de créer une commande à nouveau.\n";
    
} catch (Exception $e) {
    echo "❌ ERREUR: " . $e->getMessage() . "\n";
}
