<?php
/**
 * Gestion des utilisateurs - Admin
 */
require_once 'config/auth-check.php';

if (!isAdmin()) {
    header('Location: /index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Utilisateurs - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    
    <nav class="bg-gradient-to-r from-purple-600 to-blue-600 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <a href="/admin-dashboard.php" class="text-white hover:text-purple-200">← Dashboard</a>
                    <h1 class="text-2xl font-bold text-white">👥 Gestion des Utilisateurs</h1>
                </div>
                <button onclick="logout()" class="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg">
                    🚪 Déconnexion
                </button>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="bg-white rounded-xl shadow-lg p-6">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-xl font-bold">Liste des utilisateurs</h2>
                <button onclick="addNewUser()" class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700">
                    ➕ Ajouter un utilisateur
                </button>
            </div>
            
            <div id="users-list" class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="border-b">
                            <th class="text-left p-3">Utilisateur</th>
                            <th class="text-left p-3">Email</th>
                            <th class="text-left p-3">Rôle</th>
                            <th class="text-left p-3">Wallet</th>
                            <th class="text-left p-3">Statut</th>
                            <th class="text-left p-3">Inscrit le</th>
                            <th class="text-right p-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="users-tbody">
                        <!-- Chargé via JS -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal Éditer/Ajouter Utilisateur -->
    <div id="edit-user-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto">
        <div class="bg-white rounded-xl shadow-2xl max-w-2xl w-full m-4 max-h-[90vh] overflow-y-auto">
            <div class="sticky top-0 bg-white border-b px-6 py-4 flex justify-between items-center">
                <h3 id="edit-modal-title" class="text-2xl font-bold">👤 Ajouter un utilisateur</h3>
                <button onclick="closeEditUserModal()" class="text-gray-400 hover:text-gray-600 text-2xl">×</button>
            </div>
            
            <form id="edit-user-form" onsubmit="saveUser(event)" class="p-6">
                <input type="hidden" id="edit-user-id" name="user_id">
                
                <div class="space-y-4">
                    <!-- Nom complet -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Nom complet *</label>
                        <input type="text" id="edit-full-name" name="full_name" required
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                    </div>

                    <!-- Email -->
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Email *</label>
                        <input type="email" id="edit-email" name="email" required
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                    </div>

                    <!-- Mot de passe (uniquement pour nouveau) -->
                    <div id="password-field">
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Mot de passe <span id="password-required">*</span></label>
                        <input type="password" id="edit-password" name="password" minlength="6"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                        <p class="text-xs text-gray-500 mt-1" id="password-hint">Minimum 6 caractères. Laissez vide pour conserver l'actuel.</p>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <!-- Téléphone -->
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Téléphone</label>
                            <input type="tel" id="edit-phone" name="phone"
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                        </div>

                        <!-- Entreprise -->
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Entreprise</label>
                            <input type="text" id="edit-company" name="company"
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <!-- Rôle -->
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Rôle *</label>
                            <select id="edit-role" name="role_id" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                                <!-- Chargé via JS -->
                            </select>
                        </div>

                        <!-- Statut -->
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">Statut *</label>
                            <select id="edit-status" name="status" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                                <option value="active">Actif</option>
                                <option value="inactive">Inactif</option>
                                <option value="suspended">Suspendu</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="flex gap-3 mt-6">
                    <button type="submit" class="flex-1 bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700">
                        💾 Enregistrer
                    </button>
                    <button type="button" onclick="closeEditUserModal()" class="px-6 py-3 border rounded-lg hover:bg-gray-50">
                        Annuler
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Voir Utilisateur -->
    <div id="view-user-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto">
        <div class="bg-white rounded-xl shadow-2xl max-w-4xl w-full m-4 max-h-[90vh] overflow-y-auto">
            <div class="sticky top-0 bg-white border-b px-6 py-4 flex justify-between items-center">
                <h3 class="text-2xl font-bold">👤 Détails de l'utilisateur</h3>
                <button onclick="closeViewUserModal()" class="text-gray-400 hover:text-gray-600 text-2xl">×</button>
            </div>
            
            <div id="user-details-content" class="p-6">
                <!-- Chargé dynamiquement -->
            </div>
        </div>
    </div>

    <!-- Notification -->
    <div id="notification" class="hidden fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50"></div>

    <script>
        window.addEventListener('load', async () => {
            await loadUsers();
            await loadRoles();
        });

        async function loadRoles() {
            const response = await fetch('/api/admin.php?action=get_all_roles');
            const result = await response.json();
            
            if (result.success) {
                const select = document.getElementById('edit-role');
                select.innerHTML = result.roles.map(role => 
                    `<option value="${role.id}">${role.display_name}</option>`
                ).join('');
            }
        }

        async function loadUsers() {
            const response = await fetch('/api/admin.php?action=get_all_users');
            const result = await response.json();
            
            const tbody = document.getElementById('users-tbody');
            if (result.success) {
                tbody.innerHTML = result.users.map(user => `
                    <tr class="border-b hover:bg-gray-50">
                        <td class="p-3">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                                    <span class="font-bold text-purple-600">${user.full_name.charAt(0)}</span>
                                </div>
                                <span class="font-semibold">${user.full_name}</span>
                            </div>
                        </td>
                        <td class="p-3 text-gray-600">${user.email}</td>
                        <td class="p-3">
                            <span class="bg-purple-100 text-purple-700 px-2 py-1 rounded text-sm">${user.role_display}</span>
                        </td>
                        <td class="p-3 font-semibold text-green-600">${user.balance} ${user.currency}</td>
                        <td class="p-3">
                            <span class="bg-${user.status === 'active' ? 'green' : 'red'}-100 text-${user.status === 'active' ? 'green' : 'red'}-700 px-2 py-1 rounded text-sm">
                                ${user.status}
                            </span>
                        </td>
                        <td class="p-3 text-gray-600 text-sm">${new Date(user.created_at).toLocaleDateString('fr-FR')}</td>
                        <td class="p-3 text-right">
                            <button onclick="viewUser(${user.id})" class="text-blue-600 hover:text-blue-800 mr-2" title="Voir détails">👁️</button>
                            <button onclick="connectAsUser(${user.id})" class="text-green-600 hover:text-green-800 mr-2" title="Se connecter en tant que">🔄</button>
                            <button onclick="editUser(${user.id})" class="text-purple-600 hover:text-purple-800 mr-2" title="Modifier">✏️</button>
                            <button onclick="deleteUser(${user.id})" class="text-red-600 hover:text-red-800" title="Supprimer">🗑️</button>
                        </td>
                    </tr>
                `).join('');
            }
        }

        async function viewUser(id) {
            // Charger les détails de l'utilisateur
            const response = await fetch(`/api/admin.php?action=get_user_details&user_id=${id}`);
            const result = await response.json();
            
            if (!result.success) {
                showNotification('❌ ' + result.error, 'error');
                return;
            }
            
            const user = result.user;
            const transactions = result.transactions || [];
            
            // Construire le contenu du modal
            const content = `
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Colonne 1: Photo et infos principales -->
                    <div class="col-span-1">
                        <div class="bg-gradient-to-br from-purple-50 to-blue-50 rounded-xl p-6 text-center">
                            <div class="w-32 h-32 mx-auto bg-purple-200 rounded-full flex items-center justify-center mb-4">
                                <span class="text-5xl font-bold text-purple-600">${user.full_name.charAt(0)}</span>
                            </div>
                            <h4 class="text-xl font-bold text-gray-800 mb-2">${user.full_name}</h4>
                            <p class="text-gray-600 mb-4">${user.email}</p>
                            <div class="flex justify-center gap-2 mb-4">
                                <span class="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-semibold">${user.role_display}</span>
                                <span class="bg-${user.status === 'active' ? 'green' : 'red'}-100 text-${user.status === 'active' ? 'green' : 'red'}-700 px-3 py-1 rounded-full text-sm font-semibold">${user.status}</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Colonne 2 & 3: Détails -->
                    <div class="col-span-2 space-y-6">
                        <!-- Informations personnelles -->
                        <div class="bg-white border-2 border-gray-200 rounded-xl p-6">
                            <h5 class="text-lg font-bold mb-4 flex items-center gap-2">
                                <span class="text-2xl">👤</span>
                                Informations personnelles
                            </h5>
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">ID</p>
                                    <p class="font-semibold">#${user.id}</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">Email</p>
                                    <p class="font-semibold">${user.email}</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">Téléphone</p>
                                    <p class="font-semibold">${user.phone || 'Non renseigné'}</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">Entreprise</p>
                                    <p class="font-semibold">${user.company || 'Non renseigné'}</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">Date d'inscription</p>
                                    <p class="font-semibold">${new Date(user.created_at).toLocaleDateString('fr-FR')}</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">Dernière connexion</p>
                                    <p class="font-semibold">${user.last_login ? new Date(user.last_login).toLocaleDateString('fr-FR') : 'Jamais'}</p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Wallet -->
                        <div class="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl p-6">
                            <h5 class="text-lg font-bold mb-4 flex items-center gap-2">
                                <span class="text-2xl">💰</span>
                                Wallet
                            </h5>
                            <div class="grid grid-cols-3 gap-4">
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">Solde actuel</p>
                                    <p class="text-2xl font-bold text-green-600">${parseFloat(user.balance || 0).toFixed(2)} ${user.currency}</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">Devise</p>
                                    <p class="text-lg font-semibold">${user.currency}</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600 mb-1">Statut wallet</p>
                                    <span class="bg-green-100 text-green-700 px-2 py-1 rounded text-sm font-semibold">${user.wallet_status}</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Transactions récentes -->
                        <div class="bg-white border-2 border-gray-200 rounded-xl p-6">
                            <h5 class="text-lg font-bold mb-4 flex items-center gap-2">
                                <span class="text-2xl">💳</span>
                                Transactions récentes (${transactions.length})
                            </h5>
                            ${transactions.length > 0 ? `
                                <div class="space-y-2 max-h-64 overflow-y-auto">
                                    ${transactions.slice(0, 10).map(t => `
                                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                            <div class="flex items-center gap-3">
                                                <div class="w-10 h-10 ${t.type === 'credit' ? 'bg-green-100' : 'bg-red-100'} rounded-full flex items-center justify-center">
                                                    <span class="text-lg">${t.type === 'credit' ? '↑' : '↓'}</span>
                                                </div>
                                                <div>
                                                    <p class="font-semibold text-sm">${t.description || t.type}</p>
                                                    <p class="text-xs text-gray-500">${new Date(t.created_at).toLocaleString('fr-FR')}</p>
                                                </div>
                                            </div>
                                            <p class="font-bold ${t.type === 'credit' ? 'text-green-600' : 'text-red-600'}">
                                                ${t.type === 'credit' ? '+' : '-'}${t.amount} ${user.currency}
                                            </p>
                                        </div>
                                    `).join('')}
                                </div>
                            ` : '<p class="text-gray-500 text-center py-4">Aucune transaction</p>'}
                        </div>
                        
                        <!-- Actions -->
                        <div class="flex gap-3">
                            <button onclick="window.location.href='/admin-wallets.php'" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700">
                                💰 Gérer le wallet
                            </button>
                            <button onclick="editUser(${user.id}); closeViewUserModal();" class="flex-1 bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700">
                                ✏️ Modifier
                            </button>
                            <button onclick="if(confirm('Supprimer cet utilisateur ?')) deleteUser(${user.id})" class="bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700">
                                🗑️
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            document.getElementById('user-details-content').innerHTML = content;
            document.getElementById('view-user-modal').classList.remove('hidden');
        }

        function closeViewUserModal() {
            document.getElementById('view-user-modal').classList.add('hidden');
        }

        function addNewUser() {
            document.getElementById('edit-modal-title').textContent = '➕ Ajouter un utilisateur';
            document.getElementById('edit-user-id').value = '';
            document.getElementById('edit-user-form').reset();
            document.getElementById('edit-password').required = true;
            document.getElementById('password-required').style.display = 'inline';
            document.getElementById('password-hint').textContent = 'Minimum 6 caractères';
            document.getElementById('edit-user-modal').classList.remove('hidden');
        }

        async function editUser(id) {
            const response = await fetch(`/api/admin.php?action=get_user_details&user_id=${id}`);
            const result = await response.json();
            
            if (!result.success) {
                showNotification('❌ ' + result.error, 'error');
                return;
            }
            
            const user = result.user;
            
            document.getElementById('edit-modal-title').textContent = '✏️ Modifier l\'utilisateur';
            document.getElementById('edit-user-id').value = user.id;
            document.getElementById('edit-full-name').value = user.full_name;
            document.getElementById('edit-email').value = user.email;
            document.getElementById('edit-phone').value = user.phone || '';
            document.getElementById('edit-company').value = user.company || '';
            document.getElementById('edit-role').value = user.role_id;
            document.getElementById('edit-status').value = user.status;
            document.getElementById('edit-password').value = '';
            document.getElementById('edit-password').required = false;
            document.getElementById('password-required').style.display = 'none';
            document.getElementById('password-hint').textContent = 'Laissez vide pour conserver l\'actuel';
            
            document.getElementById('edit-user-modal').classList.remove('hidden');
        }

        function closeEditUserModal() {
            document.getElementById('edit-user-modal').classList.add('hidden');
        }

        async function saveUser(e) {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            const userId = formData.get('user_id');
            
            formData.append('action', userId ? 'update_user' : 'create_user');
            
            const response = await fetch('/api/admin.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                showNotification('✅ ' + result.message, 'success');
                closeEditUserModal();
                await loadUsers();
            } else {
                showNotification('❌ ' + result.error, 'error');
            }
        }

        async function connectAsUser(id) {
            if (!confirm('Se connecter en tant que cet utilisateur ? Vous serez redirigé vers son interface.')) {
                return;
            }
            
            const formData = new FormData();
            formData.append('action', 'impersonate_user');
            formData.append('user_id', id);
            
            const response = await fetch('/api/admin.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                showNotification('✅ Connexion réussie ! Redirection...', 'success');
                setTimeout(() => {
                    window.location.href = '/index.php';
                }, 1000);
            } else {
                showNotification('❌ ' + result.error, 'error');
            }
        }

        async function deleteUser(id) {
            if (!confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')) {
                return;
            }
            
            const formData = new FormData();
            formData.append('action', 'delete_user');
            formData.append('user_id', id);
            
            const response = await fetch('/api/admin.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                showNotification('✅ ' + result.message, 'success');
                await loadUsers();
            } else {
                showNotification('❌ ' + result.error, 'error');
            }
        }

        function showNotification(message, type) {
            const notification = document.getElementById('notification');
            const colors = {
                success: 'border-green-500 bg-green-50',
                error: 'border-red-500 bg-red-50',
                info: 'border-blue-500 bg-blue-50'
            };
            
            notification.className = `fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50 ${colors[type]}`;
            notification.textContent = message;
            notification.classList.remove('hidden');
            
            setTimeout(() => notification.classList.add('hidden'), 5000);
        }

        async function logout() {
            const formData = new FormData();
            formData.append('action', 'logout');
            await fetch('/api/auth.php', { method: 'POST', body: formData });
            window.location.href = '/login.html';
        }
    </script>
</body>
</html>
