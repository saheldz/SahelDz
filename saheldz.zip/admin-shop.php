<?php
/**
 * Interface Admin - Gestion de la Boutique
 */
require_once 'config/database.php';
require_once 'config/auth-check.php';

// Check admin access
if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], ['admin', 'super_admin'])) {
    header('Location: /');
    exit;
}

$page_title = "Gestion Boutique";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .tab-active { @apply bg-blue-600 text-white; }
        .tab-inactive { @apply bg-gray-200 text-gray-700 hover:bg-gray-300; }
    </style>
</head>
<body class="bg-gray-100">
    
    <!-- Header -->
    <div class="bg-white shadow-md">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <h1 class="text-2xl font-bold text-gray-800">🛍️ Gestion Boutique</h1>
            <a href="/html/1a.php" class="text-blue-600 hover:text-blue-800">← Retour Dashboard</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto px-4 py-6">
        
        <!-- Tabs -->
        <div class="bg-white rounded-lg shadow-md mb-6">
            <div class="flex border-b">
                <button onclick="showTab('categories')" id="tab-categories" class="px-6 py-3 font-semibold transition-colors tab-active">
                    Catégories
                </button>
                <button onclick="showTab('items')" id="tab-items" class="px-6 py-3 font-semibold transition-colors tab-inactive">
                    Services & Produits
                </button>
                <button onclick="showTab('orders')" id="tab-orders" class="px-6 py-3 font-semibold transition-colors tab-inactive">
                    Commandes
                </button>
            </div>
        </div>

        <!-- Categories Tab -->
        <div id="content-categories" class="tab-content">
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-bold">Catégories</h2>
                    <button onclick="openCategoryModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                        + Nouvelle Catégorie
                    </button>
                </div>
                
                <div class="mb-4">
                    <label class="inline-flex items-center mr-4">
                        <input type="radio" name="cat-type-filter" value="all" checked onchange="loadCategories()" class="mr-2">
                        Toutes
                    </label>
                    <label class="inline-flex items-center mr-4">
                        <input type="radio" name="cat-type-filter" value="service" onchange="loadCategories()" class="mr-2">
                        Services
                    </label>
                    <label class="inline-flex items-center">
                        <input type="radio" name="cat-type-filter" value="product" onchange="loadCategories()" class="mr-2">
                        Produits
                    </label>
                </div>

                <div id="categories-list" class="space-y-2">
                    <p class="text-gray-500">Chargement...</p>
                </div>
            </div>
        </div>

        <!-- Items Tab -->
        <div id="content-items" class="tab-content hidden">
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-bold">Services & Produits</h2>
                    <button onclick="openItemModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                        + Nouvel Item
                    </button>
                </div>

                <div class="mb-4 flex gap-4">
                    <select id="item-type-filter" onchange="loadItems()" class="border rounded px-3 py-2">
                        <option value="all">Tous les types</option>
                        <option value="service">Services</option>
                        <option value="product">Produits</option>
                    </select>
                    <select id="item-category-filter" onchange="loadItems()" class="border rounded px-3 py-2">
                        <option value="0">Toutes catégories</option>
                    </select>
                </div>

                <div id="items-list" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <p class="text-gray-500">Chargement...</p>
                </div>
            </div>
        </div>

        <!-- Orders Tab -->
        <div id="content-orders" class="tab-content hidden">
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-bold mb-4">Commandes Récentes</h2>
                <div id="orders-list">
                    <p class="text-gray-500">Chargement...</p>
                </div>
            </div>
        </div>

    </div>

    <!-- Category Modal -->
    <div id="category-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
            <h3 id="category-modal-title" class="text-xl font-bold mb-4">Nouvelle Catégorie</h3>
            <form id="category-form" onsubmit="saveCategory(event)">
                <input type="hidden" id="category-id" value="">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Nom *</label>
                    <input type="text" id="category-name" required class="w-full border rounded px-3 py-2">
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Type *</label>
                    <select id="category-type" required class="w-full border rounded px-3 py-2">
                        <option value="service">Service</option>
                        <option value="product">Produit</option>
                    </select>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Icône (emoji)</label>
                    <input type="text" id="category-icon" placeholder="🎨" class="w-full border rounded px-3 py-2">
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Description</label>
                    <textarea id="category-description" rows="3" class="w-full border rounded px-3 py-2"></textarea>
                </div>

                <div class="flex justify-end gap-2">
                    <button type="button" onclick="closeCategoryModal()" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded">
                        Annuler
                    </button>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                        Enregistrer
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Item Modal -->
    <div id="item-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-2xl p-6 my-8">
            <h3 id="item-modal-title" class="text-xl font-bold mb-4">Nouvel Item</h3>
            <form id="item-form" onsubmit="saveItem(event)">
                <input type="hidden" id="item-id" value="">
                
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium mb-1">Type *</label>
                        <select id="item-type" required class="w-full border rounded px-3 py-2" onchange="filterCategoriesByType()">
                            <option value="service">Service</option>
                            <option value="product">Produit</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Catégorie *</label>
                        <div class="flex gap-2">
                            <select id="item-category" required class="flex-1 border rounded px-3 py-2">
                                <option value="">Sélectionner...</option>
                            </select>
                            <button type="button" onclick="openQuickCategoryModal()" class="bg-green-600 text-white px-3 py-2 rounded hover:bg-green-700 flex items-center gap-1 whitespace-nowrap">
                                <span>➕</span>
                                <span>Catégorie</span>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Nom *</label>
                    <input type="text" id="item-name" required class="w-full border rounded px-3 py-2">
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Description courte</label>
                    <input type="text" id="item-short-desc" maxlength="500" class="w-full border rounded px-3 py-2">
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Description complète</label>
                    <textarea id="item-description" rows="3" class="w-full border rounded px-3 py-2"></textarea>
                </div>

                <div class="grid grid-cols-3 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium mb-1">Prix (€) *</label>
                        <input type="number" id="item-price" step="0.01" required class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Icône</label>
                        <input type="text" id="item-icon" placeholder="🎨" class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Délai</label>
                        <input type="text" id="item-delivery" placeholder="5-7 jours" class="w-full border rounded px-3 py-2">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium mb-1">Statut</label>
                        <select id="item-status" class="w-full border rounded px-3 py-2">
                            <option value="available">Disponible</option>
                            <option value="unavailable">Indisponible</option>
                            <option value="coming_soon">Bientôt disponible</option>
                        </select>
                    </div>
                    <div class="flex items-center pt-6">
                        <label class="inline-flex items-center">
                            <input type="checkbox" id="item-featured" class="mr-2">
                            <span class="text-sm font-medium">Item en vedette</span>
                        </label>
                    </div>
                </div>

                <div class="flex justify-end gap-2">
                    <button type="button" onclick="closeItemModal()" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded">
                        Annuler
                    </button>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                        Enregistrer
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Stock Management Modal -->
    <div id="stock-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto p-4">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <div class="sticky top-0 bg-white border-b p-6 z-10">
                <div class="flex justify-between items-center">
                    <h3 class="text-xl font-semibold flex items-center gap-2">
                        <span id="stock-icon">🔑</span>
                        <span>Gestion du Stock - <span id="stock-product-name"></span></span>
                    </h3>
                    <button onclick="closeStockModal()" class="text-gray-500 hover:text-gray-700 text-2xl">✕</button>
                </div>
            </div>
            
            <div class="p-6">
                <div class="mb-6">
                    <div class="flex justify-between items-center mb-4">
                        <div>
                            <p class="text-sm text-gray-600">
                                <span id="stock-total">0</span> entrées • 
                                <span id="stock-available" class="font-semibold text-green-600">0</span> disponibles •
                                <span id="stock-sold" class="text-gray-500">0</span> vendus
                            </p>
                        </div>
                        <button onclick="addNewAccount()" class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600">
                            + Ajouter un code
                        </button>
                    </div>
                    
                    <div id="stock-list" class="grid gap-3">
                        <p class="text-gray-500 text-center py-8">Chargement...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Account Modal -->
    <div id="add-account-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[60]">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
            <h3 class="text-xl font-bold mb-4">Ajouter un Code Produit</h3>
            <form id="add-account-form" onsubmit="saveAccount(event)">
                <input type="hidden" id="account-item-id" value="">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Code Produit *</label>
                    <input type="text" id="account-code" required class="w-full border rounded px-3 py-2" placeholder="NETFLIX-ABC123">
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Informations Complètes *</label>
                    <textarea id="account-key" required rows="4" class="w-full border rounded px-3 py-2" placeholder="Email: user@example.com&#10;Mot de passe: Pass123&#10;Instructions: ..."></textarea>
                    <p class="text-xs text-gray-500 mt-1">Format: Email, mot de passe, instructions, etc.</p>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Notes (optionnel)</label>
                    <textarea id="account-notes" rows="2" class="w-full border rounded px-3 py-2" placeholder="Notes internes..."></textarea>
                </div>

                <div class="flex justify-end gap-2">
                    <button type="button" onclick="closeAddAccountModal()" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded">
                        Annuler
                    </button>
                    <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
                        Ajouter
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="hidden fixed top-4 right-4 bg-green-600 text-white px-6 py-3 rounded-lg shadow-lg z-50">
        <span id="toast-message"></span>
    </div>

    <script>
        // Tab Management
        function showTab(tab) {
            document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
            document.querySelectorAll('[id^="tab-"]').forEach(el => {
                el.classList.remove('tab-active');
                el.classList.add('tab-inactive');
            });
            
            document.getElementById('content-' + tab).classList.remove('hidden');
            document.getElementById('tab-' + tab).classList.remove('tab-inactive');
            document.getElementById('tab-' + tab).classList.add('tab-active');
            
            if (tab === 'categories') loadCategories();
            if (tab === 'items') loadItems();
            if (tab === 'orders') loadOrders();
        }

        // Load Categories
        async function loadCategories() {
            const type = document.querySelector('input[name="cat-type-filter"]:checked').value;
            try {
                const response = await fetch(`/api/shop-dynamic.php?action=get_categories&type=${type}`);
                const data = await response.json();
                
                const list = document.getElementById('categories-list');
                if (data.success && data.categories.length > 0) {
                    list.innerHTML = data.categories.map(cat => `
                        <div class="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                            <div class="flex items-center gap-3">
                                <span class="text-3xl">${cat.icon || '📦'}</span>
                                <div>
                                    <h4 class="font-semibold">${cat.name}</h4>
                                    <p class="text-sm text-gray-600">${cat.description || ''}</p>
                                    <span class="text-xs px-2 py-1 rounded ${cat.type === 'service' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}">
                                        ${cat.type === 'service' ? 'Service' : 'Produit'}
                                    </span>
                                </div>
                            </div>
                            <div class="flex gap-2">
                                <button onclick="editCategory(${cat.id})" class="text-blue-600 hover:text-blue-800 px-3 py-1">✏️</button>
                                <button onclick="deleteCategory(${cat.id}, '${cat.name}')" class="text-red-600 hover:text-red-800 px-3 py-1">🗑️</button>
                            </div>
                        </div>
                    `).join('');
                } else {
                    list.innerHTML = '<p class="text-gray-500 text-center py-8">Aucune catégorie trouvée</p>';
                }
            } catch (error) {
                showToast('Erreur de chargement', 'error');
            }
        }

        // Load Items
        async function loadItems() {
            const type = document.getElementById('item-type-filter').value;
            const category_id = document.getElementById('item-category-filter').value;
            
            try {
                const response = await fetch(`/api/shop-dynamic.php?action=get_items&type=${type}&category_id=${category_id}`);
                const data = await response.json();
                
                const list = document.getElementById('items-list');
                if (data.success && data.items.length > 0) {
                    list.innerHTML = data.items.map(item => `
                        <div class="border rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
                            <div class="h-32 bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
                                <span class="text-5xl">${item.icon || '📦'}</span>
                            </div>
                            <div class="p-4">
                                <div class="flex justify-between items-start mb-2">
                                    <h4 class="font-bold text-sm">${item.name}</h4>
                                    <span class="text-xs px-2 py-1 rounded ${item.status === 'available' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}">
                                        ${item.status === 'available' ? 'Disponible' : 'Indisponible'}
                                    </span>
                                </div>
                                <p class="text-xs text-gray-600 mb-2">${item.short_description || ''}</p>
                                <div class="flex justify-between items-center mb-3">
                                    <span class="font-bold text-blue-600">${item.price}€</span>
                                    <span class="text-xs text-gray-500">${item.delivery_time || ''}</span>
                                </div>
                                <div class="flex gap-2">
                                    ${item.type === 'product' ? `
                                        <button onclick="manageStock(${item.id}, '${item.name.replace(/'/g, "\\'")}', '${item.icon || '📦'}')" class="flex-1 text-sm bg-purple-600 text-white px-2 py-1 rounded hover:bg-purple-700 text-xs">
                                            🔑 Stock
                                        </button>
                                    ` : ''}
                                    <button onclick="editItem(${item.id})" class="flex-1 text-sm bg-blue-600 text-white px-2 py-1 rounded hover:bg-blue-700 text-xs">✏️</button>
                                    <button onclick="deleteItem(${item.id}, '${item.name}')" class="text-sm bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700 text-xs">🗑️</button>
                                </div>
                            </div>
                        </div>
                    `).join('');
                } else {
                    list.innerHTML = '<p class="col-span-full text-gray-500 text-center py-8">Aucun item trouvé</p>';
                }
            } catch (error) {
                showToast('Erreur de chargement', 'error');
            }
        }

        // Category Modal Functions
        function openCategoryModal(id = null) {
            document.getElementById('category-modal').classList.remove('hidden');
            document.getElementById('category-form').reset();
            document.getElementById('category-id').value = '';
            document.getElementById('category-modal-title').textContent = 'Nouvelle Catégorie';
            
            if (id) {
                document.getElementById('category-modal-title').textContent = 'Modifier Catégorie';
                loadCategoryData(id);
            }
        }

        function closeCategoryModal() {
            document.getElementById('category-modal').classList.add('hidden');
        }

        async function loadCategoryData(id) {
            const response = await fetch(`/api/shop-dynamic.php?action=get_category&id=${id}`);
            const data = await response.json();
            if (data.success) {
                document.getElementById('category-id').value = data.category.id;
                document.getElementById('category-name').value = data.category.name;
                document.getElementById('category-type').value = data.category.type;
                document.getElementById('category-icon').value = data.category.icon;
                document.getElementById('category-description').value = data.category.description || '';
            }
        }

        async function saveCategory(e) {
            e.preventDefault();
            const formData = new FormData();
            const id = document.getElementById('category-id').value;
            
            formData.append('action', id ? 'update_category' : 'create_category');
            if (id) formData.append('id', id);
            formData.append('name', document.getElementById('category-name').value);
            formData.append('type', document.getElementById('category-type').value);
            formData.append('icon', document.getElementById('category-icon').value);
            formData.append('description', document.getElementById('category-description').value);
            
            try {
                const response = await fetch('/api/shop-dynamic.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    showToast(data.message, 'success');
                    closeCategoryModal();
                    loadCategories();
                    loadCategoriesForFilter();
                } else {
                    showToast(data.message, 'error');
                }
            } catch (error) {
                showToast('Erreur de sauvegarde', 'error');
            }
        }

        async function editCategory(id) {
            openCategoryModal(id);
        }

        async function deleteCategory(id, name) {
            if (!confirm(`Supprimer la catégorie "${name}" ?`)) return;
            
            const formData = new FormData();
            formData.append('action', 'delete_category');
            formData.append('id', id);
            
            try {
                const response = await fetch('/api/shop-dynamic.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    showToast(data.message, 'success');
                    loadCategories();
                } else {
                    showToast(data.message, 'error');
                }
            } catch (error) {
                showToast('Erreur de suppression', 'error');
            }
        }

        // Item Modal Functions
        function openItemModal(id = null) {
            document.getElementById('item-modal').classList.remove('hidden');
            document.getElementById('item-form').reset();
            document.getElementById('item-id').value = '';
            document.getElementById('item-modal-title').textContent = 'Nouvel Item';
            loadCategoriesForItemForm();
            
            if (id) {
                document.getElementById('item-modal-title').textContent = 'Modifier Item';
                loadItemData(id);
            }
        }

        function closeItemModal() {
            document.getElementById('item-modal').classList.add('hidden');
        }

        async function loadCategoriesForItemForm() {
            const response = await fetch('/api/shop-dynamic.php?action=get_categories&type=all');
            const data = await response.json();
            if (data.success) {
                window.allCategories = data.categories;
                filterCategoriesByType();
            }
        }

        function filterCategoriesByType() {
            const type = document.getElementById('item-type').value;
            const select = document.getElementById('item-category');
            const filtered = window.allCategories.filter(c => c.type === type);
            
            select.innerHTML = '<option value="">Sélectionner...</option>' +
                filtered.map(c => `<option value="${c.id}">${c.icon} ${c.name}</option>`).join('');
        }

        async function loadItemData(id) {
            const response = await fetch(`/api/shop-dynamic.php?action=get_item&id=${id}`);
            const data = await response.json();
            if (data.success) {
                const item = data.item;
                document.getElementById('item-id').value = item.id;
                document.getElementById('item-type').value = item.type;
                filterCategoriesByType();
                document.getElementById('item-category').value = item.category_id;
                document.getElementById('item-name').value = item.name;
                document.getElementById('item-short-desc').value = item.short_description || '';
                document.getElementById('item-description').value = item.description || '';
                document.getElementById('item-price').value = item.price;
                document.getElementById('item-icon').value = item.icon || '';
                document.getElementById('item-delivery').value = item.delivery_time || '';
                document.getElementById('item-status').value = item.status;
                document.getElementById('item-featured').checked = item.featured == 1;
            }
        }

        async function saveItem(e) {
            e.preventDefault();
            const formData = new FormData();
            const id = document.getElementById('item-id').value;
            
            formData.append('action', id ? 'update_item' : 'create_item');
            if (id) formData.append('id', id);
            formData.append('category_id', document.getElementById('item-category').value);
            formData.append('type', document.getElementById('item-type').value);
            formData.append('name', document.getElementById('item-name').value);
            formData.append('short_description', document.getElementById('item-short-desc').value);
            formData.append('description', document.getElementById('item-description').value);
            formData.append('price', document.getElementById('item-price').value);
            formData.append('icon', document.getElementById('item-icon').value);
            formData.append('delivery_time', document.getElementById('item-delivery').value);
            formData.append('status', document.getElementById('item-status').value);
            if (document.getElementById('item-featured').checked) {
                formData.append('featured', '1');
            }
            
            try {
                const response = await fetch('/api/shop-dynamic.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    showToast(data.message, 'success');
                    closeItemModal();
                    loadItems();
                } else {
                    showToast(data.message, 'error');
                }
            } catch (error) {
                showToast('Erreur de sauvegarde', 'error');
            }
        }

        async function editItem(id) {
            openItemModal(id);
        }

        async function deleteItem(id, name) {
            if (!confirm(`Supprimer l'item "${name}" ?`)) return;
            
            const formData = new FormData();
            formData.append('action', 'delete_item');
            formData.append('id', id);
            
            try {
                const response = await fetch('/api/shop-dynamic.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    showToast(data.message, 'success');
                    loadItems();
                } else {
                    showToast(data.message, 'error');
                }
            } catch (error) {
                showToast('Erreur de suppression', 'error');
            }
        }

        // Load Categories for Filter
        async function loadCategoriesForFilter() {
            const response = await fetch('/api/shop-dynamic.php?action=get_categories&type=all');
            const data = await response.json();
            if (data.success) {
                const select = document.getElementById('item-category-filter');
                select.innerHTML = '<option value="0">Toutes catégories</option>' +
                    data.categories.map(c => `<option value="${c.id}">${c.icon} ${c.name}</option>`).join('');
            }
        }

        // Quick Category Modal - Create category from item form
        function openQuickCategoryModal() {
            // Get current item type to pre-fill category type
            const itemType = document.getElementById('item-type').value;
            
            // Open category modal
            openCategoryModal();
            
            // Pre-fill the type based on item type
            document.getElementById('category-type').value = itemType;
            document.getElementById('category-type').disabled = true; // Lock to item type
            
            // Change modal title
            document.getElementById('category-modal-title').textContent = '➕ Nouvelle Catégorie Rapide';
            
            // Mark as quick mode
            document.getElementById('category-modal').dataset.quickMode = 'true';
        }

        // Override saveCategory to handle quick mode
        const originalSaveCategory = saveCategory;
        saveCategory = async function(e) {
            e.preventDefault();
            const formData = new FormData();
            const id = document.getElementById('category-id').value;
            
            formData.append('action', id ? 'update_category' : 'create_category');
            if (id) formData.append('id', id);
            formData.append('name', document.getElementById('category-name').value);
            formData.append('type', document.getElementById('category-type').value);
            formData.append('icon', document.getElementById('category-icon').value);
            formData.append('description', document.getElementById('category-description').value);
            
            try {
                const response = await fetch('/api/shop-dynamic.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    showToast(data.message, 'success');
                    
                    // Check if in quick mode
                    const isQuickMode = document.getElementById('category-modal').dataset.quickMode === 'true';
                    
                    if (isQuickMode) {
                        // Quick mode: reload categories for item form and select new one
                        await loadCategoriesForItemForm();
                        
                        // Select the newly created category
                        document.getElementById('item-category').value = data.category_id;
                        
                        // Re-enable type selector
                        document.getElementById('category-type').disabled = false;
                        
                        // Clear quick mode flag
                        delete document.getElementById('category-modal').dataset.quickMode;
                        
                        showToast('✅ Catégorie créée et sélectionnée !', 'success');
                    } else {
                        // Normal mode: reload categories list
                        loadCategories();
                        loadCategoriesForFilter();
                    }
                    
                    closeCategoryModal();
                } else {
                    showToast(data.message, 'error');
                }
            } catch (error) {
                showToast('Erreur de sauvegarde', 'error');
            }
        };

        // Stock Management Functions
        let currentItemId = 0;

        async function manageStock(itemId, itemName, itemIcon) {
            currentItemId = itemId;
            document.getElementById('stock-product-name').textContent = itemName;
            document.getElementById('stock-icon').textContent = itemIcon;
            document.getElementById('stock-modal').classList.remove('hidden');
            await loadStock(itemId);
        }

        function closeStockModal() {
            document.getElementById('stock-modal').classList.add('hidden');
        }

        async function loadStock(itemId) {
            try {
                const response = await fetch(`/api/shop-dynamic.php?action=get_stock&item_id=${itemId}`);
                const data = await response.json();
                
                if (data.success) {
                    const stock = data.stock || [];
                    const available = stock.filter(s => s.status === 'available').length;
                    const sold = stock.filter(s => s.status === 'sold').length;
                    
                    document.getElementById('stock-total').textContent = stock.length;
                    document.getElementById('stock-available').textContent = available;
                    document.getElementById('stock-sold').textContent = sold;
                    
                    const list = document.getElementById('stock-list');
                    if (stock.length > 0) {
                        list.innerHTML = stock.map(item => `
                            <div class="border rounded-lg p-4 ${item.status === 'available' ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-300'}">
                                <div class="flex justify-between items-start">
                                    <div class="flex-1">
                                        <div class="grid grid-cols-2 gap-4 text-sm">
                                            <div>
                                                <span class="text-gray-600">Code:</span>
                                                <div class="font-mono bg-white px-2 py-1 rounded border mt-1">${item.product_code}</div>
                                            </div>
                                            <div>
                                                <span class="text-gray-600">Infos:</span>
                                                <div class="font-mono bg-white px-2 py-1 rounded border mt-1 text-xs whitespace-pre-wrap">${item.product_key || 'N/A'}</div>
                                            </div>
                                        </div>
                                        ${item.status === 'sold' && item.sold_at ? `
                                            <p class="text-xs text-gray-500 mt-2">
                                                Vendu le ${new Date(item.sold_at).toLocaleDateString('fr-FR')} à ${new Date(item.sold_at).toLocaleTimeString('fr-FR')}
                                            </p>
                                        ` : ''}
                                    </div>
                                    <div class="flex items-center gap-2 ml-4">
                                        <span class="text-sm font-medium ${item.status === 'available' ? 'text-green-600' : 'text-gray-500'}">
                                            ${item.status === 'available' ? '✅ Disponible' : '❌ Vendu'}
                                        </span>
                                        ${item.status === 'available' ? `
                                            <button onclick="removeStockItem(${item.id})" class="text-red-500 hover:text-red-700 p-1">🗑️</button>
                                        ` : ''}
                                    </div>
                                </div>
                            </div>
                        `).join('');
                    } else {
                        list.innerHTML = '<p class="text-gray-500 text-center py-8">Aucun code en stock. Ajoutez-en avec le bouton ci-dessus.</p>';
                    }
                } else {
                    showToast(data.message || 'Erreur de chargement', 'error');
                }
            } catch (error) {
                showToast('Erreur de chargement du stock', 'error');
            }
        }

        function addNewAccount() {
            document.getElementById('account-item-id').value = currentItemId;
            document.getElementById('add-account-form').reset();
            document.getElementById('add-account-modal').classList.remove('hidden');
        }

        function closeAddAccountModal() {
            document.getElementById('add-account-modal').classList.add('hidden');
        }

        async function saveAccount(e) {
            e.preventDefault();
            
            const formData = new FormData();
            formData.append('action', 'add_stock');
            formData.append('item_id', document.getElementById('account-item-id').value);
            formData.append('product_code', document.getElementById('account-code').value);
            formData.append('product_key', document.getElementById('account-key').value);
            formData.append('notes', document.getElementById('account-notes').value);
            
            try {
                const response = await fetch('/api/shop-dynamic.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    showToast('Code ajouté au stock', 'success');
                    closeAddAccountModal();
                    await loadStock(currentItemId);
                } else {
                    showToast(data.message || 'Erreur', 'error');
                }
            } catch (error) {
                showToast('Erreur lors de l\'ajout', 'error');
            }
        }

        async function removeStockItem(stockId) {
            if (!confirm('Supprimer ce code du stock ?')) return;
            
            const formData = new FormData();
            formData.append('action', 'remove_stock');
            formData.append('stock_id', stockId);
            
            try {
                const response = await fetch('/api/shop-dynamic.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    showToast('Code supprimé', 'success');
                    await loadStock(currentItemId);
                } else {
                    showToast(data.message || 'Erreur', 'error');
                }
            } catch (error) {
                showToast('Erreur lors de la suppression', 'error');
            }
        }

        // Load Orders (placeholder)
        async function loadOrders() {
            document.getElementById('orders-list').innerHTML = '<p class="text-gray-500">Fonctionnalité à venir...</p>';
        }

        // Toast Notification
        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toast-message');
            
            toast.className = `fixed top-4 right-4 px-6 py-3 rounded-lg shadow-lg z-50 ${
                type === 'success' ? 'bg-green-600' : 'bg-red-600'
            } text-white`;
            
            toastMessage.textContent = message;
            toast.classList.remove('hidden');
            
            setTimeout(() => {
                toast.classList.add('hidden');
            }, 3000);
        }

        // Initialize
        window.addEventListener('DOMContentLoaded', () => {
            loadCategories();
            loadCategoriesForFilter();
        });
    </script>
</body>
</html>
