<?php
/**
 * Contenu dynamique de la boutique - Charge depuis la base de données
 */
?>

<!-- Services Tab Content -->
<div id="services-tab" class="shop-tab-content">
    <div class="bg-white rounded-xl shadow-lg p-6 max-h-[calc(100vh-300px)] overflow-y-auto">
        <h3 class="text-2xl font-bold text-gray-800 mb-6 sticky top-0 bg-white pb-4 border-b">Services Professionnels</h3>
        
        <!-- Filtres catégories (générés dynamiquement) -->
        <div id="service-filters" class="mb-6 flex flex-wrap gap-2">
            <button onclick="filterServicesByCategory('all')" class="service-filter-btn px-4 py-2 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700 transition-colors" data-category="all">
                Tous
            </button>
        </div>
        
        <!-- Grille des services (générée dynamiquement) -->
        <div id="services-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <p class="col-span-full text-gray-500 text-center py-8">Chargement des services...</p>
        </div>
    </div>
</div>

<!-- Products Tab Content -->
<div id="products-tab" class="shop-tab-content hidden">
    <div class="bg-white rounded-xl shadow-lg p-6 max-h-[calc(100vh-300px)] overflow-y-auto">
        <h3 class="text-2xl font-bold text-gray-800 mb-6 sticky top-0 bg-white pb-4 border-b">Produits Numériques</h3>
        
        <!-- Filtres catégories (générés dynamiquement) -->
        <div id="product-filters" class="mb-6 flex flex-wrap gap-2">
            <button onclick="filterProductsByCategory('all')" class="product-filter-btn px-4 py-2 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700 transition-colors" data-category="all">
                Tous
            </button>
        </div>
        
        <!-- Grille des produits (générée dynamiquement) -->
        <div id="products-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <p class="col-span-full text-gray-500 text-center py-8">Chargement des produits...</p>
        </div>
    </div>
</div>

<script>
// Global variables
let serviceCategories = [];
let productCategories = [];
let allServices = [];
let allProducts = [];
let currentServiceCategory = 'all';
let currentProductCategory = 'all';

// Shop Tab Management
function showShopTab(tab) {
    document.getElementById('services-tab').classList.add('hidden');
    document.getElementById('products-tab').classList.add('hidden');
    document.getElementById(tab + '-tab').classList.remove('hidden');
    
    document.querySelectorAll('.shop-tab').forEach(btn => {
        btn.classList.remove('bg-white', 'text-gray-800', 'font-medium', 'shadow-sm');
        btn.classList.add('text-gray-600');
    });
    event.target.classList.add('bg-white', 'text-gray-800', 'font-medium', 'shadow-sm');
    event.target.classList.remove('text-gray-600');
}

// Load Shop Data
async function loadShopData() {
    try {
        // Load service categories
        const servCatResponse = await fetch('/api/shop-dynamic.php?action=get_categories&type=service');
        const servCatData = await servCatResponse.json();
        if (servCatData.success) {
            serviceCategories = servCatData.categories;
            renderServiceFilters();
        }
        
        // Load product categories
        const prodCatResponse = await fetch('/api/shop-dynamic.php?action=get_categories&type=product');
        const prodCatData = await prodCatResponse.json();
        if (prodCatData.success) {
            productCategories = prodCatData.categories;
            renderProductFilters();
        }
        
        // Load all services
        const servResponse = await fetch('/api/shop-dynamic.php?action=get_items&type=service');
        const servData = await servResponse.json();
        if (servData.success) {
            allServices = servData.items;
            renderServices();
        }
        
        // Load all products
        const prodResponse = await fetch('/api/shop-dynamic.php?action=get_items&type=product');
        const prodData = await prodResponse.json();
        if (prodData.success) {
            allProducts = prodData.items;
            renderProducts();
        }
        
    } catch (error) {
        console.error('Erreur chargement boutique:', error);
        showToast('❌ Erreur de chargement', 'error');
    }
}

// Render Service Filters
function renderServiceFilters() {
    const container = document.getElementById('service-filters');
    const buttonsHTML = serviceCategories.map(cat => `
        <button onclick="filterServicesByCategory(${cat.id})" 
                class="service-filter-btn px-4 py-2 rounded-lg bg-gray-100 text-gray-700 font-medium hover:bg-gray-200 transition-colors" 
                data-category="${cat.id}">
            ${cat.icon} ${cat.name}
        </button>
    `).join('');
    
    container.innerHTML = `
        <button onclick="filterServicesByCategory('all')" 
                class="service-filter-btn px-4 py-2 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700 transition-colors" 
                data-category="all">
            Tous
        </button>
        ${buttonsHTML}
    `;
}

// Render Product Filters
function renderProductFilters() {
    const container = document.getElementById('product-filters');
    const buttonsHTML = productCategories.map(cat => `
        <button onclick="filterProductsByCategory(${cat.id})" 
                class="product-filter-btn px-4 py-2 rounded-lg bg-gray-100 text-gray-700 font-medium hover:bg-gray-200 transition-colors" 
                data-category="${cat.id}">
            ${cat.icon} ${cat.name}
        </button>
    `).join('');
    
    container.innerHTML = `
        <button onclick="filterProductsByCategory('all')" 
                class="product-filter-btn px-4 py-2 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700 transition-colors" 
                data-category="all">
            Tous
        </button>
        ${buttonsHTML}
    `;
}

// Filter Services by Category
function filterServicesByCategory(categoryId) {
    currentServiceCategory = categoryId;
    
    // Update button styles
    document.querySelectorAll('.service-filter-btn').forEach(btn => {
        if (btn.dataset.category == categoryId) {
            btn.classList.remove('bg-gray-100', 'text-gray-700');
            btn.classList.add('bg-blue-600', 'text-white');
        } else {
            btn.classList.remove('bg-blue-600', 'text-white');
            btn.classList.add('bg-gray-100', 'text-gray-700');
        }
    });
    
    renderServices();
}

// Filter Products by Category
function filterProductsByCategory(categoryId) {
    currentProductCategory = categoryId;
    
    // Update button styles
    document.querySelectorAll('.product-filter-btn').forEach(btn => {
        if (btn.dataset.category == categoryId) {
            btn.classList.remove('bg-gray-100', 'text-gray-700');
            btn.classList.add('bg-blue-600', 'text-white');
        } else {
            btn.classList.remove('bg-blue-600', 'text-white');
            btn.classList.add('bg-gray-100', 'text-gray-700');
        }
    });
    
    renderProducts();
}

// Render Services
function renderServices() {
    const container = document.getElementById('services-grid');
    let filtered = allServices;
    
    if (currentServiceCategory !== 'all') {
        filtered = allServices.filter(s => s.category_id == currentServiceCategory);
    }
    
    if (filtered.length === 0) {
        container.innerHTML = '<p class="col-span-full text-gray-500 text-center py-8">Aucun service disponible</p>';
        return;
    }
    
    container.innerHTML = filtered.map(service => `
        <div class="bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200">
            <div class="h-40 bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
                <span class="text-6xl">${service.icon || '💼'}</span>
            </div>
            <div class="p-5">
                <div class="flex justify-between items-start mb-2">
                    <h5 class="font-bold text-gray-800 text-lg">${service.name}</h5>
                    <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-semibold">
                        ${service.status === 'available' ? 'Disponible' : 'Indisponible'}
                    </span>
                </div>
                <p class="text-sm text-gray-600 mb-3">${service.short_description || ''}</p>
                <div class="flex items-center justify-between mb-4">
                    <div class="text-2xl font-bold text-blue-600">${service.price}€</div>
                    <div class="text-xs text-gray-500">${service.delivery_time || ''}</div>
                </div>
                <button onclick="orderItem(${service.id}, '${service.name.replace(/'/g, "\\'")}', ${service.price}, 'service')" 
                        class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                        ${service.status !== 'available' ? 'disabled' : ''}>
                    Commander
                </button>
            </div>
        </div>
    `).join('');
}

// Render Products
function renderProducts() {
    const container = document.getElementById('products-grid');
    let filtered = allProducts;
    
    if (currentProductCategory !== 'all') {
        filtered = allProducts.filter(p => p.category_id == currentProductCategory);
    }
    
    if (filtered.length === 0) {
        container.innerHTML = '<p class="col-span-full text-gray-500 text-center py-8">Aucun produit disponible</p>';
        return;
    }
    
    container.innerHTML = filtered.map(product => `
        <div class="bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200">
            <div class="h-40 bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <span class="text-6xl">${product.icon || '📦'}</span>
            </div>
            <div class="p-5">
                <div class="flex justify-between items-start mb-2">
                    <h5 class="font-bold text-gray-800 text-lg">${product.name}</h5>
                    <span class="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-semibold">
                        ${product.is_subscription ? 'Abonnement' : 'Téléchargement'}
                    </span>
                </div>
                <p class="text-sm text-gray-600 mb-3">${product.short_description || ''}</p>
                <div class="flex items-center justify-between mb-4">
                    <div class="text-2xl font-bold text-blue-600">${product.price}€${product.is_subscription ? '/an' : ''}</div>
                    <div class="text-xs text-gray-500">${product.is_subscription ? 'Annuel' : 'Instantané'}</div>
                </div>
                <button onclick="orderItem(${product.id}, '${product.name.replace(/'/g, "\\'")}', ${product.price}, 'product')" 
                        class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                        ${product.status !== 'available' ? 'disabled' : ''}>
                    Acheter
                </button>
            </div>
        </div>
    `).join('');
}

// Order Item (Service or Product)
async function orderItem(itemId, itemName, price, type) {
    const actionText = type === 'service' ? 'Commander le service' : 'Acheter le produit';
    
    if (!confirm(`${actionText} "${itemName}" pour ${price}€ ?\n\nLe montant sera débité de votre wallet.`)) {
        return;
    }
    
    try {
        showToast('⏳ Traitement de votre commande...', 'info');
        
        const formData = new FormData();
        formData.append('action', 'create_order');
        formData.append('item_id', itemId);
        
        const response = await fetch('/api/shop-dynamic.php', { 
            method: 'POST', 
            body: formData 
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast(`✅ Commande créée avec succès !`, 'success');
            
            setTimeout(() => {
                if (type === 'product') {
                    // Show product code if delivered
                    if (data.product_code) {
                        const deliveryMessage = `🎉 PRODUIT LIVRÉ IMMÉDIATEMENT !\n\n` +
                            `📦 Commande: ${data.order_number}\n` +
                            `🛍️ Produit: ${itemName}\n` +
                            `💰 Prix: ${price}€\n\n` +
                            `🔑 VOTRE CODE:\n${data.product_code}\n\n` +
                            (data.product_key ? `📋 INFORMATIONS:\n${data.product_key}\n\n` : '') +
                            `✅ Le code a été enregistré dans "Mes Commandes"\n` +
                            `Vous pouvez y accéder à tout moment !`;
                        
                        alert(deliveryMessage);
                        
                        // Copy to clipboard
                        if (navigator.clipboard) {
                            navigator.clipboard.writeText(data.product_code).then(() => {
                                showToast('📋 Code copié dans le presse-papier !', 'success');
                            });
                        }
                    } else if (data.download_url) {
                        if (confirm(`🎉 Commande confirmée !\n\nCommande: ${data.order_number}\nProduit: ${itemName}\nPrix: ${price}€\n\nVoulez-vous télécharger le produit maintenant ?`)) {
                            window.open(data.download_url, '_blank');
                            showToast('📥 Téléchargement démarré !', 'success');
                        }
                    }
                } else {
                    alert(`🎉 Commande confirmée !\n\nCommande: ${data.order_number}\nService: ${itemName}\nPrix: ${price}€\n\nUn employé va prendre en charge votre projet sous peu.`);
                }
                
                // Reload wallet balance
                if (typeof loadWalletBalance === 'function') {
                    loadWalletBalance();
                }
            }, 500);
        } else {
            showToast(`❌ Erreur : ${data.message}`, 'error');
        }
    } catch (error) {
        console.error('Erreur commande:', error);
        showToast('❌ Erreur lors de la commande', 'error');
    }
}

// Initialize shop when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Only load if we're on the shop tab
    if (document.getElementById('services-tab')) {
        loadShopData();
    }
});
</script>
