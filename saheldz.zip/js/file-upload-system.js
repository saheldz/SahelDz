/**
 * Système d'upload de fichiers avec miniatures et bouton Sauvegarder
 * Pour les projets Branding
 */

// Stockage temporaire des fichiers avant sauvegarde
let pendingUploads = {
    reference: [],
    assets: []
};

// ID du projet actuel (sera défini lors de l'ouverture du modal)
let currentProjectId = null;

/**
 * Gérer l'upload de fichiers avec prévisualisation et bouton Sauvegarder
 */
function handleFileUploadWithSave(input, previewId, category) {
    const preview = document.getElementById(previewId);
    const files = Array.from(input.files);
    
    if (files.length === 0) return;
    
    // Stocker les fichiers en attente
    if (!pendingUploads[category]) {
        pendingUploads[category] = [];
    }
    
    files.forEach((file, index) => {
        // Créer un ID unique pour ce fichier
        const fileId = `temp_${Date.now()}_${index}`;
        
        // Ajouter au stockage temporaire
        pendingUploads[category].push({
            id: fileId,
            file: file,
            uploaded: false
        });
        
        // Créer la prévisualisation
        const fileDiv = document.createElement('div');
        fileDiv.className = 'bg-white border-2 border-gray-200 rounded-lg p-3 text-center relative hover:shadow-md transition-shadow';
        fileDiv.dataset.fileId = fileId;
        
        // Déterminer l'icône et créer la miniature
        if (file.type.startsWith('image/')) {
            // Créer une miniature depuis l'image
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.className = 'w-full h-32 object-cover rounded mb-2';
                
                // Insérer l'image au début du fileDiv
                const iconSpan = fileDiv.querySelector('.text-3xl');
                if (iconSpan) {
                    iconSpan.replaceWith(img);
                }
            };
            reader.readAsDataURL(file);
            
            fileDiv.innerHTML = `
                <span class="text-3xl block mb-2">🖼️</span>
                <p class="text-xs text-gray-700 truncate font-medium">${file.name}</p>
                <p class="text-xs text-gray-500">${(file.size / 1024 / 1024).toFixed(2)} MB</p>
                <button onclick="removeFileFromUpload('${fileId}', '${category}')" class="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 text-sm hover:bg-red-600 shadow-md flex items-center justify-center font-bold">
                    ×
                </button>
                <div class="mt-2 text-xs text-blue-600">📤 En attente</div>
            `;
        } else {
            const fileIcon = file.name.endsWith('.pdf') ? '📄' : 
                          file.name.endsWith('.ai') ? '🎨' : 
                          file.name.endsWith('.psd') ? '🎨' : 
                          file.name.endsWith('.svg') ? '🖼️' : '📁';
            
            fileDiv.innerHTML = `
                <span class="text-3xl block mb-2">${fileIcon}</span>
                <p class="text-xs text-gray-700 truncate font-medium">${file.name}</p>
                <p class="text-xs text-gray-500">${(file.size / 1024 / 1024).toFixed(2)} MB</p>
                <button onclick="removeFileFromUpload('${fileId}', '${category}')" class="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 text-sm hover:bg-red-600 shadow-md flex items-center justify-center font-bold">
                    ×
                </button>
                <div class="mt-2 text-xs text-blue-600">📤 En attente</div>
            `;
        }
        
        preview.appendChild(fileDiv);
    });
    
    // Afficher ou mettre à jour le bouton Sauvegarder
    showSaveButton(previewId, category);
    
    // Réinitialiser l'input file
    input.value = '';
}

/**
 * Afficher le bouton Sauvegarder
 */
function showSaveButton(previewId, category) {
    const preview = document.getElementById(previewId);
    
    // Vérifier si le bouton existe déjà
    let saveButton = preview.querySelector('.save-uploads-btn');
    
    if (!saveButton) {
        saveButton = document.createElement('div');
        saveButton.className = 'save-uploads-btn col-span-3 mt-4';
        saveButton.innerHTML = `
            <button onclick="saveAllPendingFiles('${category}')" class="w-full bg-green-600 text-white py-3 px-4 rounded-lg font-semibold hover:bg-green-700 transition-colors flex items-center justify-center gap-2 shadow-md">
                <span class="text-lg">💾</span>
                <span>Sauvegarder les fichiers</span>
                <span id="pending-count-${category}" class="bg-green-700 px-2 py-0.5 rounded-full text-xs">0</span>
            </button>
        `;
        preview.appendChild(saveButton);
    }
    
    // Mettre à jour le compteur
    const pendingCount = pendingUploads[category]?.filter(f => !f.uploaded).length || 0;
    const countElement = document.getElementById(`pending-count-${category}`);
    if (countElement) {
        countElement.textContent = pendingCount;
    }
    
    // Cacher le bouton si aucun fichier en attente
    if (pendingCount === 0) {
        saveButton.style.display = 'none';
    } else {
        saveButton.style.display = 'block';
    }
}

/**
 * Retirer un fichier de la file d'upload
 */
function removeFileFromUpload(fileId, category) {
    // Retirer du stockage temporaire
    pendingUploads[category] = pendingUploads[category].filter(f => f.id !== fileId);
    
    // Retirer visuellement
    const fileDiv = document.querySelector(`[data-file-id="${fileId}"]`);
    if (fileDiv) {
        fileDiv.remove();
    }
    
    // Mettre à jour le bouton Sauvegarder
    const previewId = category === 'reference' ? 'reference-preview' : 'assets-preview';
    showSaveButton(previewId, category);
    
    showNotification('❌ Fichier retiré', 'info');
}

/**
 * Sauvegarder tous les fichiers en attente
 */
async function saveAllPendingFiles(category) {
    const filesToUpload = pendingUploads[category]?.filter(f => !f.uploaded) || [];
    
    if (filesToUpload.length === 0) {
        showNotification('Aucun fichier à sauvegarder', 'info');
        return;
    }
    
    // Déterminer l'ID du projet
    if (!currentProjectId) {
        // Si pas de projet, créer un ID temporaire
        currentProjectId = Date.now();
    }
    
    showNotification(`📤 Upload de ${filesToUpload.length} fichier(s) en cours...`, 'info');
    
    let successCount = 0;
    let errorCount = 0;
    
    for (const fileData of filesToUpload) {
        try {
            const formData = new FormData();
            formData.append('action', 'upload');
            formData.append('file', fileData.file);
            formData.append('project_id', currentProjectId);
            formData.append('category', category);
            
            const response = await fetch('/api/files.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Marquer comme uploadé
                fileData.uploaded = true;
                fileData.serverData = result.file;
                
                // Mettre à jour visuellement
                const fileDiv = document.querySelector(`[data-file-id="${fileData.id}"]`);
                if (fileDiv) {
                    const statusDiv = fileDiv.querySelector('.text-blue-600');
                    if (statusDiv) {
                        statusDiv.textContent = '✅ Sauvegardé';
                        statusDiv.className = 'mt-2 text-xs text-green-600 font-medium';
                    }
                    
                    // Changer la bordure pour indiquer succès
                    fileDiv.classList.remove('border-gray-200');
                    fileDiv.classList.add('border-green-500');
                }
                
                successCount++;
                
            } else {
                throw new Error(result.error || 'Erreur lors de l\'upload');
            }
        } catch (error) {
            console.error('Upload error:', error);
            errorCount++;
            
            // Marquer visuellement l'erreur
            const fileDiv = document.querySelector(`[data-file-id="${fileData.id}"]`);
            if (fileDiv) {
                const statusDiv = fileDiv.querySelector('.text-blue-600');
                if (statusDiv) {
                    statusDiv.textContent = '❌ Erreur';
                    statusDiv.className = 'mt-2 text-xs text-red-600 font-medium';
                }
                fileDiv.classList.remove('border-gray-200');
                fileDiv.classList.add('border-red-500');
            }
        }
    }
    
    // Afficher le résultat
    if (successCount > 0) {
        showNotification(`✅ ${successCount} fichier(s) sauvegardé(s) avec succès !`, 'success');
    }
    
    if (errorCount > 0) {
        showNotification(`❌ ${errorCount} fichier(s) n'ont pas pu être uploadés`, 'error');
    }
    
    // Mettre à jour le bouton
    const previewId = category === 'reference' ? 'reference-preview' : 'assets-preview';
    showSaveButton(previewId, category);
}

/**
 * Charger les fichiers existants d'un projet depuis la DB
 */
async function loadProjectFiles(projectId) {
    currentProjectId = projectId;
    
    try {
        const response = await fetch(`/api/files.php?action=get_project_files&project_id=${projectId}`);
        const result = await response.json();
        
        if (result.success && result.files) {
            // Afficher les fichiers par catégorie
            displayExistingFiles(result.files, 'reference', 'reference-preview');
            displayExistingFiles(result.files, 'assets', 'assets-preview');
        }
    } catch (error) {
        console.error('Error loading project files:', error);
    }
}

/**
 * Afficher les fichiers existants
 */
function displayExistingFiles(files, category, previewId) {
    const categoryFiles = files.filter(f => f.file_category === category);
    const preview = document.getElementById(previewId);
    
    if (!preview) return;
    
    categoryFiles.forEach(file => {
        const fileDiv = document.createElement('div');
        fileDiv.className = 'bg-white border-2 border-green-500 rounded-lg p-3 text-center relative hover:shadow-md transition-shadow';
        fileDiv.dataset.fileDbId = file.id;
        
        // Si miniature disponible, l'afficher
        if (file.thumbnail_path && file.file_type.startsWith('image')) {
            fileDiv.innerHTML = `
                <img src="${file.thumbnail_path}" class="w-full h-32 object-cover rounded mb-2" alt="${file.original_name}">
                <p class="text-xs text-gray-700 truncate font-medium">${file.original_name}</p>
                <p class="text-xs text-gray-500">${(file.file_size / 1024 / 1024).toFixed(2)} MB</p>
                <button onclick="deleteUploadedFile(${file.id}, '${category}')" class="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 text-sm hover:bg-red-600 shadow-md flex items-center justify-center font-bold">
                    ×
                </button>
                <div class="mt-2 text-xs text-green-600 font-medium">✅ Sauvegardé</div>
            `;
        } else {
            const fileIcon = file.file_type === 'application/pdf' ? '📄' : 
                          file.original_name.endsWith('.ai') ? '🎨' : 
                          file.original_name.endsWith('.psd') ? '🎨' : 
                          file.original_name.endsWith('.svg') ? '🖼️' : '📁';
            
            fileDiv.innerHTML = `
                <span class="text-3xl block mb-2">${fileIcon}</span>
                <p class="text-xs text-gray-700 truncate font-medium">${file.original_name}</p>
                <p class="text-xs text-gray-500">${(file.file_size / 1024 / 1024).toFixed(2)} MB</p>
                <button onclick="deleteUploadedFile(${file.id}, '${category}')" class="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 text-sm hover:bg-red-600 shadow-md flex items-center justify-center font-bold">
                    ×
                </button>
                <div class="mt-2 text-xs text-green-600 font-medium">✅ Sauvegardé</div>
            `;
        }
        
        preview.appendChild(fileDiv);
    });
}

/**
 * Supprimer un fichier uploadé depuis le serveur
 */
async function deleteUploadedFile(fileId, category) {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce fichier ?')) {
        return;
    }
    
    try {
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('file_id', fileId);
        
        const response = await fetch('/api/files.php', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Retirer visuellement
            const fileDiv = document.querySelector(`[data-file-db-id="${fileId}"]`);
            if (fileDiv) {
                fileDiv.remove();
            }
            
            showNotification('🗑️ Fichier supprimé avec succès', 'success');
        } else {
            throw new Error(result.error || 'Erreur lors de la suppression');
        }
    } catch (error) {
        showNotification('❌ Erreur: ' + error.message, 'error');
    }
}

/**
 * Réinitialiser les uploads en attente
 */
function resetPendingUploads() {
    pendingUploads = {
        reference: [],
        assets: []
    };
    currentProjectId = null;
}
