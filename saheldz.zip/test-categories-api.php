<?php
/**
 * Test API - Vérifier les catégories
 */

header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Test API Catégories</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-2xl mx-auto">
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <h1 class="text-2xl font-bold mb-4">🧪 Test API Catégories</h1>
            
            <button onclick="testAPI()" class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 mb-4">
                🔄 Tester l'API
            </button>
            
            <div id="results" class="mt-4">
                <!-- Résultats ici -->
            </div>
        </div>
    </div>

    <script>
        async function testAPI() {
            const results = document.getElementById('results');
            results.innerHTML = '<div class="bg-blue-50 p-4 rounded">🔄 Test en cours...</div>';
            
            try {
                const response = await fetch('../api/shop-dynamic.php?action=getCategories');
                const data = await response.json();
                
                console.log('Réponse API:', data);
                
                let html = '<div class="bg-white border rounded-lg p-4">';
                html += '<h3 class="font-bold text-lg mb-3">Résultat de l\'API:</h3>';
                html += '<pre class="bg-gray-50 p-3 rounded text-sm overflow-auto">' + JSON.stringify(data, null, 2) + '</pre>';
                
                if (data.success && data.categories) {
                    html += '<div class="mt-4 bg-green-50 border border-green-200 p-4 rounded">';
                    html += '<h4 class="font-semibold text-green-800 mb-2">✅ API fonctionne!</h4>';
                    html += '<p class="text-green-700">Nombre de catégories: ' + data.categories.length + '</p>';
                    html += '<div class="mt-3 space-y-2">';
                    
                    data.categories.forEach(cat => {
                        html += '<div class="bg-white p-2 rounded border">';
                        html += '<span class="text-xl mr-2">' + cat.icon + '</span>';
                        html += '<span class="font-medium">' + cat.name + '</span>';
                        html += '<span class="text-sm text-gray-500 ml-2">(ID: ' + cat.id + ')</span>';
                        html += '</div>';
                    });
                    
                    html += '</div></div>';
                } else {
                    html += '<div class="mt-4 bg-red-50 border border-red-200 p-4 rounded">';
                    html += '<h4 class="font-semibold text-red-800">❌ Erreur:</h4>';
                    html += '<p class="text-red-700">' + (data.error || data.message || 'Erreur inconnue') + '</p>';
                    html += '</div>';
                }
                
                html += '</div>';
                results.innerHTML = html;
                
            } catch (error) {
                console.error('Erreur:', error);
                results.innerHTML = '<div class="bg-red-50 border border-red-200 p-4 rounded"><p class="text-red-800">❌ Erreur: ' + error.message + '</p></div>';
            }
        }
    </script>
</body>
</html>
