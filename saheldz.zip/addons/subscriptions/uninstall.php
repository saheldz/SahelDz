<?php
/**
 * Script de désinstallation de l'addon Abonnements
 * Exécuté lors de la suppression de l'addon
 */

require_once __DIR__ . '/../../config/database.php';

try {
    $pdo = getDB();
    
    echo "🗑️ Désinstallation de l'addon Abonnements...\n\n";
    
    // Supprimer les tables dans l'ordre inverse pour respecter les contraintes
    echo "📋 Suppression de la table subscription_history...\n";
    $pdo->exec("DROP TABLE IF EXISTS subscription_history");
    
    echo "📋 Suppression de la table subscription_items...\n";
    $pdo->exec("DROP TABLE IF EXISTS subscription_items");
    
    echo "📋 Suppression de la table subscriptions...\n";
    $pdo->exec("DROP TABLE IF EXISTS subscriptions");
    
    echo "📋 Suppression de la table subscription_plans...\n";
    $pdo->exec("DROP TABLE IF EXISTS subscription_plans");
    
    echo "✅ Désinstallation terminée avec succès !\n";
    
    return ['success' => true, 'message' => 'Addon Abonnements désinstallé avec succès'];
    
} catch (PDOException $e) {
    echo "❌ Erreur lors de la désinstallation : " . $e->getMessage() . "\n";
    return ['success' => false, 'error' => $e->getMessage()];
}
