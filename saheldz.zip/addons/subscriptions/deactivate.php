<?php
/**
 * Script de désactivation de l'addon Abonnements
 * Exécuté lors de la désactivation de l'addon
 */

// Rien de spécial à faire lors de la désactivation
// Les tables et données restent en place

echo "✅ Addon Abonnements désactivé avec succès !\n";

return ['success' => true, 'message' => 'Addon Abonnements désactivé'];
