# 📦 Addon Gestion des Abonnements

## Description

Module complet de gestion des plans d'abonnement et souscriptions clients avec intégration wallet pour DigiServices.

## Fonctionnalités

### Gestion des Plans
✅ Créer/modifier/supprimer des plans d'abonnement  
✅ Périodes de facturation flexibles (jour, semaine, mois, trimestre, an)  
✅ Périodes d'essai gratuites configurables  
✅ Limites personnalisables (utilisateurs, stockage)  
✅ Liste de fonctionnalités dynamique  
✅ Badge "populaire" pour mise en avant  

### Gestion des Abonnements
✅ Souscription automatisée avec calcul des dates  
✅ Intégration wallet pour paiements automatiques  
✅ Gestion des périodes d'essai  
✅ Suspendre/réactiver/annuler des abonnements  
✅ Historique complet des actions  
✅ Filtrage par statut  

### Sécurité & Intégration
✅ Authentification requise (admin uniquement)  
✅ Intégration avec le système de wallet existant  
✅ Transactions automatiques  
✅ Respect des permissions  
✅ Validation des données  

## Installation

1. Téléchargez le fichier ZIP de l'addon
2. Accédez à `/admin-addons.php` dans votre dashboard
3. Cliquez sur "📁 Sélectionner un fichier ZIP"
4. Sélectionnez le fichier `subscriptions.zip`
5. L'installation se fait automatiquement
6. Activez l'addon depuis la liste des addons installés

## Utilisation

### Accéder à l'interface

Une fois l'addon activé, accédez à :
- Via le dashboard : Cliquez sur "📦 Abonnements"
- URL directe : `/addons/subscriptions/admin/dashboard.php`

### Créer un plan d'abonnement

1. Onglet "Plans d'Abonnement"
2. Cliquez sur "➕ Nouveau Plan"
3. Remplissez les informations (nom, prix, période, etc.)
4. Ajoutez les fonctionnalités une par une
5. Marquez comme "populaire" si souhaité
6. Enregistrez

### Souscrire un client

1. Onglet "Abonnements Clients"
2. Cliquez sur "➕ Nouvel Abonnement"
3. Sélectionnez le client et le plan
4. Choisissez la date de début et la méthode de paiement
5. Créez l'abonnement

Le système calcule automatiquement :
- La période d'essai si configurée
- La prochaine date de facturation
- Les déductions du wallet si nécessaire

### Gérer un abonnement

Depuis la liste des abonnements :
- **👁️ Voir** : Afficher tous les détails
- **⏸️ Suspendre** : Mettre en pause (admin uniquement)
- **▶️ Réactiver** : Reprendre un abonnement suspendu
- **❌ Annuler** : Annuler définitivement

## API Endpoints

L'addon expose une API REST complète :

### Plans
- `GET /addons/subscriptions/api/endpoints.php?action=get_plans`
- `POST /addons/subscriptions/api/endpoints.php` (action=create_plan)
- `POST /addons/subscriptions/api/endpoints.php` (action=update_plan)
- `POST /addons/subscriptions/api/endpoints.php` (action=delete_plan)

### Abonnements
- `GET /addons/subscriptions/api/endpoints.php?action=get_subscriptions`
- `GET /addons/subscriptions/api/endpoints.php?action=get_subscription&subscription_id=X`
- `POST /addons/subscriptions/api/endpoints.php` (action=create_subscription)
- `POST /addons/subscriptions/api/endpoints.php` (action=suspend_subscription)
- `POST /addons/subscriptions/api/endpoints.php` (action=cancel_subscription)
- `POST /addons/subscriptions/api/endpoints.php` (action=reactivate_subscription)

### Statistiques
- `GET /addons/subscriptions/api/endpoints.php?action=get_stats`

Consultez la documentation complète dans `SUBSCRIPTIONS_README.md` pour plus de détails.

## Base de données

L'addon crée 4 tables :
- `subscription_plans` : Plans d'abonnement
- `subscriptions` : Abonnements clients
- `subscription_items` : Items/services additionnels
- `subscription_history` : Historique des actions

## Configuration requise

- DigiServices v1.0.0 ou supérieur
- PHP 7.4+
- MySQL 5.7+ / MariaDB 10.2+
- Module wallet actif (pour paiements automatiques)

## Support

Pour toute question ou problème :
- Consultez `SUBSCRIPTIONS_README.md` pour la documentation détaillée
- Contactez l'équipe DigiServices

## Version

**1.0.0** - Version initiale

## Auteur

DigiServices Team - https://digiservices.com

## Licence

Propriétaire - Tous droits réservés
