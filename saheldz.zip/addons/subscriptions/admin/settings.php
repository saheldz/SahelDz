<?php
/**
 * Subscriptions Addon - Settings Redirect
 * Redirige vers le dashboard principal
 */
header('Location: /addons/subscriptions/admin/dashboard.php');
exit;
