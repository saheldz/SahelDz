<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/config/auth-check.php';
if (!isAdmin()) { header('Location: /index.php'); exit; }

require_once $_SERVER['DOCUMENT_ROOT'] . '/config/database.php';
$pdo = getDB();

// Vérifier si les tables existent
try {
    $pdo->query("SELECT 1 FROM subscription_plans LIMIT 1");
    $pdo->query("SELECT 1 FROM subscriptions LIMIT 1");
} catch (Exception $e) {
    // Tables non installées - rediriger vers installation
    header('Location: /addons/subscriptions/install.php');
    exit;
}

// Stats générales
$stmt = $pdo->query("SELECT COUNT(*) as total FROM subscriptions");
$totalSubs = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) as total FROM subscriptions WHERE status IN ('active', 'trial')");
$activeSubs = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT SUM(amount) as revenue FROM subscriptions WHERE status IN ('active', 'trial')");
$monthlyRevenue = $stmt->fetchColumn() ?? 0;

$stmt = $pdo->query("SELECT COUNT(*) as total FROM subscription_plans WHERE status = 'active'");
$totalPlans = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion Abonnements - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <nav class="bg-gradient-to-r from-indigo-600 to-purple-600 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-4">
                <a href="/admin-dashboard.php" class="text-white hover:text-indigo-200">← Dashboard</a>
                <h1 class="text-2xl font-bold text-white">📦 Gestion des Abonnements</h1>
            </div>
            <button onclick="logout()" class="bg-white/10 text-white px-4 py-2 rounded-lg hover:bg-white/20">Déconnexion</button>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        
        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
                <h3 class="text-sm text-gray-600 mb-2">Total Abonnements</h3>
                <p class="text-3xl font-bold text-blue-600"><?php echo $totalSubs; ?></p>
            </div>
            
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
                <h3 class="text-sm text-gray-600 mb-2">Abonnements Actifs</h3>
                <p class="text-3xl font-bold text-green-600"><?php echo $activeSubs; ?></p>
            </div>
            
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
                <h3 class="text-sm text-gray-600 mb-2">Revenu Mensuel</h3>
                <p class="text-3xl font-bold text-purple-600"><?php echo number_format($monthlyRevenue, 2); ?> €</p>
            </div>
            
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-yellow-500">
                <h3 class="text-sm text-gray-600 mb-2">Plans Disponibles</h3>
                <p class="text-3xl font-bold text-yellow-600"><?php echo $totalPlans; ?></p>
            </div>
        </div>

        <!-- Tabs -->
        <div class="bg-white rounded-xl shadow-lg mb-6">
            <div class="flex border-b">
                <button onclick="switchTab('plans')" id="tab-plans" class="px-6 py-4 font-semibold border-b-2 border-indigo-600 text-indigo-600">
                    Plans d'Abonnement
                </button>
                <button onclick="switchTab('subscriptions')" id="tab-subscriptions" class="px-6 py-4 font-semibold text-gray-600 hover:text-gray-800">
                    Abonnements Clients
                </button>
            </div>

            <!-- Tab: Plans -->
            <div id="content-plans" class="p-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-xl font-bold">Plans d'Abonnement</h2>
                    <button onclick="openPlanModal()" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 font-semibold">
                        ➕ Nouveau Plan
                    </button>
                </div>
                
                <div id="plans-grid" class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Chargé via JS -->
                </div>
            </div>

            <!-- Tab: Subscriptions -->
            <div id="content-subscriptions" class="p-6 hidden">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-xl font-bold">Abonnements Clients</h2>
                    <div class="flex gap-2">
                        <select id="filter-status" onchange="filterSubscriptions()" class="px-4 py-2 border rounded-lg">
                            <option value="">Tous les statuts</option>
                            <option value="trial">Trial</option>
                            <option value="active">Actif</option>
                            <option value="suspended">Suspendu</option>
                            <option value="cancelled">Annulé</option>
                            <option value="expired">Expiré</option>
                        </select>
                        <button onclick="openSubscriptionModal()" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 font-semibold">
                            ➕ Nouvel Abonnement
                        </button>
                    </div>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="border-b-2">
                                <th class="text-left p-3">Client</th>
                                <th class="text-left p-3">Plan</th>
                                <th class="text-right p-3">Montant</th>
                                <th class="text-center p-3">Période</th>
                                <th class="text-center p-3">Statut</th>
                                <th class="text-center p-3">Prochaine facturation</th>
                                <th class="text-right p-3">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="subscriptions-tbody">
                            <!-- Chargé via JS -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Plan -->
    <div id="plan-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-xl shadow-2xl max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div class="flex justify-between items-center mb-6">
                <h3 id="plan-modal-title" class="text-2xl font-bold">Nouveau Plan</h3>
                <button onclick="closePlanModal()" class="text-gray-400 hover:text-gray-600 text-2xl">×</button>
            </div>
            
            <form id="plan-form" onsubmit="savePlan(event)">
                <input type="hidden" id="plan-id" name="plan_id">
                
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div class="col-span-2">
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Nom du plan *</label>
                        <input type="text" name="name" id="plan-name" required
                               placeholder="ex: Plan Pro"
                               class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                    </div>
                    
                    <div class="col-span-2">
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Description</label>
                        <textarea name="description" id="plan-description" rows="3"
                                  placeholder="Description du plan..."
                                  class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"></textarea>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Prix (€) *</label>
                        <input type="number" name="price" id="plan-price" step="0.01" min="0" required
                               placeholder="29.99"
                               class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Période *</label>
                        <select name="billing_period" id="plan-period" required
                                class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                            <option value="daily">Journalier</option>
                            <option value="weekly">Hebdomadaire</option>
                            <option value="monthly" selected>Mensuel</option>
                            <option value="quarterly">Trimestriel</option>
                            <option value="yearly">Annuel</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Jours d'essai</label>
                        <input type="number" name="trial_days" id="plan-trial" min="0"
                               placeholder="7"
                               class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Utilisateurs max</label>
                        <input type="number" name="max_users" id="plan-users" min="1"
                               placeholder="10 (vide = illimité)"
                               class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Stockage (MB)</label>
                        <input type="number" name="max_storage" id="plan-storage" min="1"
                               placeholder="5120 (vide = illimité)"
                               class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Statut</label>
                        <select name="status" id="plan-status"
                                class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                            <option value="active">Actif</option>
                            <option value="inactive">Inactif</option>
                        </select>
                    </div>
                    
                    <div class="col-span-2">
                        <label class="flex items-center gap-2">
                            <input type="checkbox" name="is_popular" id="plan-popular" class="w-5 h-5">
                            <span class="font-semibold text-gray-700">Plan populaire (badge)</span>
                        </label>
                    </div>
                    
                    <div class="col-span-2">
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Fonctionnalités</label>
                        <div id="features-list" class="space-y-2 mb-2">
                            <!-- Features dynamiques -->
                        </div>
                        <button type="button" onclick="addFeature()" class="text-indigo-600 hover:text-indigo-700 font-semibold">
                            + Ajouter une fonctionnalité
                        </button>
                    </div>
                </div>

                <div class="flex gap-3">
                    <button type="submit" class="flex-1 bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700">
                        💾 Enregistrer
                    </button>
                    <button type="button" onclick="closePlanModal()" class="px-6 py-3 border rounded-lg hover:bg-gray-50">
                        Annuler
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Subscription -->
    <div id="subscription-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-2xl font-bold">Nouvel Abonnement</h3>
                <button onclick="closeSubscriptionModal()" class="text-gray-400 hover:text-gray-600 text-2xl">×</button>
            </div>
            
            <form id="subscription-form" onsubmit="createSubscription(event)">
                <div class="space-y-4 mb-6">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Client *</label>
                        <select name="user_id" id="sub-user" required
                                class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                            <option value="">Sélectionner un client...</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Plan *</label>
                        <select name="plan_id" id="sub-plan" required
                                class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                            <option value="">Sélectionner un plan...</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Date de début</label>
                        <input type="date" name="start_date" id="sub-start"
                               class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Méthode de paiement</label>
                        <select name="payment_method" id="sub-payment"
                                class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                            <option value="wallet">Wallet</option>
                            <option value="manual">Manuel</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Notes</label>
                        <textarea name="notes" id="sub-notes" rows="3"
                                  placeholder="Notes internes..."
                                  class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"></textarea>
                    </div>
                </div>

                <div class="flex gap-3">
                    <button type="submit" class="flex-1 bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700">
                        ✅ Créer l'abonnement
                    </button>
                    <button type="button" onclick="closeSubscriptionModal()" class="px-6 py-3 border rounded-lg hover:bg-gray-50">
                        Annuler
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Détails Subscription -->
    <div id="details-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-xl shadow-2xl max-w-3xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-2xl font-bold">Détails de l'Abonnement</h3>
                <button onclick="closeDetailsModal()" class="text-gray-400 hover:text-gray-600 text-2xl">×</button>
            </div>
            
            <div id="subscription-details">
                <!-- Chargé via JS -->
            </div>
        </div>
    </div>

    <!-- Notification -->
    <div id="notification" class="hidden fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50"></div>

    <script>
        let allPlans = [];
        let allSubscriptions = [];
        let allUsers = [];
        let currentFeatures = [];

        window.addEventListener('load', () => {
            loadPlans();
            loadUsers();
            document.getElementById('sub-start').valueAsDate = new Date();
        });

        // ==================== TABS ====================
        
        function switchTab(tab) {
            // Update tabs
            document.querySelectorAll('[id^="tab-"]').forEach(el => {
                el.className = 'px-6 py-4 font-semibold text-gray-600 hover:text-gray-800';
            });
            document.getElementById('tab-' + tab).className = 'px-6 py-4 font-semibold border-b-2 border-indigo-600 text-indigo-600';
            
            // Update content
            document.querySelectorAll('[id^="content-"]').forEach(el => {
                el.classList.add('hidden');
            });
            document.getElementById('content-' + tab).classList.remove('hidden');
            
            // Load data
            if (tab === 'subscriptions' && allSubscriptions.length === 0) {
                loadSubscriptions();
            }
        }

        // ==================== PLANS ====================
        
        async function loadPlans() {
            const response = await fetch('/api/subscriptions.php?action=get_plans');
            const result = await response.json();
            
            if (result.success) {
                allPlans = result.plans;
                displayPlans(allPlans);
                
                // Populate plan select
                const planSelect = document.getElementById('sub-plan');
                planSelect.innerHTML = '<option value="">Sélectionner un plan...</option>';
                allPlans.forEach(plan => {
                    planSelect.innerHTML += `<option value="${plan.id}">${plan.name} - ${plan.price}€/${plan.billing_period}</option>`;
                });
            }
        }

        function displayPlans(plans) {
            const grid = document.getElementById('plans-grid');
            grid.innerHTML = plans.map(plan => `
                <div class="bg-white border-2 rounded-xl p-6 ${plan.is_popular ? 'border-indigo-500 shadow-lg' : 'border-gray-200'} hover:shadow-xl transition">
                    ${plan.is_popular ? '<div class="text-center mb-3"><span class="bg-indigo-600 text-white px-3 py-1 rounded-full text-sm font-bold">POPULAIRE</span></div>' : ''}
                    <h3 class="text-2xl font-bold mb-2">${plan.name}</h3>
                    <p class="text-gray-600 mb-4">${plan.description || ''}</p>
                    <div class="text-center mb-4">
                        <span class="text-4xl font-bold text-indigo-600">${plan.price}€</span>
                        <span class="text-gray-600">/${getPeriodLabel(plan.billing_period)}</span>
                    </div>
                    ${plan.trial_days > 0 ? `<div class="text-center text-sm text-green-600 mb-4">🎁 ${plan.trial_days} jours d'essai gratuit</div>` : ''}
                    <ul class="space-y-2 mb-6">
                        ${(plan.features || []).map(f => `<li class="flex items-start gap-2"><span class="text-green-600">✓</span><span class="text-sm">${f}</span></li>`).join('')}
                    </ul>
                    <div class="space-y-2">
                        <button onclick='editPlan(${JSON.stringify(plan)})' class="w-full bg-indigo-100 text-indigo-700 py-2 rounded-lg hover:bg-indigo-200 font-semibold">
                            ✏️ Modifier
                        </button>
                        <button onclick="deletePlan(${plan.id})" class="w-full bg-red-100 text-red-700 py-2 rounded-lg hover:bg-red-200 font-semibold">
                            🗑️ Supprimer
                        </button>
                    </div>
                </div>
            `).join('');
        }

        function getPeriodLabel(period) {
            const labels = {
                daily: 'jour',
                weekly: 'semaine',
                monthly: 'mois',
                quarterly: 'trimestre',
                yearly: 'an'
            };
            return labels[period] || period;
        }

        function openPlanModal() {
            document.getElementById('plan-modal-title').textContent = 'Nouveau Plan';
            document.getElementById('plan-form').reset();
            document.getElementById('plan-id').value = '';
            currentFeatures = [];
            addFeature();
            document.getElementById('plan-modal').classList.remove('hidden');
        }

        function closePlanModal() {
            document.getElementById('plan-modal').classList.add('hidden');
        }

        function editPlan(plan) {
            document.getElementById('plan-modal-title').textContent = 'Modifier le Plan';
            document.getElementById('plan-id').value = plan.id;
            document.getElementById('plan-name').value = plan.name;
            document.getElementById('plan-description').value = plan.description || '';
            document.getElementById('plan-price').value = plan.price;
            document.getElementById('plan-period').value = plan.billing_period;
            document.getElementById('plan-trial').value = plan.trial_days || '';
            document.getElementById('plan-users').value = plan.max_users || '';
            document.getElementById('plan-storage').value = plan.max_storage || '';
            document.getElementById('plan-status').value = plan.status;
            document.getElementById('plan-popular').checked = plan.is_popular == 1;
            
            currentFeatures = plan.features || [];
            renderFeatures();
            
            document.getElementById('plan-modal').classList.remove('hidden');
        }

        function addFeature() {
            currentFeatures.push('');
            renderFeatures();
        }

        function removeFeature(index) {
            currentFeatures.splice(index, 1);
            renderFeatures();
        }

        function renderFeatures() {
            const list = document.getElementById('features-list');
            list.innerHTML = currentFeatures.map((f, i) => `
                <div class="flex gap-2">
                    <input type="text" value="${f}" onchange="currentFeatures[${i}] = this.value"
                           placeholder="ex: Support 24/7"
                           class="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                    <button type="button" onclick="removeFeature(${i})" class="px-3 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200">
                        ×
                    </button>
                </div>
            `).join('');
        }

        async function savePlan(e) {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            const planId = document.getElementById('plan-id').value;
            
            formData.append('action', planId ? 'update_plan' : 'create_plan');
            formData.append('features', JSON.stringify(currentFeatures.filter(f => f.trim())));
            
            const response = await fetch('/api/subscriptions.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                showNotification('✅ Plan enregistré avec succès !', 'success');
                closePlanModal();
                await loadPlans();
            } else {
                showNotification('❌ ' + result.error, 'error');
            }
        }

        async function deletePlan(planId) {
            if (!confirm('Êtes-vous sûr de vouloir supprimer ce plan ?')) return;
            
            const formData = new FormData();
            formData.append('action', 'delete_plan');
            formData.append('plan_id', planId);
            
            const response = await fetch('/api/subscriptions.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                showNotification('✅ Plan supprimé', 'success');
                await loadPlans();
            } else {
                showNotification('❌ ' + result.error, 'error');
            }
        }

        // ==================== SUBSCRIPTIONS ====================
        
        async function loadSubscriptions(status = null) {
            let url = '/api/subscriptions.php?action=get_subscriptions';
            if (status) url += '&status=' + status;
            
            const response = await fetch(url);
            const result = await response.json();
            
            if (result.success) {
                allSubscriptions = result.subscriptions;
                displaySubscriptions(allSubscriptions);
            }
        }

        function displaySubscriptions(subs) {
            const tbody = document.getElementById('subscriptions-tbody');
            tbody.innerHTML = subs.map(sub => `
                <tr class="border-b hover:bg-gray-50">
                    <td class="p-3">
                        <div class="font-semibold">${sub.full_name}</div>
                        <div class="text-sm text-gray-600">${sub.email}</div>
                    </td>
                    <td class="p-3">${sub.plan_name}</td>
                    <td class="p-3 text-right font-bold">${parseFloat(sub.amount).toFixed(2)} €</td>
                    <td class="p-3 text-center">
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded text-sm">${getPeriodLabel(sub.billing_period)}</span>
                    </td>
                    <td class="p-3 text-center">
                        <span class="px-2 py-1 rounded text-sm ${getStatusClass(sub.status)}">${getStatusLabel(sub.status)}</span>
                    </td>
                    <td class="p-3 text-center text-sm">${sub.next_billing_date || '-'}</td>
                    <td class="p-3 text-right">
                        <button onclick="viewSubscription(${sub.id})" class="bg-indigo-100 text-indigo-700 px-3 py-1 rounded hover:bg-indigo-200 text-sm font-semibold mr-1">
                            👁️ Voir
                        </button>
                        ${sub.status === 'active' || sub.status === 'trial' ? `
                            <button onclick="suspendSubscription(${sub.id})" class="bg-yellow-100 text-yellow-700 px-3 py-1 rounded hover:bg-yellow-200 text-sm font-semibold">
                                ⏸️ Suspendre
                            </button>
                        ` : ''}
                        ${sub.status === 'suspended' ? `
                            <button onclick="reactivateSubscription(${sub.id})" class="bg-green-100 text-green-700 px-3 py-1 rounded hover:bg-green-200 text-sm font-semibold">
                                ▶️ Réactiver
                            </button>
                        ` : ''}
                    </td>
                </tr>
            `).join('');
        }

        function getStatusClass(status) {
            const classes = {
                trial: 'bg-blue-100 text-blue-700',
                active: 'bg-green-100 text-green-700',
                suspended: 'bg-yellow-100 text-yellow-700',
                cancelled: 'bg-red-100 text-red-700',
                expired: 'bg-gray-100 text-gray-700'
            };
            return classes[status] || 'bg-gray-100 text-gray-700';
        }

        function getStatusLabel(status) {
            const labels = {
                trial: 'Essai',
                active: 'Actif',
                suspended: 'Suspendu',
                cancelled: 'Annulé',
                expired: 'Expiré'
            };
            return labels[status] || status;
        }

        function filterSubscriptions() {
            const status = document.getElementById('filter-status').value;
            loadSubscriptions(status || null);
        }

        async function loadUsers() {
            const response = await fetch('/api/admin.php?action=get_all_users');
            const result = await response.json();
            
            if (result.success) {
                allUsers = result.users;
                
                // Populate user select
                const userSelect = document.getElementById('sub-user');
                userSelect.innerHTML = '<option value="">Sélectionner un client...</option>';
                allUsers.forEach(user => {
                    userSelect.innerHTML += `<option value="${user.id}">${user.full_name} (${user.email})</option>`;
                });
            }
        }

        function openSubscriptionModal() {
            document.getElementById('subscription-form').reset();
            document.getElementById('sub-start').valueAsDate = new Date();
            document.getElementById('subscription-modal').classList.remove('hidden');
        }

        function closeSubscriptionModal() {
            document.getElementById('subscription-modal').classList.add('hidden');
        }

        async function createSubscription(e) {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            formData.append('action', 'create_subscription');
            
            const response = await fetch('/api/subscriptions.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                showNotification('✅ Abonnement créé avec succès !', 'success');
                closeSubscriptionModal();
                await loadSubscriptions();
            } else {
                showNotification('❌ ' + result.error, 'error');
            }
        }

        async function viewSubscription(id) {
            const response = await fetch('/api/subscriptions.php?action=get_subscription&subscription_id=' + id);
            const result = await response.json();
            
            if (result.success) {
                const sub = result.subscription;
                document.getElementById('subscription-details').innerHTML = `
                    <div class="space-y-6">
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="text-sm text-gray-600">Client</label>
                                <p class="font-semibold">${sub.full_name}</p>
                                <p class="text-sm text-gray-600">${sub.email}</p>
                            </div>
                            <div>
                                <label class="text-sm text-gray-600">Plan</label>
                                <p class="font-semibold">${sub.plan_name}</p>
                            </div>
                            <div>
                                <label class="text-sm text-gray-600">Montant</label>
                                <p class="font-semibold text-lg">${parseFloat(sub.amount).toFixed(2)} €</p>
                            </div>
                            <div>
                                <label class="text-sm text-gray-600">Statut</label>
                                <p><span class="px-3 py-1 rounded ${getStatusClass(sub.status)}">${getStatusLabel(sub.status)}</span></p>
                            </div>
                            <div>
                                <label class="text-sm text-gray-600">Date de début</label>
                                <p class="font-semibold">${sub.start_date}</p>
                            </div>
                            <div>
                                <label class="text-sm text-gray-600">Prochaine facturation</label>
                                <p class="font-semibold">${sub.next_billing_date || '-'}</p>
                            </div>
                        </div>
                        
                        ${sub.plan_features && sub.plan_features.length > 0 ? `
                        <div>
                            <h4 class="font-semibold mb-2">Fonctionnalités incluses</h4>
                            <ul class="space-y-1">
                                ${sub.plan_features.map(f => `<li class="flex items-start gap-2"><span class="text-green-600">✓</span><span class="text-sm">${f}</span></li>`).join('')}
                            </ul>
                        </div>
                        ` : ''}
                        
                        ${sub.items && sub.items.length > 0 ? `
                        <div>
                            <h4 class="font-semibold mb-2">Items / Services</h4>
                            <table class="w-full text-sm">
                                <thead>
                                    <tr class="border-b">
                                        <th class="text-left p-2">Nom</th>
                                        <th class="text-center p-2">Qté</th>
                                        <th class="text-right p-2">Prix unitaire</th>
                                        <th class="text-right p-2">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${sub.items.map(item => `
                                        <tr class="border-b">
                                            <td class="p-2">${item.item_name}</td>
                                            <td class="text-center p-2">${item.quantity}</td>
                                            <td class="text-right p-2">${parseFloat(item.unit_price).toFixed(2)} €</td>
                                            <td class="text-right p-2 font-semibold">${parseFloat(item.total_price).toFixed(2)} €</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                        ` : ''}
                        
                        ${sub.notes ? `
                        <div>
                            <label class="text-sm text-gray-600">Notes</label>
                            <p class="text-sm bg-gray-50 p-3 rounded">${sub.notes}</p>
                        </div>
                        ` : ''}
                        
                        <div class="flex gap-2 pt-4 border-t">
                            ${sub.status === 'active' || sub.status === 'trial' ? `
                                <button onclick="suspendSubscription(${sub.id}); closeDetailsModal();" class="flex-1 bg-yellow-600 text-white py-2 rounded-lg hover:bg-yellow-700 font-semibold">
                                    ⏸️ Suspendre
                                </button>
                            ` : ''}
                            ${sub.status === 'suspended' ? `
                                <button onclick="reactivateSubscription(${sub.id}); closeDetailsModal();" class="flex-1 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 font-semibold">
                                    ▶️ Réactiver
                                </button>
                            ` : ''}
                            <button onclick="cancelSubscription(${sub.id}); closeDetailsModal();" class="flex-1 bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 font-semibold">
                                ❌ Annuler
                            </button>
                        </div>
                    </div>
                `;
                document.getElementById('details-modal').classList.remove('hidden');
            }
        }

        function closeDetailsModal() {
            document.getElementById('details-modal').classList.add('hidden');
        }

        async function suspendSubscription(id) {
            const reason = prompt('Raison de la suspension :');
            if (!reason) return;
            
            const formData = new FormData();
            formData.append('action', 'suspend_subscription');
            formData.append('subscription_id', id);
            formData.append('reason', reason);
            
            const response = await fetch('/api/subscriptions.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                showNotification('✅ Abonnement suspendu', 'success');
                await loadSubscriptions();
            } else {
                showNotification('❌ ' + result.error, 'error');
            }
        }

        async function reactivateSubscription(id) {
            if (!confirm('Réactiver cet abonnement ?')) return;
            
            const formData = new FormData();
            formData.append('action', 'reactivate_subscription');
            formData.append('subscription_id', id);
            
            const response = await fetch('/api/subscriptions.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                showNotification('✅ Abonnement réactivé', 'success');
                await loadSubscriptions();
            } else {
                showNotification('❌ ' + result.error, 'error');
            }
        }

        async function cancelSubscription(id) {
            const reason = prompt('Raison de l\'annulation :');
            if (!reason) return;
            
            const formData = new FormData();
            formData.append('action', 'cancel_subscription');
            formData.append('subscription_id', id);
            formData.append('reason', reason);
            
            const response = await fetch('/api/subscriptions.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                showNotification('✅ Abonnement annulé', 'success');
                await loadSubscriptions();
            } else {
                showNotification('❌ ' + result.error, 'error');
            }
        }

        // ==================== UTILS ====================

        async function logout() {
            const formData = new FormData();
            formData.append('action', 'logout');
            await fetch('/api/auth.php', { method: 'POST', body: formData });
            window.location.href = '/login.html';
        }

        function showNotification(message, type) {
            const notification = document.getElementById('notification');
            const colors = {
                success: 'border-green-500 bg-green-50',
                error: 'border-red-500 bg-red-50',
                info: 'border-blue-500 bg-blue-50'
            };
            
            notification.className = `fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50 ${colors[type]}`;
            notification.textContent = message;
            notification.classList.remove('hidden');
            
            setTimeout(() => notification.classList.add('hidden'), 5000);
        }
    </script>
</body>
</html>
