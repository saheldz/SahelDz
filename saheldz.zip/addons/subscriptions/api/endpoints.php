<?php
/**
 * API de gestion des abonnements
 * Gère les plans d'abonnement, les souscriptions et les items
 */

header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../config/auth-check.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Non authentifié']);
    exit;
}

$pdo = getDB();
$action = $_GET['action'] ?? $_POST['action'] ?? '';
$userId = $_SESSION['user_id'];
$userRole = $_SESSION['role'] ?? 'client';

try {
    switch ($action) {
        
        // ==================== PLANS ====================
        
        case 'get_plans':
            // Récupérer tous les plans actifs
            $status = $_GET['status'] ?? 'active';
            $query = "SELECT * FROM subscription_plans WHERE status = ? ORDER BY sort_order ASC, price ASC";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$status]);
            $plans = $stmt->fetchAll();
            
            // Décoder les features JSON
            foreach ($plans as &$plan) {
                $plan['features'] = json_decode($plan['features'], true);
            }
            
            echo json_encode(['success' => true, 'plans' => $plans]);
            break;
            
        case 'get_plan':
            // Récupérer un plan spécifique
            $planId = $_GET['plan_id'] ?? 0;
            $stmt = $pdo->prepare("SELECT * FROM subscription_plans WHERE id = ?");
            $stmt->execute([$planId]);
            $plan = $stmt->fetch();
            
            if ($plan) {
                $plan['features'] = json_decode($plan['features'], true);
                echo json_encode(['success' => true, 'plan' => $plan]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Plan non trouvé']);
            }
            break;
            
        case 'create_plan':
            // Créer un nouveau plan (admin seulement)
            if ($userRole !== 'admin') {
                throw new Exception('Accès refusé');
            }
            
            $name = $_POST['name'] ?? '';
            $description = $_POST['description'] ?? '';
            $price = $_POST['price'] ?? 0;
            $billing_period = $_POST['billing_period'] ?? 'monthly';
            $trial_days = $_POST['trial_days'] ?? 0;
            $features = $_POST['features'] ?? '[]';
            $max_users = $_POST['max_users'] ?? null;
            $max_storage = $_POST['max_storage'] ?? null;
            $is_popular = isset($_POST['is_popular']) ? 1 : 0;
            
            if (empty($name)) {
                throw new Exception('Le nom du plan est requis');
            }
            
            // Convertir features en JSON si c'est un tableau
            if (is_array($features)) {
                $features = json_encode($features);
            }
            
            $stmt = $pdo->prepare("
                INSERT INTO subscription_plans 
                (name, description, price, billing_period, trial_days, features, max_users, max_storage, is_popular)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $name, $description, $price, $billing_period, $trial_days, 
                $features, $max_users, $max_storage, $is_popular
            ]);
            
            echo json_encode(['success' => true, 'plan_id' => $pdo->lastInsertId()]);
            break;
            
        case 'update_plan':
            // Mettre à jour un plan (admin seulement)
            if ($userRole !== 'admin') {
                throw new Exception('Accès refusé');
            }
            
            $planId = $_POST['plan_id'] ?? 0;
            $name = $_POST['name'] ?? '';
            $description = $_POST['description'] ?? '';
            $price = $_POST['price'] ?? 0;
            $billing_period = $_POST['billing_period'] ?? 'monthly';
            $trial_days = $_POST['trial_days'] ?? 0;
            $features = $_POST['features'] ?? '[]';
            $max_users = $_POST['max_users'] ?? null;
            $max_storage = $_POST['max_storage'] ?? null;
            $status = $_POST['status'] ?? 'active';
            $is_popular = isset($_POST['is_popular']) ? 1 : 0;
            
            if (is_array($features)) {
                $features = json_encode($features);
            }
            
            $stmt = $pdo->prepare("
                UPDATE subscription_plans 
                SET name = ?, description = ?, price = ?, billing_period = ?, 
                    trial_days = ?, features = ?, max_users = ?, max_storage = ?, 
                    status = ?, is_popular = ?
                WHERE id = ?
            ");
            
            $stmt->execute([
                $name, $description, $price, $billing_period, $trial_days,
                $features, $max_users, $max_storage, $status, $is_popular, $planId
            ]);
            
            echo json_encode(['success' => true]);
            break;
            
        case 'delete_plan':
            // Supprimer un plan (admin seulement)
            if ($userRole !== 'admin') {
                throw new Exception('Accès refusé');
            }
            
            $planId = $_POST['plan_id'] ?? 0;
            
            // Vérifier s'il y a des abonnements actifs
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM subscriptions WHERE plan_id = ? AND status IN ('active', 'trial')");
            $stmt->execute([$planId]);
            $result = $stmt->fetch();
            
            if ($result['count'] > 0) {
                throw new Exception('Impossible de supprimer un plan avec des abonnements actifs');
            }
            
            // Archiver au lieu de supprimer
            $stmt = $pdo->prepare("UPDATE subscription_plans SET status = 'archived' WHERE id = ?");
            $stmt->execute([$planId]);
            
            echo json_encode(['success' => true]);
            break;
            
        // ==================== SUBSCRIPTIONS ====================
        
        case 'get_subscriptions':
            // Récupérer les abonnements
            if ($userRole === 'admin') {
                // Admin voit tous les abonnements
                $status = $_GET['status'] ?? null;
                $query = "
                    SELECT s.*, p.name as plan_name, p.price as plan_price, 
                           u.full_name, u.email
                    FROM subscriptions s
                    JOIN subscription_plans p ON s.plan_id = p.id
                    JOIN users u ON s.user_id = u.id
                ";
                
                if ($status) {
                    $query .= " WHERE s.status = ?";
                    $stmt = $pdo->prepare($query . " ORDER BY s.created_at DESC");
                    $stmt->execute([$status]);
                } else {
                    $stmt = $pdo->prepare($query . " ORDER BY s.created_at DESC");
                    $stmt->execute();
                }
            } else {
                // Utilisateur voit seulement ses abonnements
                $query = "
                    SELECT s.*, p.name as plan_name, p.price as plan_price
                    FROM subscriptions s
                    JOIN subscription_plans p ON s.plan_id = p.id
                    WHERE s.user_id = ?
                    ORDER BY s.created_at DESC
                ";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$userId]);
            }
            
            $subscriptions = $stmt->fetchAll();
            echo json_encode(['success' => true, 'subscriptions' => $subscriptions]);
            break;
            
        case 'get_subscription':
            // Récupérer un abonnement spécifique
            $subscriptionId = $_GET['subscription_id'] ?? 0;
            
            $query = "
                SELECT s.*, p.name as plan_name, p.description as plan_description,
                       p.features as plan_features, u.full_name, u.email
                FROM subscriptions s
                JOIN subscription_plans p ON s.plan_id = p.id
                JOIN users u ON s.user_id = u.id
                WHERE s.id = ?
            ";
            
            if ($userRole !== 'admin') {
                $query .= " AND s.user_id = ?";
                $stmt = $pdo->prepare($query);
                $stmt->execute([$subscriptionId, $userId]);
            } else {
                $stmt = $pdo->prepare($query);
                $stmt->execute([$subscriptionId]);
            }
            
            $subscription = $stmt->fetch();
            
            if ($subscription) {
                $subscription['plan_features'] = json_decode($subscription['plan_features'], true);
                
                // Récupérer les items
                $stmt = $pdo->prepare("SELECT * FROM subscription_items WHERE subscription_id = ?");
                $stmt->execute([$subscriptionId]);
                $subscription['items'] = $stmt->fetchAll();
                
                echo json_encode(['success' => true, 'subscription' => $subscription]);
            } else {
                echo json_encode(['success' => false, 'error' => 'Abonnement non trouvé']);
            }
            break;
            
        case 'create_subscription':
            // Créer un nouvel abonnement
            $targetUserId = $_POST['user_id'] ?? $userId;
            $planId = $_POST['plan_id'] ?? 0;
            $startDate = $_POST['start_date'] ?? date('Y-m-d');
            $paymentMethod = $_POST['payment_method'] ?? 'wallet';
            $notes = $_POST['notes'] ?? '';
            
            // Vérifier les permissions
            if ($userRole !== 'admin' && $targetUserId != $userId) {
                throw new Exception('Accès refusé');
            }
            
            // Récupérer les infos du plan
            $stmt = $pdo->prepare("SELECT * FROM subscription_plans WHERE id = ? AND status = 'active'");
            $stmt->execute([$planId]);
            $plan = $stmt->fetch();
            
            if (!$plan) {
                throw new Exception('Plan non trouvé ou inactif');
            }
            
            // Calculer les dates
            $trialEndsAt = null;
            $nextBillingDate = null;
            $status = 'active';
            
            if ($plan['trial_days'] > 0) {
                $status = 'trial';
                $trialEndsAt = date('Y-m-d', strtotime($startDate . ' + ' . $plan['trial_days'] . ' days'));
                $nextBillingDate = $trialEndsAt;
            } else {
                // Calculer la prochaine date de facturation
                switch ($plan['billing_period']) {
                    case 'daily':
                        $nextBillingDate = date('Y-m-d', strtotime($startDate . ' + 1 day'));
                        break;
                    case 'weekly':
                        $nextBillingDate = date('Y-m-d', strtotime($startDate . ' + 1 week'));
                        break;
                    case 'monthly':
                        $nextBillingDate = date('Y-m-d', strtotime($startDate . ' + 1 month'));
                        break;
                    case 'quarterly':
                        $nextBillingDate = date('Y-m-d', strtotime($startDate . ' + 3 months'));
                        break;
                    case 'yearly':
                        $nextBillingDate = date('Y-m-d', strtotime($startDate . ' + 1 year'));
                        break;
                }
            }
            
            // Vérifier le wallet si paiement par wallet
            if ($paymentMethod === 'wallet' && $plan['price'] > 0 && $status !== 'trial') {
                $stmt = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ?");
                $stmt->execute([$targetUserId]);
                $wallet = $stmt->fetch();
                
                if (!$wallet || $wallet['balance'] < $plan['price']) {
                    throw new Exception('Solde insuffisant dans le wallet');
                }
            }
            
            $pdo->beginTransaction();
            
            try {
                // Créer l'abonnement
                $stmt = $pdo->prepare("
                    INSERT INTO subscriptions 
                    (user_id, plan_id, status, start_date, next_billing_date, trial_ends_at, 
                     amount, billing_period, payment_method, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $stmt->execute([
                    $targetUserId, $planId, $status, $startDate, $nextBillingDate,
                    $trialEndsAt, $plan['price'], $plan['billing_period'], $paymentMethod, $notes
                ]);
                
                $subscriptionId = $pdo->lastInsertId();
                
                // Déduire du wallet si nécessaire
                if ($paymentMethod === 'wallet' && $plan['price'] > 0 && $status !== 'trial') {
                    $stmt = $pdo->prepare("UPDATE wallets SET balance = balance - ? WHERE user_id = ?");
                    $stmt->execute([$plan['price'], $targetUserId]);
                    
                    // Créer une transaction
                    $stmt = $pdo->prepare("
                        INSERT INTO transactions (user_id, type, amount, description, status)
                        VALUES (?, 'debit', ?, ?, 'completed')
                    ");
                    $stmt->execute([
                        $targetUserId,
                        $plan['price'],
                        "Abonnement - " . $plan['name']
                    ]);
                }
                
                // Enregistrer dans l'historique
                $stmt = $pdo->prepare("
                    INSERT INTO subscription_history 
                    (subscription_id, action, new_status, amount, description, created_by)
                    VALUES (?, 'created', ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $subscriptionId,
                    $status,
                    $plan['price'],
                    "Abonnement créé - " . $plan['name'],
                    $userId
                ]);
                
                $pdo->commit();
                
                echo json_encode([
                    'success' => true,
                    'subscription_id' => $subscriptionId,
                    'message' => 'Abonnement créé avec succès'
                ]);
                
            } catch (Exception $e) {
                $pdo->rollBack();
                throw $e;
            }
            break;
            
        case 'update_subscription':
            // Mettre à jour un abonnement (admin seulement)
            if ($userRole !== 'admin') {
                throw new Exception('Accès refusé');
            }
            
            $subscriptionId = $_POST['subscription_id'] ?? 0;
            $status = $_POST['status'] ?? null;
            $nextBillingDate = $_POST['next_billing_date'] ?? null;
            $autoRenew = isset($_POST['auto_renew']) ? ($_POST['auto_renew'] ? 1 : 0) : null;
            $notes = $_POST['notes'] ?? null;
            
            $updates = [];
            $params = [];
            
            if ($status !== null) {
                $updates[] = "status = ?";
                $params[] = $status;
            }
            if ($nextBillingDate !== null) {
                $updates[] = "next_billing_date = ?";
                $params[] = $nextBillingDate;
            }
            if ($autoRenew !== null) {
                $updates[] = "auto_renew = ?";
                $params[] = $autoRenew;
            }
            if ($notes !== null) {
                $updates[] = "notes = ?";
                $params[] = $notes;
            }
            
            if (empty($updates)) {
                throw new Exception('Aucune mise à jour spécifiée');
            }
            
            $params[] = $subscriptionId;
            
            $stmt = $pdo->prepare("UPDATE subscriptions SET " . implode(', ', $updates) . " WHERE id = ?");
            $stmt->execute($params);
            
            echo json_encode(['success' => true]);
            break;
            
        case 'suspend_subscription':
            // Suspendre un abonnement (admin seulement)
            if ($userRole !== 'admin') {
                throw new Exception('Accès refusé');
            }
            
            $subscriptionId = $_POST['subscription_id'] ?? 0;
            $reason = $_POST['reason'] ?? '';
            
            $pdo->beginTransaction();
            
            try {
                // Récupérer l'ancien statut
                $stmt = $pdo->prepare("SELECT status FROM subscriptions WHERE id = ?");
                $stmt->execute([$subscriptionId]);
                $oldStatus = $stmt->fetchColumn();
                
                // Suspendre
                $stmt = $pdo->prepare("UPDATE subscriptions SET status = 'suspended' WHERE id = ?");
                $stmt->execute([$subscriptionId]);
                
                // Historique
                $stmt = $pdo->prepare("
                    INSERT INTO subscription_history 
                    (subscription_id, action, old_status, new_status, description, created_by)
                    VALUES (?, 'suspended', ?, 'suspended', ?, ?)
                ");
                $stmt->execute([$subscriptionId, $oldStatus, $reason, $userId]);
                
                $pdo->commit();
                echo json_encode(['success' => true, 'message' => 'Abonnement suspendu']);
                
            } catch (Exception $e) {
                $pdo->rollBack();
                throw $e;
            }
            break;
            
        case 'cancel_subscription':
            // Annuler un abonnement
            $subscriptionId = $_POST['subscription_id'] ?? 0;
            $reason = $_POST['reason'] ?? '';
            
            // Vérifier la permission
            $stmt = $pdo->prepare("SELECT user_id, status FROM subscriptions WHERE id = ?");
            $stmt->execute([$subscriptionId]);
            $subscription = $stmt->fetch();
            
            if (!$subscription) {
                throw new Exception('Abonnement non trouvé');
            }
            
            if ($userRole !== 'admin' && $subscription['user_id'] != $userId) {
                throw new Exception('Accès refusé');
            }
            
            $pdo->beginTransaction();
            
            try {
                // Annuler
                $stmt = $pdo->prepare("
                    UPDATE subscriptions 
                    SET status = 'cancelled', cancelled_at = NOW(), cancel_reason = ?, auto_renew = 0
                    WHERE id = ?
                ");
                $stmt->execute([$reason, $subscriptionId]);
                
                // Historique
                $stmt = $pdo->prepare("
                    INSERT INTO subscription_history 
                    (subscription_id, action, old_status, new_status, description, created_by)
                    VALUES (?, 'cancelled', ?, 'cancelled', ?, ?)
                ");
                $stmt->execute([$subscriptionId, $subscription['status'], $reason, $userId]);
                
                $pdo->commit();
                echo json_encode(['success' => true, 'message' => 'Abonnement annulé']);
                
            } catch (Exception $e) {
                $pdo->rollBack();
                throw $e;
            }
            break;
            
        case 'reactivate_subscription':
            // Réactiver un abonnement (admin seulement)
            if ($userRole !== 'admin') {
                throw new Exception('Accès refusé');
            }
            
            $subscriptionId = $_POST['subscription_id'] ?? 0;
            
            $pdo->beginTransaction();
            
            try {
                $stmt = $pdo->prepare("SELECT status FROM subscriptions WHERE id = ?");
                $stmt->execute([$subscriptionId]);
                $oldStatus = $stmt->fetchColumn();
                
                $stmt = $pdo->prepare("UPDATE subscriptions SET status = 'active', auto_renew = 1 WHERE id = ?");
                $stmt->execute([$subscriptionId]);
                
                $stmt = $pdo->prepare("
                    INSERT INTO subscription_history 
                    (subscription_id, action, old_status, new_status, description, created_by)
                    VALUES (?, 'reactivated', ?, 'active', 'Abonnement réactivé', ?)
                ");
                $stmt->execute([$subscriptionId, $oldStatus, $userId]);
                
                $pdo->commit();
                echo json_encode(['success' => true, 'message' => 'Abonnement réactivé']);
                
            } catch (Exception $e) {
                $pdo->rollBack();
                throw $e;
            }
            break;
            
        // ==================== ITEMS ====================
        
        case 'add_item':
            // Ajouter un item à un abonnement (admin seulement)
            if ($userRole !== 'admin') {
                throw new Exception('Accès refusé');
            }
            
            $subscriptionId = $_POST['subscription_id'] ?? 0;
            $itemType = $_POST['item_type'] ?? 'service';
            $itemName = $_POST['item_name'] ?? '';
            $itemDescription = $_POST['item_description'] ?? '';
            $quantity = $_POST['quantity'] ?? 1;
            $unitPrice = $_POST['unit_price'] ?? 0;
            $totalPrice = $quantity * $unitPrice;
            
            if (empty($itemName)) {
                throw new Exception('Le nom de l\'item est requis');
            }
            
            $stmt = $pdo->prepare("
                INSERT INTO subscription_items 
                (subscription_id, item_type, item_name, item_description, quantity, unit_price, total_price)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $subscriptionId, $itemType, $itemName, $itemDescription,
                $quantity, $unitPrice, $totalPrice
            ]);
            
            echo json_encode(['success' => true, 'item_id' => $pdo->lastInsertId()]);
            break;
            
        case 'update_item':
            // Mettre à jour un item (admin seulement)
            if ($userRole !== 'admin') {
                throw new Exception('Accès refusé');
            }
            
            $itemId = $_POST['item_id'] ?? 0;
            $quantity = $_POST['quantity'] ?? 1;
            $unitPrice = $_POST['unit_price'] ?? 0;
            $totalPrice = $quantity * $unitPrice;
            
            $stmt = $pdo->prepare("
                UPDATE subscription_items 
                SET quantity = ?, unit_price = ?, total_price = ?
                WHERE id = ?
            ");
            
            $stmt->execute([$quantity, $unitPrice, $totalPrice, $itemId]);
            echo json_encode(['success' => true]);
            break;
            
        case 'delete_item':
            // Supprimer un item (admin seulement)
            if ($userRole !== 'admin') {
                throw new Exception('Accès refusé');
            }
            
            $itemId = $_POST['item_id'] ?? 0;
            $stmt = $pdo->prepare("DELETE FROM subscription_items WHERE id = ?");
            $stmt->execute([$itemId]);
            
            echo json_encode(['success' => true]);
            break;
            
        case 'get_history':
            // Récupérer l'historique d'un abonnement
            $subscriptionId = $_GET['subscription_id'] ?? 0;
            
            // Vérifier la permission
            if ($userRole !== 'admin') {
                $stmt = $pdo->prepare("SELECT user_id FROM subscriptions WHERE id = ?");
                $stmt->execute([$subscriptionId]);
                $sub = $stmt->fetch();
                
                if (!$sub || $sub['user_id'] != $userId) {
                    throw new Exception('Accès refusé');
                }
            }
            
            $query = "
                SELECT h.*, u.full_name as created_by_name
                FROM subscription_history h
                LEFT JOIN users u ON h.created_by = u.id
                WHERE h.subscription_id = ?
                ORDER BY h.created_at DESC
            ";
            
            $stmt = $pdo->prepare($query);
            $stmt->execute([$subscriptionId]);
            $history = $stmt->fetchAll();
            
            echo json_encode(['success' => true, 'history' => $history]);
            break;
            
        case 'get_stats':
            // Récupérer les statistiques (admin seulement)
            if ($userRole !== 'admin') {
                throw new Exception('Accès refusé');
            }
            
            // Total abonnements
            $stmt = $pdo->query("SELECT COUNT(*) as total FROM subscriptions");
            $stats['total_subscriptions'] = $stmt->fetchColumn();
            
            // Par statut
            $stmt = $pdo->query("
                SELECT status, COUNT(*) as count 
                FROM subscriptions 
                GROUP BY status
            ");
            $stats['by_status'] = $stmt->fetchAll();
            
            // Revenu mensuel estimé
            $stmt = $pdo->query("
                SELECT SUM(amount) as monthly_revenue
                FROM subscriptions
                WHERE status IN ('active', 'trial') AND billing_period = 'monthly'
            ");
            $stats['monthly_revenue'] = $stmt->fetchColumn() ?? 0;
            
            // Plans populaires
            $stmt = $pdo->query("
                SELECT p.name, COUNT(s.id) as count
                FROM subscription_plans p
                LEFT JOIN subscriptions s ON p.id = s.plan_id
                WHERE s.status IN ('active', 'trial')
                GROUP BY p.id
                ORDER BY count DESC
                LIMIT 5
            ");
            $stats['popular_plans'] = $stmt->fetchAll();
            
            echo json_encode(['success' => true, 'stats' => $stats]);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Action non reconnue']);
            break;
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
