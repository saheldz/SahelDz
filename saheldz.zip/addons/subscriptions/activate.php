<?php
/**
 * Script d'activation de l'addon Abonnements
 * Exécuté lors de l'activation de l'addon
 */

// Rien de spécial à faire lors de l'activation
// Les tables sont déjà créées lors de l'installation

echo "✅ Addon Abonnements activé avec succès !\n";

return ['success' => true, 'message' => 'Addon Abonnements activé'];
