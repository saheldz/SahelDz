<?php
/**
 * Vérification de l'authentification
 * À inclure en haut de toutes les pages protégées
 */

// Vérifier si le système est installé
if (!file_exists(__DIR__ . '/.installed')) {
    header('Location: /setup.php');
    exit;
}

// Démarrer la session si pas déjà faite
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id']) || !isset($_SESSION['session_token'])) {
    header('Location: /login.html');
    exit;
}

// Vérifier que la session est valide dans la DB
require_once __DIR__ . '/database.php';

try {
    $pdo = getDB();
    
    $stmt = $pdo->prepare("
        SELECT s.*, u.status, u.email, u.full_name, r.name as role_name
        FROM user_sessions s
        JOIN users u ON s.user_id = u.id
        LEFT JOIN roles r ON u.role_id = r.id
        WHERE s.session_token = ? AND s.expires_at > NOW() AND u.status = 'active'
    ");
    $stmt->execute([$_SESSION['session_token']]);
    $session = $stmt->fetch();
    
    if (!$session) {
        // Session invalide, déconnecter
        session_destroy();
        header('Location: /login.html');
        exit;
    }
    
    // Stocker les infos utilisateur dans une variable globale
    $GLOBALS['current_user'] = [
        'id' => $session['user_id'],
        'email' => $session['email'],
        'full_name' => $session['full_name'],
        'role' => $session['role_name']
    ];
    
} catch (PDOException $e) {
    // Erreur DB, rediriger vers login
    session_destroy();
    header('Location: /login.html');
    exit;
}

/**
 * Vérifier si l'utilisateur est admin
 */
function isAdmin() {
    global $current_user;
    return in_array($current_user['role'], ['super_admin', 'admin']);
}

/**
 * Vérifier si l'utilisateur a une permission spécifique
 */
function hasPermission($permission) {
    global $current_user;
    
    if ($current_user['role'] === 'super_admin') {
        return true;
    }
    
    try {
        $pdo = getDB();
        $stmt = $pdo->prepare("
            SELECT r.permissions
            FROM users u
            JOIN roles r ON u.role_id = r.id
            WHERE u.id = ?
        ");
        $stmt->execute([$current_user['id']]);
        $role = $stmt->fetch();
        
        if ($role) {
            $permissions = json_decode($role['permissions'], true);
            return isset($permissions['all']) && $permissions['all'] === true
                || isset($permissions[$permission]) && $permissions[$permission] === true;
        }
    } catch (PDOException $e) {
        return false;
    }
    
    return false;
}
