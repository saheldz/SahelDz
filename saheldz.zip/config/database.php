<?php
/**
 * Configuration de la base de données
 */

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'u497064961_Saheldz');
define('DB_USER', 'u497064961_Saheldz');
define('DB_PASS', 'Allef18321@');

// Créer la connexion PDO
function getDB() {
    static $pdo = null;
    
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch (PDOException $e) {
            die(json_encode([
                'success' => false,
                'error' => 'Erreur de connexion à la base de données: ' . $e->getMessage()
            ]));
        }
    }
    
    return $pdo;
}

// Fonction pour exécuter une requête
function executeQuery($sql, $params = []) {
    $pdo = getDB();
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

// Fonction pour récupérer toutes les lignes
function fetchAll($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt->fetchAll();
}

// Fonction pour récupérer une seule ligne
function fetchOne($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt->fetch();
}
