<?php
/**
 * Bannière d'impersonation
 * Affiche un bandeau quand un admin est connecté en tant qu'utilisateur
 */

if (isset($_SESSION['is_impersonating']) && $_SESSION['is_impersonating'] === true): 
?>
<div id="impersonation-banner" class="fixed top-0 left-0 right-0 bg-gradient-to-r from-orange-500 to-red-500 text-white py-3 px-4 shadow-lg z-[9999]" style="z-index: 99999;">
    <div class="max-w-7xl mx-auto flex items-center justify-between">
        <div class="flex items-center gap-3">
            <span class="text-2xl">⚠️</span>
            <div>
                <p class="font-bold text-lg">Mode Impersonation Actif</p>
                <p class="text-sm opacity-90">Vous naviguez en tant qu'utilisateur. Vos actions sont effectuées en son nom.</p>
            </div>
        </div>
        <button onclick="returnToAdmin()" class="bg-white text-orange-600 px-6 py-2 rounded-lg font-bold hover:bg-gray-100 transition-colors flex items-center gap-2">
            <span>👨‍💼</span>
            <span>Retour Admin</span>
        </button>
    </div>
</div>

<style>
    /* Ajuster le body pour ne pas cacher le contenu sous la bannière */
    body {
        padding-top: 80px !important;
    }
</style>

<script>
    async function returnToAdmin() {
        if (!confirm('Revenir en mode administrateur ?')) {
            return;
        }
        
        const formData = new FormData();
        formData.append('action', 'stop_impersonation');
        
        const response = await fetch('/api/admin.php', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            window.location.href = '/admin-users.php';
        } else {
            alert('Erreur: ' + result.error);
        }
    }
</script>
<?php endif; ?>
