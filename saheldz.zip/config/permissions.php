<?php
/**
 * Système de vérification des permissions
 * Fonctions helper pour vérifier les permissions des utilisateurs
 */

/**
 * Charge les permissions d'un utilisateur
 * @param int $userId
 * @return array Liste des codes de permissions
 */
function loadUserPermissions($userId) {
    try {
        $pdo = getDB();
        $stmt = $pdo->prepare("
            SELECT p.code
            FROM user_permissions up
            JOIN permissions p ON up.permission_id = p.id
            WHERE up.user_id = ?
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {
        error_log("Error loading permissions: " . $e->getMessage());
        return [];
    }
}

/**
 * Vérifie si l'utilisateur a une permission spécifique
 * @param string $permissionCode Code de la permission (ex: 'pos_access')
 * @param int|null $userId ID de l'utilisateur (null = utilisateur courant)
 * @return bool
 */
function hasPermission($permissionCode, $userId = null) {
    // Super admin et admin ont toujours toutes les permissions
    $userRole = $GLOBALS['current_user']['role'] ?? null;
    if ($userRole === 'super_admin' || $userRole === 'admin') {
        return true;
    }
    
    // Utiliser l'utilisateur courant si non spécifié
    if ($userId === null) {
        $userId = $GLOBALS['current_user']['id'] ?? 0;
    }
    
    // Charger les permissions si pas encore en cache
    if (!isset($GLOBALS['user_permissions'])) {
        $GLOBALS['user_permissions'] = loadUserPermissions($userId);
    }
    
    return in_array($permissionCode, $GLOBALS['user_permissions']);
}

/**
 * Vérifie si l'utilisateur a au moins une des permissions listées
 * @param array $permissionCodes Liste des codes de permissions
 * @param int|null $userId ID de l'utilisateur
 * @return bool
 */
function hasAnyPermission($permissionCodes, $userId = null) {
    foreach ($permissionCodes as $code) {
        if (hasPermission($code, $userId)) {
            return true;
        }
    }
    return false;
}

/**
 * Vérifie si l'utilisateur a toutes les permissions listées
 * @param array $permissionCodes Liste des codes de permissions
 * @param int|null $userId ID de l'utilisateur
 * @return bool
 */
function hasAllPermissions($permissionCodes, $userId = null) {
    foreach ($permissionCodes as $code) {
        if (!hasPermission($code, $userId)) {
            return false;
        }
    }
    return true;
}

/**
 * Retourne toutes les permissions de l'utilisateur courant en JSON
 * Pour utilisation dans JavaScript
 * @return string JSON
 */
function getUserPermissionsJSON() {
    $userId = $GLOBALS['current_user']['id'] ?? 0;
    $permissions = loadUserPermissions($userId);
    return json_encode($permissions);
}

/**
 * Redirige vers une page d'erreur si l'utilisateur n'a pas la permission
 * @param string $permissionCode Code de la permission requis
 * @param string $redirectUrl URL de redirection (défaut: page d'accueil)
 */
function requirePermission($permissionCode, $redirectUrl = '/') {
    if (!hasPermission($permissionCode)) {
        header('Location: ' . $redirectUrl);
        exit;
    }
}

/**
 * Affiche un message d'erreur et arrête l'exécution si pas de permission
 * @param string $permissionCode Code de la permission
 * @param string $message Message d'erreur personnalisé
 */
function denyAccessWithoutPermission($permissionCode, $message = "Accès refusé - Permission insuffisante") {
    if (!hasPermission($permissionCode)) {
        http_response_code(403);
        die($message);
    }
}
?>
