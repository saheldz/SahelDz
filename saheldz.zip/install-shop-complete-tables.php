<?php
/**
 * Installation complète des tables pour le système de boutique dynamique
 */

require_once 'config/database.php';

try {
    $pdo = getDB();
    
    echo "🛍️ Installation complète du système de boutique...\n\n";

    // Table shop_categories
    echo "📁 Création de la table 'shop_categories'...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS shop_categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            slug VARCHAR(100) NOT NULL UNIQUE,
            type ENUM('service', 'product') NOT NULL,
            icon VARCHAR(50),
            description TEXT,
            sort_order INT DEFAULT 0,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_type (type),
            INDEX idx_slug (slug),
            INDEX idx_active (is_active)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✅ Table 'shop_categories' créée\n\n";

    // Table shop_items (services et produits)
    echo "📦 Création de la table 'shop_items'...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS shop_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            category_id INT NOT NULL,
            type ENUM('service', 'product') NOT NULL,
            name VARCHAR(255) NOT NULL,
            slug VARCHAR(255) NOT NULL UNIQUE,
            description TEXT,
            short_description VARCHAR(500),
            price DECIMAL(10,2) NOT NULL,
            icon VARCHAR(50),
            delivery_time VARCHAR(100),
            is_subscription BOOLEAN DEFAULT FALSE,
            subscription_period ENUM('monthly', 'yearly') NULL,
            status ENUM('available', 'unavailable', 'coming_soon') DEFAULT 'available',
            featured BOOLEAN DEFAULT FALSE,
            sort_order INT DEFAULT 0,
            created_by INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES shop_categories(id) ON DELETE CASCADE,
            FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_category (category_id),
            INDEX idx_type (type),
            INDEX idx_status (status),
            INDEX idx_featured (featured)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✅ Table 'shop_items' créée\n\n";

    // Table orders
    echo "📋 Création de la table 'orders'...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            item_id INT NOT NULL,
            order_number VARCHAR(50) UNIQUE NOT NULL,
            item_name VARCHAR(255) NOT NULL,
            price DECIMAL(10,2) NOT NULL,
            status ENUM('pending', 'processing', 'completed', 'cancelled', 'refunded') DEFAULT 'pending',
            payment_method VARCHAR(50) DEFAULT 'wallet',
            notes TEXT,
            assigned_to INT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            completed_at TIMESTAMP NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (item_id) REFERENCES shop_items(id) ON DELETE CASCADE,
            FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_user (user_id),
            INDEX idx_item (item_id),
            INDEX idx_status (status),
            INDEX idx_order_number (order_number)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✅ Table 'orders' créée\n\n";

    // Table order_files
    echo "📎 Création de la table 'order_files'...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS order_files (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            file_name VARCHAR(255) NOT NULL,
            file_path VARCHAR(500) NOT NULL,
            file_type VARCHAR(50),
            file_size INT,
            uploaded_by INT NOT NULL,
            is_final BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_order (order_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✅ Table 'order_files' créée\n\n";

    // Table order_messages
    echo "💬 Création de la table 'order_messages'...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS order_messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            user_id INT NOT NULL,
            message_type ENUM('text', 'voice', 'image', 'file') DEFAULT 'text',
            message TEXT,
            file_path VARCHAR(500),
            file_name VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_order (order_id),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✅ Table 'order_messages' créée\n\n";

    // Table product_downloads
    echo "📥 Création de la table 'product_downloads'...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS product_downloads (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            item_id INT NOT NULL,
            download_token VARCHAR(64) UNIQUE NOT NULL,
            download_count INT DEFAULT 0,
            max_downloads INT DEFAULT 10,
            expires_at TIMESTAMP NULL,
            last_download_at TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (item_id) REFERENCES shop_items(id) ON DELETE CASCADE,
            INDEX idx_token (download_token),
            INDEX idx_order (order_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✅ Table 'product_downloads' créée\n\n";

    // Insérer des catégories par défaut
    echo "📝 Insertion des catégories par défaut...\n";
    $categories = [
        ['Design & Branding', 'design-branding', 'service', '🎨', 'Services de design graphique et identité visuelle'],
        ['Développement Web', 'developpement-web', 'service', '💻', 'Création de sites web et applications'],
        ['Marketing Digital', 'marketing-digital', 'service', '📢', 'Services de marketing et communication digitale'],
        ['Templates & Thèmes', 'templates-themes', 'product', '🎨', 'Templates et thèmes prêts à l\'emploi'],
        ['Logiciels & Outils', 'logiciels-outils', 'product', '💻', 'Plugins, outils et logiciels numériques']
    ];

    $stmt = $pdo->prepare("
        INSERT INTO shop_categories (name, slug, type, icon, description, sort_order)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    foreach ($categories as $index => $cat) {
        $stmt->execute([$cat[0], $cat[1], $cat[2], $cat[3], $cat[4], $index + 1]);
    }
    echo "✅ Catégories par défaut insérées\n\n";

    echo "✅ INSTALLATION TERMINÉE AVEC SUCCÈS !\n\n";
    echo "📊 Tables créées :\n";
    echo "   - shop_categories (catégories de services/produits)\n";
    echo "   - shop_items (services et produits)\n";
    echo "   - orders (commandes)\n";
    echo "   - order_files (fichiers livrés)\n";
    echo "   - order_messages (communication)\n";
    echo "   - product_downloads (téléchargements)\n\n";
    
    echo "🎯 Prochaine étape :\n";
    echo "   Accédez à admin-shop.php pour gérer les catégories et produits\n\n";

} catch (PDOException $e) {
    echo "❌ Erreur : " . $e->getMessage() . "\n";
    exit(1);
}
