<?php
/**
 * Mise à jour de la table users pour ajouter photo de profil et préférences
 */

require_once 'config/database.php';

try {
    $pdo = getDB();
    
    // Ajouter les colonnes manquantes
    $pdo->exec("ALTER TABLE users 
        ADD COLUMN IF NOT EXISTS profile_picture VARCHAR(255) DEFAULT NULL,
        ADD COLUMN IF NOT EXISTS preferred_currency VARCHAR(3) DEFAULT 'EUR',
        ADD COLUMN IF NOT EXISTS language VARCHAR(5) DEFAULT 'fr',
        ADD COLUMN IF NOT EXISTS theme VARCHAR(20) DEFAULT 'light'
    ");
    
    // Mettre à jour la table wallets pour permettre différentes devises par défaut
    $pdo->exec("ALTER TABLE wallets 
        MODIFY COLUMN currency VARCHAR(3) DEFAULT 'EUR'
    ");
    
    // Créer le dossier pour les photos de profil
    $uploadDir = 'uploads/profiles';
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    echo json_encode([
        'success' => true,
        'message' => '✅ Table users mise à jour avec succès!',
        'added_columns' => [
            'profile_picture',
            'preferred_currency',
            'language',
            'theme'
        ]
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Erreur: ' . $e->getMessage()
    ]);
}
