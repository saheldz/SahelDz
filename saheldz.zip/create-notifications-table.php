<?php
/**
 * Créer la table notifications pour informer admin/employés
 */

require_once 'config/database.php';

$pdo = getDB();

echo "=== CREATION TABLE NOTIFICATIONS ===\n\n";

try {
    echo "📝 Création de la table notifications...\n";
    
    $sql = "CREATE TABLE IF NOT EXISTS notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NULL COMMENT 'NULL = tous les admins/employés',
        type ENUM('sale', 'order', 'stock_low', 'system') DEFAULT 'sale',
        title VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        link VARCHAR(500),
        is_read TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user (user_id),
        INDEX idx_read (is_read),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $pdo->exec($sql);
    echo "✅ Table notifications créée\n\n";
    
    // Verify structure
    echo "📋 Vérification de la structure...\n";
    $stmt = $pdo->query("DESCRIBE notifications");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($columns as $col) {
        echo "  ✓ {$col['Field']} ({$col['Type']})\n";
    }
    
    echo "\n✅ TABLE PRÊTE !\n\n";
    echo "Les notifications seront créées automatiquement lors des ventes.\n";
    
} catch (PDOException $e) {
    echo "❌ ERREUR: " . $e->getMessage() . "\n";
}
