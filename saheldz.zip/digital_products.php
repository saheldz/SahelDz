<?php
// Connexion MySQL
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "u497064961_Saheldz";
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}
mysqli_set_charset($conn, "utf8mb4");

// Charger catégories
$categories = $conn->query("SELECT * FROM shop_categories WHERE is_active = 1 ORDER BY name ASC");

// Charger produits avec stock
$sql = "
    SELECT si.*, sc.name AS category_name, 
    (SELECT COUNT(*) FROM product_stock ps WHERE ps.item_id = si.id AND ps.status = 'available') AS available_stock
    FROM shop_items si
    LEFT JOIN shop_categories sc ON si.category_id = sc.id
    ORDER BY sc.name, si.name
";
$products = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Produits Digitaux - Employé</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-8">
    <div id="digital-products" class="section p-8">
        <div class="flex gap-6">
            <!-- Sidebar Catégories -->
            <div class="w-1/4 bg-white rounded-lg shadow-lg p-6">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold text-gray-800">Catégories</h2>
                </div>
                <div id="categoryTree" style="max-height: 400px; overflow-y: auto;">
                    <?php while($cat = $categories->fetch_assoc()): ?>
                        <div class="border-b py-2 px-2 hover:bg-gray-50 cursor-pointer">
                            <?= htmlspecialchars($cat['icon']) ?> <?= htmlspecialchars($cat['name']) ?>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>

            <!-- Zone principale des produits -->
            <div class="flex-1">
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-2xl font-semibold text-gray-800">Produits Digitaux</h2>
                    </div>

                    <div id="productsGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <?php while($p = $products->fetch_assoc()): ?>
                            <div class="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                                <div class="flex items-start justify-between mb-3">
                                    <div class="flex items-center gap-2">
                                        <span class="text-2xl"><?= htmlspecialchars($p['icon']) ?></span>
                                        <div>
                                            <h3 class="font-semibold text-gray-800"><?= htmlspecialchars($p['name']) ?></h3>
                                            <p class="text-sm text-gray-500"><?= htmlspecialchars($p['category_name']) ?></p>
                                        </div>
                                    </div>
                                </div>
                                <p class="text-sm text-gray-600 mb-3"><?= htmlspecialchars($p['description']) ?></p>
                                <div class="flex items-center justify-between text-sm text-gray-500 mb-3">
                                    <span>⏱️ <?= htmlspecialchars($p['delivery_time']) ?></span>
                                    <span class="flex items-center gap-1">
                                        <span>🔑</span>
                                        <span class="<?= $p['available_stock'] > 0 ? 'text-green-600' : 'text-red-500' ?> font-medium">
                                            <?= $p['available_stock'] ?> disponibles
                                        </span>
                                    </span>
                                </div>
                                <div class="flex items-center justify-between">
                                    <span class="text-xl font-bold text-green-600"><?= htmlspecialchars($p['price']) ?>€</span>
                                    <div class="flex gap-2">
                                        <button onclick="manageAccounts(<?= $p['id'] ?>)" class="px-3 py-1 bg-purple-500 text-white rounded text-sm hover:bg-purple-600">
                                            Comptes
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Gestion des Comptes -->
    <div id="accountsModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50">
        <div class="bg-white rounded-lg p-6 w-2/3 max-w-4xl max-h-90vh overflow-y-auto">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-xl font-semibold flex items-center gap-2">
                    <span>🔑</span> Gestion des Comptes
                </h3>
                <button onclick="closeAccountsModal()" class="text-gray-500 hover:text-gray-700">✕</button>
            </div>
            <div id="accountsContent"></div>
        </div>
    </div>

<script>
async function manageAccounts(productId) {
    const res = await fetch("product_stock_api.php?action=list&id=" + productId);
    const data = await res.text();
    document.getElementById("accountsContent").innerHTML = data;
    document.getElementById("accountsModal").classList.remove("hidden");
}
function closeAccountsModal() {
    document.getElementById("accountsModal").classList.add("hidden");
}
</script>
</body>
</html>
