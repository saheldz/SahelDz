<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "u497064961_Saheldz";
$conn = new mysqli($host, $user, $pass, $dbname);
mysqli_set_charset($conn, "utf8mb4");

$action = $_GET['action'] ?? '';
$id = intval($_GET['id'] ?? 0);

// Liste des comptes
if ($action === 'list') {
    $product = $conn->query("SELECT name FROM shop_items WHERE id=$id")->fetch_assoc();
    echo "<h4 class='text-lg font-semibold mb-3'>Produit : {$product['name']}</h4>";
    echo "<button onclick=\"addAccount($id)\" class='bg-green-500 text-white px-3 py-2 rounded mb-3'>+ Ajouter un compte</button>";
    $res = $conn->query("SELECT * FROM product_stock WHERE item_id=$id ORDER BY id DESC");
    echo "<div class='space-y-2'>";
    while($row = $res->fetch_assoc()) {
        echo "<div class='border p-3 rounded flex justify-between'>
                <span>" . htmlspecialchars($row['product_key']) . "</span>
                <div class='flex gap-2'>
                    <button onclick=\"editAccount({$row['id']}, '{$row['product_key']}')\" class='bg-blue-500 text-white px-2 rounded'>✎</button>
                    <button onclick=\"deleteAccount({$row['id']})\" class='bg-red-500 text-white px-2 rounded'>🗑</button>
                </div>
              </div>";
    }
    echo "</div>";
    exit;
}

// Ajouter un compte
if ($action === 'add' && !empty($_POST['product_key'])) {
    $item_id = intval($_POST['item_id']);
    $key = $conn->real_escape_string($_POST['product_key']);
    $conn->query("INSERT INTO product_stock (item_id, product_key) VALUES ($item_id, '$key')");
    echo "ok";
    exit;
}

// Modifier un compte
if ($action === 'edit' && !empty($_POST['id'])) {
    $id = intval($_POST['id']);
    $key = $conn->real_escape_string($_POST['product_key']);
    $conn->query("UPDATE product_stock SET product_key='$key' WHERE id=$id");
    echo "ok";
    exit;
}

// Supprimer un compte
if ($action === 'delete' && !empty($_GET['id'])) {
    $id = intval($_GET['id']);
    $conn->query("DELETE FROM product_stock WHERE id=$id");
    echo "ok";
    exit;
}
?>
