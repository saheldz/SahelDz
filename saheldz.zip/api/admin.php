<?php
/**
 * API d'administration
 * Gestion des utilisateurs, rôles et permissions (Admin seulement)
 */

session_start();
header('Content-Type: application/json');
require_once '../config/database.php';

// Vérifier l'authentification
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Non authentifié']);
    exit;
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// Permettre stop_impersonation même si l'utilisateur actuel n'est pas admin
// car un admin en mode impersonation apparaît comme l'utilisateur impersoné
if ($action === 'stop_impersonation') {
    stopImpersonation();
    exit;
}

// Vérifier les droits admin pour toutes les autres actions
if (!isAdmin()) {
    echo json_encode(['success' => false, 'error' => 'Accès refusé - Admin seulement']);
    exit;
}

switch ($action) {
    case 'get_all_users':
        getAllUsers();
        break;
    case 'get_user':
        getUser();
        break;
    case 'get_user_details':
        getUser(); // Alias pour get_user
        break;
    case 'update_user_role':
        updateUserRole();
        break;
    case 'update_user_status':
        updateUserStatus();
        break;
    case 'get_all_roles':
        getAllRoles();
        break;
    case 'create_role':
        createRole();
        break;
    case 'update_role':
        updateRole();
        break;
    case 'delete_user':
        deleteUser();
        break;
    case 'get_recent_users':
        getRecentUsers();
        break;
    case 'get_recent_transactions':
        getRecentTransactions();
        break;
    case 'create_user':
        createUser();
        break;
    case 'update_user':
        updateUser();
        break;
    case 'impersonate_user':
        impersonateUser();
        break;
    case 'stop_impersonation':
        stopImpersonation();
        break;
    default:
        echo json_encode(['success' => false, 'error' => 'Action non valide']);
}

/**
 * Se connecter en tant qu'utilisateur (Impersonation)
 */
function impersonateUser() {
    $targetUserId = intval($_POST['user_id'] ?? 0);
    
    if (!$targetUserId) {
        echo json_encode(['success' => false, 'error' => 'ID utilisateur requis']);
        return;
    }
    
    try {
        $pdo = getDB();
        
        // Vérifier que l'utilisateur cible existe
        $stmt = $pdo->prepare("SELECT id, email, full_name, status FROM users WHERE id = ?");
        $stmt->execute([$targetUserId]);
        $targetUser = $stmt->fetch();
        
        if (!$targetUser) {
            echo json_encode(['success' => false, 'error' => 'Utilisateur non trouvé']);
            return;
        }
        
        if ($targetUser['status'] !== 'active') {
            echo json_encode(['success' => false, 'error' => 'Cet utilisateur n\'est pas actif']);
            return;
        }
        
        // Sauvegarder l'ID admin d'origine
        $_SESSION['impersonating_from'] = $_SESSION['user_id'];
        $_SESSION['impersonating_from_token'] = $_SESSION['session_token'];
        
        // Créer une nouvelle session pour l'utilisateur cible
        $sessionToken = bin2hex(random_bytes(32));
        $expiresAt = date('Y-m-d H:i:s', strtotime('+30 days'));
        $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        $stmt = $pdo->prepare("
            INSERT INTO user_sessions (user_id, session_token, ip_address, user_agent, expires_at)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$targetUserId, $sessionToken, $ipAddress, $userAgent, $expiresAt]);
        
        // Basculer vers l'utilisateur cible
        $_SESSION['user_id'] = $targetUserId;
        $_SESSION['session_token'] = $sessionToken;
        $_SESSION['is_impersonating'] = true;
        
        echo json_encode([
            'success' => true,
            'message' => 'Connexion réussie en tant que ' . $targetUser['full_name']
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Arrêter l'impersonation et revenir en admin
 */
function stopImpersonation() {
    if (!isset($_SESSION['is_impersonating']) || !isset($_SESSION['impersonating_from'])) {
        echo json_encode(['success' => false, 'error' => 'Pas d\'impersonation en cours']);
        return;
    }
    
    try {
        $pdo = getDB();
        
        // Supprimer la session de l'utilisateur impersoné
        if (isset($_SESSION['session_token'])) {
            $stmt = $pdo->prepare("DELETE FROM user_sessions WHERE session_token = ?");
            $stmt->execute([$_SESSION['session_token']]);
        }
        
        // Restaurer la session admin
        $_SESSION['user_id'] = $_SESSION['impersonating_from'];
        $_SESSION['session_token'] = $_SESSION['impersonating_from_token'];
        unset($_SESSION['is_impersonating']);
        unset($_SESSION['impersonating_from']);
        unset($_SESSION['impersonating_from_token']);
        
        echo json_encode([
            'success' => true,
            'message' => 'Retour en mode administrateur'
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Créer un nouvel utilisateur
 */
function createUser() {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $fullName = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $company = trim($_POST['company'] ?? '');
    $status = $_POST['status'] ?? 'active';
    
    try {
        $pdo = getDB();
        
        // Si un rôle est spécifié, l'utiliser, sinon prendre le rôle "client" par défaut
        if (isset($_POST['role_id']) && $_POST['role_id'] !== '') {
            $roleId = intval($_POST['role_id']);
        } else {
            // Récupérer l'ID du rôle "client" par défaut
            $stmt = $pdo->prepare("SELECT id FROM roles WHERE name = 'client' LIMIT 1");
            $stmt->execute();
            $clientRole = $stmt->fetch();
            $roleId = $clientRole ? $clientRole['id'] : 3; // Fallback vers 3
        }
        
        if (!$email || !$password || !$fullName) {
            echo json_encode(['success' => false, 'error' => 'Email, mot de passe et nom complet requis']);
            return;
        }
        
        if (strlen($password) < 6) {
            echo json_encode(['success' => false, 'error' => 'Le mot de passe doit contenir au moins 6 caractères']);
            return;
        }
        
        // Vérifier si l'email existe
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            echo json_encode(['success' => false, 'error' => 'Cet email est déjà utilisé']);
            return;
        }
        
        // Hasher le mot de passe
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        
        // Insérer l'utilisateur
        $stmt = $pdo->prepare("
            INSERT INTO users (email, password, full_name, phone, company, role_id, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$email, $hashedPassword, $fullName, $phone, $company, $roleId, $status]);
        
        $userId = $pdo->lastInsertId();
        
        // Créer le wallet
        $stmt = $pdo->prepare("INSERT INTO wallets (user_id, balance, status) VALUES (?, 0.00, 'active')");
        $stmt->execute([$userId]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Utilisateur créé avec succès',
            'user_id' => $userId
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Mettre à jour un utilisateur
 */
function updateUser() {
    $userId = intval($_POST['user_id'] ?? 0);
    $email = trim($_POST['email'] ?? '');
    $fullName = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $company = trim($_POST['company'] ?? '');
    $roleId = intval($_POST['role_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (!$userId || !$email || !$fullName) {
        echo json_encode(['success' => false, 'error' => 'Données requises manquantes']);
        return;
    }
    
    try {
        $pdo = getDB();
        
        $updates = ['full_name = ?', 'email = ?', 'phone = ?', 'company = ?', 'role_id = ?', 'status = ?'];
        $params = [$fullName, $email, $phone, $company, $roleId, $status];
        
        // Mettre à jour le mot de passe si fourni
        if (!empty($password)) {
            if (strlen($password) < 6) {
                echo json_encode(['success' => false, 'error' => 'Le mot de passe doit contenir au moins 6 caractères']);
                return;
            }
            $updates[] = 'password = ?';
            $params[] = password_hash($password, PASSWORD_BCRYPT);
        }
        
        $params[] = $userId;
        $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        echo json_encode([
            'success' => true,
            'message' => 'Utilisateur mis à jour avec succès'
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Récupérer les utilisateurs récents
 */
function getRecentUsers() {
    try {
        $pdo = getDB();
        $limit = $_GET['limit'] ?? 10;
        
        $stmt = $pdo->prepare("
            SELECT u.id, u.email, u.full_name, u.created_at, r.display_name as role
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.id
            ORDER BY u.created_at DESC
            LIMIT ?
        ");
        $stmt->execute([$limit]);
        $users = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'users' => $users
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Récupérer les transactions récentes
 */
function getRecentTransactions() {
    try {
        $pdo = getDB();
        $limit = $_GET['limit'] ?? 10;
        
        $stmt = $pdo->prepare("
            SELECT 
                t.id, t.type, t.amount, t.description, t.created_at,
                u.email as user_email, u.full_name as user_name
            FROM transactions t
            JOIN wallets w ON t.wallet_id = w.id
            JOIN users u ON w.user_id = u.id
            ORDER BY t.created_at DESC
            LIMIT ?
        ");
        $stmt->execute([$limit]);
        $transactions = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'transactions' => $transactions
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Récupérer tous les utilisateurs
 */
function getAllUsers() {
    try {
        $pdo = getDB();
        
        $stmt = $pdo->query("
            SELECT 
                u.id,
                u.email,
                u.full_name,
                u.phone,
                u.company,
                u.status,
                u.email_verified,
                u.last_login,
                u.created_at,
                r.name as role_name,
                r.display_name as role_display,
                w.balance,
                w.currency
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.id
            LEFT JOIN wallets w ON u.id = w.user_id
            ORDER BY u.created_at DESC
        ");
        
        $users = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'users' => $users,
            'total' => count($users)
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Récupérer un utilisateur spécifique
 */
function getUser() {
    $userId = intval($_GET['user_id'] ?? 0);
    
    if (!$userId) {
        echo json_encode(['success' => false, 'error' => 'ID utilisateur requis']);
        return;
    }
    
    try {
        $pdo = getDB();
        
        $stmt = $pdo->prepare("
            SELECT 
                u.*,
                r.name as role_name,
                r.display_name as role_display,
                r.permissions,
                w.balance,
                w.currency,
                w.status as wallet_status
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.id
            LEFT JOIN wallets w ON u.id = w.user_id
            WHERE u.id = ?
        ");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            echo json_encode(['success' => false, 'error' => 'Utilisateur non trouvé']);
            return;
        }
        
        unset($user['password']); // Ne pas renvoyer le mot de passe
        
        // Récupérer les dernières transactions
        $stmt = $pdo->prepare("
            SELECT t.* FROM transactions t
            JOIN wallets w ON t.wallet_id = w.id
            WHERE w.user_id = ?
            ORDER BY t.created_at DESC
            LIMIT 20
        ");
        $stmt->execute([$userId]);
        $transactions = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'user' => $user,
            'transactions' => $transactions
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Modifier le rôle d'un utilisateur
 */
function updateUserRole() {
    $userId = intval($_POST['user_id'] ?? 0);
    $roleId = intval($_POST['role_id'] ?? 0);
    
    if (!$userId || !$roleId) {
        echo json_encode(['success' => false, 'error' => 'ID utilisateur et ID rôle requis']);
        return;
    }
    
    try {
        $pdo = getDB();
        
        // Vérifier que le rôle existe
        $stmt = $pdo->prepare("SELECT id, display_name FROM roles WHERE id = ?");
        $stmt->execute([$roleId]);
        $role = $stmt->fetch();
        
        if (!$role) {
            echo json_encode(['success' => false, 'error' => 'Rôle non trouvé']);
            return;
        }
        
        // Mettre à jour le rôle
        $stmt = $pdo->prepare("UPDATE users SET role_id = ? WHERE id = ?");
        $stmt->execute([$roleId, $userId]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Rôle mis à jour avec succès',
            'new_role' => $role['display_name']
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Modifier le statut d'un utilisateur
 */
function updateUserStatus() {
    $userId = intval($_POST['user_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    
    if (!$userId || !in_array($status, ['active', 'inactive', 'suspended'])) {
        echo json_encode(['success' => false, 'error' => 'ID utilisateur et statut valide requis']);
        return;
    }
    
    try {
        $pdo = getDB();
        
        $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
        $stmt->execute([$status, $userId]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Statut mis à jour avec succès',
            'new_status' => $status
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Récupérer tous les rôles
 */
function getAllRoles() {
    try {
        $pdo = getDB();
        
        $stmt = $pdo->query("SELECT * FROM roles ORDER BY id");
        $roles = $stmt->fetchAll();
        
        // Décoder les permissions JSON
        foreach ($roles as &$role) {
            $role['permissions'] = json_decode($role['permissions'], true);
        }
        
        echo json_encode([
            'success' => true,
            'roles' => $roles
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Créer un nouveau rôle
 */
function createRole() {
    $name = trim($_POST['name'] ?? '');
    $displayName = trim($_POST['display_name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $permissions = $_POST['permissions'] ?? '{}';
    
    if (!$name || !$displayName) {
        echo json_encode(['success' => false, 'error' => 'Nom et nom d\'affichage requis']);
        return;
    }
    
    // Valider le JSON des permissions
    $permissionsArray = json_decode($permissions, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['success' => false, 'error' => 'Format JSON des permissions invalide']);
        return;
    }
    
    try {
        $pdo = getDB();
        
        $stmt = $pdo->prepare("
            INSERT INTO roles (name, display_name, description, permissions)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$name, $displayName, $description, $permissions]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Rôle créé avec succès',
            'role_id' => $pdo->lastInsertId()
        ]);
        
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            echo json_encode(['success' => false, 'error' => 'Ce nom de rôle existe déjà']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
        }
    }
}

/**
 * Mettre à jour un rôle
 */
function updateRole() {
    $roleId = intval($_POST['role_id'] ?? 0);
    $displayName = trim($_POST['display_name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $permissions = $_POST['permissions'] ?? '';
    
    if (!$roleId) {
        echo json_encode(['success' => false, 'error' => 'ID rôle requis']);
        return;
    }
    
    // Valider le JSON des permissions
    if ($permissions) {
        $permissionsArray = json_decode($permissions, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode(['success' => false, 'error' => 'Format JSON des permissions invalide']);
            return;
        }
    }
    
    try {
        $pdo = getDB();
        
        $updates = [];
        $params = [];
        
        if ($displayName) {
            $updates[] = "display_name = ?";
            $params[] = $displayName;
        }
        
        if ($description) {
            $updates[] = "description = ?";
            $params[] = $description;
        }
        
        if ($permissions) {
            $updates[] = "permissions = ?";
            $params[] = $permissions;
        }
        
        if (empty($updates)) {
            echo json_encode(['success' => false, 'error' => 'Aucune modification à effectuer']);
            return;
        }
        
        $params[] = $roleId;
        $sql = "UPDATE roles SET " . implode(', ', $updates) . " WHERE id = ?";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        echo json_encode([
            'success' => true,
            'message' => 'Rôle mis à jour avec succès'
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Supprimer un utilisateur
 */
function deleteUser() {
    $userId = intval($_POST['user_id'] ?? 0);
    
    if (!$userId) {
        echo json_encode(['success' => false, 'error' => 'ID utilisateur requis']);
        return;
    }
    
    // Ne pas permettre de supprimer le super admin
    if ($userId == 1) {
        echo json_encode(['success' => false, 'error' => 'Impossible de supprimer le super administrateur']);
        return;
    }
    
    try {
        $pdo = getDB();
        
        // Supprimer l'utilisateur (cascade supprimera wallet, transactions, sessions)
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Utilisateur supprimé avec succès'
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Vérifier si l'utilisateur est admin
 */
function isAdmin() {
    try {
        $pdo = getDB();
        
        $stmt = $pdo->prepare("
            SELECT r.name, r.permissions
            FROM users u
            JOIN roles r ON u.role_id = r.id
            WHERE u.id = ?
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        
        if (!$user) {
            return false;
        }
        
        // Super admin ou admin
        if ($user['name'] === 'super_admin' || $user['name'] === 'admin') {
            return true;
        }
        
        // Vérifier les permissions JSON
        $permissions = json_decode($user['permissions'], true);
        if (isset($permissions['all']) && $permissions['all'] === true) {
            return true;
        }
        
        return false;
        
    } catch (PDOException $e) {
        return false;
    }
}
