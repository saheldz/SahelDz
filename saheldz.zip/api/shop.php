<?php
/**
 * API Shop - Gestion des commandes de services et produits
 */

header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../config/auth-check.php';

$pdo = getDB();
$response = ['success' => false, 'message' => ''];

try {
    $action = $_POST['action'] ?? $_GET['action'] ?? '';
    $userId = $GLOBALS['current_user']['id'];

    switch ($action) {
        case 'order_service':
            $serviceId = $_POST['service_id'] ?? '';
            $serviceName = $_POST['service_name'] ?? '';
            $price = floatval($_POST['price'] ?? 0);
            $description = $_POST['description'] ?? '';

            if (empty($serviceId) || empty($serviceName) || $price <= 0) {
                throw new Exception('Données invalides');
            }

            // Vérifier le solde du wallet
            $stmt = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ? AND status = 'active'");
            $stmt->execute([$userId]);
            $wallet = $stmt->fetch();

            if (!$wallet || $wallet['balance'] < $price) {
                throw new Exception('Solde insuffisant dans votre wallet');
            }

            // Créer la commande
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                INSERT INTO orders (user_id, type, item_id, item_name, price, status, description, created_at)
                VALUES (?, 'service', ?, ?, ?, 'pending', ?, NOW())
            ");
            $stmt->execute([$userId, $serviceId, $serviceName, $price, $description]);
            $orderId = $pdo->lastInsertId();

            // Débiter le wallet
            $stmt = $pdo->prepare("UPDATE wallets SET balance = balance - ? WHERE user_id = ?");
            $stmt->execute([$price, $userId]);

            // Ajouter une transaction
            $stmt = $pdo->prepare("
                INSERT INTO wallet_transactions (wallet_id, type, amount, description, created_at)
                SELECT id, 'debit', ?, CONCAT('Commande service: ', ?), NOW()
                FROM wallets WHERE user_id = ?
            ");
            $stmt->execute([$price, $serviceName, $userId]);

            $pdo->commit();

            $response['success'] = true;
            $response['message'] = 'Commande créée avec succès';
            $response['order_id'] = $orderId;
            $response['new_balance'] = $wallet['balance'] - $price;
            break;

        case 'order_product':
            $productId = $_POST['product_id'] ?? '';
            $productName = $_POST['product_name'] ?? '';
            $price = floatval($_POST['price'] ?? 0);

            if (empty($productId) || empty($productName) || $price <= 0) {
                throw new Exception('Données invalides');
            }

            // Vérifier le solde du wallet
            $stmt = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ? AND status = 'active'");
            $stmt->execute([$userId]);
            $wallet = $stmt->fetch();

            if (!$wallet || $wallet['balance'] < $price) {
                throw new Exception('Solde insuffisant dans votre wallet');
            }

            // Créer la commande
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                INSERT INTO orders (user_id, type, item_id, item_name, price, status, created_at)
                VALUES (?, 'product', ?, ?, ?, 'completed', NOW())
            ");
            $stmt->execute([$userId, $productId, $productName, $price]);
            $orderId = $pdo->lastInsertId();

            // Débiter le wallet
            $stmt = $pdo->prepare("UPDATE wallets SET balance = balance - ? WHERE user_id = ?");
            $stmt->execute([$price, $userId]);

            // Ajouter une transaction
            $stmt = $pdo->prepare("
                INSERT INTO wallet_transactions (wallet_id, type, amount, description, created_at)
                SELECT id, 'debit', ?, CONCAT('Achat produit: ', ?), NOW()
                FROM wallets WHERE user_id = ?
            ");
            $stmt->execute([$price, $productName, $userId]);

            // Générer un lien de téléchargement
            $downloadToken = bin2hex(random_bytes(32));
            $stmt = $pdo->prepare("
                INSERT INTO product_downloads (order_id, product_id, download_token, expires_at)
                VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))
            ");
            $stmt->execute([$orderId, $productId, $downloadToken]);

            $pdo->commit();

            $response['success'] = true;
            $response['message'] = 'Produit acheté avec succès';
            $response['order_id'] = $orderId;
            $response['download_url'] = "/download.php?token=" . $downloadToken;
            $response['new_balance'] = $wallet['balance'] - $price;
            break;

        case 'get_orders':
            $type = $_GET['type'] ?? 'all'; // all, service, product
            
            $sql = "SELECT * FROM orders WHERE user_id = ?";
            if ($type !== 'all') {
                $sql .= " AND type = ?";
            }
            $sql .= " ORDER BY created_at DESC";

            $stmt = $pdo->prepare($sql);
            if ($type !== 'all') {
                $stmt->execute([$userId, $type]);
            } else {
                $stmt->execute([$userId]);
            }
            $orders = $stmt->fetchAll();

            $response['success'] = true;
            $response['orders'] = $orders;
            break;

        case 'get_order_details':
            $orderId = $_GET['order_id'] ?? 0;
            
            $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
            $stmt->execute([$orderId, $userId]);
            $order = $stmt->fetch();

            if (!$order) {
                throw new Exception('Commande non trouvée');
            }

            // Si c'est un produit, récupérer le lien de téléchargement
            if ($order['type'] === 'product') {
                $stmt = $pdo->prepare("
                    SELECT download_token, expires_at, download_count 
                    FROM product_downloads 
                    WHERE order_id = ?
                ");
                $stmt->execute([$orderId]);
                $download = $stmt->fetch();
                
                if ($download) {
                    $order['download_url'] = "/download.php?token=" . $download['download_token'];
                    $order['download_expires'] = $download['expires_at'];
                    $order['download_count'] = $download['download_count'];
                }
            }

            $response['success'] = true;
            $response['order'] = $order;
            break;

        case 'cancel_order':
            $orderId = $_POST['order_id'] ?? 0;
            
            $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
            $stmt->execute([$orderId, $userId]);
            $order = $stmt->fetch();

            if (!$order) {
                throw new Exception('Commande non trouvée');
            }

            if ($order['status'] !== 'pending') {
                throw new Exception('Cette commande ne peut pas être annulée');
            }

            // Annuler la commande et rembourser
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("UPDATE orders SET status = 'cancelled', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$orderId]);

            // Rembourser le wallet
            $stmt = $pdo->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
            $stmt->execute([$order['price'], $userId]);

            // Ajouter une transaction
            $stmt = $pdo->prepare("
                INSERT INTO wallet_transactions (wallet_id, type, amount, description, created_at)
                SELECT id, 'credit', ?, CONCAT('Remboursement commande annulée: ', ?), NOW()
                FROM wallets WHERE user_id = ?
            ");
            $stmt->execute([$order['price'], $order['item_name'], $userId]);

            $pdo->commit();

            $response['success'] = true;
            $response['message'] = 'Commande annulée et remboursée';
            break;

        default:
            throw new Exception('Action non valide');
    }

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
