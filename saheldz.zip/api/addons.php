<?php
/**
 * API de gestion des Addons
 */

session_start();
header('Content-Type: application/json');
require_once '../config/database.php';

// Vérifier l'authentification et droits admin
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Non authentifié']);
    exit;
}

if (!isAdmin()) {
    echo json_encode(['success' => false, 'error' => 'Accès refusé - Admin seulement']);
    exit;
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'get_installed':
        getInstalledAddons();
        break;
    case 'get_addon_details':
        getAddonDetails();
        break;
    case 'upload_addon':
        uploadAddon();
        break;
    case 'activate_addon':
        activateAddon();
        break;
    case 'deactivate_addon':
        deactivateAddon();
        break;
    case 'delete_addon':
        deleteAddon();
        break;
    default:
        echo json_encode(['success' => false, 'error' => 'Action non valide']);
}

/**
 * Récupérer les détails d'un addon
 */
function getAddonDetails() {
    $addonName = $_GET['addon_name'] ?? '';
    
    if (!$addonName) {
        echo json_encode(['success' => false, 'error' => 'Nom de l\'addon requis']);
        return;
    }
    
    $addonPath = '../addons/' . $addonName;
    $configFile = $addonPath . '/addon.json';
    
    if (!file_exists($configFile)) {
        echo json_encode(['success' => false, 'error' => 'Addon non trouve']);
        return;
    }
    
    $config = json_decode(file_get_contents($configFile), true);
    
    if (!$config) {
        echo json_encode(['success' => false, 'error' => 'Configuration invalide']);
        return;
    }
    
    // Vérifier si l'addon est actif
    $statusFile = $addonPath . '/.active';
    $config['active'] = file_exists($statusFile);
    $config['path'] = $addonName;
    
    echo json_encode([
        'success' => true,
        'addon' => $config
    ]);
}

/**
 * Récupérer la liste des addons installés
 */
function getInstalledAddons() {
    $addonsDir = '../addons';
    $addons = [];
    
    if (!file_exists($addonsDir)) {
        mkdir($addonsDir, 0755, true);
    }
    
    $dirs = scandir($addonsDir);
    
    foreach ($dirs as $dir) {
        if ($dir === '.' || $dir === '..') continue;
        
        $addonPath = $addonsDir . '/' . $dir;
        $configFile = $addonPath . '/addon.json';
        
        if (is_dir($addonPath) && file_exists($configFile)) {
            $config = json_decode(file_get_contents($configFile), true);
            
            if ($config) {
                // Vérifier si l'addon est actif
                $statusFile = $addonPath . '/.active';
                $config['active'] = file_exists($statusFile);
                $config['path'] = $dir;
                
                $addons[] = $config;
            }
        }
    }
    
    echo json_encode([
        'success' => true,
        'addons' => $addons
    ]);
}

/**
 * Upload et installer un addon
 */
function uploadAddon() {
    if (!isset($_FILES['addon_file'])) {
        echo json_encode(['success' => false, 'error' => 'Aucun fichier fourni']);
        return;
    }
    
    $file = $_FILES['addon_file'];
    
    // Vérifier que c'est un ZIP
    $fileType = mime_content_type($file['tmp_name']);
    if ($fileType !== 'application/zip' && $fileType !== 'application/x-zip-compressed') {
        echo json_encode(['success' => false, 'error' => 'Le fichier doit être un ZIP']);
        return;
    }
    
    try {
        $zip = new ZipArchive();
        
        if ($zip->open($file['tmp_name']) !== TRUE) {
            echo json_encode(['success' => false, 'error' => 'Impossible d\'ouvrir le fichier ZIP']);
            return;
        }
        
        // Chercher le fichier addon.json
        $configContent = null;
        $addonName = null;
        
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $filename = $zip->getNameIndex($i);
            
            if (basename($filename) === 'addon.json') {
                $configContent = $zip->getFromIndex($i);
                break;
            }
        }
        
        if (!$configContent) {
            $zip->close();
            echo json_encode(['success' => false, 'error' => 'Fichier addon.json non trouvé dans le ZIP']);
            return;
        }
        
        $config = json_decode($configContent, true);
        
        if (!$config || !isset($config['name'])) {
            $zip->close();
            echo json_encode(['success' => false, 'error' => 'Fichier addon.json invalide']);
            return;
        }
        
        $addonName = $config['name'];
        $addonPath = '../addons/' . $addonName;
        
        // Vérifier si l'addon existe déjà
        if (file_exists($addonPath)) {
            $zip->close();
            echo json_encode(['success' => false, 'error' => 'Un addon avec ce nom existe déjà']);
            return;
        }
        
        // Créer le dossier et extraire
        mkdir($addonPath, 0755, true);
        $zip->extractTo($addonPath);
        $zip->close();
        
        // Exécuter le script d'installation si présent
        $installScript = $addonPath . '/install.php';
        if (file_exists($installScript)) {
            try {
                require_once $installScript;
                if (function_exists($addonName . '_install')) {
                    call_user_func($addonName . '_install');
                }
            } catch (Exception $e) {
                // Log l'erreur mais continue
            }
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'Addon installé avec succès',
            'addon' => $config
        ]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Activer un addon
 */
function activateAddon() {
    $addonName = $_POST['addon_name'] ?? '';
    
    if (!$addonName) {
        echo json_encode(['success' => false, 'error' => 'Nom de l\'addon requis']);
        return;
    }
    
    $addonPath = '../addons/' . $addonName;
    
    if (!file_exists($addonPath)) {
        echo json_encode(['success' => false, 'error' => 'Addon non trouvé']);
        return;
    }
    
    // Créer le fichier .active
    $statusFile = $addonPath . '/.active';
    file_put_contents($statusFile, date('Y-m-d H:i:s'));
    
    // Exécuter le script d'activation si présent
    $activateScript = $addonPath . '/activate.php';
    if (file_exists($activateScript)) {
        try {
            require_once $activateScript;
            if (function_exists($addonName . '_activate')) {
                call_user_func($addonName . '_activate');
            }
        } catch (Exception $e) {
            // Log l'erreur
        }
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Addon activé avec succès'
    ]);
}

/**
 * Désactiver un addon
 */
function deactivateAddon() {
    $addonName = $_POST['addon_name'] ?? '';
    
    if (!$addonName) {
        echo json_encode(['success' => false, 'error' => 'Nom de l\'addon requis']);
        return;
    }
    
    $addonPath = '../addons/' . $addonName;
    
    if (!file_exists($addonPath)) {
        echo json_encode(['success' => false, 'error' => 'Addon non trouvé']);
        return;
    }
    
    // Supprimer le fichier .active
    $statusFile = $addonPath . '/.active';
    if (file_exists($statusFile)) {
        unlink($statusFile);
    }
    
    // Exécuter le script de désactivation si présent
    $deactivateScript = $addonPath . '/deactivate.php';
    if (file_exists($deactivateScript)) {
        try {
            require_once $deactivateScript;
            if (function_exists($addonName . '_deactivate')) {
                call_user_func($addonName . '_deactivate');
            }
        } catch (Exception $e) {
            // Log l'erreur
        }
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Addon désactivé avec succès'
    ]);
}

/**
 * Supprimer un addon
 */
function deleteAddon() {
    $addonName = $_POST['addon_name'] ?? '';
    
    if (!$addonName) {
        echo json_encode(['success' => false, 'error' => 'Nom de l\'addon requis']);
        return;
    }
    
    $addonPath = '../addons/' . $addonName;
    
    if (!file_exists($addonPath)) {
        echo json_encode(['success' => false, 'error' => 'Addon non trouvé']);
        return;
    }
    
    // Exécuter le script de désinstallation si présent
    $uninstallScript = $addonPath . '/uninstall.php';
    if (file_exists($uninstallScript)) {
        try {
            require_once $uninstallScript;
            if (function_exists($addonName . '_uninstall')) {
                call_user_func($addonName . '_uninstall');
            }
        } catch (Exception $e) {
            // Log l'erreur
        }
    }
    
    // Supprimer le dossier
    deleteDirectory($addonPath);
    
    echo json_encode([
        'success' => true,
        'message' => 'Addon supprimé avec succès'
    ]);
}

/**
 * Supprimer un dossier récursivement
 */
function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    
    if (!is_dir($dir)) {
        return unlink($dir);
    }
    
    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }
        
        if (!deleteDirectory($dir . '/' . $item)) {
            return false;
        }
    }
    
    return rmdir($dir);
}

/**
 * Vérifier si l'utilisateur est admin
 */
function isAdmin() {
    try {
        $pdo = getDB();
        
        $stmt = $pdo->prepare("
            SELECT r.name
            FROM users u
            JOIN roles r ON u.role_id = r.id
            WHERE u.id = ?
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        
        return $user && in_array($user['name'], ['super_admin', 'admin']);
        
    } catch (PDOException $e) {
        return false;
    }
}
