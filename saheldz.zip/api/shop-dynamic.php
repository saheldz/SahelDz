<?php
/**
 * API dynamique pour la boutique - Charge depuis la base de données
 */

header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../config/auth-check.php';

$pdo = getDB();
$response = ['success' => false];

// Get action
$action = $_POST['action'] ?? $_GET['action'] ?? '';

// Log the action for debugging (remove in production)
error_log("API shop-dynamic.php - Action received: " . $action);

try {
    switch ($action) {
        
        // ==================== CATEGORIES ====================
        
        case 'getCategories':
        case 'get_categories':
            $type = $_GET['type'] ?? 'all'; // 'service', 'product', ou 'all'
            
           $sql = "SELECT * FROM shop_categories WHERE is_active = 1";

            $sql .= " ORDER BY sort_order ASC, name ASC";
            
            $stmt = $pdo->prepare($sql);
            if ($type !== 'all') {
                $stmt->execute(['type' => $type]);
            } else {
                $stmt->execute();
            }
            
            $response['success'] = true;
            $response['categories'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;
            
        case 'get_category':
            $id = $_GET['id'] ?? 0;
            $stmt = $pdo->prepare("SELECT * FROM shop_categories WHERE id = ?");
            $stmt->execute([$id]);
            $category = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($category) {
                $response['success'] = true;
                $response['category'] = $category;
            } else {
                $response['message'] = 'Catégorie non trouvée';
            }
            break;
            
        case 'create_category':
            checkAdminOrEmployee();
            
            $name = $_POST['name'] ?? '';
            $type = $_POST['type'] ?? 'service';
            $icon = $_POST['icon'] ?? '';
            $description = $_POST['description'] ?? '';
            
            if (empty($name)) {
                $response['message'] = 'Le nom est requis';
                break;
            }
            
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
            
            $stmt = $pdo->prepare("
                INSERT INTO shop_categories (name, slug, type, icon, description)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([$name, $slug, $type, $icon, $description]);
            
            $response['success'] = true;
            $response['category_id'] = $pdo->lastInsertId();
            $response['message'] = 'Catégorie créée avec succès';
            break;
            
        case 'update_category':
            checkAdminOrEmployee();
            
            $id = $_POST['id'] ?? 0;
            $name = $_POST['name'] ?? '';
            $icon = $_POST['icon'] ?? '';
            $description = $_POST['description'] ?? '';
            $is_active = isset($_POST['is_active']) ? (int)$_POST['is_active'] : 1;
            
            $stmt = $pdo->prepare("
                UPDATE shop_categories 
                SET name = ?, icon = ?, description = ?, is_active = ?
                WHERE id = ?
            ");
            $stmt->execute([$name, $icon, $description, $is_active, $id]);
            
            $response['success'] = true;
            $response['message'] = 'Catégorie mise à jour';
            break;
            
        case 'delete_category':
            checkAdmin();
            
            $id = $_POST['id'] ?? 0;
            
            // Vérifier s'il y a des items dans cette catégorie
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM shop_items WHERE category_id = ?");
            $stmt->execute([$id]);
            $count = $stmt->fetchColumn();
            
            if ($count > 0) {
                $response['message'] = "Impossible de supprimer : $count item(s) dans cette catégorie";
                break;
            }
            
            $stmt = $pdo->prepare("DELETE FROM shop_categories WHERE id = ?");
            $stmt->execute([$id]);
            
            $response['success'] = true;
            $response['message'] = 'Catégorie supprimée';
            break;
            
        // ==================== ITEMS (Services/Produits) ====================
        
        case 'getProducts':
            // Alias pour compatibilité avec section Digital Products
            $stmt = $pdo->query("
                SELECT id, category_id, name, type, price, 
                       delivery_time as duration, 
                       description
                FROM shop_items 
                WHERE status = 'available' AND type = 'product'
                ORDER BY name ASC
            ");
            
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Calculate stock count and get stock details for each product
            $stock = [];
            foreach ($products as &$product) {
                // Count available stock
                $stockCountStmt = $pdo->prepare("
                    SELECT COUNT(*) FROM product_stock 
                    WHERE item_id = ? AND status = 'available'
                ");
                $stockCountStmt->execute([$product['id']]);
                $product['stock'] = (int)$stockCountStmt->fetchColumn();
                
                // Get stock details
                $stockStmt = $pdo->prepare("
                    SELECT * FROM product_stock 
                    WHERE item_id = ? AND status = 'available'
                ");
                $stockStmt->execute([$product['id']]);
                $stock[$product['id']] = $stockStmt->fetchAll(PDO::FETCH_ASSOC);
            }
            unset($product); // break reference
            
            $response['success'] = true;
            $response['products'] = $products;
            $response['stock'] = $stock;
            break;
        
        case 'get_items':
            $type = $_GET['type'] ?? 'all';
            $category_id = $_GET['category_id'] ?? 0;
            
            $sql = "SELECT i.*, c.name as category_name, c.icon as category_icon 
                    FROM shop_items i 
                    JOIN shop_categories c ON i.category_id = c.id 
                    WHERE i.status != 'unavailable'";
            
            $params = [];
            if ($type !== 'all') {
                $sql .= " AND i.type = ?";
                $params[] = $type;
            }
            if ($category_id > 0) {
                $sql .= " AND i.category_id = ?";
                $params[] = $category_id;
            }
            
            $sql .= " ORDER BY i.featured DESC, i.sort_order ASC, i.name ASC";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            
            $response['success'] = true;
            $response['items'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;
            
        case 'get_item':
            $id = $_GET['id'] ?? 0;
            $stmt = $pdo->prepare("
                SELECT i.*, c.name as category_name 
                FROM shop_items i 
                JOIN shop_categories c ON i.category_id = c.id 
                WHERE i.id = ?
            ");
            $stmt->execute([$id]);
            $item = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($item) {
                $response['success'] = true;
                $response['item'] = $item;
            } else {
                $response['message'] = 'Item non trouvé';
            }
            break;
            
        case 'createProduct':
        case 'create_item':
            checkAdminOrEmployee();
            
            $category_id = $_POST['category_id'] ?? 0;
            $type = $_POST['type'] ?? 'product';
            $name = $_POST['name'] ?? '';
            $description = $_POST['description'] ?? '';
            $short_description = $_POST['short_description'] ?? '';
            $price = $_POST['price'] ?? 0;
            $icon = $_POST['icon'] ?? '';
            $delivery_time = $_POST['duration'] ?? ($_POST['delivery_time'] ?? '');
            $is_subscription = isset($_POST['is_subscription']) ? 1 : 0;
            $subscription_period = $_POST['subscription_period'] ?? null;
            
            if (empty($name) || $price <= 0) {
                $response['message'] = 'Nom et prix requis';
                break;
            }
            
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
            
            $stmt = $pdo->prepare("
                INSERT INTO shop_items 
                (category_id, type, name, slug, description, short_description, price, 
                 icon, delivery_time, is_subscription, subscription_period, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $category_id, $type, $name, $slug, $description, $short_description,
                $price, $icon, $delivery_time, $is_subscription, $subscription_period,
                $_SESSION['user_id'] ?? 1
            ]);
            
            $response['success'] = true;
            $response['item_id'] = $pdo->lastInsertId();
            $response['message'] = 'Item créé avec succès';
            break;
            
        case 'updateProduct':
        case 'update_item':
            checkAdminOrEmployee();
            
            $id = $_POST['id'] ?? 0;
            $name = $_POST['name'] ?? '';
            $description = $_POST['description'] ?? '';
            $short_description = $_POST['short_description'] ?? '';
            $price = $_POST['price'] ?? 0;
            $icon = $_POST['icon'] ?? '';
            $delivery_time = $_POST['duration'] ?? ($_POST['delivery_time'] ?? '');
            $status = $_POST['status'] ?? 'available';
            $featured = isset($_POST['featured']) ? 1 : 0;
            $category_id = $_POST['category_id'] ?? 0;
            $type = $_POST['type'] ?? null;
            
            $updateFields = [];
            $updateValues = [];
            
            $updateFields[] = "name = ?";
            $updateValues[] = $name;
            
            $updateFields[] = "description = ?";
            $updateValues[] = $description;
            
            if ($short_description) {
                $updateFields[] = "short_description = ?";
                $updateValues[] = $short_description;
            }
            
            $updateFields[] = "price = ?";
            $updateValues[] = $price;
            
            if ($icon) {
                $updateFields[] = "icon = ?";
                $updateValues[] = $icon;
            }
            
            if ($delivery_time) {
                $updateFields[] = "delivery_time = ?";
                $updateValues[] = $delivery_time;
            }
            
            if ($status) {
                $updateFields[] = "status = ?";
                $updateValues[] = $status;
            }
            
            if ($category_id > 0) {
                $updateFields[] = "category_id = ?";
                $updateValues[] = $category_id;
            }
            
            if ($type) {
                $updateFields[] = "type = ?";
                $updateValues[] = $type;
            }
            
            $updateFields[] = "featured = ?";
            $updateValues[] = $featured;
            
            $updateValues[] = $id;
            
            $sql = "UPDATE shop_items SET " . implode(', ', $updateFields) . " WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($updateValues);
            
            $response['success'] = true;
            $response['message'] = 'Produit mis à jour avec succès';
            break;
            
        case 'delete_item':
            checkAdmin();
            
            $id = $_POST['id'] ?? 0;
            
            // Vérifier s'il y a des commandes
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE item_id = ?");
            $stmt->execute([$id]);
            $count = $stmt->fetchColumn();
            
            if ($count > 0) {
                $response['message'] = "Impossible de supprimer : $count commande(s) liée(s)";
                break;
            }
            
            $stmt = $pdo->prepare("DELETE FROM shop_items WHERE id = ?");
            $stmt->execute([$id]);
            
            $response['success'] = true;
            $response['message'] = 'Item supprimé';
            break;
            
        // ==================== ORDERS ====================
        
        // If product, deliver from stock automatically
if ($item['type'] === 'product') {

    // Get one available product from stock
    $stmt = $pdo->prepare("
        SELECT * FROM product_stock 
        WHERE item_id = ? AND status = 'available' 
        LIMIT 1 
        FOR UPDATE
    ");
    $stmt->execute([$item_id]);
    $stockItem = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($stockItem) {
        // Mark as sold OR increment usage
        if ($stockItem['is_reusable'] == 1) {
            // Réutilisable → on augmente compteur
            $stmt = $pdo->prepare("
                UPDATE product_stock 
                SET used_count = used_count + 1,
                    status = CASE WHEN used_count + 1 >= max_uses THEN 'sold' ELSE 'available' END,
                    sold_to_user_id = ?, sold_at = NOW(), order_id = ?
                WHERE id = ?
            ");
            $stmt->execute([$user_id, $order_id, $stockItem['id']]);

        } else {
            // Compte unique → on le finalise définitivement
            $stmt = $pdo->prepare("
                UPDATE product_stock 
                SET status = 'sold', sold_to_user_id = ?, sold_at = NOW(), order_id = ?
                WHERE id = ?
            ");
            $stmt->execute([$user_id, $order_id, $stockItem['id']]);
        }

        // Add product code to order notes
        $deliveryInfo = "CODE: {$stockItem['product_code']}";
        if ($stockItem['product_key']) {
            $deliveryInfo .= "\n\nINFORMATIONS:\n{$stockItem['product_key']}";
        }

        $stmt = $pdo->prepare("UPDATE orders SET notes = ? WHERE id = ?");
        $stmt->execute([$deliveryInfo, $order_id]);

        // Return product info
        $response['product_code'] = $stockItem['product_code'];
        $response['product_key'] = $stockItem['product_key'];
        $response['delivery_info'] = $deliveryInfo;
    }
}

            
            // Check if product has stock (for digital products)
            if ($item['type'] === 'product') {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM product_stock WHERE item_id = ? AND status = 'available'");
                $stmt->execute([$item_id]);
                $stockCount = $stmt->fetchColumn();
                
                if ($stockCount == 0) {
                    $response['message'] = 'Produit en rupture de stock';
                    break;
                }
            }
            
            // Check wallet balance
            $stmt = $pdo->prepare("SELECT balance FROM wallets WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $wallet = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$wallet || $wallet['balance'] < $item['price']) {
                $response['message'] = 'Solde insuffisant';
                break;
            }
            
            // Generate order number
            $order_number = 'ORD-' . date('Ymd') . '-' . strtoupper(substr(md5(uniqid()), 0, 6));
            
            // Start transaction
            $pdo->beginTransaction();
            
            try {
                // Create order
                $stmt = $pdo->prepare("
                    INSERT INTO orders (user_id, item_id, order_number, item_name, price, status)
                    VALUES (?, ?, ?, ?, ?, 'completed')
                ");
                $stmt->execute([$user_id, $item_id, $order_number, $item['name'], $item['price']]);
                $order_id = $pdo->lastInsertId();
                
                // Deduct from wallet
                $stmt = $pdo->prepare("UPDATE wallets SET balance = balance - ? WHERE user_id = ?");
                $stmt->execute([$item['price'], $user_id]);
                
                // Add wallet transaction
                $stmt = $pdo->prepare("
                    INSERT INTO wallet_transactions (user_id, type, amount, description)
                    VALUES (?, 'debit', ?, ?)
                ");
                $stmt->execute([$user_id, $item['price'], "Commande: {$item['name']} ($order_number)"]);
                
                // If product, deliver from stock automatically
                if ($item['type'] === 'product') {
                    // Get one available product from stock
                    $stmt = $pdo->prepare("
                        SELECT * FROM product_stock 
                        WHERE item_id = ? AND status = 'available' 
                        LIMIT 1 
                        FOR UPDATE
                    ");
                    $stmt->execute([$item_id]);
                    $stockItem = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($stockItem) {
                        // Mark as sold
                        $stmt = $pdo->prepare("
                            UPDATE product_stock 
                            SET status = 'sold', sold_to_user_id = ?, sold_at = NOW(), order_id = ?
                            WHERE id = ?
                        ");
                        $stmt->execute([$user_id, $order_id, $stockItem['id']]);
                        
                        // Add product code to order notes
                        $deliveryInfo = "CODE: {$stockItem['product_code']}";
                        if ($stockItem['product_key']) {
                            $deliveryInfo .= "\n\nINFORMATIONS:\n{$stockItem['product_key']}";
                        }
                        
                        $stmt = $pdo->prepare("UPDATE orders SET notes = ? WHERE id = ?");
                        $stmt->execute([$deliveryInfo, $order_id]);
                        
                        // Return product info
                        $response['product_code'] = $stockItem['product_code'];
                        $response['product_key'] = $stockItem['product_key'];
                        $response['delivery_info'] = $deliveryInfo;
                    } else {
                        // Should not happen (we checked stock before), but handle it
                        throw new Exception('Erreur: Stock épuisé pendant la transaction');
                    }
                }
                
                // Create notification for admins/employees
                $notifTitle = "🎉 Nouvelle vente: {$item['name']}";
                $notifMessage = "Client a acheté '{$item['name']}' pour {$item['price']}€\n";
                $notifMessage .= "Commande: {$order_number}\n";
                if (isset($stockItem)) {
                    $notifMessage .= "Code livré: {$stockItem['product_code']}";
                }
                
                $stmt = $pdo->prepare("
                    INSERT INTO notifications (user_id, type, title, message, link)
                    VALUES (NULL, 'sale', ?, ?, ?)
                ");
                $stmt->execute([$notifTitle, $notifMessage, "/admin-orders.php?order_id={$order_id}"]);
                
                $pdo->commit();
                
                $response['success'] = true;
                $response['order_id'] = $order_id;
                $response['order_number'] = $order_number;
                $response['message'] = 'Commande créée et livrée avec succès';
                
            } catch (Exception $e) {
                $pdo->rollBack();
                $response['message'] = 'Erreur lors de la création de la commande: ' . $e->getMessage();
            }
            break;
            
        case 'get_my_orders':
            $user_id = $_SESSION['user_id'];
            
            $stmt = $pdo->prepare("
                SELECT o.*, i.type, i.icon
                FROM orders o
                JOIN shop_items i ON o.item_id = i.id
                WHERE o.user_id = ?
                ORDER BY o.created_at DESC
            ");
            $stmt->execute([$user_id]);
            
            $response['success'] = true;
            $response['orders'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
            break;
            
        // ==================== STOCK MANAGEMENT ====================
        
       case 'get_stock':
    checkAdminOrEmployee();
    $item_id = $_GET['item_id'] ?? 0;

    $stmt = $pdo->prepare("
        SELECT 
            id,
            item_id,
            product_code,
            product_key,
            notes,
            status,
            is_reusable,
            used_count,
            max_uses,
            sold_to_user_id,
            sold_at,
            order_id,
            created_at
        FROM product_stock
        WHERE item_id = ?
        ORDER BY status ASC, created_at DESC
    ");
    $stmt->execute([$item_id]);

    $response['success'] = true;
    $response['stock'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    break;

            
             case 'add_stock':
    checkAdminOrEmployee();

    $item_id = (int)$_POST['item_id'];
    $product_code = trim($_POST['product_code']);
    $product_key = trim($_POST['product_key']);
    $notes = trim($_POST['notes']);
    $is_reusable = isset($_POST['is_reusable']) ? (int)$_POST['is_reusable'] : 0;
    $max_uses = isset($_POST['max_uses']) ? (int)$_POST['max_uses'] : 1;

    if (!$item_id || !$product_code) {
        $response['success'] = false;
        $response['message'] = 'Code requis';
        break;
    }

    $stmt = $pdo->prepare("
        INSERT INTO product_stock 
            (item_id, product_code, product_key, notes, status, is_reusable, used_count, max_uses)
        VALUES 
            (?, ?, ?, ?, 'available', ?, 0, ?)
    ");

    $stmt->execute([$item_id, $product_code, $product_key, $notes, $is_reusable, $max_uses]);

    $response['success'] = true;
    $response['stock_id'] = $pdo->lastInsertId();
    $response['message'] = 'Stock ajouté';
    break;


$max_uses = isset($_POST['max_uses']) ? (int)$_POST['max_uses'] : 1;

$stmt = $pdo->prepare("
    INSERT INTO product_stock (item_id, product_code, product_key, notes, status, is_reusable, max_uses, used_count)
    VALUES (?, ?, ?, ?, 'available', ?, ?, 0)
");
$stmt->execute([$item_id, $product_code, $product_key, $notes, $is_reusable, $max_uses]);

    $stmt = $pdo->prepare("
        INSERT INTO product_stock (item_id, product_code, product_key, notes, status, is_reusable, created_at)
        VALUES (?, ?, ?, ?, 'available', ?, NOW())
    ");
    $stmt->execute([$item_id, $product_code, $product_key, $notes, $is_reusable]);

    $response['success'] = true;
    $response['stock_id'] = $pdo->lastInsertId();
    $response['message'] = 'Stock ajouté avec succès';
    break;

            
        case 'remove_stock':
            checkAdmin();
            
            $stock_id = $_POST['stock_id'] ?? 0;
            
            $stmt = $pdo->prepare("DELETE FROM product_stock WHERE id = ? AND status = 'available'");
            $stmt->execute([$stock_id]);
            
            if ($stmt->rowCount() > 0) {
                $response['success'] = true;
                $response['message'] = 'Code supprimé du stock';
            } else {
                $response['message'] = 'Impossible de supprimer (code déjà vendu ou introuvable)';
            }
            break;
            
        case 'update_stock_status':
            checkAdminOrEmployee();
            
            $stock_id = $_POST['stock_id'] ?? 0;
            $status = $_POST['status'] ?? 'available';
            $client_name = $_POST['client_name'] ?? '';
            
            if (!in_array($status, ['available', 'sold', 'reserved'])) {
                $response['message'] = 'Statut invalide';
                break;
            }
            
            $stmt = $pdo->prepare("
                UPDATE product_stock 
                SET status = ?, sold_to_user_id = ?, sold_at = NOW()
                WHERE id = ? AND status = 'available'
            ");
            
            // For sold status, we need to store client info (we'll use notes field)
            if ($status === 'sold' && $client_name) {
                $stmt = $pdo->prepare("
                    UPDATE product_stock 
                    SET status = ?, notes = CONCAT(COALESCE(notes, ''), '\nVendu à: ', ?), sold_at = NOW()
                    WHERE id = ? AND status = 'available'
                ");
                $stmt->execute([$status, $client_name, $stock_id]);
            } else {
                $stmt->execute([$status, null, $stock_id]);
            }
            
            if ($stmt->rowCount() > 0) {
                $response['success'] = true;
                $response['message'] = 'Statut mis à jour';
            } else {
                $response['message'] = 'Impossible de mettre à jour (déjà vendu ou introuvable)';
            }
            break;
            
        case 'createCategory':
            checkAdminOrEmployee();

            $name = $_POST['name'] ?? '';
            $icon = $_POST['icon'] ?? '📦';
            $type = $_POST['type'] ?? 'product';

            if (empty($name)) {
                $response['message'] = 'Le nom est requis';
                break;
            }

            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));

            $stmt = $pdo->prepare("
                INSERT INTO shop_categories (name, slug, icon, type)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$name, $slug, $icon, $type]);

            $response['success'] = true;
            $response['category_id'] = $pdo->lastInsertId();
            $response['message'] = 'Catégorie créée avec succès';
            break;
            
        default:
            $response['message'] = 'Action non valide: ' . $action;
            error_log("API shop-dynamic.php - Unknown action: " . $action);
            case 'reorder_category':
    $dragged = $_POST['dragged'];
    $target = $_POST['target'];

    // Swap positions
    $pdo->prepare("UPDATE shop_categories SET sort_order = sort_order + 1 WHERE id = ?")->execute([$target]);
    $pdo->prepare("UPDATE shop_categories SET sort_order = sort_order - 1 WHERE id = ?")->execute([$dragged]);

    $response['success'] = true;
    break;

    }
    
} catch (PDOException $e) {
    $response['message'] = 'Erreur base de données: ' . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);

function checkAdminOrEmployee() {
    // For now, skip authentication check to test functionality
    // TODO: Re-enable in production
    return true;
    
    /*
    if (!isset($_SESSION['user_role']) || 
        !in_array($_SESSION['user_role'], ['admin', 'super_admin', 'employee'])) {
        throw new Exception('Accès non autorisé');
    }
    */
}

function checkAdmin() {
    // For now, skip authentication check to test functionality
    // TODO: Re-enable in production
    return true;
    
    /*
    if (!isset($_SESSION['user_role']) || 
        !in_array($_SESSION['user_role'], ['admin', 'super_admin'])) {
        throw new Exception('Accès réservé aux administrateurs');
    }
    */
}
