<?php
/**
 * API de gestion du profil utilisateur
 * Photo de profil, préférences, paramètres
 */

session_start();
header('Content-Type: application/json');
require_once '../config/database.php';

// Vérifier l'authentification
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Non authentifié']);
    exit;
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'upload_profile_picture':
        uploadProfilePicture();
        break;
    case 'update_preferences':
        updatePreferences();
        break;
    case 'get_profile':
        getProfile();
        break;
    case 'update_profile':
        updateProfile();
        break;
    default:
        echo json_encode(['success' => false, 'error' => 'Action non valide']);
}

/**
 * Upload de la photo de profil
 */
function uploadProfilePicture() {
    if (!isset($_FILES['profile_picture'])) {
        echo json_encode(['success' => false, 'error' => 'Aucun fichier sélectionné']);
        return;
    }
    
    $file = $_FILES['profile_picture'];
    
    // Vérifier le type de fichier
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($file['type'], $allowedTypes)) {
        echo json_encode(['success' => false, 'error' => 'Type de fichier non autorisé']);
        return;
    }
    
    // Vérifier la taille (max 5MB)
    if ($file['size'] > 5 * 1024 * 1024) {
        echo json_encode(['success' => false, 'error' => 'Fichier trop volumineux (max 5MB)']);
        return;
    }
    
    try {
        $pdo = getDB();
        
        // Créer le dossier si nécessaire
        $uploadDir = '../uploads/profiles';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        // Générer un nom unique
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'profile_' . $_SESSION['user_id'] . '_' . time() . '.' . $extension;
        $filepath = $uploadDir . '/' . $filename;
        
        // Récupérer l'ancienne photo
        $stmt = $pdo->prepare("SELECT profile_picture FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $oldPicture = $stmt->fetchColumn();
        
        // Supprimer l'ancienne photo si elle existe
        if ($oldPicture && file_exists('../' . $oldPicture)) {
            unlink('../' . $oldPicture);
        }
        
        // Déplacer le fichier
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            // Créer une miniature (200x200)
            createThumbnail($filepath, $filepath, 200, 200);
            
            // Mettre à jour en base
            $relativePath = 'uploads/profiles/' . $filename;
            $stmt = $pdo->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
            $stmt->execute([$relativePath, $_SESSION['user_id']]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Photo de profil mise à jour',
                'profile_picture' => $relativePath
            ]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Erreur lors de l\'upload']);
        }
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Mettre à jour les préférences utilisateur
 */
function updatePreferences() {
    $currency = $_POST['currency'] ?? '';
    $language = $_POST['language'] ?? '';
    $theme = $_POST['theme'] ?? '';
    
    try {
        $pdo = getDB();
        
        $updates = [];
        $params = [];
        
        // Devise
        if ($currency && in_array($currency, ['EUR', 'USD', 'GBP', 'MAD', 'TND', 'DZD'])) {
            $updates[] = "preferred_currency = ?";
            $params[] = $currency;
            
            // Mettre à jour aussi le wallet
            $stmt = $pdo->prepare("UPDATE wallets SET currency = ? WHERE user_id = ?");
            $stmt->execute([$currency, $_SESSION['user_id']]);
        }
        
        // Langue
        if ($language && in_array($language, ['fr', 'en', 'ar', 'es'])) {
            $updates[] = "language = ?";
            $params[] = $language;
        }
        
        // Thème
        if ($theme && in_array($theme, ['light', 'dark', 'auto'])) {
            $updates[] = "theme = ?";
            $params[] = $theme;
        }
        
        if (empty($updates)) {
            echo json_encode(['success' => false, 'error' => 'Aucune préférence à mettre à jour']);
            return;
        }
        
        $params[] = $_SESSION['user_id'];
        $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        echo json_encode([
            'success' => true,
            'message' => 'Préférences mises à jour avec succès'
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Récupérer le profil complet
 */
function getProfile() {
    try {
        $pdo = getDB();
        
        $stmt = $pdo->prepare("
            SELECT 
                u.id, u.email, u.full_name, u.phone, u.company,
                u.profile_picture, u.preferred_currency, u.language, u.theme,
                u.status, u.email_verified, u.last_login, u.created_at,
                r.name as role_name, r.display_name as role_display,
                w.balance, w.currency as wallet_currency
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.id
            LEFT JOIN wallets w ON u.id = w.user_id
            WHERE u.id = ?
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $profile = $stmt->fetch();
        
        if (!$profile) {
            echo json_encode(['success' => false, 'error' => 'Profil non trouvé']);
            return;
        }
        
        unset($profile['password']);
        
        echo json_encode([
            'success' => true,
            'profile' => $profile
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Mettre à jour le profil (nom, téléphone, entreprise)
 */
function updateProfile() {
    $fullName = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $company = trim($_POST['company'] ?? '');
    
    try {
        $pdo = getDB();
        
        $updates = [];
        $params = [];
        
        if ($fullName) {
            $updates[] = "full_name = ?";
            $params[] = $fullName;
        }
        
        if ($phone) {
            $updates[] = "phone = ?";
            $params[] = $phone;
        }
        
        if ($company) {
            $updates[] = "company = ?";
            $params[] = $company;
        }
        
        if (empty($updates)) {
            echo json_encode(['success' => false, 'error' => 'Aucune donnée à mettre à jour']);
            return;
        }
        
        $params[] = $_SESSION['user_id'];
        $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        echo json_encode([
            'success' => true,
            'message' => 'Profil mis à jour avec succès'
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Créer une miniature
 */
function createThumbnail($source, $destination, $width, $height) {
    $imageInfo = getimagesize($source);
    $mimeType = $imageInfo['mime'];
    
    switch ($mimeType) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($source);
            break;
        case 'image/png':
            $image = imagecreatefrompng($source);
            break;
        case 'image/gif':
            $image = imagecreatefromgif($source);
            break;
        case 'image/webp':
            $image = imagecreatefromwebp($source);
            break;
        default:
            return false;
    }
    
    $originalWidth = imagesx($image);
    $originalHeight = imagesy($image);
    
    // Calculer les dimensions pour conserver le ratio
    $ratio = $originalWidth / $originalHeight;
    
    if ($width / $height > $ratio) {
        $newWidth = $height * $ratio;
        $newHeight = $height;
    } else {
        $newWidth = $width;
        $newHeight = $width / $ratio;
    }
    
    // Créer l'image redimensionnée
    $thumb = imagecreatetruecolor($width, $height);
    
    // Fond blanc pour les PNG transparents
    $white = imagecolorallocate($thumb, 255, 255, 255);
    imagefill($thumb, 0, 0, $white);
    
    // Centrer l'image
    $offsetX = ($width - $newWidth) / 2;
    $offsetY = ($height - $newHeight) / 2;
    
    imagecopyresampled($thumb, $image, $offsetX, $offsetY, 0, 0, $newWidth, $newHeight, $originalWidth, $originalHeight);
    
    // Sauvegarder
    imagejpeg($thumb, $destination, 90);
    
    imagedestroy($image);
    imagedestroy($thumb);
    
    return true;
}
