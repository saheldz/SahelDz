<?php
/**
 * API de gestion des wallets
 * Admin peut ajouter/retirer du solde
 * Clients peuvent voir leur historique
 */

session_start();
header('Content-Type: application/json');
require_once '../config/database.php';

// Vérifier l'authentification
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Non authentifié']);
    exit;
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'get_balance':
        getBalance();
        break;
    case 'get_transactions':
        getTransactions();
        break;
    case 'add_funds':
        addFunds();  // Admin seulement
        break;
    case 'deduct_funds':
        deductFunds();  // Admin seulement
        break;
    case 'get_all_wallets':
        getAllWallets();  // Admin seulement
        break;
    case 'manage_wallet_funds':
        manageWalletFunds();  // Admin seulement
        break;
    default:
        echo json_encode(['success' => false, 'error' => 'Action non valide']);
}

/**
 * Gérer les fonds (ajouter ou retirer) selon le type
 */
function manageWalletFunds() {
    $type = $_POST['type'] ?? '';
    
    if ($type === 'credit') {
        addFunds();
    } elseif ($type === 'debit') {
        deductFunds();
    } else {
        echo json_encode(['success' => false, 'error' => 'Type de transaction invalide']);
    }
}

/**
 * Récupérer le solde de l'utilisateur
 */
function getBalance() {
    try {
        $pdo = getDB();
        
        $stmt = $pdo->prepare("SELECT balance, currency, status FROM wallets WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $wallet = $stmt->fetch();
        
        if (!$wallet) {
            echo json_encode(['success' => false, 'error' => 'Wallet non trouvé']);
            return;
        }
        
        echo json_encode([
            'success' => true,
            'wallet' => $wallet
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Récupérer l'historique des transactions
 */
function getTransactions() {
    $limit = intval($_GET['limit'] ?? 50);
    $offset = intval($_GET['offset'] ?? 0);
    
    try {
        $pdo = getDB();
        
        // Récupérer le wallet_id
        $stmt = $pdo->prepare("SELECT id FROM wallets WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $wallet = $stmt->fetch();
        
        if (!$wallet) {
            echo json_encode(['success' => false, 'error' => 'Wallet non trouvé']);
            return;
        }
        
        // Récupérer les transactions
        $stmt = $pdo->prepare("
            SELECT t.*, u.full_name as created_by_name
            FROM transactions t
            LEFT JOIN users u ON t.created_by = u.id
            WHERE t.wallet_id = ?
            ORDER BY t.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$wallet['id'], $limit, $offset]);
        $transactions = $stmt->fetchAll();
        
        // Compter le total
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM transactions WHERE wallet_id = ?");
        $stmt->execute([$wallet['id']]);
        $total = $stmt->fetch()['total'];
        
        echo json_encode([
            'success' => true,
            'transactions' => $transactions,
            'total' => $total,
            'limit' => $limit,
            'offset' => $offset
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Ajouter des fonds (Admin seulement)
 */
function addFunds() {
    // Vérifier les permissions
    if (!isAdmin()) {
        echo json_encode(['success' => false, 'error' => 'Accès refusé - Admin seulement']);
        return;
    }
    
    $userId = intval($_POST['user_id'] ?? 0);
    $amount = floatval($_POST['amount'] ?? 0);
    $description = trim($_POST['description'] ?? 'Ajout de fonds par administrateur');
    
    if (!$userId || $amount <= 0) {
        echo json_encode(['success' => false, 'error' => 'ID utilisateur et montant valides requis']);
        return;
    }
    
    try {
        $pdo = getDB();
        $pdo->beginTransaction();
        
        // Récupérer le wallet
        $stmt = $pdo->prepare("SELECT id, balance FROM wallets WHERE user_id = ? FOR UPDATE");
        $stmt->execute([$userId]);
        $wallet = $stmt->fetch();
        
        if (!$wallet) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'error' => 'Wallet non trouvé']);
            return;
        }
        
        $balanceBefore = floatval($wallet['balance']);
        $balanceAfter = $balanceBefore + $amount;
        
        // Mettre à jour le solde
        $stmt = $pdo->prepare("UPDATE wallets SET balance = ? WHERE id = ?");
        $stmt->execute([$balanceAfter, $wallet['id']]);
        
        // Créer la transaction
        $reference = 'CREDIT-' . time() . '-' . $userId;
        $stmt = $pdo->prepare("
            INSERT INTO transactions (wallet_id, type, amount, balance_before, balance_after, description, reference, created_by, status)
            VALUES (?, 'credit', ?, ?, ?, ?, ?, ?, 'completed')
        ");
        $stmt->execute([
            $wallet['id'],
            $amount,
            $balanceBefore,
            $balanceAfter,
            $description,
            $reference,
            $_SESSION['user_id']
        ]);
        
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Fonds ajoutés avec succès',
            'wallet' => [
                'balance_before' => $balanceBefore,
                'balance_after' => $balanceAfter,
                'amount_added' => $amount
            ],
            'transaction_id' => $pdo->lastInsertId()
        ]);
        
    } catch (PDOException $e) {
        if (isset($pdo)) {
            $pdo->rollBack();
        }
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Retirer des fonds (Admin seulement)
 */
function deductFunds() {
    // Vérifier les permissions
    if (!isAdmin()) {
        echo json_encode(['success' => false, 'error' => 'Accès refusé - Admin seulement']);
        return;
    }
    
    $userId = intval($_POST['user_id'] ?? 0);
    $amount = floatval($_POST['amount'] ?? 0);
    $description = trim($_POST['description'] ?? 'Retrait de fonds par administrateur');
    
    if (!$userId || $amount <= 0) {
        echo json_encode(['success' => false, 'error' => 'ID utilisateur et montant valides requis']);
        return;
    }
    
    try {
        $pdo = getDB();
        $pdo->beginTransaction();
        
        // Récupérer le wallet
        $stmt = $pdo->prepare("SELECT id, balance FROM wallets WHERE user_id = ? FOR UPDATE");
        $stmt->execute([$userId]);
        $wallet = $stmt->fetch();
        
        if (!$wallet) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'error' => 'Wallet non trouvé']);
            return;
        }
        
        $balanceBefore = floatval($wallet['balance']);
        
        if ($balanceBefore < $amount) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'error' => 'Solde insuffisant']);
            return;
        }
        
        $balanceAfter = $balanceBefore - $amount;
        
        // Mettre à jour le solde
        $stmt = $pdo->prepare("UPDATE wallets SET balance = ? WHERE id = ?");
        $stmt->execute([$balanceAfter, $wallet['id']]);
        
        // Créer la transaction
        $reference = 'DEBIT-' . time() . '-' . $userId;
        $stmt = $pdo->prepare("
            INSERT INTO transactions (wallet_id, type, amount, balance_before, balance_after, description, reference, created_by, status)
            VALUES (?, 'debit', ?, ?, ?, ?, ?, ?, 'completed')
        ");
        $stmt->execute([
            $wallet['id'],
            $amount,
            $balanceBefore,
            $balanceAfter,
            $description,
            $reference,
            $_SESSION['user_id']
        ]);
        
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Fonds retirés avec succès',
            'wallet' => [
                'balance_before' => $balanceBefore,
                'balance_after' => $balanceAfter,
                'amount_deducted' => $amount
            ],
            'transaction_id' => $pdo->lastInsertId()
        ]);
        
    } catch (PDOException $e) {
        if (isset($pdo)) {
            $pdo->rollBack();
        }
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Récupérer tous les wallets (Admin seulement)
 */
function getAllWallets() {
    if (!isAdmin()) {
        echo json_encode(['success' => false, 'error' => 'Accès refusé - Admin seulement']);
        return;
    }
    
    try {
        $pdo = getDB();
        
        $stmt = $pdo->query("
            SELECT 
                u.id,
                u.email,
                u.full_name,
                u.company,
                w.balance,
                w.currency,
                w.status as wallet_status,
                r.display_name as role
            FROM users u
            LEFT JOIN wallets w ON u.id = w.user_id
            LEFT JOIN roles r ON u.role_id = r.id
            WHERE u.status = 'active'
            ORDER BY w.balance DESC
        ");
        
        $wallets = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'wallets' => $wallets
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Vérifier si l'utilisateur est admin
 */
function isAdmin() {
    try {
        $pdo = getDB();
        
        $stmt = $pdo->prepare("
            SELECT r.name, r.permissions
            FROM users u
            JOIN roles r ON u.role_id = r.id
            WHERE u.id = ?
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        
        if (!$user) {
            return false;
        }
        
        // Super admin ou admin
        if ($user['name'] === 'super_admin' || $user['name'] === 'admin') {
            return true;
        }
        
        // Vérifier les permissions JSON
        $permissions = json_decode($user['permissions'], true);
        if (isset($permissions['all']) && $permissions['all'] === true) {
            return true;
        }
        
        return false;
        
    } catch (PDOException $e) {
        return false;
    }
}
