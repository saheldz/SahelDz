<?php
/**
 * API d'authentification
 * Login, Register, Logout, Session management
 */

session_start();
header('Content-Type: application/json');
require_once '../config/database.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'register':
        handleRegister();
        break;
    case 'login':
        handleLogin();
        break;
    case 'logout':
        handleLogout();
        break;
    case 'check_session':
        checkSession();
        break;
    case 'get_user_info':
        getUserInfo();
        break;
    case 'change_password':
        changePassword();
        break;
    default:
        echo json_encode(['success' => false, 'error' => 'Action non valide']);
}

/**
 * Changer le mot de passe
 */
function changePassword() {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'error' => 'Non authentifié']);
        return;
    }
    
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    
    if (!$currentPassword || !$newPassword) {
        echo json_encode(['success' => false, 'error' => 'Tous les champs sont requis']);
        return;
    }
    
    if (strlen($newPassword) < 8) {
        echo json_encode(['success' => false, 'error' => 'Le nouveau mot de passe doit contenir au moins 8 caractères']);
        return;
    }
    
    try {
        $pdo = getDB();
        
        // Récupérer le mot de passe actuel
        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        
        if (!$user) {
            echo json_encode(['success' => false, 'error' => 'Utilisateur non trouvé']);
            return;
        }
        
        // Vérifier le mot de passe actuel
        if (!password_verify($currentPassword, $user['password'])) {
            echo json_encode(['success' => false, 'error' => 'Mot de passe actuel incorrect']);
            return;
        }
        
        // Hasher le nouveau mot de passe
        $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
        
        // Mettre à jour le mot de passe
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$hashedPassword, $_SESSION['user_id']]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Mot de passe modifié avec succès'
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Inscription d'un nouvel utilisateur
 */
function handleRegister() {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $company = trim($_POST['company'] ?? '');
    
    // Validation
    if (!$email || !$password || !$full_name) {
        echo json_encode(['success' => false, 'error' => 'Email, mot de passe et nom complet sont requis']);
        return;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'error' => 'Email invalide']);
        return;
    }
    
    if (strlen($password) < 6) {
        echo json_encode(['success' => false, 'error' => 'Le mot de passe doit contenir au moins 6 caractères']);
        return;
    }
    
    try {
        $pdo = getDB();
        
        // Vérifier si l'email existe déjà
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        
        if ($stmt->fetch()) {
            echo json_encode(['success' => false, 'error' => 'Cet email est déjà utilisé']);
            return;
        }
        
        // Hasher le mot de passe
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        
        // Récupérer l'ID du rôle "client" par défaut
        $stmt = $pdo->prepare("SELECT id FROM roles WHERE name = 'client' LIMIT 1");
        $stmt->execute();
        $clientRole = $stmt->fetch();
        $defaultRoleId = $clientRole ? $clientRole['id'] : 3; // Fallback vers 3 si le rôle n'existe pas
        
        // Insérer l'utilisateur avec le rôle client par défaut
        $stmt = $pdo->prepare("INSERT INTO users (email, password, full_name, phone, company, role_id, status) 
                              VALUES (?, ?, ?, ?, ?, ?, 'active')");
        $stmt->execute([$email, $hashedPassword, $full_name, $phone, $company, $defaultRoleId]);
        
        $userId = $pdo->lastInsertId();
        
        // Créer un wallet pour l'utilisateur
        $stmt = $pdo->prepare("INSERT INTO wallets (user_id, balance, status) VALUES (?, 0.00, 'active')");
        $stmt->execute([$userId]);
        
        // Créer la session
        createUserSession($userId);
        
        echo json_encode([
            'success' => true,
            'message' => 'Inscription réussie!',
            'user' => [
                'id' => $userId,
                'email' => $email,
                'full_name' => $full_name,
                'role' => 'client'
            ]
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Connexion utilisateur
 */
function handleLogin() {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (!$email || !$password) {
        echo json_encode(['success' => false, 'error' => 'Email et mot de passe requis']);
        return;
    }
    
    try {
        $pdo = getDB();
        
        // Récupérer l'utilisateur
        $stmt = $pdo->prepare("
            SELECT u.*, r.name as role_name, r.display_name as role_display, r.permissions
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.id
            WHERE u.email = ?
        ");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if (!$user) {
            echo json_encode(['success' => false, 'error' => 'Email ou mot de passe incorrect']);
            return;
        }
        
        // Vérifier le mot de passe
        if (!password_verify($password, $user['password'])) {
            echo json_encode(['success' => false, 'error' => 'Email ou mot de passe incorrect']);
            return;
        }
        
        // Vérifier le statut
        if ($user['status'] !== 'active') {
            echo json_encode(['success' => false, 'error' => 'Compte ' . $user['status']]);
            return;
        }
        
        // Mettre à jour last_login
        $stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $stmt->execute([$user['id']]);
        
        // Créer la session
        createUserSession($user['id']);
        
        // Récupérer le wallet
        $stmt = $pdo->prepare("SELECT balance, currency FROM wallets WHERE user_id = ?");
        $stmt->execute([$user['id']]);
        $wallet = $stmt->fetch();
        
        echo json_encode([
            'success' => true,
            'message' => 'Connexion réussie!',
            'user' => [
                'id' => $user['id'],
                'email' => $user['email'],
                'full_name' => $user['full_name'],
                'phone' => $user['phone'],
                'company' => $user['company'],
                'role' => $user['role_name'],
                'role_display' => $user['role_display'],
                'permissions' => json_decode($user['permissions'], true),
                'wallet' => $wallet
            ]
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Déconnexion
 */
function handleLogout() {
    if (isset($_SESSION['user_id']) && isset($_SESSION['session_token'])) {
        try {
            $pdo = getDB();
            $stmt = $pdo->prepare("DELETE FROM user_sessions WHERE session_token = ?");
            $stmt->execute([$_SESSION['session_token']]);
        } catch (PDOException $e) {
            // Silent fail
        }
    }
    
    session_destroy();
    echo json_encode(['success' => true, 'message' => 'Déconnexion réussie']);
}

/**
 * Vérifier la session
 */
function checkSession() {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['session_token'])) {
        echo json_encode(['success' => false, 'authenticated' => false]);
        return;
    }
    
    try {
        $pdo = getDB();
        
        // Vérifier que la session existe et n'est pas expirée
        $stmt = $pdo->prepare("
            SELECT s.*, u.email, u.full_name, u.status, r.name as role_name, r.display_name as role_display
            FROM user_sessions s
            JOIN users u ON s.user_id = u.id
            LEFT JOIN roles r ON u.role_id = r.id
            WHERE s.session_token = ? AND s.expires_at > NOW() AND u.status = 'active'
        ");
        $stmt->execute([$_SESSION['session_token']]);
        $session = $stmt->fetch();
        
        if (!$session) {
            session_destroy();
            echo json_encode(['success' => false, 'authenticated' => false]);
            return;
        }
        
        // Récupérer le wallet
        $stmt = $pdo->prepare("SELECT balance, currency FROM wallets WHERE user_id = ?");
        $stmt->execute([$session['user_id']]);
        $wallet = $stmt->fetch();
        
        echo json_encode([
            'success' => true,
            'authenticated' => true,
            'user' => [
                'id' => $session['user_id'],
                'email' => $session['email'],
                'full_name' => $session['full_name'],
                'role' => $session['role_name'],
                'role_display' => $session['role_display'],
                'wallet' => $wallet
            ]
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Récupérer les informations utilisateur
 */
function getUserInfo() {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'error' => 'Non authentifié']);
        return;
    }
    
    try {
        $pdo = getDB();
        
        $stmt = $pdo->prepare("
            SELECT u.*, r.name as role_name, r.display_name as role_display, r.permissions
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.id
            WHERE u.id = ?
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        
        if (!$user) {
            echo json_encode(['success' => false, 'error' => 'Utilisateur non trouvé']);
            return;
        }
        
        // Récupérer le wallet
        $stmt = $pdo->prepare("SELECT balance, currency, status FROM wallets WHERE user_id = ?");
        $stmt->execute([$user['id']]);
        $wallet = $stmt->fetch();
        
        // Récupérer les dernières transactions
        $stmt = $pdo->prepare("
            SELECT t.* FROM transactions t
            JOIN wallets w ON t.wallet_id = w.id
            WHERE w.user_id = ?
            ORDER BY t.created_at DESC
            LIMIT 10
        ");
        $stmt->execute([$user['id']]);
        $transactions = $stmt->fetchAll();
        
        unset($user['password']); // Ne pas renvoyer le mot de passe
        
        echo json_encode([
            'success' => true,
            'user' => $user,
            'wallet' => $wallet,
            'recent_transactions' => $transactions
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Créer une session utilisateur
 */
function createUserSession($userId) {
    $sessionToken = bin2hex(random_bytes(32));
    $expiresAt = date('Y-m-d H:i:s', strtotime('+30 days'));
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    try {
        $pdo = getDB();
        $stmt = $pdo->prepare("
            INSERT INTO user_sessions (user_id, session_token, ip_address, user_agent, expires_at)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$userId, $sessionToken, $ipAddress, $userAgent, $expiresAt]);
        
        // Stocker dans la session PHP
        $_SESSION['user_id'] = $userId;
        $_SESSION['session_token'] = $sessionToken;
        
    } catch (PDOException $e) {
        // Silent fail
    }
}
