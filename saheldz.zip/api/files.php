<?php
/**
 * API de gestion des fichiers
 * Upload, suppression, génération de miniatures
 */

header('Content-Type: application/json');
require_once '../config/database.php';

// Récupérer l'action
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'upload':
        handleUpload();
        break;
    case 'delete':
        handleDelete();
        break;
    case 'list':
        handleList();
        break;
    case 'get_project_files':
        getProjectFiles();
        break;
    default:
        echo json_encode(['success' => false, 'error' => 'Action non valide']);
}

/**
 * Upload de fichiers
 */
function handleUpload() {
    if (!isset($_FILES['file']) || !isset($_POST['project_id']) || !isset($_POST['category'])) {
        echo json_encode(['success' => false, 'error' => 'Paramètres manquants']);
        return;
    }
    
    $projectId = intval($_POST['project_id']);
    $category = $_POST['category']; // 'reference', 'assets', 'deliverables'
    $file = $_FILES['file'];
    
    // Vérifier les erreurs d'upload
    if ($file['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['success' => false, 'error' => 'Erreur lors de l\'upload']);
        return;
    }
    
    // Vérifier le type de fichier
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf', 'image/svg+xml'];
    $fileType = mime_content_type($file['tmp_name']);
    
    if (!in_array($fileType, $allowedTypes)) {
        echo json_encode(['success' => false, 'error' => 'Type de fichier non autorisé']);
        return;
    }
    
    // Créer un nom de fichier unique
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid('file_') . '_' . time() . '.' . $extension;
    
    // Déterminer le chemin de destination
    $uploadDir = "../uploads/branding/project_" . $projectId . "/";
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $filepath = $uploadDir . $filename;
    
    // Déplacer le fichier
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        echo json_encode(['success' => false, 'error' => 'Impossible de déplacer le fichier']);
        return;
    }
    
    // Générer une miniature si c'est une image
    $thumbnailPath = null;
    if (strpos($fileType, 'image') === 0 && $fileType !== 'image/svg+xml') {
        $thumbnailPath = generateThumbnail($filepath, $uploadDir, $filename);
    }
    
    // Enregistrer dans la base de données
    try {
        $pdo = getDB();
        $sql = "INSERT INTO project_files (project_id, filename, original_name, filepath, file_type, file_size, file_category, thumbnail_path) 
                VALUES (:project_id, :filename, :original_name, :filepath, :file_type, :file_size, :file_category, :thumbnail_path)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'project_id' => $projectId,
            'filename' => $filename,
            'original_name' => $file['name'],
            'filepath' => $filepath,
            'file_type' => $fileType,
            'file_size' => $file['size'],
            'file_category' => $category,
            'thumbnail_path' => $thumbnailPath
        ]);
        
        $fileId = $pdo->lastInsertId();
        
        echo json_encode([
            'success' => true,
            'file' => [
                'id' => $fileId,
                'filename' => $filename,
                'original_name' => $file['name'],
                'filepath' => str_replace('../', '', $filepath),
                'thumbnail' => $thumbnailPath ? str_replace('../', '', $thumbnailPath) : null,
                'file_type' => $fileType,
                'file_size' => $file['size'],
                'category' => $category
            ]
        ]);
        
    } catch (PDOException $e) {
        // Supprimer le fichier si l'insertion échoue
        if (file_exists($filepath)) {
            unlink($filepath);
        }
        if ($thumbnailPath && file_exists($thumbnailPath)) {
            unlink($thumbnailPath);
        }
        
        echo json_encode(['success' => false, 'error' => 'Erreur base de données: ' . $e->getMessage()]);
    }
}

/**
 * Générer une miniature
 */
function generateThumbnail($sourcePath, $uploadDir, $filename) {
    $thumbnailDir = $uploadDir . 'thumbnails/';
    if (!file_exists($thumbnailDir)) {
        mkdir($thumbnailDir, 0755, true);
    }
    
    $thumbnailPath = $thumbnailDir . 'thumb_' . $filename;
    
    // Obtenir les dimensions de l'image source
    list($width, $height, $type) = getimagesize($sourcePath);
    
    // Créer l'image source
    switch ($type) {
        case IMAGETYPE_JPEG:
            $source = imagecreatefromjpeg($sourcePath);
            break;
        case IMAGETYPE_PNG:
            $source = imagecreatefrompng($sourcePath);
            break;
        case IMAGETYPE_GIF:
            $source = imagecreatefromgif($sourcePath);
            break;
        case IMAGETYPE_WEBP:
            $source = imagecreatefromwebp($sourcePath);
            break;
        default:
            return null;
    }
    
    if (!$source) {
        return null;
    }
    
    // Calculer les nouvelles dimensions (max 200px)
    $maxSize = 200;
    $ratio = min($maxSize / $width, $maxSize / $height);
    $newWidth = intval($width * $ratio);
    $newHeight = intval($height * $ratio);
    
    // Créer la miniature
    $thumbnail = imagecreatetruecolor($newWidth, $newHeight);
    
    // Préserver la transparence pour PNG et GIF
    if ($type == IMAGETYPE_PNG || $type == IMAGETYPE_GIF) {
        imagecolortransparent($thumbnail, imagecolorallocatealpha($thumbnail, 0, 0, 0, 127));
        imagealphablending($thumbnail, false);
        imagesavealpha($thumbnail, true);
    }
    
    // Redimensionner
    imagecopyresampled($thumbnail, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
    
    // Sauvegarder la miniature
    switch ($type) {
        case IMAGETYPE_JPEG:
            imagejpeg($thumbnail, $thumbnailPath, 85);
            break;
        case IMAGETYPE_PNG:
            imagepng($thumbnail, $thumbnailPath, 8);
            break;
        case IMAGETYPE_GIF:
            imagegif($thumbnail, $thumbnailPath);
            break;
        case IMAGETYPE_WEBP:
            imagewebp($thumbnail, $thumbnailPath, 85);
            break;
    }
    
    // Libérer la mémoire
    imagedestroy($source);
    imagedestroy($thumbnail);
    
    return $thumbnailPath;
}

/**
 * Supprimer un fichier
 */
function handleDelete() {
    if (!isset($_POST['file_id'])) {
        echo json_encode(['success' => false, 'error' => 'ID de fichier manquant']);
        return;
    }
    
    $fileId = intval($_POST['file_id']);
    
    try {
        $pdo = getDB();
        
        // Récupérer les informations du fichier
        $stmt = $pdo->prepare("SELECT filepath, thumbnail_path FROM project_files WHERE id = ?");
        $stmt->execute([$fileId]);
        $file = $stmt->fetch();
        
        if (!$file) {
            echo json_encode(['success' => false, 'error' => 'Fichier non trouvé']);
            return;
        }
        
        // Supprimer les fichiers physiques
        if (file_exists($file['filepath'])) {
            unlink($file['filepath']);
        }
        
        if ($file['thumbnail_path'] && file_exists($file['thumbnail_path'])) {
            unlink($file['thumbnail_path']);
        }
        
        // Supprimer de la base de données
        $stmt = $pdo->prepare("DELETE FROM project_files WHERE id = ?");
        $stmt->execute([$fileId]);
        
        echo json_encode(['success' => true, 'message' => 'Fichier supprimé avec succès']);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur base de données: ' . $e->getMessage()]);
    }
}

/**
 * Lister les fichiers d'un projet
 */
function getProjectFiles() {
    if (!isset($_GET['project_id'])) {
        echo json_encode(['success' => false, 'error' => 'ID de projet manquant']);
        return;
    }
    
    $projectId = intval($_GET['project_id']);
    
    try {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT * FROM project_files WHERE project_id = ? ORDER BY created_at DESC");
        $stmt->execute([$projectId]);
        $files = $stmt->fetchAll();
        
        // Convertir les chemins pour l'affichage
        foreach ($files as &$file) {
            $file['filepath'] = str_replace('../', '', $file['filepath']);
            if ($file['thumbnail_path']) {
                $file['thumbnail_path'] = str_replace('../', '', $file['thumbnail_path']);
            }
        }
        
        echo json_encode(['success' => true, 'files' => $files]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur base de données: ' . $e->getMessage()]);
    }
}

/**
 * Lister tous les fichiers (optionnel)
 */
function handleList() {
    try {
        $category = $_GET['category'] ?? null;
        
        $pdo = getDB();
        $sql = "SELECT * FROM project_files";
        $params = [];
        
        if ($category) {
            $sql .= " WHERE file_category = ?";
            $params[] = $category;
        }
        
        $sql .= " ORDER BY created_at DESC";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $files = $stmt->fetchAll();
        
        // Convertir les chemins
        foreach ($files as &$file) {
            $file['filepath'] = str_replace('../', '', $file['filepath']);
            if ($file['thumbnail_path']) {
                $file['thumbnail_path'] = str_replace('../', '', $file['thumbnail_path']);
            }
        }
        
        echo json_encode(['success' => true, 'files' => $files]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur base de données: ' . $e->getMessage()]);
    }
}
