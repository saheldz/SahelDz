<?php
/**
 * API SMTP - Configuration et envoi d'emails
 */

session_start();
header('Content-Type: application/json');
require_once '../config/database.php';

// Vérifier l'authentification
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Non authentifié']);
    exit;
}

// Vérifier les droits admin pour la configuration
$action = $_POST['action'] ?? $_GET['action'] ?? '';
$adminActions = ['save_smtp_config', 'save_auth_settings', 'test_smtp'];

if (in_array($action, $adminActions) && !isAdmin()) {
    echo json_encode(['success' => false, 'error' => 'Accès refusé - Admin seulement']);
    exit;
}

switch ($action) {
    case 'save_smtp_config':
        saveSMTPConfig();
        break;
    case 'save_auth_settings':
        saveAuthSettings();
        break;
    case 'test_smtp':
        testSMTP();
        break;
    case 'send_email':
        sendEmail();
        break;
    default:
        echo json_encode(['success' => false, 'error' => 'Action non valide']);
}

/**
 * Sauvegarder la configuration SMTP
 */
function saveSMTPConfig() {
    try {
        $pdo = getDB();
        
        // Créer la table si elle n'existe pas
        $pdo->exec("CREATE TABLE IF NOT EXISTS smtp_config (
            id INT PRIMARY KEY AUTO_INCREMENT,
            smtp_host VARCHAR(255) NOT NULL,
            smtp_port INT NOT NULL DEFAULT 587,
            smtp_username VARCHAR(255) NOT NULL,
            smtp_password VARCHAR(255),
            smtp_encryption VARCHAR(10) DEFAULT 'tls',
            from_email VARCHAR(255),
            from_name VARCHAR(255) DEFAULT 'DigiServices',
            email_verification_enabled TINYINT DEFAULT 0,
            send_welcome_email TINYINT DEFAULT 1,
            notify_project_updates TINYINT DEFAULT 1,
            notify_wallet_transactions TINYINT DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )");
        
        $smtp_host = $_POST['smtp_host'] ?? '';
        $smtp_port = intval($_POST['smtp_port'] ?? 587);
        $smtp_username = $_POST['smtp_username'] ?? '';
        $smtp_password = $_POST['smtp_password'] ?? '';
        $smtp_encryption = $_POST['smtp_encryption'] ?? 'tls';
        $from_email = $_POST['from_email'] ?? '';
        $from_name = $_POST['from_name'] ?? 'DigiServices';
        
        if (!$smtp_host || !$smtp_username) {
            echo json_encode(['success' => false, 'error' => 'Serveur et nom d\'utilisateur requis']);
            return;
        }
        
        // Vérifier si une config existe
        $stmt = $pdo->query("SELECT id, smtp_password FROM smtp_config LIMIT 1");
        $existing = $stmt->fetch();
        
        if ($existing) {
            // Mise à jour
            $updates = [
                'smtp_host = ?',
                'smtp_port = ?',
                'smtp_username = ?',
                'smtp_encryption = ?',
                'from_email = ?',
                'from_name = ?'
            ];
            $params = [$smtp_host, $smtp_port, $smtp_username, $smtp_encryption, $from_email, $from_name];
            
            // Mettre à jour le mot de passe seulement s'il est fourni
            if (!empty($smtp_password)) {
                $updates[] = 'smtp_password = ?';
                $params[] = $smtp_password;
            }
            
            $params[] = $existing['id'];
            $sql = "UPDATE smtp_config SET " . implode(', ', $updates) . " WHERE id = ?";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
        } else {
            // Insertion
            $stmt = $pdo->prepare("
                INSERT INTO smtp_config (smtp_host, smtp_port, smtp_username, smtp_password, smtp_encryption, from_email, from_name)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$smtp_host, $smtp_port, $smtp_username, $smtp_password, $smtp_encryption, $from_email, $from_name]);
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'Configuration SMTP enregistrée'
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Sauvegarder les paramètres d'authentification
 */
function saveAuthSettings() {
    try {
        $pdo = getDB();
        
        $email_verification = isset($_POST['email_verification_enabled']) ? 1 : 0;
        $welcome_email = isset($_POST['send_welcome_email']) ? 1 : 0;
        $project_updates = isset($_POST['notify_project_updates']) ? 1 : 0;
        $wallet_transactions = isset($_POST['notify_wallet_transactions']) ? 1 : 0;
        
        $stmt = $pdo->prepare("
            UPDATE smtp_config SET
                email_verification_enabled = ?,
                send_welcome_email = ?,
                notify_project_updates = ?,
                notify_wallet_transactions = ?
            WHERE id = 1
        ");
        
        $stmt->execute([$email_verification, $welcome_email, $project_updates, $wallet_transactions]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Paramètres enregistrés'
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Tester la connexion SMTP
 */
function testSMTP() {
    try {
        $pdo = getDB();
        
        $stmt = $pdo->query("SELECT * FROM smtp_config LIMIT 1");
        $config = $stmt->fetch();
        
        if (!$config) {
            echo json_encode(['success' => false, 'error' => 'Aucune configuration SMTP trouvée']);
            return;
        }
        
        // Récupérer l'email de l'admin
        $stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        
        // Tester avec mail() PHP natif
        $result = sendTestEmailNative($config, $user['email']);
        
        echo json_encode($result);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => 'Erreur: ' . $e->getMessage()]);
    }
}

/**
 * Envoyer un email de test avec mail() natif
 */
function sendTestEmailNative($config, $to) {
    try {
        $from_email = $config['from_email'] ?: $config['smtp_username'];
        $from_name = $config['from_name'];
        
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        $headers .= "From: {$from_name} <{$from_email}>\r\n";
        
        $subject = "Test SMTP - DigiServices";
        $message = "<div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;'>";
        $message .= "<h2 style='color: #667eea;'>✅ Test SMTP réussi !</h2>";
        $message .= "<p>Votre configuration SMTP fonctionne correctement.</p>";
        $message .= "<p>Ce message a été envoyé depuis votre système DigiServices.</p>";
        $message .= "<hr style='margin: 20px 0; border: none; border-top: 1px solid #e5e7eb;'>";
        $message .= "<p style='color: #6b7280; font-size: 14px;'>Serveur: {$config['smtp_host']}:{$config['smtp_port']}</p>";
        $message .= "</div>";
        
        $result = mail($to, $subject, $message, $headers);
        
        if ($result) {
            return ['success' => true, 'message' => 'Email de test envoyé'];
        } else {
            return ['success' => false, 'error' => 'Échec de l\'envoi de l\'email'];
        }
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Envoyer un email générique
 */
function sendEmail() {
    $to = $_POST['to'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $message = $_POST['message'] ?? '';
    
    if (!$to || !$subject || !$message) {
        echo json_encode(['success' => false, 'error' => 'Paramètres manquants']);
        return;
    }
    
    try {
        $pdo = getDB();
        $stmt = $pdo->query("SELECT * FROM smtp_config LIMIT 1");
        $config = $stmt->fetch();
        
        if (!$config) {
            echo json_encode(['success' => false, 'error' => 'Configuration SMTP non trouvée']);
            return;
        }
        
        $from_email = $config['from_email'] ?: $config['smtp_username'];
        $from_name = $config['from_name'];
        
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        $headers .= "From: {$from_name} <{$from_email}>\r\n";
        
        $result = mail($to, $subject, $message, $headers);
        
        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Email envoyé']);
        } else {
            echo json_encode(['success' => false, 'error' => 'Échec de l\'envoi']);
        }
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
}

/**
 * Vérifier si l'utilisateur est admin
 */
function isAdmin() {
    try {
        $pdo = getDB();
        
        $stmt = $pdo->prepare("
            SELECT r.name
            FROM users u
            JOIN roles r ON u.role_id = r.id
            WHERE u.id = ?
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        
        return $user && in_array($user['name'], ['super_admin', 'admin']);
        
    } catch (PDOException $e) {
        return false;
    }
}
