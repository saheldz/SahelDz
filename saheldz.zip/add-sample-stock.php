<?php
/**
 * Ajouter des produits exemple au stock
 */

require_once 'config/database.php';

$pdo = getDB();

echo "=== AJOUT DE PRODUITS AU STOCK ===\n\n";

try {
    // Get product IDs
    $stmt = $pdo->query("SELECT id, name FROM shop_items WHERE type = 'product' ORDER BY id");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($products)) {
        echo "❌ Aucun produit trouvé dans shop_items\n";
        exit(1);
    }
    
    echo "Produits disponibles:\n";
    foreach ($products as $product) {
        echo "  - ID {$product['id']}: {$product['name']}\n";
    }
    echo "\n";
    
    // Sample stock data (3 codes par produit)
    $stockData = [];
    
    foreach ($products as $index => $product) {
        for ($i = 1; $i <= 3; $i++) {
            $code = strtoupper(substr($product['name'], 0, 3)) . '-' . strtoupper(substr(md5(uniqid()), 0, 8));
            $key = "Email: demo{$i}@example.com\nMotdepasse: Pass" . rand(1000, 9999);
            
            $stockData[] = [
                'item_id' => $product['id'],
                'code' => $code,
                'key' => $key
            ];
        }
    }
    
    echo "Insertion de " . count($stockData) . " codes produits...\n\n";
    
    $stmt = $pdo->prepare("
        INSERT INTO product_stock (item_id, product_code, product_key, status)
        VALUES (?, ?, ?, 'available')
    ");
    
    foreach ($stockData as $stock) {
        $stmt->execute([$stock['item_id'], $stock['code'], $stock['key']]);
        echo "  ✅ {$stock['code']} ajouté\n";
    }
    
    echo "\n✅ STOCK AJOUTÉ AVEC SUCCÈS !\n\n";
    
    // Show summary
    echo "📊 Résumé par produit:\n";
    foreach ($products as $product) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM product_stock WHERE item_id = ? AND status = 'available'");
        $stmt->execute([$product['id']]);
        $count = $stmt->fetchColumn();
        echo "  - {$product['name']}: {$count} code(s) disponible(s)\n";
    }
    
    echo "\n🎉 Vous pouvez maintenant acheter des produits !\n";
    
} catch (PDOException $e) {
    echo "❌ ERREUR: " . $e->getMessage() . "\n";
}
