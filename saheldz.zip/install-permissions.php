<?php
/**
 * Installation du système de permissions
 * Crée les tables nécessaires pour gérer les permissions par utilisateur
 */

require_once 'config/database.php';

try {
    $pdo = getDB();
    
    echo "<h2>🔐 Installation du Système de Permissions</h2>";
    
    // 1. Créer la table permissions
    echo "<p>Création de la table permissions...</p>";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS permissions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            code VARCHAR(50) NOT NULL UNIQUE,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            category VARCHAR(50) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    
    // 2. Créer la table user_permissions
    echo "<p>Création de la table user_permissions...</p>";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS user_permissions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            permission_id INT NOT NULL,
            granted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            granted_by INT,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE,
            FOREIGN KEY (granted_by) REFERENCES users(id) ON DELETE SET NULL,
            UNIQUE KEY unique_user_permission (user_id, permission_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    
    // 3. Insérer les permissions par défaut
    echo "<p>Insertion des permissions par défaut...</p>";
    
    $permissions = [
        // Dashboard
        ['dashboard_view', 'Voir le Tableau de Bord', 'Accéder au tableau de bord principal', 'Dashboard'],
        ['dashboard_stats', 'Voir les Statistiques', 'Voir les statistiques et métriques', 'Dashboard'],
        
        // POS
        ['pos_access', 'Accéder au POS', 'Accéder au système de point de vente', 'POS'],
        ['pos_sell', 'Effectuer des Ventes', 'Créer et finaliser des ventes', 'POS'],
        ['pos_refund', 'Faire des Remboursements', 'Effectuer des remboursements', 'POS'],
        
        // SMM
        ['smm_access', 'Accéder aux Commandes SMM', 'Accéder au module SMM', 'SMM'],
        ['smm_api_config', 'Configurer l\'API SMM', 'Configurer et modifier la clé API', 'SMM'],
        ['smm_create_order', 'Créer des Commandes SMM', 'Créer de nouvelles commandes SMM', 'SMM'],
        ['smm_view_orders', 'Voir les Commandes SMM', 'Consulter les commandes SMM', 'SMM'],
        ['smm_view_services', 'Voir les Services SMM', 'Consulter la liste des services', 'SMM'],
        ['smm_add_funds', 'Gérer les Fonds SMM', 'Ajouter et gérer les fonds', 'SMM'],
        
        // Branding
        ['branding_access', 'Accéder au Branding', 'Accéder au module branding', 'Branding'],
        ['branding_create_project', 'Créer des Projets', 'Créer de nouveaux projets branding', 'Branding'],
        ['branding_edit_project', 'Modifier des Projets', 'Modifier les projets existants', 'Branding'],
        ['branding_delete_project', 'Supprimer des Projets', 'Supprimer des projets', 'Branding'],
        ['branding_upload_files', 'Upload de Fichiers', 'Uploader des fichiers dans les projets', 'Branding'],
        ['branding_create_service', 'Créer des Services', 'Créer de nouveaux services branding', 'Branding'],
        
        // Sites Web
        ['websites_access', 'Accéder aux Sites Web', 'Accéder au module sites web', 'Sites Web'],
        ['websites_create', 'Créer des Sites', 'Créer de nouveaux projets de sites web', 'Sites Web'],
        ['websites_manage', 'Gérer les Sites', 'Gérer les projets de sites web', 'Sites Web'],
        
        // Produits Digitaux
        ['digital_access', 'Accéder aux Produits Digitaux', 'Accéder au module produits digitaux', 'Produits Digitaux'],
        ['digital_create_product', 'Créer des Produits', 'Créer de nouveaux produits', 'Produits Digitaux'],
        ['digital_sell', 'Vendre des Produits', 'Effectuer des ventes de produits digitaux', 'Produits Digitaux'],
        ['digital_manage_accounts', 'Gérer les Comptes', 'Gérer les comptes et stocks', 'Produits Digitaux'],
        ['digital_create_category', 'Créer des Catégories', 'Créer et gérer les catégories', 'Produits Digitaux'],
        
        // Commandes
        ['orders_access', 'Accéder aux Commandes', 'Accéder à la gestion des commandes', 'Commandes'],
        ['orders_view_all', 'Voir Toutes les Commandes', 'Voir toutes les commandes (pas seulement les siennes)', 'Commandes'],
        ['orders_manage', 'Gérer les Commandes', 'Modifier et gérer les commandes', 'Commandes'],
        ['orders_delete', 'Supprimer des Commandes', 'Supprimer des commandes', 'Commandes'],
        
        // Clients
        ['clients_access', 'Accéder aux Clients', 'Accéder à la gestion des clients', 'Clients'],
        ['clients_create', 'Créer des Clients', 'Ajouter de nouveaux clients', 'Clients'],
        ['clients_edit', 'Modifier des Clients', 'Modifier les informations clients', 'Clients'],
        ['clients_delete', 'Supprimer des Clients', 'Supprimer des clients', 'Clients'],
        ['clients_view_history', 'Voir l\'Historique Client', 'Voir l\'historique complet des clients', 'Clients'],
        
        // Administration
        ['admin_users', 'Gérer les Utilisateurs', 'Gérer les comptes utilisateurs', 'Administration'],
        ['admin_permissions', 'Gérer les Permissions', 'Assigner des permissions aux utilisateurs', 'Administration'],
        ['admin_roles', 'Gérer les Rôles', 'Gérer les rôles et leurs permissions', 'Administration'],
        ['admin_settings', 'Paramètres Système', 'Accéder aux paramètres système', 'Administration'],
    ];
    
    $stmt = $pdo->prepare("
        INSERT IGNORE INTO permissions (code, name, description, category)
        VALUES (?, ?, ?, ?)
    ");
    
    $inserted = 0;
    foreach ($permissions as $perm) {
        if ($stmt->execute($perm)) {
            $inserted++;
        }
    }
    
    echo "<p>✅ $inserted permissions insérées/vérifiées</p>";
    
    // 4. Donner toutes les permissions aux super admins et admins existants
    echo "<p>Attribution des permissions aux admins...</p>";
    
    $adminRoles = $pdo->query("
        SELECT id FROM roles WHERE name IN ('super_admin', 'admin')
    ")->fetchAll(PDO::FETCH_COLUMN);
    
    if (!empty($adminRoles)) {
        $placeholders = implode(',', array_fill(0, count($adminRoles), '?'));
        $admins = $pdo->prepare("
            SELECT id FROM users WHERE role_id IN ($placeholders)
        ");
        $admins->execute($adminRoles);
        $adminUsers = $admins->fetchAll(PDO::FETCH_COLUMN);
        
        $allPermissions = $pdo->query("SELECT id FROM permissions")->fetchAll(PDO::FETCH_COLUMN);
        
        $grantStmt = $pdo->prepare("
            INSERT IGNORE INTO user_permissions (user_id, permission_id)
            VALUES (?, ?)
        ");
        
        $granted = 0;
        foreach ($adminUsers as $userId) {
            foreach ($allPermissions as $permId) {
                if ($grantStmt->execute([$userId, $permId])) {
                    $granted++;
                }
            }
        }
        
        echo "<p>✅ $granted permissions attribuées aux admins</p>";
    }
    
    echo "<h3>✅ Installation Terminée avec Succès!</h3>";
    echo "<p><a href='admin-permissions.php' style='color: blue; text-decoration: underline;'>→ Aller à la Gestion des Permissions</a></p>";
    echo "<p><a href='admin-dashboard.php' style='color: blue; text-decoration: underline;'>→ Retour au Dashboard Admin</a></p>";
    
} catch (PDOException $e) {
    echo "<h3 style='color: red;'>❌ Erreur lors de l'installation</h3>";
    echo "<p style='color: red;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<pre>" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
}
?>
