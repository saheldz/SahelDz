<?php
/**
 * Gestion des rôles - Admin seulement
 */
require_once 'config/auth-check.php';

if (!isAdmin()) {
    header('Location: /index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Rôles - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    
    <!-- Header -->
    <nav class="bg-white shadow-sm border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
            <div class="flex items-center gap-4">
                <a href="/index.php" class="text-2xl font-bold text-purple-600">🚀 DigiServices</a>
                <span class="text-gray-400">|</span>
                <h2 class="text-lg font-semibold text-gray-700">👥 Gestion des Rôles</h2>
            </div>
            
            <div class="flex items-center gap-4">
                <div id="user-profile" class="flex items-center gap-3 bg-gray-50 px-4 py-2 rounded-lg">
                    <img id="profile-picture" src="https://ui-avatars.com/api/?name=Admin&background=667eea&color=fff" 
                         alt="Profile" class="w-10 h-10 rounded-full object-cover border-2 border-purple-200">
                    <div>
                        <p id="user-name" class="font-semibold text-gray-800 text-sm">Admin</p>
                        <p class="text-xs text-gray-500">Administrateur</p>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="flex justify-between items-center mb-6">
            <div>
                <h1 class="text-3xl font-bold text-gray-800">Gestion des Rôles et Permissions</h1>
                <p class="text-gray-600 mt-1">Créez et gérez les rôles avec leurs permissions détaillées</p>
            </div>
            <button onclick="showCreateModal()" class="bg-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors shadow-md">
                ➕ Créer un rôle
            </button>
        </div>

        <!-- Liste des rôles -->
        <div id="roles-list" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!-- Les rôles seront chargés ici -->
        </div>
    </div>

    <!-- Modal Créer/Modifier Rôle -->
    <div id="role-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div class="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div class="p-6 border-b border-gray-200">
                <div class="flex justify-between items-center">
                    <h3 id="modal-title" class="text-2xl font-bold text-gray-800">Créer un nouveau rôle</h3>
                    <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600 text-2xl">×</button>
                </div>
            </div>
            
            <form id="role-form" onsubmit="saveRole(event)" class="p-6">
                <input type="hidden" id="role-id" name="role_id">
                
                <!-- Informations de base -->
                <div class="space-y-4 mb-6">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Nom technique *</label>
                        <input type="text" name="name" id="role-name" required
                               placeholder="ex: manager, supervisor"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        <p class="text-xs text-gray-500 mt-1">Utilisé en interne, pas d'espaces ni caractères spéciaux</p>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Nom d'affichage *</label>
                        <input type="text" name="display_name" id="role-display-name" required
                               placeholder="ex: Manager de Projets"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Description</label>
                        <textarea name="description" id="role-description" rows="2"
                                  placeholder="Description du rôle..."
                                  class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"></textarea>
                    </div>
                </div>

                <!-- Permissions -->
                <div class="mb-6">
                    <h4 class="text-lg font-bold text-gray-800 mb-4">🔐 Permissions</h4>
                    
                    <!-- Accès complet -->
                    <div class="bg-purple-50 border-2 border-purple-200 rounded-lg p-4 mb-4">
                        <label class="flex items-start gap-3 cursor-pointer">
                            <input type="checkbox" id="perm-all" onchange="toggleAllPermissions()" 
                                   class="w-5 h-5 text-purple-600 mt-1">
                            <div>
                                <span class="font-semibold text-purple-900">⚡ Accès complet (Super Admin)</span>
                                <p class="text-sm text-purple-700">Tous les droits sur le système</p>
                            </div>
                        </label>
                    </div>

                    <!-- Permissions détaillées -->
                    <div id="detailed-permissions" class="space-y-4">
                        <!-- Gestion des utilisateurs -->
                        <div class="border border-gray-200 rounded-lg p-4">
                            <h5 class="font-semibold text-gray-800 mb-3">👥 Gestion des utilisateurs</h5>
                            <div class="space-y-2">
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="view_users">
                                    <div>
                                        <span class="text-sm font-medium">Voir les utilisateurs</span>
                                        <p class="text-xs text-gray-500">Consulter la liste des utilisateurs</p>
                                    </div>
                                </label>
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="manage_users">
                                    <div>
                                        <span class="text-sm font-medium">Gérer les utilisateurs</span>
                                        <p class="text-xs text-gray-500">Créer, modifier, supprimer des utilisateurs</p>
                                    </div>
                                </label>
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="change_user_roles">
                                    <div>
                                        <span class="text-sm font-medium">Modifier les rôles</span>
                                        <p class="text-xs text-gray-500">Changer le rôle d'un utilisateur</p>
                                    </div>
                                </label>
                            </div>
                        </div>

                        <!-- Gestion des commandes -->
                        <div class="border border-gray-200 rounded-lg p-4">
                            <h5 class="font-semibold text-gray-800 mb-3">📦 Gestion des commandes</h5>
                            <div class="space-y-2">
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="view_orders">
                                    <div>
                                        <span class="text-sm font-medium">Voir les commandes</span>
                                        <p class="text-xs text-gray-500">Consulter toutes les commandes</p>
                                    </div>
                                </label>
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="manage_orders">
                                    <div>
                                        <span class="text-sm font-medium">Gérer les commandes</span>
                                        <p class="text-xs text-gray-500">Créer, modifier, annuler des commandes</p>
                                    </div>
                                </label>
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="create_orders">
                                    <div>
                                        <span class="text-sm font-medium">Créer des commandes</span>
                                        <p class="text-xs text-gray-500">Passer des commandes pour les clients</p>
                                    </div>
                                </label>
                            </div>
                        </div>

                        <!-- Gestion financière -->
                        <div class="border border-gray-200 rounded-lg p-4">
                            <h5 class="font-semibold text-gray-800 mb-3">💰 Gestion financière</h5>
                            <div class="space-y-2">
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="view_wallet">
                                    <div>
                                        <span class="text-sm font-medium">Voir le wallet</span>
                                        <p class="text-xs text-gray-500">Consulter son solde et transactions</p>
                                    </div>
                                </label>
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="view_all_wallets">
                                    <div>
                                        <span class="text-sm font-medium">Voir tous les wallets</span>
                                        <p class="text-xs text-gray-500">Consulter les soldes de tous les utilisateurs</p>
                                    </div>
                                </label>
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="manage_funds">
                                    <div>
                                        <span class="text-sm font-medium">Gérer les fonds</span>
                                        <p class="text-xs text-gray-500">Ajouter ou retirer des fonds des wallets</p>
                                    </div>
                                </label>
                            </div>
                        </div>

                        <!-- Projets et contenus -->
                        <div class="border border-gray-200 rounded-lg p-4">
                            <h5 class="font-semibold text-gray-800 mb-3">📁 Projets et contenus</h5>
                            <div class="space-y-2">
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="manage_projects">
                                    <div>
                                        <span class="text-sm font-medium">Gérer les projets</span>
                                        <p class="text-xs text-gray-500">Créer, modifier, supprimer des projets</p>
                                    </div>
                                </label>
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="upload_files">
                                    <div>
                                        <span class="text-sm font-medium">Upload de fichiers</span>
                                        <p class="text-xs text-gray-500">Uploader des fichiers dans les projets</p>
                                    </div>
                                </label>
                            </div>
                        </div>

                        <!-- Rapports et statistiques -->
                        <div class="border border-gray-200 rounded-lg p-4">
                            <h5 class="font-semibold text-gray-800 mb-3">📊 Rapports et statistiques</h5>
                            <div class="space-y-2">
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="view_reports">
                                    <div>
                                        <span class="text-sm font-medium">Voir les rapports</span>
                                        <p class="text-xs text-gray-500">Accéder aux rapports et statistiques</p>
                                    </div>
                                </label>
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="export_data">
                                    <div>
                                        <span class="text-sm font-medium">Exporter les données</span>
                                        <p class="text-xs text-gray-500">Exporter des rapports en CSV/PDF</p>
                                    </div>
                                </label>
                            </div>
                        </div>

                        <!-- Paramètres système -->
                        <div class="border border-gray-200 rounded-lg p-4">
                            <h5 class="font-semibold text-gray-800 mb-3">⚙️ Paramètres système</h5>
                            <div class="space-y-2">
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="manage_roles">
                                    <div>
                                        <span class="text-sm font-medium">Gérer les rôles</span>
                                        <p class="text-xs text-gray-500">Créer et modifier des rôles</p>
                                    </div>
                                </label>
                                <label class="flex items-start gap-2 cursor-pointer">
                                    <input type="checkbox" class="permission-checkbox w-4 h-4 text-purple-600 mt-1" data-permission="system_settings">
                                    <div>
                                        <span class="text-sm font-medium">Paramètres système</span>
                                        <p class="text-xs text-gray-500">Modifier les paramètres globaux</p>
                                    </div>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Boutons -->
                <div class="flex gap-3">
                    <button type="submit" class="flex-1 bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors">
                        💾 Enregistrer le rôle
                    </button>
                    <button type="button" onclick="closeModal()" class="px-6 py-3 border border-gray-300 rounded-lg font-semibold hover:bg-gray-50 transition-colors">
                        Annuler
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Notification -->
    <div id="notification" class="hidden fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50"></div>

    <script>
        // Charger les rôles au démarrage
        window.addEventListener('load', async () => {
            await checkAuth();
            await loadRoles();
        });

        // Vérifier l'authentification
        async function checkAuth() {
            const response = await fetch('/api/auth.php?action=check_session');
            const result = await response.json();
            
            if (!result.authenticated) {
                window.location.href = '/login.html';
            } else {
                // Vérifier que c'est un admin
                if (result.user.role !== 'super_admin' && result.user.role !== 'admin') {
                    alert('Accès refusé - Admin seulement');
                    window.location.href = '/index.php';
                }
                
                // Mettre à jour le header
                document.getElementById('user-name').textContent = result.user.full_name || result.user.email;
            }
        }

        // Charger tous les rôles
        async function loadRoles() {
            const response = await fetch('/api/admin.php?action=get_all_roles');
            const result = await response.json();
            
            if (result.success) {
                displayRoles(result.roles);
            } else {
                showNotification('❌ ' + result.error, 'error');
            }
        }

        // Afficher les rôles
        function displayRoles(roles) {
            const container = document.getElementById('roles-list');
            container.innerHTML = '';
            
            roles.forEach(role => {
                const permCount = role.permissions.all ? 'Tous' : Object.keys(role.permissions).length;
                const isSystem = role.id <= 4;
                
                const roleCard = document.createElement('div');
                roleCard.className = 'bg-white rounded-lg shadow-sm border-2 border-gray-200 p-6 hover:shadow-md transition-shadow';
                
                roleCard.innerHTML = `
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <h3 class="text-xl font-bold text-gray-800">${role.display_name}</h3>
                            <p class="text-sm text-gray-500">${role.name}</p>
                        </div>
                        ${isSystem ? '<span class="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded-full">Système</span>' : ''}
                    </div>
                    
                    <p class="text-sm text-gray-600 mb-4">${role.description || 'Aucune description'}</p>
                    
                    <div class="flex items-center gap-2 mb-4">
                        <span class="text-2xl">🔐</span>
                        <span class="text-sm font-medium text-gray-700">${permCount} permission(s)</span>
                    </div>
                    
                    <div class="flex gap-2">
                        <button onclick="editRole(${role.id})" class="flex-1 bg-purple-100 text-purple-700 py-2 rounded-lg font-semibold hover:bg-purple-200 transition-colors">
                            ✏️ Modifier
                        </button>
                        ${!isSystem ? `<button onclick="deleteRole(${role.id})" class="bg-red-100 text-red-700 px-4 py-2 rounded-lg font-semibold hover:bg-red-200 transition-colors">
                            🗑️
                        </button>` : ''}
                    </div>
                `;
                
                container.appendChild(roleCard);
            });
        }

        // Afficher le modal de création
        function showCreateModal() {
            document.getElementById('modal-title').textContent = 'Créer un nouveau rôle';
            document.getElementById('role-form').reset();
            document.getElementById('role-id').value = '';
            
            // Décocher toutes les permissions
            document.querySelectorAll('.permission-checkbox').forEach(cb => cb.checked = false);
            document.getElementById('perm-all').checked = false;
            
            document.getElementById('role-modal').classList.remove('hidden');
        }

        // Modifier un rôle
        async function editRole(roleId) {
            const response = await fetch('/api/admin.php?action=get_all_roles');
            const result = await response.json();
            
            if (result.success) {
                const role = result.roles.find(r => r.id === roleId);
                
                if (role) {
                    document.getElementById('modal-title').textContent = 'Modifier le rôle';
                    document.getElementById('role-id').value = role.id;
                    document.getElementById('role-name').value = role.name;
                    document.getElementById('role-display-name').value = role.display_name;
                    document.getElementById('role-description').value = role.description || '';
                    
                    // Cocher les permissions
                    document.querySelectorAll('.permission-checkbox').forEach(cb => cb.checked = false);
                    
                    if (role.permissions.all) {
                        document.getElementById('perm-all').checked = true;
                        toggleAllPermissions();
                    } else {
                        Object.keys(role.permissions).forEach(perm => {
                            const checkbox = document.querySelector(`[data-permission="${perm}"]`);
                            if (checkbox && role.permissions[perm]) {
                                checkbox.checked = true;
                            }
                        });
                    }
                    
                    document.getElementById('role-modal').classList.remove('hidden');
                }
            }
        }

        // Supprimer un rôle
        async function deleteRole(roleId) {
            if (!confirm('Êtes-vous sûr de vouloir supprimer ce rôle ?')) {
                return;
            }
            
            // Note: Cette fonction nécessiterait un endpoint delete_role dans admin.php
            showNotification('⚠️ La suppression de rôles sera disponible prochainement', 'info');
        }

        // Fermer le modal
        function closeModal() {
            document.getElementById('role-modal').classList.add('hidden');
        }

        // Toggle toutes les permissions
        function toggleAllPermissions() {
            const allChecked = document.getElementById('perm-all').checked;
            const detailedPerms = document.getElementById('detailed-permissions');
            
            document.querySelectorAll('.permission-checkbox').forEach(cb => {
                cb.checked = allChecked;
                cb.disabled = allChecked;
            });
            
            if (allChecked) {
                detailedPerms.style.opacity = '0.5';
            } else {
                detailedPerms.style.opacity = '1';
            }
        }

        // Sauvegarder le rôle
        async function saveRole(e) {
            e.preventDefault();
            
            const roleId = document.getElementById('role-id').value;
            const formData = new FormData(e.target);
            
            // Construire l'objet permissions
            const permissions = {};
            
            if (document.getElementById('perm-all').checked) {
                permissions.all = true;
            } else {
                document.querySelectorAll('.permission-checkbox:checked').forEach(cb => {
                    permissions[cb.dataset.permission] = true;
                });
            }
            
            formData.append('permissions', JSON.stringify(permissions));
            
            // Déterminer l'action
            if (roleId) {
                formData.append('action', 'update_role');
                formData.append('role_id', roleId);
            } else {
                formData.append('action', 'create_role');
            }
            
            try {
                const response = await fetch('/api/admin.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showNotification('✅ Rôle enregistré avec succès !', 'success');
                    closeModal();
                    await loadRoles();
                } else {
                    showNotification('❌ ' + result.error, 'error');
                }
            } catch (error) {
                showNotification('❌ Erreur lors de l\'enregistrement', 'error');
            }
        }

        // Notification
        function showNotification(message, type) {
            const notification = document.getElementById('notification');
            const colors = {
                success: 'border-green-500 bg-green-50',
                error: 'border-red-500 bg-red-50',
                info: 'border-blue-500 bg-blue-50'
            };
            
            notification.className = `fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50 ${colors[type]}`;
            notification.textContent = message;
            notification.classList.remove('hidden');
            
            setTimeout(() => notification.classList.add('hidden'), 5000);
        }
    </script>
</body>
</html>
