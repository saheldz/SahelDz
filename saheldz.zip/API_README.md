# 🚀 Installation du Système avec Base de Données

Ce guide vous explique comment installer et configurer le système complet avec base de données MySQL et gestion des fichiers.

## 📋 Prérequis

- PHP 7.4 ou supérieur
- MySQL 5.7 ou supérieur (ou MariaDB)
- Extensions PHP requises:
  - PDO
  - PDO_MySQL
  - GD (pour les miniatures)
  - fileinfo

## 🔧 Installation

### 1. Configuration de la Base de Données

Ouvrez le fichier `config/database.php` et modifiez les paramètres si nécessaire:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'digiservices_db');
define('DB_USER', 'root');
define('DB_PASS', '');
```

### 2. Installer la Base de Données

**Option A: Via le navigateur**
Accédez à: `http://localhost:8003/install.php`

**Option B: Via ligne de commande**
```bash
cd /Users/mac15/Desktop/localhost-system-backup
php install.php
```

Vous devriez voir:
```json
{
  "success": true,
  "message": "✅ Base de données créée avec succès!",
  "tables": ["clients", "orders", "branding_projects", ...]
}
```

### 3. Vérifier les Permissions

Assurez-vous que les dossiers uploads ont les bonnes permissions:

```bash
chmod -R 755 uploads/
```

## 📁 Structure de la Base de Données

### Tables Créées

1. **clients** - Gestion des clients
   - id, name, email, phone, company

2. **orders** - Toutes les commandes (POS, SMM, etc.)
   - id, order_id, client_id, name, description, price, status, type

3. **branding_projects** - Projets de branding
   - id, project_id, client_id, name, description, price, status, facebook_url, deadline

4. **project_services** - Services liés aux projets
   - id, project_id, service_id, service_name, price

5. **project_files** - Fichiers uploadés (logos, images, etc.)
   - id, project_id, filename, original_name, filepath, file_type, file_size, file_category, thumbnail_path

6. **digital_products** - Produits digitaux (Netflix, Adobe, etc.)
   - id, name, type, category, price, stock, duration, description

7. **product_accounts** - Comptes pour produits digitaux
   - id, product_id, account_type, email, password, access_key, code, stock, used

8. **smm_orders** - Commandes SMM
   - id, order_id, client_name, service_id, service_name, platform, link, quantity, cost, status

9. **pos_cart** - Panier POS temporaire
   - id, session_id, product_name, price

10. **categories** - Catégories pour produits digitaux
    - id, name, icon, parent_id

## 🔌 APIs Disponibles

### API Fichiers: `/api/files.php`

**Upload de fichier:**
```javascript
const formData = new FormData();
formData.append('action', 'upload');
formData.append('file', fileInput.files[0]);
formData.append('project_id', 123);
formData.append('category', 'reference'); // ou 'assets', 'deliverables'

fetch('/api/files.php', {
    method: 'POST',
    body: formData
}).then(response => response.json());
```

**Supprimer un fichier:**
```javascript
const formData = new FormData();
formData.append('action', 'delete');
formData.append('file_id', 456);

fetch('/api/files.php', {
    method: 'POST',
    body: formData
}).then(response => response.json());
```

**Lister les fichiers d'un projet:**
```javascript
fetch('/api/files.php?action=get_project_files&project_id=123')
    .then(response => response.json());
```

## 📸 Gestion des Images

### Miniatures Automatiques

Le système génère automatiquement des miniatures (200x200px max) pour:
- Images JPEG
- Images PNG
- Images GIF
- Images WebP

Les miniatures sont stockées dans: `uploads/branding/project_{id}/thumbnails/`

### Types de Fichiers Autorisés

- Images: JPEG, PNG, GIF, WebP, SVG
- Documents: PDF

## 🎨 Gestion des Projets Branding

### Upload de Fichiers dans un Projet

Les fichiers sont organisés par catégorie:
- **reference** - Fichiers de référence
- **assets** - Éléments existants (logos, etc.)
- **deliverables** - Fichiers livrables

Chaque projet a son propre dossier: `uploads/branding/project_{id}/`

### Affichage avec Miniatures

Les fichiers images sont affichés avec:
- Miniature cliquable
- Nom du fichier
- Taille
- Bouton de suppression (×)

## 🔒 Sécurité

- ✅ Validation des types de fichiers
- ✅ Noms de fichiers uniques
- ✅ Requêtes SQL préparées (PDO)
- ✅ Protection contre les injections SQL
- ✅ Vérification des permissions

## 🐛 Dépannage

### Erreur "Base de données non trouvée"

Le script `install.php` crée automatiquement la base de données. Si l'erreur persiste:

1. Vérifiez les credentials dans `config/database.php`
2. Assurez-vous que MySQL est démarré
3. Vérifiez que l'utilisateur MySQL a les droits CREATE DATABASE

### Erreur "Impossible d'uploader"

1. Vérifiez les permissions du dossier uploads:
```bash
chmod -R 755 uploads/
```

2. Vérifiez la configuration PHP:
```bash
php -i | grep upload_max_filesize
php -i | grep post_max_size
```

3. Augmentez si nécessaire dans php.ini:
```ini
upload_max_filesize = 64M
post_max_size = 64M
```

### Erreur "Miniatures non créées"

Vérifiez que l'extension GD est installée:
```bash
php -m | grep gd
```

Si non installée:
```bash
# Sur macOS avec Homebrew
brew install php-gd

# Sur Ubuntu/Debian
sudo apt-get install php-gd
```

## 📊 Migration des Données Existantes

Si vous avez des données en localStorage, vous pouvez les migrer vers la base de données en utilisant l'API.

Le système continue de fonctionner avec localStorage en fallback si la base de données n'est pas configurée.

## ✅ Vérification de l'Installation

1. Accédez à `http://localhost:8003/install.php` - Devrait afficher "success": true
2. Testez l'upload d'une image dans un projet Branding
3. Vérifiez que la miniature est générée
4. Testez la suppression d'un fichier

## 🎯 Prochaines Étapes

Une fois l'installation réussie:

1. Les données seront automatiquement sauvegardées en base de données
2. Les fichiers uploadés seront stockés dans `uploads/`
3. Les miniatures seront générées automatiquement
4. Vous pourrez supprimer les fichiers avec le bouton ×

## 💡 Conseils

- Faites des backups réguliers de la base de données
- Sauvegardez le dossier `uploads/` régulièrement
- Surveillez la taille du dossier uploads
- Nettoyez les fichiers non utilisés périodiquement

## 📞 Support

Pour toute question ou problème:
1. Vérifiez ce README
2. Consultez les logs d'erreurs PHP
3. Activez le mode debug dans `config/database.php`
