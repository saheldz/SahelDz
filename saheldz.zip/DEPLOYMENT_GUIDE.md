# 🚀 Guide de Déploiement - Corrections Production

## ✅ Corrections Apportées

### 1. **api/addons.php**
- ✅ Ajout de la fonction `get_addon_details()` manquante
- ✅ Correction des messages JSON (sans emojis pour éviter erreurs de parsing)
- ✅ Amélioration de la gestion d'erreurs

### 2. **admin-addons.php**
- ✅ Interface complètement refaite
- ✅ Barre de progression pour uploads
- ✅ Modal de détails d'addon
- ✅ Documentation intégrée
- ✅ Meilleure UX/UI

### 3. **addons/subscriptions/admin/dashboard.php**
- ✅ Vérification des tables AVANT requêtes SQL
- ✅ Redirection automatique vers installation si tables manquantes
- ✅ Plus d'erreur HTTP 500

### 4. **subscriptions.zip**
- ✅ Contient toutes les corrections
- ✅ Prêt pour déploiement

## 📦 Fichiers à Uploader sur Production

### Option 1 : Upload Manuel (Recommandé)

**Via FTP/SFTP (FileZilla, Cyberduck, etc.) :**

1. **Fichier API** (IMPORTANT)
   ```
   Local:  /Users/mac15/Desktop/localhost-system-backup/api/addons.php
   Serveur: /public_html/api/addons.php
   ```

2. **Gestionnaire d'addons**
   ```
   Local:  /Users/mac15/Desktop/localhost-system-backup/admin-addons.php
   Serveur: /public_html/admin-addons.php
   ```

3. **ZIP de l'addon** (si vous voulez réinstaller)
   ```
   Local:  /Users/mac15/Desktop/localhost-system-backup/subscriptions.zip
   Serveur: Uploadez via https://saheldz.mpsdash.com/admin-addons.php
   ```

### Option 2 : Via cPanel File Manager

1. Connectez-vous à votre cPanel
2. Ouvrez "File Manager"
3. Naviguez vers `public_html`
4. Uploadez les 2 fichiers :
   - `api/addons.php`
   - `admin-addons.php`

### Option 3 : Via SSH (Si vous avez accès)

```bash
# Se connecter au serveur
ssh votre-user@saheldz.mpsdash.com

# Naviguer vers le dossier
cd /path/to/public_html

# Sauvegarder les anciens fichiers
cp api/addons.php api/addons.php.backup
cp admin-addons.php admin-addons.php.backup

# Uploader les nouveaux fichiers (via scp depuis votre machine locale)
# Depuis votre terminal local :
scp /Users/mac15/Desktop/localhost-system-backup/api/addons.php votre-user@saheldz.mpsdash.com:/path/to/public_html/api/
scp /Users/mac15/Desktop/localhost-system-backup/admin-addons.php votre-user@saheldz.mpsdash.com:/path/to/public_html/
```

## 🔧 Étapes de Déploiement Détaillées

### Étape 1 : Backup (IMPORTANT)

Avant toute mise à jour, sauvegardez les fichiers actuels :
- `api/addons.php`
- `admin-addons.php`
- Dossier `addons/subscriptions/` (si déjà installé)

### Étape 2 : Upload des Corrections

**Fichiers prioritaires (corrigent les erreurs) :**

1. **api/addons.php** ← CRITIQUE (corrige l'erreur JSON)
2. **admin-addons.php** ← Améliore l'interface

### Étape 3 : Mettre à Jour l'Addon Subscriptions

#### Si l'addon est déjà installé :

**Option A : Mise à jour du fichier dashboard.php uniquement**
```
Local:  /Users/mac15/Desktop/localhost-system-backup/addons/subscriptions/admin/dashboard.php
Serveur: /public_html/addons/subscriptions/admin/dashboard.php
```

**Option B : Réinstallation complète**
1. Allez sur https://saheldz.mpsdash.com/admin-addons.php
2. Supprimez l'ancien addon "subscriptions"
3. Uploadez le nouveau `subscriptions.zip`
4. Activez l'addon
5. L'installation des tables se fera automatiquement

#### Si l'addon n'est pas encore installé :

1. Allez sur https://saheldz.mpsdash.com/admin-addons.php
2. Uploadez `subscriptions.zip`
3. Activez l'addon
4. Accédez à l'installation (redirection automatique)

### Étape 4 : Installation des Tables (Si nécessaire)

Si les tables ne sont pas créées, accédez à :
```
https://saheldz.mpsdash.com/addons/subscriptions/install.php
```

Cela créera :
- `subscription_plans`
- `subscriptions`
- `subscription_items`

### Étape 5 : Vérification

1. **Tester le gestionnaire d'addons** :
   ```
   https://saheldz.mpsdash.com/admin-addons.php
   ```
   - ✅ La liste des addons doit s'afficher
   - ✅ Le bouton "Ouvrir" doit fonctionner
   - ✅ Pas d'erreur JSON dans la console

2. **Tester l'addon subscriptions** :
   ```
   https://saheldz.mpsdash.com/addons/subscriptions/admin/dashboard.php
   ```
   - ✅ Plus d'erreur HTTP 500
   - ✅ Si tables manquantes → redirection automatique vers installation
   - ✅ Si tables présentes → dashboard s'affiche correctement

## 🐛 Résolution des Problèmes

### Erreur : "unexpected token ✅ is not valid"
**Cause** : L'API retournait du texte avec emojis
**Solution** : ✅ Corrigé dans `api/addons.php`

### Erreur : HTTP 500 sur dashboard.php
**Cause** : Requêtes SQL sur tables non existantes
**Solution** : ✅ Corrigé - vérification des tables ajoutée

### Erreur : "get_addon_details action not found"
**Cause** : Fonction manquante dans l'API
**Solution** : ✅ Ajoutée dans `api/addons.php`

## 📋 Checklist de Déploiement

- [ ] Sauvegarder les fichiers actuels
- [ ] Uploader `api/addons.php` sur le serveur
- [ ] Uploader `admin-addons.php` sur le serveur
- [ ] Tester https://saheldz.mpsdash.com/admin-addons.php
- [ ] Vérifier qu'aucune erreur JSON n'apparaît dans la console
- [ ] Si addon subscriptions déjà installé :
  - [ ] Uploader le nouveau `dashboard.php` OU
  - [ ] Supprimer et réinstaller l'addon complet
- [ ] Si addon pas installé : uploader `subscriptions.zip`
- [ ] Activer l'addon
- [ ] Installer les tables si nécessaire
- [ ] Tester le dashboard : https://saheldz.mpsdash.com/addons/subscriptions/admin/dashboard.php
- [ ] ✅ Tout fonctionne !

## 🎯 Résultat Attendu

Après le déploiement :
- ✅ Gestionnaire d'addons moderne et fonctionnel
- ✅ Barre de progression pour uploads
- ✅ Modal de détails d'addon
- ✅ Addon subscriptions sans erreur 500
- ✅ Installation automatique des tables
- ✅ Plus d'erreurs JSON

## 💡 Conseil Final

**Ordre de priorité pour résoudre l'erreur actuelle :**

1. **URGENT** : Uploader `api/addons.php` (corrige l'erreur JSON)
2. **IMPORTANT** : Uploader `addons/subscriptions/admin/dashboard.php` (corrige HTTP 500)
3. **OPTIONNEL** : Uploader `admin-addons.php` (améliore UX)

Une fois ces 2-3 fichiers uploadés, tout devrait fonctionner parfaitement ! 🎉
