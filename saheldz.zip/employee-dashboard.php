<?php
/**
 * Dashboard Employé - Redirection vers 1a.php
 */
require_once 'config/auth-check.php';

// Rediriger les employés vers 1a.php
header('Location: /html/1a.php');
exit;

// Code ci-dessous conservé pour référence mais ne sera jamais exécuté
require_once 'config/database.php';
$pdo = getDB();

// Stats de l'employé - avec gestion d'erreur
try {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_orders
        FROM orders 
        WHERE assigned_to = ?
    ");
    $stmt->execute([$GLOBALS['current_user']['id']]);
    $orderStats = $stmt->fetch();
} catch (PDOException $e) {
    // Si la table orders n'existe pas, utiliser des valeurs par défaut
    $orderStats = ['total_orders' => 0];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Espace Employé - DigiServices</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <?php include 'config/impersonation-banner.php'; ?>
    
    <!-- Header Employé -->
    <nav class="bg-gradient-to-r from-indigo-600 to-blue-600 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <a href="/employee-dashboard.php" class="text-2xl font-bold text-white">🚀 DigiServices</a>
                    <span class="text-white/60">|</span>
                    <span class="text-white/90">Espace Employé</span>
                </div>
                
                <div class="flex items-center gap-4">
                    <div class="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-lg">
                        <div class="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                            <span class="text-xl">👨‍💼</span>
                        </div>
                        <div class="text-white">
                            <p class="font-semibold text-sm"><?php echo htmlspecialchars($GLOBALS['current_user']['full_name']); ?></p>
                            <p class="text-xs text-indigo-100">Employé</p>
                        </div>
                    </div>
                    
                    <a href="/settings.php" class="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg font-semibold transition-colors">
                        ⚙️ Paramètres
                    </a>
                    
                    <button onclick="logout()" class="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg font-semibold transition-colors">
                        🚪 Déconnexion
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        
        <!-- Bienvenue -->
        <div class="bg-gradient-to-r from-indigo-500 to-blue-600 rounded-xl shadow-lg p-8 mb-8 text-white">
            <h1 class="text-3xl font-bold mb-2">Bienvenue, <?php echo htmlspecialchars($GLOBALS['current_user']['full_name']); ?> ! 👨‍💼</h1>
            <p class="text-indigo-100">Gérez vos tâches et projets en cours</p>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <!-- Tâches du jour -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">📋</span>
                    </div>
                </div>
                <h3 class="text-3xl font-bold text-gray-800 mb-1">0</h3>
                <p class="text-gray-600 text-sm">Tâches du jour</p>
            </div>

            <!-- Projets actifs -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">📁</span>
                    </div>
                </div>
                <h3 class="text-3xl font-bold text-gray-800 mb-1">0</h3>
                <p class="text-gray-600 text-sm">Projets actifs</p>
            </div>

            <!-- Commandes -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">📦</span>
                    </div>
                </div>
                <h3 class="text-3xl font-bold text-gray-800 mb-1"><?php echo $orderStats['total_orders']; ?></h3>
                <p class="text-gray-600 text-sm">Commandes assignées</p>
            </div>

            <!-- Messages -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-yellow-500">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">💬</span>
                    </div>
                </div>
                <h3 class="text-3xl font-bold text-gray-800 mb-1">0</h3>
                <p class="text-gray-600 text-sm">Messages non lus</p>
            </div>
        </div>

        <!-- Actions rapides -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-6">⚡ Actions Rapides</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="/html/1a.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-blue-200 hover:border-blue-400">
                    <span class="text-4xl mb-3">🎨</span>
                    <span class="font-semibold text-gray-800">Branding</span>
                    <span class="text-xs text-gray-600 mt-1">Projets design</span>
                </a>

                <div class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-purple-200 hover:border-purple-400">
                    <span class="text-4xl mb-3">📦</span>
                    <span class="font-semibold text-gray-800">Commandes</span>
                    <span class="text-xs text-gray-600 mt-1">Gérer les commandes</span>
                </div>

                <div class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-green-200 hover:border-green-400">
                    <span class="text-4xl mb-3">📁</span>
                    <span class="font-semibold text-gray-800">Projets</span>
                    <span class="text-xs text-gray-600 mt-1">Mes projets</span>
                </div>

                <div class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-yellow-200 hover:border-yellow-400">
                    <span class="text-4xl mb-3">📊</span>
                    <span class="font-semibold text-gray-800">Rapports</span>
                    <span class="text-xs text-gray-600 mt-1">Mes statistiques</span>
                </div>
            </div>
        </div>

        <!-- Tâches récentes & Projets en cours -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Tâches récentes -->
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4">📋 Tâches Récentes</h3>
                <div class="space-y-3">
                    <p class="text-gray-500 text-sm text-center py-4">Aucune tâche pour le moment</p>
                </div>
            </div>

            <!-- Projets en cours -->
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4">📁 Projets en Cours</h3>
                <div class="space-y-3">
                    <p class="text-gray-500 text-sm text-center py-4">Aucun projet en cours</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        async function logout() {
            const formData = new FormData();
            formData.append('action', 'logout');
            await fetch('/api/auth.php', { method: 'POST', body: formData });
            window.location.href = '/login.html';
        }
    </script>
</body>
</html>
