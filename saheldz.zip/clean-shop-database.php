<?php
// Script pour nettoyer complètement la boutique
require_once 'config/database.php';

echo "=== NETTOYAGE COMPLET DE LA BOUTIQUE ===\n\n";

try {
    $pdo->beginTransaction();
    
    // 1. Supprimer tous les codes de stock
    echo "1. Suppression des codes de stock...\n";
    $stmt = $pdo->query("DELETE FROM product_stock");
    $deleted = $stmt->rowCount();
    echo "   ✅ $deleted codes supprimés\n";
    
    // 2. Supprimer toutes les commandes
    echo "\n2. Suppression des commandes...\n";
    $stmt = $pdo->query("DELETE FROM orders");
    $deleted = $stmt->rowCount();
    echo "   ✅ $deleted commandes supprimées\n";
    
    // 3. Supprimer tous les produits
    echo "\n3. Suppression des produits...\n";
    $stmt = $pdo->query("DELETE FROM shop_items");
    $deleted = $stmt->rowCount();
    echo "   ✅ $deleted produits supprimés\n";
    
    // 4. Supprimer toutes les catégories
    echo "\n4. Suppression des catégories...\n";
    $stmt = $pdo->query("DELETE FROM shop_categories");
    $deleted = $stmt->rowCount();
    echo "   ✅ $deleted catégories supprimées\n";
    
    // 5. Réinitialiser les auto-increments
    echo "\n5. Réinitialisation des compteurs...\n";
    $pdo->query("ALTER TABLE product_stock AUTO_INCREMENT = 1");
    $pdo->query("ALTER TABLE orders AUTO_INCREMENT = 1");
    $pdo->query("ALTER TABLE shop_items AUTO_INCREMENT = 1");
    $pdo->query("ALTER TABLE shop_categories AUTO_INCREMENT = 1");
    echo "   ✅ Compteurs réinitialisés\n";
    
    $pdo->commit();
    
    echo "\n✅ NETTOYAGE TERMINÉ !\n";
    echo "\nLa boutique est maintenant vide.\n";
    echo "Vous pouvez maintenant utiliser l'admin pour créer vos produits.\n";
    
} catch (Exception $e) {
    $pdo->rollBack();
    echo "\n❌ ERREUR: " . $e->getMessage() . "\n";
}
?>
