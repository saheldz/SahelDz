<?php
require_once 'config/database.php';

try {
    $pdo = getDB();
    $stmt = $pdo->query("SELECT id, name, display_name, permissions FROM roles ORDER BY id");
    $roles = $stmt->fetchAll();
    
    echo "=== ROLES EXISTANTS ===\n\n";
    foreach ($roles as $role) {
        echo "ID: {$role['id']}\n";
        echo "Name: {$role['name']}\n";
        echo "Display Name: {$role['display_name']}\n";
        echo "Permissions: {$role['permissions']}\n";
        echo "---\n\n";
    }
} catch (Exception $e) {
    echo "Erreur: " . $e->getMessage() . "\n";
}
