<?php
/**
 * Page web d'initialisation des rôles
 * Accessible via navigateur pour initialiser les rôles
 */
require_once 'config/auth-check.php';
require_once 'config/database.php';

// Vérifier que l'utilisateur est admin
if (!isAdmin()) {
    die('Accès refusé - Admin seulement');
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo = getDB();
        
        // Définir les rôles par défaut
        $defaultRoles = [
            [
                'name' => 'super_admin',
                'display_name' => 'Super Administrateur',
                'description' => 'Accès complet à toutes les fonctionnalités du système',
                'permissions' => json_encode(['all' => true])
            ],
            [
                'name' => 'admin',
                'display_name' => 'Administrateur',
                'description' => 'Gestion complète des utilisateurs, commandes et paramètres',
                'permissions' => json_encode(['all' => true])
            ],
            [
                'name' => 'employee',
                'display_name' => 'Employé',
                'description' => 'Gestion des commandes, projets et clients',
                'permissions' => json_encode([
                    'view_users' => true,
                    'view_orders' => true,
                    'manage_orders' => true,
                    'create_orders' => true,
                    'view_wallet' => true,
                    'manage_projects' => true,
                    'upload_files' => true,
                    'view_reports' => true
                ])
            ],
            [
                'name' => 'client',
                'display_name' => 'Client',
                'description' => 'Accès client standard avec gestion des commandes et projets personnels',
                'permissions' => json_encode([
                    'view_wallet' => true,
                    'view_orders' => true,
                    'create_orders' => true,
                    'upload_files' => true
                ])
            ]
        ];
        
        $rolesCreated = 0;
        $rolesUpdated = 0;
        
        foreach ($defaultRoles as $role) {
            $stmt = $pdo->prepare("SELECT id FROM roles WHERE name = ?");
            $stmt->execute([$role['name']]);
            $existing = $stmt->fetch();
            
            if ($existing) {
                $stmt = $pdo->prepare("
                    UPDATE roles 
                    SET display_name = ?, description = ?, permissions = ?
                    WHERE name = ?
                ");
                $stmt->execute([
                    $role['display_name'],
                    $role['description'],
                    $role['permissions'],
                    $role['name']
                ]);
                $rolesUpdated++;
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO roles (name, display_name, description, permissions)
                    VALUES (?, ?, ?, ?)
                ");
                $stmt->execute([
                    $role['name'],
                    $role['display_name'],
                    $role['description'],
                    $role['permissions']
                ]);
                $rolesCreated++;
            }
        }
        
        // Assigner le rôle client aux utilisateurs sans rôle
        $stmt = $pdo->prepare("SELECT id FROM roles WHERE name = 'client' LIMIT 1");
        $stmt->execute();
        $clientRole = $stmt->fetch();
        
        $usersUpdated = 0;
        if ($clientRole) {
            $stmt = $pdo->prepare("
                UPDATE users 
                SET role_id = ? 
                WHERE role_id IS NULL OR role_id = 0 OR role_id NOT IN (SELECT id FROM roles)
            ");
            $stmt->execute([$clientRole['id']]);
            $usersUpdated = $stmt->rowCount();
        }
        
        $message = "✅ Initialisation réussie !<br>";
        $message .= "• $rolesCreated rôle(s) créé(s)<br>";
        $message .= "• $rolesUpdated rôle(s) mis à jour<br>";
        $message .= "• $usersUpdated utilisateur(s) assigné(s) au rôle Client";
        
    } catch (Exception $e) {
        $error = "❌ Erreur : " . $e->getMessage();
    }
}

// Récupérer les rôles existants
try {
    $pdo = getDB();
    $stmt = $pdo->query("SELECT * FROM roles ORDER BY id");
    $roles = $stmt->fetchAll();
    
    $stmt = $pdo->query("
        SELECT COUNT(*) as count 
        FROM users 
        WHERE role_id IS NULL OR role_id = 0 OR role_id NOT IN (SELECT id FROM roles)
    ");
    $usersWithoutRole = $stmt->fetchColumn();
    
} catch (Exception $e) {
    $error = "❌ Erreur de connexion : " . $e->getMessage();
    $roles = [];
    $usersWithoutRole = 0;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Initialisation des Rôles - DigiServices</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    
    <nav class="bg-gradient-to-r from-purple-600 to-blue-600 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <h1 class="text-2xl font-bold text-white">🔧 Configuration des Rôles</h1>
                <a href="/admin-dashboard.php" class="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg transition-colors">
                    ← Retour Dashboard
                </a>
            </div>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto px-4 py-8">
        
        <?php if ($message): ?>
            <div class="bg-green-50 border-l-4 border-green-500 p-4 mb-6 rounded">
                <p class="text-green-800"><?php echo $message; ?></p>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded">
                <p class="text-red-800"><?php echo $error; ?></p>
            </div>
        <?php endif; ?>
        
        <!-- Statut -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4">📊 État Actuel</h2>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div class="bg-blue-50 p-4 rounded-lg">
                    <p class="text-sm text-gray-600">Rôles configurés</p>
                    <p class="text-3xl font-bold text-blue-600"><?php echo count($roles); ?></p>
                </div>
                
                <div class="bg-<?php echo $usersWithoutRole > 0 ? 'yellow' : 'green'; ?>-50 p-4 rounded-lg">
                    <p class="text-sm text-gray-600">Utilisateurs sans rôle</p>
                    <p class="text-3xl font-bold text-<?php echo $usersWithoutRole > 0 ? 'yellow' : 'green'; ?>-600">
                        <?php echo $usersWithoutRole; ?>
                    </p>
                </div>
            </div>
            
            <?php if ($usersWithoutRole > 0): ?>
                <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded">
                    <p class="text-yellow-800">
                        ⚠️ <strong><?php echo $usersWithoutRole; ?> utilisateur(s)</strong> n'ont pas de rôle valide et doivent être assignés.
                    </p>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Rôles existants -->
        <?php if (!empty($roles)): ?>
            <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">📋 Rôles Existants</h2>
                <div class="space-y-3">
                    <?php foreach ($roles as $role): ?>
                        <div class="border-l-4 border-purple-500 bg-purple-50 p-4 rounded">
                            <div class="flex justify-between items-start">
                                <div>
                                    <h3 class="font-bold text-gray-800"><?php echo htmlspecialchars($role['display_name']); ?></h3>
                                    <p class="text-sm text-gray-600"><?php echo htmlspecialchars($role['name']); ?></p>
                                    <p class="text-sm text-gray-500 mt-1"><?php echo htmlspecialchars($role['description']); ?></p>
                                </div>
                                <span class="bg-purple-200 text-purple-800 text-xs px-2 py-1 rounded-full">
                                    ID: <?php echo $role['id']; ?>
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Action -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4">🚀 Initialiser / Mettre à Jour les Rôles</h2>
            
            <p class="text-gray-600 mb-6">
                Cette action va :
            </p>
            
            <ul class="list-disc list-inside text-gray-600 mb-6 space-y-2">
                <li>Créer ou mettre à jour les 4 rôles de base (Super Admin, Admin, Employé, Client)</li>
                <li>Configurer les permissions appropriées pour chaque rôle</li>
                <li>Assigner automatiquement le rôle "Client" aux utilisateurs sans rôle</li>
            </ul>
            
            <form method="POST" onsubmit="return confirm('Voulez-vous initialiser/mettre à jour les rôles ?');">
                <button type="submit" class="w-full bg-purple-600 text-white py-4 rounded-lg font-bold text-lg hover:bg-purple-700 transition-colors shadow-lg">
                    ✨ Lancer l'Initialisation
                </button>
            </form>
        </div>
        
    </div>
</body>
</html>
