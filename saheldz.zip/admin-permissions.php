<?php
require_once 'config/auth-check.php';
require_once 'config/database.php';

if (!isAdmin()) { header('Location: /'); exit; }
$pdo = getDB();

try { $pdo->query("SELECT 1 FROM permissions LIMIT 1"); } 
catch (Exception $e) { ?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Installation</title><script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen">
<div class="max-w-2xl mx-auto p-8"><div class="bg-white rounded-xl shadow-lg p-8 text-center">
<div class="text-6xl mb-6">⚠️</div><h1 class="text-3xl font-bold mb-4">Installation Requise</h1>
<a href="/install-permissions.php" class="bg-purple-600 text-white px-6 py-3 rounded-lg">🚀 Installer</a>
</div></div></body></html>
<?php exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $response = ['success' => false];
    if ($_POST['action'] === 'update_user_permissions') {
        try {
            $pdo->beginTransaction();
            $pdo->prepare("DELETE FROM user_permissions WHERE user_id = ?")->execute([intval($_POST['user_id'])]);
            if (isset($_POST['permissions'])) {
                $stmt = $pdo->prepare("INSERT INTO user_permissions (user_id, permission_id, granted_by) VALUES (?, ?, ?)");
                foreach ($_POST['permissions'] as $p) $stmt->execute([intval($_POST['user_id']), intval($p), $GLOBALS['current_user']['id']]);
            }
            $pdo->commit();
            $response = ['success' => true, 'message' => 'Permissions utilisateur mises à jour'];
        } catch (Exception $e) { $pdo->rollBack(); $response = ['success' => false, 'message' => $e->getMessage()]; }
    }
    if ($_POST['action'] === 'update_role_permissions') {
        try {
            $perms = isset($_POST['all_permissions']) ? ['all' => true] : array_fill_keys($_POST['permissions'] ?? [], true);
            $pdo->prepare("UPDATE roles SET permissions = ? WHERE id = ?")->execute([json_encode($perms), intval($_POST['role_id'])]);
            $response = ['success' => true, 'message' => 'Permissions du rôle mises à jour'];
        } catch (Exception $e) { $response = ['success' => false, 'message' => $e->getMessage()]; }
    }
    header('Content-Type: application/json'); echo json_encode($response); exit;
}

$roles = $pdo->query("SELECT * FROM roles ORDER BY id")->fetchAll();
$selectedRoleId = isset($_GET['role_id']) ? intval($_GET['role_id']) : ($roles[0]['id'] ?? 0);
$selectedRole = null; $rolePermissions = [];
foreach ($roles as $role) {
    if ($role['id'] == $selectedRoleId) {
        $selectedRole = $role;
        $perms = json_decode($role['permissions'], true) ?? [];
        $rolePermissions = isset($perms['all']) ? ['all' => true] : array_keys(array_filter($perms));
        break;
    }
}

$users = $pdo->query("SELECT u.*, r.name as role_name, r.display_name as role_display FROM users u LEFT JOIN roles r ON u.role_id = r.id WHERE r.name != 'super_admin' ORDER BY r.id, u.full_name")->fetchAll();
$selectedUserId = isset($_GET['user_id']) ? intval($_GET['user_id']) : ($users[0]['id'] ?? 0);
$selectedUser = null; $userPermissions = [];
foreach ($users as $user) {
    if ($user['id'] == $selectedUserId) {
        $selectedUser = $user;
        $stmt = $pdo->prepare("SELECT permission_id FROM user_permissions WHERE user_id = ?");
        $stmt->execute([$selectedUserId]);
        $userPermissions = $stmt->fetchAll(PDO::FETCH_COLUMN);
        break;
    }
}

$permissions = $pdo->query("SELECT * FROM permissions ORDER BY category, name")->fetchAll();
$permissionsByCategory = [];
foreach ($permissions as $perm) $permissionsByCategory[$perm['category']][] = $perm;
?>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Rôles & Permissions</title><script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-gray-50">
<?php include 'config/impersonation-banner.php'; ?>
<nav class="bg-gradient-to-r from-purple-600 to-indigo-600 shadow-lg">
<div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
<div class="flex items-center gap-4"><a href="/admin-dashboard.php" class="text-white">← Retour</a><h1 class="text-2xl font-bold text-white">🔐 Rôles & Permissions</h1></div>
<div class="text-white text-sm"><?php echo htmlspecialchars($GLOBALS['current_user']['full_name']); ?></div>
</div></nav>

<div class="max-w-7xl mx-auto px-4 py-8">
<div class="bg-white rounded-lg shadow-sm p-2 flex gap-2 mb-6">
<button onclick="switchTab('roles')" id="tab-roles" class="flex-1 px-6 py-3 rounded-md font-semibold bg-purple-600 text-white">🔐 Rôles</button>
<button onclick="switchTab('permissions')" id="tab-permissions" class="flex-1 px-6 py-3 rounded-md font-semibold text-gray-600">🔑 Utilisateurs</button>
</div>
<div id="alert-message" class="hidden mb-6"></div>

<div id="section-roles"><div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
<div><div class="bg-white rounded-xl shadow-lg p-6"><h2 class="text-lg font-bold mb-4">🔐 Rôles</h2><div class="space-y-2">
<?php foreach ($roles as $role): ?>
<a href="?role_id=<?=$role['id']?>" onclick="switchTab('roles')" class="block p-3 rounded-lg <?=$role['id']==$selectedRoleId?'bg-purple-100 border-2 border-purple-500':'bg-gray-50 hover:bg-gray-100'?>">
<div class="flex items-center gap-2">
<div class="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold"><?=strtoupper(substr($role['name'],0,1))?></div>
<div class="flex-1"><p class="font-medium text-sm"><?=htmlspecialchars($role['display_name'])?></p><p class="text-xs text-gray-500"><?=htmlspecialchars($role['name'])?></p></div>
</div></a>
<?php endforeach; ?>
</div></div></div>

<div class="lg:col-span-3"><?php if ($selectedRole): ?>
<div class="bg-white rounded-xl shadow-lg p-6">
<div class="flex justify-between mb-6"><div><h2 class="text-2xl font-bold"><?=htmlspecialchars($selectedRole['display_name'])?></h2></div>
<div class="flex gap-2"><button onclick="selectAllRole()" class="bg-green-600 text-white px-4 py-2 rounded-lg text-sm">✓</button>
<button onclick="deselectAllRole()" class="bg-gray-600 text-white px-4 py-2 rounded-lg text-sm">✗</button></div></div>
<form id="role-form" onsubmit="saveRole(event)">
<input type="hidden" name="role_id" value="<?=$selectedRoleId?>">
<div class="bg-purple-50 border-2 border-purple-200 rounded-lg p-4 mb-4">
<label class="flex gap-3 cursor-pointer"><input type="checkbox" id="role-all" onchange="toggleAllRole()" class="w-5 h-5" <?=isset($rolePermissions['all'])?'checked':''?>><span class="font-semibold">⚡ Toutes</span></label>
</div>
<div id="role-perms" class="grid md:grid-cols-2 gap-4">
<?php foreach ($permissionsByCategory as $cat => $perms): ?>
<div class="border rounded-lg p-4"><h3 class="font-bold text-sm mb-3"><?=htmlspecialchars($cat)?></h3>
<?php foreach ($perms as $p): ?>
<label class="flex gap-2 p-2 hover:bg-gray-50 rounded"><input type="checkbox" name="permissions[]" value="<?=$p['code']?>" class="role-cb" <?=in_array($p['code'],$rolePermissions)?'checked':''?>><span class="text-sm"><?=htmlspecialchars($p['name'])?></span></label>
<?php endforeach; ?>
</div>
<?php endforeach; ?>
</div>
<div class="mt-6 flex justify-end gap-3"><button type="submit" class="px-6 py-3 bg-purple-600 text-white rounded-lg">💾 Enregistrer</button></div>
</form></div>
<?php endif; ?></div>
</div></div>

<div id="section-permissions" class="hidden"><div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
<div><div class="bg-white rounded-xl shadow-lg p-6"><h2 class="text-lg font-bold mb-4">👥 Utilisateurs</h2><div class="space-y-2">
<?php foreach ($users as $u): ?>
<a href="?user_id=<?=$u['id']?>" onclick="switchTab('permissions')" class="block p-3 rounded-lg <?=$u['id']==$selectedUserId?'bg-purple-100 border-2 border-purple-500':'bg-gray-50 hover:bg-gray-100'?>">
<div class="flex items-center gap-2">
<div class="w-8 h-8 bg-gradient-to-br from-purple-500 to-indigo-500 rounded-full flex items-center justify-center text-white text-sm font-bold"><?=strtoupper(substr($u['full_name'],0,1))?></div>
<div class="flex-1"><p class="font-medium text-sm truncate"><?=htmlspecialchars($u['full_name'])?></p><p class="text-xs text-gray-500 truncate"><?=htmlspecialchars($u['email'])?></p></div>
</div></a>
<?php endforeach; ?>
</div></div></div>

<div class="lg:col-span-3"><?php if ($selectedUser): ?>
<div class="bg-white rounded-xl shadow-lg p-6">
<div class="flex justify-between mb-6"><div><h2 class="text-2xl font-bold"><?=htmlspecialchars($selectedUser['full_name'])?></h2></div>
<div class="flex gap-2"><button onclick="selectAllUser()" class="bg-green-600 text-white px-4 py-2 rounded-lg text-sm">✓</button>
<button onclick="deselectAllUser()" class="bg-gray-600 text-white px-4 py-2 rounded-lg text-sm">✗</button></div></div>
<form id="user-form" onsubmit="saveUser(event)">
<input type="hidden" name="user_id" value="<?=$selectedUserId?>">
<div class="grid md:grid-cols-2 gap-4">
<?php foreach ($permissionsByCategory as $cat => $perms): ?>
<div class="border rounded-lg p-4"><h3 class="font-bold text-sm mb-3"><?=htmlspecialchars($cat)?></h3>
<?php foreach ($perms as $p): ?>
<label class="flex gap-2 p-2 hover:bg-gray-50 rounded"><input type="checkbox" name="permissions[]" value="<?=$p['id']?>" class="user-cb" <?=in_array($p['id'],$userPermissions)?'checked':''?>><span class="text-sm"><?=htmlspecialchars($p['name'])?></span></label>
<?php endforeach; ?>
</div>
<?php endforeach; ?>
</div>
<div class="mt-6 flex justify-end gap-3"><button type="submit" class="px-6 py-3 bg-purple-600 text-white rounded-lg">💾 Enregistrer</button></div>
</form></div>
<?php endif; ?></div>
</div></div>

</div>

<script>
function switchTab(t){document.getElementById('tab-roles').className='flex-1 px-6 py-3 rounded-md font-semibold text-gray-600';document.getElementById('tab-permissions').className='flex-1 px-6 py-3 rounded-md font-semibold text-gray-600';document.getElementById('section-roles').classList.add('hidden');document.getElementById('section-permissions').classList.add('hidden');if(t=='roles'){document.getElementById('tab-roles').className='flex-1 px-6 py-3 rounded-md font-semibold bg-purple-600 text-white';document.getElementById('section-roles').classList.remove('hidden')}else{document.getElementById('tab-permissions').className='flex-1 px-6 py-3 rounded-md font-semibold bg-purple-600 text-white';document.getElementById('section-permissions').classList.remove('hidden')}}
function selectAllRole(){document.querySelectorAll('.role-cb').forEach(c=>c.checked=true)}
function deselectAllRole(){document.querySelectorAll('.role-cb').forEach(c=>c.checked=false)}
function selectAllUser(){document.querySelectorAll('.user-cb').forEach(c=>c.checked=true)}
function deselectAllUser(){document.querySelectorAll('.user-cb').forEach(c=>c.checked=false)}
function toggleAllRole(){const all=document.getElementById('role-all').checked;document.querySelectorAll('.role-cb').forEach(c=>{c.disabled=all;if(all)c.checked=true});document.getElementById('role-perms').style.opacity=all?'0.5':'1'}
async function saveRole(e){e.preventDefault();const fd=new FormData(e.target);fd.append('action','update_role_permissions');if(document.getElementById('role-all').checked)fd.append('all_permissions','1');try{const r=await fetch('admin-permissions.php',{method:'POST',body:fd});const d=await r.json();showAlert(d.message,d.success?'success':'error');if(d.success)setTimeout(()=>location.reload(),1000)}catch(err){showAlert('Erreur','error')}}
async function saveUser(e){e.preventDefault();const fd=new FormData(e.target);fd.append('action','update_user_permissions');try{const r=await fetch('admin-permissions.php',{method:'POST',body:fd});const d=await r.json();showAlert(d.message,d.success?'success':'error')}catch(err){showAlert('Erreur','error')}}
function showAlert(msg,type){const a=document.getElementById('alert-message');a.className=`mb-6 p-4 rounded-lg ${type=='success'?'bg-green-100 text-green-800':'bg-red-100 text-red-800'}`;a.textContent=msg;a.classList.remove('hidden');setTimeout(()=>a.classList.add('hidden'),3000);window.scrollTo({top:0})}
</script>
</body></html>
