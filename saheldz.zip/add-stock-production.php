<?php
// Script simple pour ajouter du stock directement
require_once 'config/database.php';

echo "=== AJOUT DE STOCK EN PRODUCTION ===\n\n";

try {
    // 1. Lister les produits
    echo "1. Produits disponibles:\n";
    $stmt = $pdo->query("SELECT id, name, type, price FROM shop_items WHERE status = 'available'");
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($items as $item) {
        echo "  - ID {$item['id']}: {$item['name']} ({$item['type']}) - {$item['price']}€\n";
        
        if ($item['type'] === 'product') {
            // Vérifier stock actuel
            $stmt = $pdo->prepare("
                SELECT COUNT(*) as available 
                FROM product_stock 
                WHERE item_id = ? AND status = 'available'
            ");
            $stmt->execute([$item['id']]);
            $stock = $stmt->fetchColumn();
            echo "    Stock disponible: {$stock}\n";
        }
    }
    
    echo "\n2. Ajout de 20 codes pour chaque produit...\n\n";
    
    // 2. Ajouter du stock pour chaque produit
    foreach ($items as $item) {
        if ($item['type'] === 'product') {
            echo "Ajout de codes pour: {$item['name']}\n";
            
            for ($i = 1; $i <= 20; $i++) {
                $code = 'CODE-' . strtoupper(bin2hex(random_bytes(8)));
                $key = "Instructions d'utilisation du code:\n- Étape 1: ...\n- Étape 2: ...\n- Support: contact@example.com";
                
                $stmt = $pdo->prepare("
                    INSERT INTO product_stock (item_id, product_code, product_key, status)
                    VALUES (?, ?, ?, 'available')
                ");
                $stmt->execute([$item['id'], $code, $key]);
            }
            
            echo "  ✅ 20 codes ajoutés\n\n";
        }
    }
    
    echo "3. Vérification finale:\n";
    foreach ($items as $item) {
        if ($item['type'] === 'product') {
            $stmt = $pdo->prepare("
                SELECT COUNT(*) as available 
                FROM product_stock 
                WHERE item_id = ? AND status = 'available'
            ");
            $stmt->execute([$item['id']]);
            $stock = $stmt->fetchColumn();
            echo "  - {$item['name']}: {$stock} codes disponibles\n";
        }
    }
    
    echo "\n✅ STOCK AJOUTÉ AVEC SUCCÈS !\n";
    
} catch (Exception $e) {
    echo "❌ ERREUR: " . $e->getMessage() . "\n";
}
?>
