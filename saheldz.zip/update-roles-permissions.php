<?php
/**
 * Script pour mettre à jour les permissions des rôles
 * Exécuter ce script pour configurer les permissions appropriées
 */

require_once 'config/database.php';

try {
    $pdo = getDB();
    
    echo "=== MISE À JOUR DES PERMISSIONS DES RÔLES ===\n\n";
    
    // 1. Super Admin - Accès complet
    $superAdminPerms = json_encode(['all' => true]);
    $stmt = $pdo->prepare("UPDATE roles SET permissions = ? WHERE name = 'super_admin'");
    $stmt->execute([$superAdminPerms]);
    echo "✓ Super Admin: Toutes les permissions\n";
    
    // 2. Admin - Accès complet
    $adminPerms = json_encode(['all' => true]);
    $stmt = $pdo->prepare("UPDATE roles SET permissions = ? WHERE name = 'admin'");
    $stmt->execute([$adminPerms]);
    echo "✓ Admin: Toutes les permissions\n";
    
    // 3. Employé - Permissions de travail
    $employeePerms = json_encode([
        'view_users' => true,           // Voir les utilisateurs/clients
        'view_orders' => true,          // Voir les commandes
        'manage_orders' => true,        // Gérer les commandes
        'create_orders' => true,        // Créer des commandes
        'view_wallet' => true,          // Voir son propre wallet
        'manage_projects' => true,      // Gérer les projets
        'upload_files' => true,         // Upload de fichiers
        'view_reports' => true          // Voir les rapports
    ]);
    $stmt = $pdo->prepare("UPDATE roles SET permissions = ? WHERE name = 'employee'");
    $stmt->execute([$employeePerms]);
    echo "✓ Employé: Permissions de gestion des commandes et projets\n";
    
    // 4. Client - Permissions limitées
    $clientPerms = json_encode([
        'view_wallet' => true,          // Voir son wallet
        'view_orders' => true,          // Voir ses propres commandes
        'create_orders' => true,        // Passer des commandes
        'upload_files' => true          // Upload dans ses projets
    ]);
    $stmt = $pdo->prepare("UPDATE roles SET permissions = ? WHERE name = 'client'");
    $stmt->execute([$clientPerms]);
    echo "✓ Client: Permissions de consultation et commande\n";
    
    echo "\n=== MISE À JOUR TERMINÉE AVEC SUCCÈS ===\n\n";
    
    // Afficher un résumé
    echo "Résumé des rôles:\n";
    echo "----------------\n";
    $stmt = $pdo->query("SELECT name, display_name, permissions FROM roles ORDER BY id");
    $roles = $stmt->fetchAll();
    
    foreach ($roles as $role) {
        echo "\n{$role['display_name']} ({$role['name']}):\n";
        $perms = json_decode($role['permissions'], true);
        if (isset($perms['all']) && $perms['all']) {
            echo "  - Toutes les permissions\n";
        } else {
            foreach ($perms as $perm => $value) {
                if ($value) {
                    echo "  - " . str_replace('_', ' ', ucfirst($perm)) . "\n";
                }
            }
        }
    }
    
    echo "\n✅ Les permissions ont été configurées avec succès!\n";
    
} catch (Exception $e) {
    echo "❌ Erreur: " . $e->getMessage() . "\n";
}
