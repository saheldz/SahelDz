<?php
/**
 * Page des paramètres utilisateur
 */
require_once 'config/auth-check.php';
require_once 'config/database.php';

$pdo = getDB();
$user = $GLOBALS['current_user'];

// Récupérer les informations complètes de l'utilisateur
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user['id']]);
$userData = $stmt->fetch();

$success_message = '';
$error_message = '';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    
    if (empty($full_name) || empty($email)) {
        $error_message = 'Le nom et l\'email sont obligatoires.';
    } else {
        // Vérifier si l'email existe déjà pour un autre utilisateur
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $user['id']]);
        
        if ($stmt->fetch()) {
            $error_message = 'Cet email est déjà utilisé par un autre compte.';
        } else {
            // Mettre à jour les informations
            $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ? WHERE id = ?");
            if ($stmt->execute([$full_name, $email, $phone, $user['id']])) {
                // Mettre à jour la session
                $_SESSION['user_name'] = $full_name;
                $_SESSION['user_email'] = $email;
                
                $success_message = 'Vos informations ont été mises à jour avec succès!';
                
                // Recharger les données
                $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                $stmt->execute([$user['id']]);
                $userData = $stmt->fetch();
            } else {
                $error_message = 'Erreur lors de la mise à jour. Veuillez réessayer.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paramètres du compte - DigiServices</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .gradient-bg { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
    </style>
</head>
<body class="h-full bg-gray-50">
    <?php include 'config/impersonation-banner.php'; ?>
    
    <div class="min-h-full">
        <!-- Header -->
        <div class="gradient-bg">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex items-center justify-between h-16">
                    <div class="flex items-center">
                        <a href="<?php echo $user['role'] === 'client' ? '/html/client-app.php' : '/html/1a.php'; ?>" class="text-white hover:text-gray-200 flex items-center">
                            <span class="text-2xl mr-2">←</span>
                            <span class="font-semibold">Retour</span>
                        </a>
                    </div>
                    <h1 class="text-xl font-bold text-white">⚙️ Paramètres du compte</h1>
                    <div class="w-24"></div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <!-- Messages -->
            <?php if ($success_message): ?>
                <div class="mb-6 bg-green-50 border-l-4 border-green-500 p-4 rounded-lg">
                    <div class="flex items-center">
                        <span class="text-2xl mr-3">✅</span>
                        <p class="text-green-700 font-medium"><?php echo htmlspecialchars($success_message); ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
                <div class="mb-6 bg-red-50 border-l-4 border-red-500 p-4 rounded-lg">
                    <div class="flex items-center">
                        <span class="text-2xl mr-3">❌</span>
                        <p class="text-red-700 font-medium"><?php echo htmlspecialchars($error_message); ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Profile Card -->
            <div class="bg-white rounded-xl shadow-lg overflow-hidden mb-6">
                <div class="gradient-bg px-6 py-8">
                    <div class="flex items-center">
                        <div class="w-20 h-20 rounded-full bg-white flex items-center justify-center text-4xl font-bold text-purple-600">
                            <?php echo strtoupper(substr($userData['full_name'], 0, 1)); ?>
                        </div>
                        <div class="ml-6 text-white">
                            <h2 class="text-2xl font-bold"><?php echo htmlspecialchars($userData['full_name']); ?></h2>
                            <p class="text-purple-100"><?php echo htmlspecialchars($userData['email']); ?></p>
                            <p class="text-purple-100 text-sm mt-1">
                                <span class="inline-block px-2 py-1 bg-white bg-opacity-20 rounded">
                                    <?php echo htmlspecialchars($userData['role_name'] ?? ucfirst($userData['role'])); ?>
                                </span>
                            </p>
                        </div>
                    </div>
                </div>

                <form method="POST" class="p-6">
                    <div class="space-y-6">
                        <!-- Nom complet -->
                        <div>
                            <label for="full_name" class="block text-sm font-medium text-gray-700 mb-2">
                                👤 Nom complet <span class="text-red-500">*</span>
                            </label>
                            <input 
                                type="text" 
                                id="full_name" 
                                name="full_name" 
                                value="<?php echo htmlspecialchars($userData['full_name']); ?>"
                                required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
                                placeholder="Votre nom complet"
                            >
                        </div>

                        <!-- Email -->
                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
                                📧 Adresse email <span class="text-red-500">*</span>
                            </label>
                            <input 
                                type="email" 
                                id="email" 
                                name="email" 
                                value="<?php echo htmlspecialchars($userData['email']); ?>"
                                required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
                                placeholder="votre@email.com"
                            >
                        </div>

                        <!-- Téléphone -->
                        <div>
                            <label for="phone" class="block text-sm font-medium text-gray-700 mb-2">
                                📱 Téléphone
                            </label>
                            <input 
                                type="tel" 
                                id="phone" 
                                name="phone" 
                                value="<?php echo htmlspecialchars($userData['phone'] ?? ''); ?>"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
                                placeholder="+213 XXX XXX XXX"
                            >
                        </div>

                        <!-- Informations non modifiables -->
                        <div class="bg-gray-50 rounded-lg p-4 space-y-3">
                            <h3 class="font-semibold text-gray-800 mb-3">Informations du compte</h3>
                            
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600">Rôle:</span>
                                <span class="font-medium"><?php echo htmlspecialchars($userData['role_name'] ?? ucfirst($userData['role'])); ?></span>
                            </div>
                            
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600">Compte créé le:</span>
                                <span class="font-medium"><?php echo date('d/m/Y', strtotime($userData['created_at'])); ?></span>
                            </div>
                            
                            <div class="flex justify-between text-sm">
                                <span class="text-gray-600">Statut:</span>
                                <span class="font-medium">
                                    <?php if ($userData['status'] === 'active'): ?>
                                        <span class="text-green-600">✓ Actif</span>
                                    <?php else: ?>
                                        <span class="text-gray-600"><?php echo htmlspecialchars($userData['status']); ?></span>
                                    <?php endif; ?>
                                </span>
                            </div>
                        </div>

                        <!-- Boutons d'action -->
                        <div class="flex gap-4 pt-4">
                            <button 
                                type="submit"
                                class="flex-1 gradient-bg text-white py-3 px-6 rounded-lg font-semibold hover:opacity-90 transition-opacity"
                            >
                                💾 Enregistrer les modifications
                            </button>
                            
                            <a 
                                href="<?php echo $user['role'] === 'client' ? '/html/client-app.php' : '/html/1a.php'; ?>"
                                class="flex-1 bg-gray-200 text-gray-700 py-3 px-6 rounded-lg font-semibold hover:bg-gray-300 transition-colors text-center"
                            >
                                Annuler
                            </a>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Quick Links -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <a href="/change-password.php" class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center text-2xl">
                            🔐
                        </div>
                        <div class="ml-4">
                            <h3 class="font-semibold text-gray-800">Changer le mot de passe</h3>
                            <p class="text-sm text-gray-600">Modifier votre mot de passe</p>
                        </div>
                    </div>
                </a>

                <a href="<?php echo $user['role'] === 'client' ? '/html/client-app.php' : '/html/1a.php'; ?>" class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center text-2xl">
                            🏠
                        </div>
                        <div class="ml-4">
                            <h3 class="font-semibold text-gray-800">Tableau de bord</h3>
                            <p class="text-sm text-gray-600">Retour à l'accueil</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</body>
</html>
