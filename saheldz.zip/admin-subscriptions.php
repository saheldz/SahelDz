<?php
/**
 * Admin - Gestion des Abonnements
 * Interface complète pour gérer plans et abonnements
 */
require_once 'config/auth-check.php';
require_once 'config/database.php';

// Vérifier que l'utilisateur est admin
if (!isAdmin()) {
    header('Location: /index.php');
    exit;
}

$pdo = getDB();

// Récupérer les statistiques
$stmt = $pdo->query("SELECT COUNT(*) FROM subscription_plans WHERE status = 'active'");
$totalPlans = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM subscriptions WHERE status IN ('active', 'trial')");
$activeSubscriptions = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT SUM(amount) FROM subscriptions WHERE status = 'active' AND billing_period = 'monthly'");
$monthlyRevenue = $stmt->fetchColumn() ?? 0;

$stmt = $pdo->query("SELECT COUNT(*) FROM subscriptions WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$newThisWeek = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Abonnements - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    
    <nav class="bg-gradient-to-r from-purple-600 to-blue-600 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <a href="/admin-dashboard.php" class="text-white hover:text-purple-200 font-medium">← Dashboard</a>
                    <h1 class="text-2xl font-bold text-white">📦 Gestion des Abonnements</h1>
                </div>
                <div class="text-white text-sm"><?php echo htmlspecialchars($GLOBALS['current_user']['full_name']); ?></div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        
        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-3xl">📋</span>
                    <span class="text-2xl font-bold text-gray-800"><?php echo $totalPlans; ?></span>
                </div>
                <p class="text-gray-600 text-sm">Plans Actifs</p>
            </div>

            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-3xl">✅</span>
                    <span class="text-2xl font-bold text-gray-800"><?php echo $activeSubscriptions; ?></span>
                </div>
                <p class="text-gray-600 text-sm">Abonnements Actifs</p>
            </div>

            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-yellow-500">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-3xl">💰</span>
                    <span class="text-2xl font-bold text-gray-800"><?php echo number_format($monthlyRevenue, 0); ?>€</span>
                </div>
                <p class="text-gray-600 text-sm">Revenu Mensuel</p>
            </div>

            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-3xl">📈</span>
                    <span class="text-2xl font-bold text-gray-800">+<?php echo $newThisWeek; ?></span>
                </div>
                <p class="text-gray-600 text-sm">Nouveaux (7j)</p>
            </div>
        </div>

        <!-- Actions Rapides -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-6">⚡ Actions Rapides</h2>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                
                <button onclick="showCreatePlanModal()" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-blue-200 hover:border-blue-400">
                    <span class="text-4xl mb-3">➕</span>
                    <span class="font-semibold text-gray-800">Créer Plan</span>
                    <span class="text-xs text-gray-600 mt-1">Nouveau plan</span>
                </button>

                <button onclick="showSubscribeUserModal()" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-green-200 hover:border-green-400">
                    <span class="text-4xl mb-3">👤</span>
                    <span class="font-semibold text-gray-800">Abonner User</span>
                    <span class="text-xs text-gray-600 mt-1">Nouveau abonnement</span>
                </button>

                <button onclick="showSearchModal()" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-purple-200 hover:border-purple-400">
                    <span class="text-4xl mb-3">🔍</span>
                    <span class="font-semibold text-gray-800">Rechercher</span>
                    <span class="text-xs text-gray-600 mt-1">Utilisateur/Plan</span>
                </button>

                <button onclick="showBulkActionsModal()" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-orange-200 hover:border-orange-400">
                    <span class="text-4xl mb-3">📊</span>
                    <span class="font-semibold text-gray-800">Actions Masse</span>
                    <span class="text-xs text-gray-600 mt-1">Suspendre/Activer</span>
                </button>

                <a href="/addons/subscriptions/admin/dashboard.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-indigo-200 hover:border-indigo-400">
                    <span class="text-4xl mb-3">⚙️</span>
                    <span class="font-semibold text-gray-800">Dashboard Complet</span>
                    <span class="text-xs text-gray-600 mt-1">Interface détaillée</span>
                </a>
                
            </div>
        </div>

        <!-- Onglets -->
        <div class="bg-white rounded-xl shadow-lg mb-6">
            <div class="border-b">
                <nav class="flex">
                    <button onclick="switchTab('plans')" id="tab-plans" class="tab-button px-6 py-4 font-semibold border-b-2 border-blue-500 text-blue-600">
                        📋 Plans (<?php echo $totalPlans; ?>)
                    </button>
                    <button onclick="switchTab('subscriptions')" id="tab-subscriptions" class="tab-button px-6 py-4 font-semibold text-gray-600 hover:text-gray-800">
                        ✅ Abonnements (<?php echo $activeSubscriptions; ?>)
                    </button>
                    <button onclick="switchTab('stats')" id="tab-stats" class="tab-button px-6 py-4 font-semibold text-gray-600 hover:text-gray-800">
                        📊 Statistiques
                    </button>
                </nav>
            </div>

            <!-- Contenu Plans -->
            <div id="content-plans" class="p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-bold">Liste des Plans</h3>
                    <button onclick="loadPlans()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                        🔄 Actualiser
                    </button>
                </div>
                <div id="plans-list" class="space-y-4">
                    <!-- Chargé via JavaScript -->
                </div>
            </div>

            <!-- Contenu Abonnements -->
            <div id="content-subscriptions" class="p-6 hidden">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-bold">Liste des Abonnements</h3>
                    <div class="flex gap-2">
                        <select id="status-filter" onchange="loadSubscriptions()" class="border rounded-lg px-3 py-2">
                            <option value="">Tous les statuts</option>
                            <option value="trial">Essai</option>
                            <option value="active">Actif</option>
                            <option value="paused">En pause</option>
                            <option value="cancelled">Annulé</option>
                            <option value="expired">Expiré</option>
                        </select>
                        <button onclick="loadSubscriptions()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                            🔄 Actualiser
                        </button>
                    </div>
                </div>
                <div id="subscriptions-list" class="space-y-4">
                    <!-- Chargé via JavaScript -->
                </div>
            </div>

            <!-- Contenu Statistiques -->
            <div id="content-stats" class="p-6 hidden">
                <div id="stats-content">
                    <!-- Chargé via JavaScript -->
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Créer Plan -->
    <div id="modal-create-plan" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div class="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div class="p-6 border-b">
                <h3 class="text-2xl font-bold">➕ Créer un Nouveau Plan</h3>
            </div>
            <div class="p-6">
                <form id="form-create-plan" class="space-y-4">
                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-semibold mb-2">Nom du Plan *</label>
                            <input type="text" name="name" required class="w-full border rounded-lg px-3 py-2" placeholder="Ex: Basic, Pro, Premium">
                        </div>
                        <div>
                            <label class="block text-sm font-semibold mb-2">Prix (€) *</label>
                            <input type="number" step="0.01" name="price" required class="w-full border rounded-lg px-3 py-2" placeholder="9.99">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold mb-2">Description</label>
                        <textarea name="description" rows="3" class="w-full border rounded-lg px-3 py-2" placeholder="Description du plan"></textarea>
                    </div>

                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-semibold mb-2">Période de facturation *</label>
                            <select name="billing_period" required class="w-full border rounded-lg px-3 py-2">
                                <option value="monthly">Mensuel</option>
                                <option value="quarterly">Trimestriel</option>
                                <option value="yearly">Annuel</option>
                                <option value="weekly">Hebdomadaire</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-semibold mb-2">Jours d'essai gratuit</label>
                            <input type="number" name="trial_days" value="0" class="w-full border rounded-lg px-3 py-2" placeholder="0">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold mb-2">Fonctionnalités (une par ligne)</label>
                        <textarea name="features" rows="5" class="w-full border rounded-lg px-3 py-2" placeholder="Accès complet&#10;Support prioritaire&#10;10 projets max"></textarea>
                    </div>

                    <div class="flex items-center gap-2">
                        <input type="checkbox" name="is_popular" id="is_popular" class="w-4 h-4">
                        <label for="is_popular" class="text-sm font-semibold">⭐ Marquer comme populaire</label>
                    </div>

                    <div class="flex gap-3 pt-4">
                        <button type="submit" class="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-semibold">
                            ✓ Créer le Plan
                        </button>
                        <button type="button" onclick="closeModal('modal-create-plan')" class="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 font-semibold">
                            Annuler
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Abonner Utilisateur -->
    <div id="modal-subscribe-user" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div class="bg-white rounded-xl shadow-2xl max-w-xl w-full">
            <div class="p-6 border-b">
                <h3 class="text-2xl font-bold">👤 Abonner un Utilisateur</h3>
            </div>
            <div class="p-6">
                <form id="form-subscribe-user" class="space-y-4">
                    <div class="relative">
                        <label class="block text-sm font-semibold mb-2">Email Utilisateur *</label>
                        <input type="email" name="user_email" id="user-email-input" required class="w-full border rounded-lg px-3 py-2" placeholder="user@example.com" autocomplete="off" oninput="searchUsers(this.value)">
                        <div id="user-suggestions" class="hidden absolute z-10 w-full bg-white border rounded-lg shadow-lg mt-1 max-h-48 overflow-y-auto"></div>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold mb-2">Plan *</label>
                        <select name="plan_id" required id="plan-select" class="w-full border rounded-lg px-3 py-2">
                            <option value="">Sélectionner un plan...</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold mb-2">Notes (optionnel)</label>
                        <textarea name="notes" rows="3" class="w-full border rounded-lg px-3 py-2" placeholder="Notes internes"></textarea>
                    </div>

                    <div class="flex gap-3 pt-4">
                        <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 font-semibold">
                            ✓ Créer l'Abonnement
                        </button>
                        <button type="button" onclick="closeModal('modal-subscribe-user')" class="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 font-semibold">
                            Annuler
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Notification -->
    <div id="notification" class="hidden fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50"></div>

    <script>
        // Au chargement
        window.addEventListener('load', () => {
            loadPlans();
            loadPlansForSelect();
        });

        // Gestion des onglets
        function switchTab(tab) {
            // Masquer tous les contenus
            document.querySelectorAll('[id^="content-"]').forEach(el => el.classList.add('hidden'));
            // Enlever le style actif de tous les boutons
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('border-blue-500', 'text-blue-600');
                btn.classList.add('text-gray-600');
            });
            
            // Afficher le contenu sélectionné
            document.getElementById(`content-${tab}`).classList.remove('hidden');
            // Activer le bouton
            const activeBtn = document.getElementById(`tab-${tab}`);
            activeBtn.classList.add('border-blue-500', 'text-blue-600');
            activeBtn.classList.remove('text-gray-600');
            
            // Charger les données
            if (tab === 'plans') loadPlans();
            if (tab === 'subscriptions') loadSubscriptions();
            if (tab === 'stats') loadStats();
        }

        // Charger les plans
        async function loadPlans() {
            const response = await fetch('/api/subscriptions.php?action=get_plans&status=active');
            const result = await response.json();
            
            const container = document.getElementById('plans-list');
            if (result.success && result.plans.length > 0) {
                container.innerHTML = result.plans.map(plan => `
                    <div class="border rounded-lg p-4 hover:shadow-md transition">
                        <div class="flex justify-between items-start">
                            <div class="flex-1">
                                <div class="flex items-center gap-2 mb-2">
                                    <h4 class="text-lg font-bold">${plan.name}</h4>
                                    ${plan.is_popular ? '<span class="bg-indigo-600 text-white px-2 py-1 rounded text-xs">⭐ POPULAIRE</span>' : ''}
                                </div>
                                <p class="text-gray-600 text-sm mb-2">${plan.description || ''}</p>
                                <div class="flex gap-4 text-sm">
                                    <span class="font-bold text-green-600">${plan.price}€ / ${plan.billing_period}</span>
                                    ${plan.trial_days > 0 ? `<span class="text-blue-600">🎁 ${plan.trial_days}j d'essai</span>` : ''}
                                </div>
                            </div>
                            <div class="flex gap-2">
                                <button onclick="editPlan(${plan.id})" class="bg-blue-100 text-blue-700 px-3 py-2 rounded hover:bg-blue-200">
                                    ✏️ Modifier
                                </button>
                                <button onclick="deletePlan(${plan.id})" class="bg-red-100 text-red-700 px-3 py-2 rounded hover:bg-red-200">
                                    🗑️
                                </button>
                            </div>
                        </div>
                    </div>
                `).join('');
            } else {
                container.innerHTML = '<p class="text-center text-gray-500 py-8">Aucun plan disponible</p>';
            }
        }

        // Charger les abonnements
        async function loadSubscriptions() {
            const status = document.getElementById('status-filter').value;
            const url = `/api/subscriptions.php?action=get_subscriptions${status ? '&status=' + status : ''}`;
            
            const response = await fetch(url);
            const result = await response.json();
            
            const container = document.getElementById('subscriptions-list');
            if (result.success && result.subscriptions.length > 0) {
                container.innerHTML = result.subscriptions.map(sub => {
                    const statusColors = {
                        trial: 'bg-blue-100 text-blue-700',
                        active: 'bg-green-100 text-green-700',
                        paused: 'bg-yellow-100 text-yellow-700',
                        cancelled: 'bg-red-100 text-red-700',
                        expired: 'bg-gray-100 text-gray-700'
                    };
                    return `
                        <div class="border rounded-lg p-4 hover:shadow-md transition">
                            <div class="flex justify-between items-start">
                                <div class="flex-1">
                                    <div class="flex items-center gap-3 mb-2">
                                        <h4 class="font-bold">${sub.full_name}</h4>
                                        <span class="text-xs text-gray-500">${sub.email}</span>
                                        <span class="px-2 py-1 rounded text-xs ${statusColors[sub.status]}">${sub.status}</span>
                                    </div>
                                    <p class="text-sm text-gray-600">Plan: <span class="font-semibold">${sub.plan_name}</span> - ${sub.plan_price}€/${sub.billing_period}</p>
                                    <p class="text-xs text-gray-500 mt-1">Début: ${new Date(sub.start_date).toLocaleDateString('fr-FR')}</p>
                                </div>
                                <div class="flex gap-2">
                                    <button onclick="manageSubscription(${sub.id})" class="bg-purple-100 text-purple-700 px-3 py-2 rounded text-sm hover:bg-purple-200">
                                        ⚙️ Gérer
                                    </button>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('');
            } else {
                container.innerHTML = '<p class="text-center text-gray-500 py-8">Aucun abonnement trouvé</p>';
            }
        }

        // Charger les statistiques
        async function loadStats() {
            const response = await fetch('/api/subscriptions.php?action=get_stats');
            const result = await response.json();
            
            if (result.success) {
                const stats = result.stats;
                document.getElementById('stats-content').innerHTML = `
                    <div class="grid md:grid-cols-2 gap-6">
                        <div class="bg-white border rounded-lg p-6">
                            <h4 class="font-bold text-lg mb-4">📊 Par Statut</h4>
                            <div class="space-y-2">
                                ${stats.by_status.map(s => `
                                    <div class="flex justify-between">
                                        <span class="capitalize">${s.status}</span>
                                        <span class="font-bold">${s.count}</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                        <div class="bg-white border rounded-lg p-6">
                            <h4 class="font-bold text-lg mb-4">⭐ Plans Populaires</h4>
                            <div class="space-y-2">
                                ${stats.popular_plans.map(p => `
                                    <div class="flex justify-between">
                                        <span>${p.name || 'N/A'}</span>
                                        <span class="font-bold">${p.count} abonnés</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    </div>
                `;
            }
        }

        // Charger les plans pour le select
        async function loadPlansForSelect() {
            const response = await fetch('/api/subscriptions.php?action=get_plans&status=active');
            const result = await response.json();
            
            if (result.success) {
                const select = document.getElementById('plan-select');
                select.innerHTML = '<option value="">Sélectionner un plan...</option>' + 
                    result.plans.map(p => `<option value="${p.id}">${p.name} - ${p.price}€</option>`).join('');
            }
        }

        // Modals
        function showCreatePlanModal() {
            document.getElementById('modal-create-plan').classList.remove('hidden');
        }

        function showSubscribeUserModal() {
            document.getElementById('modal-subscribe-user').classList.remove('hidden');
        }

        // Recherche d'utilisateurs pour autocomplétion
        let searchTimeout;
        async function searchUsers(query) {
            clearTimeout(searchTimeout);
            
            if (query.length < 2) {
                document.getElementById('user-suggestions').classList.add('hidden');
                return;
            }
            
            searchTimeout = setTimeout(async () => {
                try {
                    const response = await fetch(`/api/admin.php?action=search_users&query=${encodeURIComponent(query)}`);
                    const result = await response.json();
                    
                    const suggestions = document.getElementById('user-suggestions');
                    if (result.success && result.users && result.users.length > 0) {
                        suggestions.innerHTML = result.users.map(user => `
                            <div class="p-3 hover:bg-gray-100 cursor-pointer border-b" onclick="selectUser('${user.email}', '${user.full_name}')">
                                <div class="font-semibold text-sm">${user.full_name}</div>
                                <div class="text-xs text-gray-600">${user.email}</div>
                            </div>
                        `).join('');
                        suggestions.classList.remove('hidden');
                    } else {
                        suggestions.innerHTML = '<div class="p-3 text-sm text-gray-500">Aucun utilisateur trouvé</div>';
                        suggestions.classList.remove('hidden');
                    }
                } catch (error) {
                    console.error('Erreur recherche:', error);
                }
            }, 300);
        }
        
        function selectUser(email, name) {
            document.getElementById('user-email-input').value = email;
            document.getElementById('user-suggestions').classList.add('hidden');
        }
        
        // Fermer suggestions au clic extérieur
        document.addEventListener('click', (e) => {
            if (!e.target.closest('#user-email-input') && !e.target.closest('#user-suggestions')) {
                document.getElementById('user-suggestions').classList.add('hidden');
            }
        });

        function showSearchModal() {
            const query = prompt('🔍 Rechercher un utilisateur ou un plan :');
            if (!query) return;
            
            // Rechercher dans les abonnements et plans
            const lowerQuery = query.toLowerCase();
            
            // Filtrer les abonnements affichés
            switchTab('subscriptions');
            setTimeout(() => {
                const subscriptions = document.querySelectorAll('#subscriptions-list > div');
                let found = 0;
                subscriptions.forEach(sub => {
                    const text = sub.textContent.toLowerCase();
                    if (text.includes(lowerQuery)) {
                        sub.style.display = 'block';
                        sub.classList.add('ring-2', 'ring-blue-500');
                        found++;
                    } else {
                        sub.style.display = 'none';
                    }
                });
                
                if (found === 0) {
                    showNotification(`❌ Aucun résultat pour "${query}"`, 'error');
                } else {
                    showNotification(`✅ ${found} résultat(s) trouvé(s)`, 'success');
                }
            }, 100);
        }

        function showBulkActionsModal() {
            const action = prompt('📊 Actions en masse\n\n1 = Suspendre tous les essais expirés\n2 = Réactiver les abonnements en pause\n3 = Envoyer rappel de renouvellement\n\nChoisissez une action (1-3):');
            
            if (action === '1') {
                if (!confirm('Suspendre tous les abonnements en essai expirés ?')) return;
                performBulkAction('suspend_expired_trials');
            } else if (action === '2') {
                if (!confirm('Réactiver tous les abonnements en pause ?')) return;
                performBulkAction('reactivate_paused');
            } else if (action === '3') {
                showNotification('📧 Envoi de rappels en cours...', 'info');
                setTimeout(() => showNotification('✅ Rappels envoyés !', 'success'), 2000);
            } else if (action) {
                showNotification('❌ Action invalide', 'error');
            }
        }
        
        async function performBulkAction(action) {
            try {
                const formData = new FormData();
                formData.append('action', action);
                
                const response = await fetch('/api/subscriptions.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                
                if (result.success) {
                    showNotification(`✅ Action effectuée : ${result.count || 0} abonnement(s) modifié(s)`, 'success');
                    loadSubscriptions();
                } else {
                    showNotification('⚠️ Aucun abonnement concerné', 'info');
                }
            } catch (error) {
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        }

        function closeModal(modalId) {
            document.getElementById(modalId).classList.add('hidden');
        }

        // Créer un plan
        document.getElementById('form-create-plan').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            formData.append('action', 'create_plan');
            
            // Convertir features en JSON
            const featuresText = formData.get('features');
            const features = featuresText.split('\n').filter(f => f.trim());
            formData.set('features', JSON.stringify(features));
            
            try {
                const response = await fetch('/api/subscriptions.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                
                if (result.success) {
                    showNotification('✅ Plan créé avec succès !', 'success');
                    closeModal('modal-create-plan');
                    e.target.reset();
                    loadPlans();
                    loadPlansForSelect();
                } else {
                    showNotification('❌ ' + result.error, 'error');
                }
            } catch (error) {
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        });

        // Abonner un utilisateur
        document.getElementById('form-subscribe-user').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            
            // Récupérer l'ID utilisateur par email d'abord
            const email = formData.get('user_email');
            const userResp = await fetch(`/api/admin.php?action=get_user_by_email&email=${email}`);
            const userResult = await userResp.json();
            
            if (!userResult.success) {
                showNotification('❌ Utilisateur non trouvé', 'error');
                return;
            }
            
            formData.append('action', 'create_subscription');
            formData.append('user_id', userResult.user.id);
            
            try {
                const response = await fetch('/api/subscriptions.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                
                if (result.success) {
                    showNotification('✅ Utilisateur abonné avec succès !', 'success');
                    closeModal('modal-subscribe-user');
                    e.target.reset();
                    loadSubscriptions();
                } else {
                    showNotification('❌ ' + result.error, 'error');
                }
            } catch (error) {
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        });

        // Supprimer un plan
        async function deletePlan(planId) {
            if (!confirm('Êtes-vous sûr de vouloir supprimer ce plan ?')) return;
            
            const formData = new FormData();
            formData.append('action', 'delete_plan');
            formData.append('plan_id', planId);
            
            try {
                const response = await fetch('/api/subscriptions.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                
                if (result.success) {
                    showNotification('✅ Plan supprimé', 'success');
                    loadPlans();
                } else {
                    showNotification('❌ ' + result.error, 'error');
                }
            } catch (error) {
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        }

        // Gérer un abonnement
        function manageSubscription(subId) {
            window.location.href = `/addons/subscriptions/admin/dashboard.php?subscription=${subId}`;
        }

        // Notification
        function showNotification(message, type) {
            const notification = document.getElementById('notification');
            const colors = {
                success: 'border-green-500 bg-green-50 text-green-800',
                error: 'border-red-500 bg-red-50 text-red-800',
                info: 'border-blue-500 bg-blue-50 text-blue-800'
            };
            
            notification.className = `fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50 ${colors[type]}`;
            notification.textContent = message;
            notification.classList.remove('hidden');
            
            setTimeout(() => notification.classList.add('hidden'), 5000);
        }

        function editPlan(planId) {
            showNotification('✏️ Fonction d\'édition à venir', 'info');
        }
    </script>
</body>
</html>
