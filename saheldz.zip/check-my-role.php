<?php
/**
 * Page de diagnostic - Voir mon rôle actuel
 */
require_once 'config/auth-check.php';
require_once 'config/database.php';

$pdo = getDB();

// Récupérer les informations complètes de l'utilisateur
$stmt = $pdo->prepare("
    SELECT u.*, r.id as role_id, r.name as role_name, r.display_name as role_display
    FROM users u
    LEFT JOIN roles r ON u.role_id = r.id
    WHERE u.id = ?
");
$stmt->execute([$GLOBALS['current_user']['id']]);
$userInfo = $stmt->fetch();

// Récupérer tous les rôles disponibles
$stmt = $pdo->query("SELECT * FROM roles ORDER BY id");
$allRoles = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diagnostic Rôle - DigiServices</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="max-w-4xl mx-auto px-4 py-8">
        <div class="bg-white rounded-xl shadow-lg p-8">
            <h1 class="text-3xl font-bold text-gray-800 mb-6">🔍 Diagnostic de Rôle</h1>
            
            <!-- Informations utilisateur -->
            <div class="bg-blue-50 border-l-4 border-blue-500 p-6 mb-6 rounded">
                <h2 class="text-xl font-bold text-gray-800 mb-4">👤 Vos Informations</h2>
                <div class="space-y-2">
                    <p><strong>ID:</strong> <?php echo $userInfo['id']; ?></p>
                    <p><strong>Nom:</strong> <?php echo htmlspecialchars($userInfo['full_name']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($userInfo['email']); ?></p>
                    <p><strong>Role ID:</strong> <?php echo $userInfo['role_id'] ?? 'NULL'; ?></p>
                    <p><strong>Role Name:</strong> <span class="text-2xl font-bold text-blue-600"><?php echo $userInfo['role_name'] ?? 'AUCUN RÔLE'; ?></span></p>
                    <p><strong>Role Display:</strong> <?php echo $userInfo['role_display'] ?? 'N/A'; ?></p>
                </div>
            </div>
            
            <!-- Redirection attendue -->
            <div class="bg-<?php echo $userInfo['role_name'] ? 'green' : 'yellow'; ?>-50 border-l-4 border-<?php echo $userInfo['role_name'] ? 'green' : 'yellow'; ?>-500 p-6 mb-6 rounded">
                <h2 class="text-xl font-bold text-gray-800 mb-4">🎯 Redirection Attendue</h2>
                <?php
                $role = $userInfo['role_name'];
                if ($role === 'super_admin' || $role === 'admin') {
                    echo '<p class="text-lg">Vous devriez être redirigé vers: <strong class="text-blue-600">/admin-dashboard.php</strong></p>';
                } elseif ($role === 'employee') {
                    echo '<p class="text-lg">Vous devriez être redirigé vers: <strong class="text-indigo-600">/employee-dashboard.php</strong></p>';
                } elseif ($role === 'client') {
                    echo '<p class="text-lg">Vous devriez être redirigé vers: <strong class="text-green-600">/html/1a.php</strong></p>';
                } else {
                    echo '<p class="text-lg text-yellow-600">⚠️ Aucun rôle valide - Sera assigné au rôle "client" automatiquement</p>';
                }
                ?>
            </div>
            
            <!-- Tous les rôles -->
            <div class="bg-gray-50 border-l-4 border-gray-500 p-6 mb-6 rounded">
                <h2 class="text-xl font-bold text-gray-800 mb-4">📋 Rôles Disponibles</h2>
                <div class="space-y-2">
                    <?php foreach ($allRoles as $role): ?>
                        <div class="flex items-center gap-2">
                            <span class="<?php echo $role['id'] == $userInfo['role_id'] ? 'text-green-600 font-bold' : 'text-gray-600'; ?>">
                                <?php echo $role['id'] == $userInfo['role_id'] ? '✓' : '○'; ?>
                                ID <?php echo $role['id']; ?>: <?php echo $role['display_name']; ?> (<?php echo $role['name']; ?>)
                            </span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- Actions -->
            <div class="grid grid-cols-2 gap-4">
                <a href="/index.php" class="bg-blue-600 text-white py-3 px-6 rounded-lg text-center font-bold hover:bg-blue-700">
                    🔄 Aller à l'Accueil
                </a>
                <a href="/admin-users.php" class="bg-purple-600 text-white py-3 px-6 rounded-lg text-center font-bold hover:bg-purple-700">
                    👥 Gérer les Utilisateurs
                </a>
            </div>
        </div>
    </div>
</body>
</html>
