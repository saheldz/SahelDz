<?php
/**
 * Recréer la table orders avec les bonnes colonnes
 */

require_once 'config/database.php';

$pdo = getDB();

echo "=== CORRECTION TABLE ORDERS ===\n\n";

try {
    // Disable foreign key checks
    echo "🔓 Désactivation des contraintes de clés étrangères...\n";
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
    
    // Drop related tables first
    echo "📝 Suppression des tables dépendantes...\n";
    $pdo->exec("DROP TABLE IF EXISTS order_files");
    $pdo->exec("DROP TABLE IF EXISTS order_messages");
    $pdo->exec("DROP TABLE IF EXISTS product_downloads");
    echo "✅ Tables dépendantes supprimées\n\n";
    
    // Drop and recreate orders table
    echo "📝 Suppression de l'ancienne table orders...\n";
    $pdo->exec("DROP TABLE IF EXISTS orders");
    
    echo "✅ Ancienne table supprimée\n\n";
    
    echo "📝 Création de la nouvelle table orders...\n";
    
    $sql = "CREATE TABLE orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        item_id INT NOT NULL,
        order_number VARCHAR(50) NOT NULL UNIQUE,
        item_name VARCHAR(255) NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        status ENUM('pending', 'processing', 'completed', 'cancelled') DEFAULT 'pending',
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_user (user_id),
        INDEX idx_item (item_id),
        INDEX idx_status (status),
        INDEX idx_order_number (order_number)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $pdo->exec($sql);
    echo "✅ Table orders créée avec succès\n\n";
    
    // Verify
    echo "📋 Vérification des colonnes créées...\n";
    $stmt = $pdo->query("DESCRIBE orders");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($columns as $col) {
        echo "  ✓ {$col['Field']} ({$col['Type']})\n";
    }
    
    // Recreate dependent tables
    echo "\n📝 Recréation des tables dépendantes...\n";
    
    $pdo->exec("CREATE TABLE order_files (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        file_name VARCHAR(255) NOT NULL,
        file_path VARCHAR(500) NOT NULL,
        file_size INT,
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
        INDEX idx_order (order_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    $pdo->exec("CREATE TABLE order_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        user_id INT NOT NULL,
        message TEXT NOT NULL,
        is_client TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
        INDEX idx_order (order_id),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    $pdo->exec("CREATE TABLE product_downloads (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        item_id INT NOT NULL,
        download_token VARCHAR(100) NOT NULL UNIQUE,
        download_count INT DEFAULT 0,
        expires_at TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
        INDEX idx_order (order_id),
        INDEX idx_token (download_token)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    
    echo "✅ Tables dépendantes recréées\n\n";
    
    // Re-enable foreign key checks
    echo "🔒 Réactivation des contraintes de clés étrangères...\n";
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
    
    echo "\n✅ TOUT EST PRÊT !\n\n";
    echo "Maintenant vous pouvez créer des commandes sans erreur ! 🎉\n";
    
} catch (PDOException $e) {
    echo "❌ ERREUR: " . $e->getMessage() . "\n";
}
