<?php
/**
 * Installation des tables pour la boutique Services & Produits
 */

require_once 'config/database.php';

try {
    $pdo = getDB();
    
    echo "🛍️ Installation des tables de la boutique...\n\n";

    // Table orders
    echo "📦 Création de la table 'orders'...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            type ENUM('service', 'product') NOT NULL,
            item_id VARCHAR(100) NOT NULL,
            item_name VARCHAR(255) NOT NULL,
            price DECIMAL(10,2) NOT NULL,
            status ENUM('pending', 'processing', 'completed', 'cancelled') DEFAULT 'pending',
            description TEXT,
            assigned_to INT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            completed_at TIMESTAMP NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_user_id (user_id),
            INDEX idx_status (status),
            INDEX idx_type (type),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✅ Table 'orders' créée\n\n";

    // Table product_downloads
    echo "📥 Création de la table 'product_downloads'...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS product_downloads (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            product_id VARCHAR(100) NOT NULL,
            download_token VARCHAR(64) UNIQUE NOT NULL,
            download_count INT DEFAULT 0,
            max_downloads INT DEFAULT 10,
            expires_at TIMESTAMP NULL,
            last_download_at TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            INDEX idx_token (download_token),
            INDEX idx_order (order_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✅ Table 'product_downloads' créée\n\n";

    // Table order_files (pour stocker les fichiers livrés pour les services)
    echo "📁 Création de la table 'order_files'...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS order_files (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            file_name VARCHAR(255) NOT NULL,
            file_path VARCHAR(500) NOT NULL,
            file_type VARCHAR(50),
            file_size INT,
            uploaded_by INT NOT NULL,
            is_final BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_order (order_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✅ Table 'order_files' créée\n\n";

    // Table order_messages (pour la communication client-employé)
    echo "💬 Création de la table 'order_messages'...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS order_messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            user_id INT NOT NULL,
            message_type ENUM('text', 'voice', 'image', 'file') DEFAULT 'text',
            message TEXT,
            file_path VARCHAR(500),
            file_name VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_order (order_id),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✅ Table 'order_messages' créée\n\n";

    echo "✅ Installation terminée avec succès !\n\n";
    echo "📊 Tables créées :\n";
    echo "   - orders (commandes de services et produits)\n";
    echo "   - product_downloads (liens de téléchargement)\n";
    echo "   - order_files (fichiers livrés)\n";
    echo "   - order_messages (communication client-employé)\n\n";

} catch (PDOException $e) {
    echo "❌ Erreur : " . $e->getMessage() . "\n";
    exit(1);
}
