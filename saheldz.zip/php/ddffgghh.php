<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendrier de progression</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .progress-container {
            height: 12px;
            background-color: #e5e7eb;
            border-radius: 6px;
            overflow: hidden;
        }
        .progress-bar {
            height: 100%;
            border-radius: 6px;
            transition: width 0.5s ease-in-out;
        }
        .calendar-day {
            min-width: 36px;
            transition: all 0.2s ease;
        }
        .calendar-day:hover {
            transform: translateY(-3px);
        }
        .calendar-container {
            scrollbar-width: thin;
            scrollbar-color: #cbd5e0 #f1f5f9;
        }
        .calendar-container::-webkit-scrollbar {
            height: 6px;
        }
        .calendar-container::-webkit-scrollbar-track {
            background: #f1f5f9;
        }
        .calendar-container::-webkit-scrollbar-thumb {
            background-color: #cbd5e0;
            border-radius: 6px;
        }
        .week-container {
            background-color: white;
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        .week-container:hover {
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }
        .week-label {
            background: linear-gradient(to right, #6366f1, #8b5cf6);
            color: white;
            border-radius: 0.5rem 0.5rem 0 0;
            font-weight: 600;
            text-align: center;
            padding: 0.25rem 0;
            font-size: 0.875rem;
        }
        .week-total {
            background-color: #f3f4f6;
            border-radius: 0 0 0.5rem 0.5rem;
            text-align: center;
            padding: 0.25rem 0;
            font-weight: 500;
            font-size: 0.875rem;
        }
        .current-day {
            position: relative;
        }
        .current-day::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 50%;
            transform: translateX(-50%);
            width: 6px;
            height: 6px;
            background-color: #3b82f6;
            border-radius: 50%;
        }
        .day-capsule {
            background-color: #f9fafb;
            border-radius: 0.5rem;
            margin: 0.15rem;
            padding: 0.25rem;
            transition: all 0.2s ease;
            transform-origin: center;
            box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        }
        .day-capsule:hover {
            transform: scale(1.08);
            background-color: #f3f4f6;
            box-shadow: 0 3px 6px rgba(0,0,0,0.1);
            z-index: 10;
        }
    </style>
</head>
<body class="bg-gray-50 p-4">
    <div class="max-w-3xl mx-auto">
        <!-- Calendrier horizontal -->
        <div class="card p-6 mb-6 bg-white rounded-lg shadow">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold">📅 Calendrier du mois</h2>
                <div id="monthly-total" class="text-sm font-medium bg-gradient-to-r from-green-400 to-emerald-600 text-white px-3 py-1 rounded-full"></div>
            </div>
            
            <div class="grid grid-cols-4 gap-4">
                <!-- 4 semaines fixes -->
                <div class="week-container">
                    <div class="week-label">Semaine 1</div>
                    <div id="week1" class="grid grid-cols-7 text-center"></div>
                    <div id="week1-total" class="week-total">Total: 0€</div>
                </div>
                
                <div class="week-container">
                    <div class="week-label">Semaine 2</div>
                    <div id="week2" class="grid grid-cols-7 text-center"></div>
                    <div id="week2-total" class="week-total">Total: 0€</div>
                </div>
                
                <div class="week-container">
                    <div class="week-label">Semaine 3</div>
                    <div id="week3" class="grid grid-cols-7 text-center"></div>
                    <div id="week3-total" class="week-total">Total: 0€</div>
                </div>
                
                <div class="week-container">
                    <div class="week-label">Semaine 4</div>
                    <div id="week4" class="grid grid-cols-7 text-center"></div>
                    <div id="week4-total" class="week-total">Total: 0€</div>
                </div>
            </div>
            
            <div class="mt-4 text-center">
                <div id="motivation-message" class="text-sm font-medium text-indigo-600"></div>
            </div>
        </div>

        <div class="card p-6 mb-6 bg-white rounded-lg shadow">
            <h2 class="text-xl font-bold mb-4">📊 Progression des objectifs</h2>
            
            <div class="space-y-6">
                <!-- Today's Progress -->
                <div>
                    <div class="flex justify-between items-center mb-2">
                        <h3 class="font-semibold">Aujourd'hui</h3>
                        <span id="today-progress" class="text-sm font-medium"></span>
                    </div>
                    <div class="relative progress-container">
                        <div id="today-progress-bar" class="progress-bar bg-gradient-to-r from-green-400 to-emerald-600"></div>
                        <!-- Milestones will be added dynamically -->
                    </div>
                </div>
                
                <!-- This Week's Progress -->
                <div>
                    <div class="flex justify-between items-center mb-2">
                        <h3 class="font-semibold">Cette semaine</h3>
                        <span id="week-progress" class="text-sm font-medium"></span>
                    </div>
                    <div class="relative progress-container">
                        <div id="week-progress-bar" class="progress-bar bg-gradient-to-r from-blue-400 to-indigo-600"></div>
                        <!-- Milestones will be added dynamically -->
                    </div>
                </div>
                
                <!-- This Month's Progress -->
                <div>
                    <div class="flex justify-between items-center mb-2">
                        <h3 class="font-semibold">Ce mois</h3>
                        <span id="month-progress" class="text-sm font-medium"></span>
                    </div>
                    <div class="relative progress-container">
                        <div id="month-progress-bar" class="progress-bar bg-gradient-to-r from-purple-400 to-fuchsia-600"></div>
                        <!-- Milestones will be added dynamically -->
                    </div>
                </div>
                
                <!-- This Year's Progress -->
                <div>
                    <div class="flex justify-between items-center mb-2">
                        <h3 class="font-semibold">Cette année</h3>
                        <span id="year-progress" class="text-sm font-medium"></span>
                    </div>
                    <div class="relative progress-container">
                        <div id="year-progress-bar" class="progress-bar bg-gradient-to-r from-rose-400 to-red-600"></div>
                        <!-- Milestones will be added dynamically -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Générer le calendrier du mois
            generateSimplifiedCalendar();
            
            // Initialiser les barres de progression
            updateProgressBars();
            
            // Afficher un message motivant
            displayMotivationalMessage();
        });

        function generateSimplifiedCalendar() {
            const today = new Date();
            const currentMonth = today.getMonth();
            const currentYear = today.getFullYear();
            
            // Déterminer le nombre de jours dans le mois actuel
            const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
            
            // Générer des données fictives pour les montants gagnés
            const dailyEarnings = generateDailyEarnings(daysInMonth);
            
            // Calculer le total mensuel
            const monthlyTotal = dailyEarnings.reduce((sum, amount) => sum + amount, 0);
            document.getElementById('monthly-total').textContent = `Total: ${monthlyTotal}€`;
            
            // Jours de la semaine
            const weekdayNames = ['Lu', 'Ma', 'Me', 'Je', 'Ve', 'Sa', 'Di'];
            
            // Diviser le mois en 4 semaines exactement
            // Calculer le nombre de jours par semaine (arrondi)
            const daysPerWeek = Math.ceil(daysInMonth / 4);
            
            // Créer 4 semaines
            for (let weekIndex = 0; weekIndex < 4; weekIndex++) {
                const weekContainer = document.getElementById(`week${weekIndex + 1}`);
                let weekTotal = 0;
                
                // Ajouter les en-têtes des jours de la semaine
                weekdayNames.forEach(dayName => {
                    const dayHeader = document.createElement('div');
                    dayHeader.className = 'text-xs text-gray-500 py-1';
                    dayHeader.textContent = dayName;
                    weekContainer.appendChild(dayHeader);
                });
                
                // Calculer les jours pour cette semaine
                const startDay = weekIndex * daysPerWeek + 1;
                const endDay = Math.min(daysInMonth, (weekIndex + 1) * daysPerWeek);
                
                // Créer un tableau pour les jours de cette semaine
                const weekDays = [];
                for (let day = startDay; day <= endDay; day++) {
                    weekDays.push(day);
                }
                
                // Ajouter des espaces vides au début si nécessaire pour aligner sur les jours de la semaine
                if (weekIndex === 0) {
                    const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
                    const firstDayIndex = firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1; // Convertir en format lundi=0, dimanche=6
                    
                    for (let i = 0; i < firstDayIndex; i++) {
                        weekDays.unshift(null); // Ajouter des jours vides au début
                    }
                }
                
                // S'assurer qu'il y a exactement 7 jours dans la semaine
                while (weekDays.length < 7) {
                    weekDays.push(null); // Ajouter des jours vides à la fin
                }
                while (weekDays.length > 7) {
                    weekDays.pop(); // Supprimer les jours excédentaires
                }
                
                // Ajouter les jours à la semaine
                weekDays.forEach(day => {
                    if (day === null) {
                        // Jour vide
                        const emptyDay = document.createElement('div');
                        emptyDay.className = 'day-capsule opacity-30';
                        emptyDay.innerHTML = '<div class="text-xs text-center">-</div>';
                        weekContainer.appendChild(emptyDay);
                    } else {
                        const date = new Date(currentYear, currentMonth, day);
                        const isPast = date < new Date(today.setHours(0, 0, 0, 0));
                        const isToday = day === today.getDate();
                        const amount = dailyEarnings[day - 1];
                        
                        if (isPast && amount > 0) {
                            weekTotal += amount;
                        }
                        
                        const dayElement = document.createElement('div');
                        dayElement.className = `day-capsule ${isToday ? 'ring-2 ring-blue-500' : ''} ${isPast ? 'bg-gray-100' : 'bg-white'}`;
                        
                        // Numéro du jour
                        const dayNumberElement = document.createElement('div');
                        dayNumberElement.className = `text-sm font-medium ${isToday ? 'current-day text-blue-600' : ''}`;
                        dayNumberElement.textContent = day;
                        
                        // Indicateur de jour passé
                        const checkElement = document.createElement('div');
                        if (isPast) {
                            // Ajouter des indicateurs visuels basés sur le montant
                            if (amount > 100) {
                                checkElement.className = 'text-amber-500 font-bold text-xs';
                                checkElement.innerHTML = '🌟';
                            } else if (amount > 50) {
                                checkElement.className = 'text-green-500 font-bold text-xs';
                                checkElement.innerHTML = '✓✓';
                            } else if (amount > 0) {
                                checkElement.className = 'text-green-500 font-bold text-xs';
                                checkElement.innerHTML = '✓';
                            } else {
                                checkElement.className = 'text-gray-400 text-xs';
                                checkElement.innerHTML = '✗';
                            }
                        } else {
                            checkElement.className = 'text-transparent text-xs';
                            checkElement.innerHTML = '·';
                        }
                        
                        // Montant gagné avec code couleur
                        const amountElement = document.createElement('div');
                        amountElement.className = `text-xs ${getAmountColorClass(amount)}`;
                        amountElement.textContent = amount > 0 ? `${amount}€` : '-';
                        
                        // Assembler les éléments
                        dayElement.appendChild(dayNumberElement);
                        dayElement.appendChild(checkElement);
                        dayElement.appendChild(amountElement);
                        
                        weekContainer.appendChild(dayElement);
                    }
                });
                
                // Mettre à jour le total de la semaine
                document.getElementById(`week${weekIndex + 1}-total`).textContent = `Total: ${weekTotal}€`;
            }
            
            // Mettre en évidence la semaine actuelle
            const currentWeekIndex = Math.min(3, Math.floor((today.getDate() - 1) / daysPerWeek));
            const currentWeekElement = document.querySelector(`.week-container:nth-child(${currentWeekIndex + 1})`);
            currentWeekElement.classList.add('ring-2', 'ring-blue-500');
        }
        
        function getAmountColorClass(amount) {
            if (amount > 100) return 'text-amber-500 font-bold';
            if (amount > 75) return 'text-green-600';
            if (amount > 50) return 'text-green-500';
            if (amount > 30) return 'text-blue-500';
            return 'text-gray-600';
        }
        
        function generateDailyEarnings(days) {
            // Générer des montants aléatoires pour chaque jour
            const earnings = [];
            let previousAmount = 50; // Commencer avec un montant moyen
            
            for (let i = 0; i < days; i++) {
                // Créer une tendance avec une variation de ±30% par rapport au jour précédent
                const variation = (Math.random() * 0.6) - 0.3; // Entre -0.3 et +0.3
                let amount = Math.round(previousAmount * (1 + variation));
                
                // Ajouter des pics occasionnels pour plus de motivation
                if (Math.random() < 0.15) { // 15% de chance d'avoir un jour exceptionnel
                    amount = Math.round(amount * (1.5 + Math.random()));
                }
                
                // Assurer un minimum et un maximum raisonnables
                amount = Math.max(20, Math.min(150, amount));
                
                // Pour les jours futurs, mettre à zéro
                const today = new Date();
                if (i >= today.getDate()) {
                    amount = 0;
                }
                
                earnings.push(amount);
                previousAmount = amount;
            }
            return earnings;
        }
        
        function updateProgressBars() {
            // Simuler des données de progression
            const today = new Date();
            
            // Progression journalière (heure actuelle / 24h)
            const hourProgress = today.getHours() / 24 * 100;
            document.getElementById('today-progress-bar').style.width = `${hourProgress}%`;
            document.getElementById('today-progress').textContent = `${Math.round(hourProgress)}%`;
            
            // Progression hebdomadaire (jour de la semaine / 7)
            const dayOfWeek = today.getDay() || 7; // 0 = dimanche, donc on le transforme en 7
            const weekProgress = dayOfWeek / 7 * 100;
            document.getElementById('week-progress-bar').style.width = `${weekProgress}%`;
            document.getElementById('week-progress').textContent = `${Math.round(weekProgress)}%`;
            
            // Progression mensuelle (jour du mois / jours dans le mois)
            const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
            const monthProgress = today.getDate() / daysInMonth * 100;
            document.getElementById('month-progress-bar').style.width = `${monthProgress}%`;
            document.getElementById('month-progress').textContent = `${Math.round(monthProgress)}%`;
            
            // Progression annuelle (jour de l'année / 365 ou 366)
            const start = new Date(today.getFullYear(), 0, 0);
            const diff = today - start;
            const oneDay = 1000 * 60 * 60 * 24;
            const dayOfYear = Math.floor(diff / oneDay);
            const daysInYear = new Date(today.getFullYear(), 11, 31).getDate() === 31 ? 365 : 366;
            const yearProgress = dayOfYear / daysInYear * 100;
            document.getElementById('year-progress-bar').style.width = `${yearProgress}%`;
            document.getElementById('year-progress').textContent = `${Math.round(yearProgress)}%`;
        }
        
        function displayMotivationalMessage() {
            const messages = [
                "Continuez comme ça ! Chaque semaine vous rapproche de vos objectifs 💪",
                "Vous êtes sur la bonne voie ! Concentrez-vous sur une semaine à la fois 🚀",
                "Votre constance paie, gardez le rythme ! ✨",
                "Bravo pour votre progression ! Une semaine après l'autre 🎯",
                "Petit à petit, l'oiseau fait son nid ! 🌟"
            ];
            
            const messageElement = document.getElementById('motivation-message');
            const randomIndex = Math.floor(Math.random() * messages.length);
            messageElement.textContent = messages[randomIndex];
        }
    </script>
<script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'94ec3b9695fba96c',t:'MTc0OTc2MTU1NS4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>
</html>