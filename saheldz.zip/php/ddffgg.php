@php

$logo=\App\Models\Utility::get_file('uploads/logo/');
$profile=\App\Models\Utility::get_file('uploads/profile/');
$logo1=\App\Models\Utility::get_file('uploads/is_cover_image/');
$setting = App\Models\Utility::settings();
$company_logo = \App\Models\Utility::getValByName('company_logo');
@endphp

@extends('layouts.admin')
@section('page-title')
    {{ __('Dashboard') }}
@endsection

@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('dashboard') }}">{{__('Home')}}</a></li>
@endsection
@push('script-page')
    <script>
        var timezone = '{{ !empty($setting['timezone']) ? $setting['timezone'] : 'Asia/Kolkata' }}';

        let today = new Date(new Date().toLocaleString("en-US", {
            timeZone: timezone
        }));
        var curHr = today.getHours()
        var target = document.getElementById("greetings");

        if (curHr < 12) {
            target.innerHTML = "Good Morning,";
        } else if (curHr < 17) {
            target.innerHTML = "Good Afternoon,";
        } else {
            target.innerHTML = "Good Evening,";
        }

    </script>
    <script>
        $(document).on('click', '#code-generate', function() {
            var length = 10;
            var result = '';
            var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            var charactersLength = characters.length;
            for (var i = 0; i < length; i++) {
                result += characters.charAt(Math.floor(Math.random() * charactersLength));
            }
            $('#auto-code').val(result);
        });
    </script>
@endpush
@section('content')
@if (\Auth::user()->type == 'super admin')
<div class="row">
    <!-- [ sample-page ] start -->
    <div class="col-sm-12">
        <div class="row">
            <div class="col-xxl-6">
                <div class="row">
                    <div class="col-lg-4 col-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="theme-avtar bg-primary">
                                    <i class="fas fa-cube"></i>
                                </div>
                                <h6 class="mb-3 mt-4 ">{{ __('Total Store') }}</h6>
                                <h3 class="mb-0">{{ $user->total_user }}</h3>
                                {{-- <h6 class="mb-3 mt-4 ">{{ __('Paid Store') }}</h6>
                                <h3 class="mb-0">{{ $user['total_paid_user'] }}</h3> --}}
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="theme-avtar bg-warning">
                                    <i class="fas fa-cart-plus"></i>
                                </div>
                                <h6 class="mb-3 mt-4 ">{{ __('Total Orders') }}</h6>
                                <h3 class="mb-0">{{ $user->total_orders }}</h3>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="theme-avtar bg-danger">
                                    <i class="fas fa-shopping-bag"></i>
                                </div>
                                <h6 class="mb-3 mt-4 ">{{ __('Total Plans') }}</h6>
                                <h3 class="mb-0">{{ $user['total_plan'] }}</h3>
                                {{-- <h6 class="mb-3 mt-4 ">{{ __('Most Purchase Plan') }}</h6>
                                <h3 class="mb-0">
                                    {{ !empty($user['most_purchese_plan']) ? $user['most_purchese_plan'] : '-' }}</h3> --}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xxl-6">
                <div class="card">
                    <div class="card-header">
                        <h5>{{ __('Recent Orders') }}</h5>
                    </div>
                    <div class="card-body">
                        <div id="plan_order" data-color="primary" data-height="230"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- [ sample-page ] end -->
</div>
@else
<!-- [ Main Content ] start -->
<div class="row">
    <!-- [ sample-page ] start -->
    <div class="col-sm-12">
        <div class="row mb-5 gy-4">
            <div class="col-lg-4">
                <div class="welcome-card border bg-light-primary p-3 border-primary rounded text-dark h-100">
                    <div class="d-flex align-items-center mb-4">
                        <div class="me-2">
                            <img src="{{ !empty($users->avatar) ? $profile . '/' . $users->avatar : $profile . '/avatar.png' }}" alt="" class="theme-avtar">
                        </div>
                        <div>
                            <h5 class="mb-0">
                                <span class="d-block text-primary" id="greetings"></span>
                                <b class="f-w-700 text-primary">{{ __(Auth::user()->name) }}</b>
                            </h5>
                        </div>
                    </div>
                    <p class="mb-0 text-primary">{{ __('Have a nice day! Did you know that you can quickly add your favorite product or category to the store?') }}</p>
                    <div class="btn-group mt-4">
                        <button class="btn  btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <i data-feather="plus" class="me-2"></i>
                            {{ __('Quick add') }}</button>
                        <div class="dropdown-menu">
                            @can('Create Products')
                                <a class="dropdown-item" href="{{ route('product.create') }}">{{ __('Add new product') }}</a>
                            @endcan
                            @can('Create Product Tax')
                                <a href="#" data-size="md" data-url="{{ route('product_tax.create') }}" data-ajax-popup="true" data-title="{{ __('Create New Product Tax') }}" class="dropdown-item" data-bs-placement="top ">
                                    <span>{{ __('Add new product tax') }}</span>
                                </a>
                            @endcan
                            @can('Create Product category')
                                <a href="#" data-size="md" data-url="{{ route('product_categorie.create') }}" data-ajax-popup="true" data-title="{{ __('Create New Product Category') }}" class="dropdown-item" data-bs-placement="top">
                                    <span>{{ __('Add new product category') }}</span>
                                </a>
                            @endcan
                            @can('Create Product Coupan')
                                <a href="#" data-size="md" data-url="{{ route('product-coupon.create') }}" data-ajax-popup="true" data-title="{{ __('Create New Product Coupon') }}" class="dropdown-item" data-bs-placement="top ">
                                    <span>{{ __('Add new product coupon') }}</span>
                                </a>
                            @endcan
                        </div>
                    </div>
                </div>
            </div>
            






            <div class="col-lg-8">
                <div class="row gy-4">
                    <div class="col-xl-3 col-lg-6 col-sm-6">
                        <div class="card shadow-none mb-0">
                            <div class="card-body border rounded  p-3">
                                <div class="mb-4 d-flex align-items-center justify-content-between">
                                    <h6 class="mb-0">{{ $store_id->name }}</h6>
                                    <span>
                                        <i data-feather="arrow-up-right"></i>
                                    </span>
                                </div>
                                <div class="mb-4 qrcode">
                                    {!! QrCode::generate($store_id['store_url']) !!}
                                </div>
                                <a href="#!" class="btn btn-light-primary w-100 cp_link" data-link="{{  $store_id['store_url'] }}" data-bs-toggle="tooltip" data-bs-placement="top" title="{{ __('Click to copy Store link') }}">
                                    {{ __('Store Link') }}
                                    <i class="ms-3"data-feather="copy"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-sm-6">
                        <div class="card shadow-none mb-0">
                            <div class="card-body border rounded  p-3">
                                <div class="mb-3 d-flex align-items-center justify-content-between">
                                    <h6 class="mb-0">{{ __('Total Products') }}</h6>
                                    <span>
                                        <i data-feather="arrow-up-right"></i>
                                    </span>
                                </div>
                                <div class="mb-3 d-flex align-items-center justify-content-between">
                                    <span class="f-30 f-w-600">{{ $newproduct }}</span>
                                </div>
                                <div class="chart-wrapper">
                                    <div id="TotalProducts" class="remove-min"></div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-sm-6">
                        <div class="card shadow-none mb-0">
                            <div class="card-body border rounded  p-3">
                                <div class="mb-3 d-flex align-items-center justify-content-between">
                                    <h6 class="mb-0">{{ __('Total Sales') }}</h6>
                                    <span>
                                        <i data-feather="arrow-up-right"></i>
                                    </span>
                                </div>
                                <div class="mb-3 d-flex align-items-center justify-content-between">
                                    <span class="f-30 f-w-600" style=" word-break: break-word; ">{{ \App\Models\Utility::priceFormat($totle_sale) }}</span>
                                </div>
                                <div class="chart-wrapper">
                                    <div id="TotalSales" class="remove-min"></div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-sm-6">
                        <div class="card shadow-none mb-0">
                            <div class="card-body border rounded  p-3">
                                <div class="mb-3 d-flex align-items-center justify-content-between">
                                    <h6 class="mb-0">{{ __('Total Orders') }}</h6>
                                    <span>
                                        <i data-feather="arrow-up-right"></i>
                                    </span>
                                </div>
                                <div class="mb-3 d-flex align-items-center justify-content-between">
                                    <span class="f-30 f-w-600">{{ $totle_order }}</span>
                                </div>
                                <div class="chart-wrapper">
                                    <div id="TotalOrders" class="remove-min"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            
            <!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RISE CRM - Tableau de Bord des Ventes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4f46e5;
            --primary-light: #818cf8;
            --primary-dark: #3730a3;
            --secondary: #06b6d4;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --dark: #1e293b;
            --light: #f8fafc;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f1f5f9;
            color: #334155;
        }
        
        .dashboard-container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .card {
            background-color: white;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
        }
        
        .card:hover {
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
        }
        
        .progress-container {
            height: 12px;
            background-color: #e2e8f0;
            border-radius: 6px;
            overflow: hidden;
            position: relative;
        }
        
        .progress-bar {
            height: 100%;
            border-radius: 6px;
            transition: width 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
        
        .milestone {
            position: absolute;
            top: -4px;
            width: 4px;
            height: 20px;
            background-color: rgba(0, 0, 0, 0.3);
            z-index: 2;
        }
        
        .milestone-label {
            position: absolute;
            top: -25px;
            transform: translateX(-50%);
            font-size: 10px;
            color: #64748b;
            font-weight: 600;
        }
        
        .product-card {
            border-radius: 12px;
            transition: transform 0.2s, box-shadow 0.2s;
            overflow: hidden;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 20px rgba(0, 0, 0, 0.1);
        }
        
        .product-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 18px;
        }
        
        .tab-active {
            color: var(--primary);
            border-bottom: 3px solid var(--primary);
            font-weight: 600;
        }
        
        .trophy {
            position: absolute;
            width: 30px;
            height: 30px;
            background-color: #fbbf24;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transform: translateY(-50%);
            z-index: 10;
        }
        
        .locked {
            filter: grayscale(1);
            opacity: 0.7;
        }
        
        .objective-meter {
            height: 24px;
            background: linear-gradient(to right, #4ade80, #3b82f6, #8b5cf6, #ec4899);
            border-radius: 12px;
            position: relative;
            overflow: hidden;
        }
        
        .objective-marker {
            position: absolute;
            width: 4px;
            height: 24px;
            background-color: white;
            top: 0;
            z-index: 2;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }
        
        .objective-current {
            position: absolute;
            width: 12px;
            height: 30px;
            background-color: white;
            top: -3px;
            border-radius: 3px;
            z-index: 3;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }
        
        .sales-history-item {
            transition: background-color 0.2s;
        }
        
        .sales-history-item:hover {
            background-color: #f8fafc;
        }
        
        .delete-btn {
            opacity: 0;
            transition: opacity 0.2s;
        }
        
        .sales-history-item:hover .delete-btn {
            opacity: 1;
        }
        
        .icon-selector {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 8px;
        }
        
        .icon-option {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: transform 0.2s;
        }
        
        .icon-option:hover {
            transform: scale(1.1);
        }
        
        .icon-option.selected {
            box-shadow: 0 0 0 2px white, 0 0 0 4px var(--primary);
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .pulse-animation {
            animation: pulse 1.5s infinite;
        }
        
        .tooltip {
            position: relative;
        }
        
        .tooltip:hover::after {
            content: attr(data-tooltip);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            background-color: #334155;
            color: white;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            white-space: nowrap;
            z-index: 10;
        }
    </style>
</head>
<body class="py-6">

        <!-- Header with status message -->
        <div class="flex items-center justify-between mb-6">
            
            <div id="status-message" class="px-6 py-3 rounded-full text-white font-semibold"></div>
        </div>
        
        <!-- Objective Meter (Gamified) -->
        <div class="card p-6 mb-6 bg-white rounded shadow">
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-bold">🎯 Objectifomètre</h2>
        <div class="flex items-center space-x-2">
            <span class="text-sm font-medium">Objectif Mensuel:</span>
            <input id="goalInput" type="number" placeholder="10000000" value="10000000" class="w-32 px-2 py-1 border rounded text-right text-indigo-600 font-bold" />
            <button onclick="updateGoal()" class="bg-indigo-600 text-white px-3 py-1 rounded hover:bg-indigo-700">✅</button>
        </div>
    </div>


<script>
    // Initialisation de l'objectif
    let currentGoal = 10000000; // Valeur par défaut
    let dailyGoal = Math.round(currentGoal / 30); // Objectif journalier par défaut

    // Fonction pour mettre à jour l'objectif
    function updateGoal() {
        const inputValue = document.getElementById('goalInput').value.trim();
        const newGoal = parseInt(inputValue);

        if (inputValue === '' || isNaN(newGoal) || newGoal <= 0) {
            alert('Veuillez entrer un montant valide.');
            return;
        }

        // Mettre à jour l'objectif
        currentGoal = newGoal;

        // Calculer l'objectif journalier (réparti sur 30 jours)
        const periodInDays = 30;
        dailyGoal = Math.round(currentGoal / periodInDays);

        // Mettre à jour le slider et l'affichage
        const dailyGoalSlider = document.getElementById('daily-goal-slider');
        if (dailyGoalSlider) {
            dailyGoalSlider.value = dailyGoal;
            const dailyGoalValue = document.getElementById('daily-goal-value');
            if (dailyGoalValue) {
                dailyGoalValue.textContent = formatCurrency(dailyGoal);
            }
        }

        console.log("Objectif final mis à jour:", currentGoal);
        console.log("Objectif journalier recalculé:", dailyGoal);

        // Sauvegarder
        saveGoals();

        // Mettre à jour le dashboard
        updateProgressBars();
        updateObjectiveMeter();
        updateStatusMessage();
        updateRecoveryPlan();
    }


</script>

            
            <div class="relative mb-8">
                <div class="objective-meter">
                    <!-- Milestones will be added dynamically -->
                </div>
                <div id="objective-current" class="objective-current"></div>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <div class="flex justify-between items-center mb-2">
                        <h3 class="font-semibold">Objectif global</h3>
                        <span id="global-progress" class="text-sm font-medium"></span>
                    </div>
                    <div class="progress-container">
                        <div id="global-progress-bar" class="progress-bar bg-gradient-to-r from-indigo-500 to-purple-600"></div>
                    </div>
                </div>
                
                <div>
                    <div class="flex justify-between items-center mb-2">
                        <h3 class="font-semibold">Objectif journalier</h3>
                        <div class="flex items-center">
    <span type="range" id="daily-goal-slider" min="0" max="100000" step="10000" class="w-32 mr-2"
        oninput="this.nextElementSibling.textContent = parseInt(this.value).toLocaleString('fr-FR') + ' DA';">
    <span id="daily-goal-value" class="text-sm font-medium text-indigo-600">DA</span>
</div>

                    </div>
                    <div class="progress-container">
                        <div id="daily-progress-bar" class="progress-bar bg-gradient-to-r from-cyan-500 to-blue-600"></div>
                    </div>
                </div>
            </div>
        </div>
        
       
        
        <!-- Progress Bars with Milestones -->
        <div class="card p-6 mb-6">
            <h2 class="text-xl font-bold mb-4">📊 Progression des objectifs</h2>
            
            <!-- Calendrier intégré depuis ddffgghh.php -->
            <div class="mb-6">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="mb-0">📅 {{ __('Calendrier du mois') }}</h5>
                    <div id="monthly-total" class="badge bg-success rounded-pill"></div>
                </div>
                
                <div class="row">
                    <!-- 4 semaines fixes -->
                    <div class="col-md-3">
                        <div class="week-container">
                            <div class="week-label">{{ __('Semaine 1') }}</div>
                            <div id="week1" class="d-grid" style="grid-template-columns: repeat(7, 1fr); text-align: center;"></div>
                            <div id="week1-total" class="week-total">Total: 0 DA</div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="week-container">
                            <div class="week-label">{{ __('Semaine 2') }}</div>
                            <div id="week2" class="d-grid" style="grid-template-columns: repeat(7, 1fr); text-align: center;"></div>
                            <div id="week2-total" class="week-total">Total: 0 DA</div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="week-container">
                            <div class="week-label">{{ __('Semaine 3') }}</div>
                            <div id="week3" class="d-grid" style="grid-template-columns: repeat(7, 1fr); text-align: center;"></div>
                            <div id="week3-total" class="week-total">Total: 0 DA</div>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="week-container">
                            <div class="week-label">{{ __('Semaine 4') }}</div>
                            <div id="week4" class="d-grid" style="grid-template-columns: repeat(7, 1fr); text-align: center;"></div>
                            <div id="week4-total" class="week-total">Total: 0 DA</div>
                        </div>
                    </div>
                </div>
                
                <div class="mt-3 text-center">
                    <div id="motivation-message" class="text-sm text-primary"></div>
                </div>
            </div>
            
            <div class="space-y-6">
                <!-- Today's Progress -->
                <div>
                    <div class="flex justify-between items-center mb-2">
                        <h3 class="font-semibold">Aujourd'hui</h3>
                        <span id="today-progress" class="text-sm font-medium"></span>
                    </div>
                    <div class="relative progress-container">
                        <div id="today-progress-bar" class="progress-bar bg-gradient-to-r from-green-400 to-emerald-600"></div>
                        <!-- Milestones will be added dynamically -->
                    </div>
                </div>
                
                <!-- This Week's Progress -->
                <div>
                    <div class="flex justify-between items-center mb-2">
                        <h3 class="font-semibold">Cette semaine</h3>
                        <span id="week-progress" class="text-sm font-medium"></span>
                    </div>
                    <div class="relative progress-container">
                        <div id="week-progress-bar" class="progress-bar bg-gradient-to-r from-blue-400 to-indigo-600"></div>
                        <!-- Milestones will be added dynamically -->
                    </div>
                </div>
                
                <!-- This Month's Progress -->
                <div>
                    <div class="flex justify-between items-center mb-2">
                        <h3 class="font-semibold">Ce mois</h3>
                        <span id="month-progress" class="text-sm font-medium"></span>
                    </div>
                    <div class="relative progress-container">
                        <div id="month-progress-bar" class="progress-bar bg-gradient-to-r from-purple-400 to-fuchsia-600"></div>
                        <!-- Milestones will be added dynamically -->
                    </div>
                </div>
                
                <!-- This Year's Progress -->
                <div>
                    <div class="flex justify-between items-center mb-2">
                        <h3 class="font-semibold">Cette année</h3>
                        <span id="year-progress" class="text-sm font-medium"></span>
                    </div>
                    <div class="relative progress-container">
                        <div id="year-progress-bar" class="progress-bar bg-gradient-to-r from-rose-400 to-red-600"></div>
                        <!-- Milestones will be added dynamically -->
                    </div>
                </div>
            </div>
        </div>
        
        
        
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <!-- Recovery Plan -->
            <div class="card p-6">
                <h2 class="text-xl font-bold mb-4">📅 Plan de rattrapage intelligent</h2>
                
                <div class="flex border-b mb-4">
                    <button class="recovery-tab-btn tab-active px-4 py-2" data-tab="day">Jour</button>
                    <button class="recovery-tab-btn px-4 py-2" data-tab="week">Semaine</button>
                    <button class="recovery-tab-btn px-4 py-2" data-tab="month">Mois</button>
                </div>
                
                <div id="recovery-plan" class="space-y-4">
                    <!-- Recovery plan will be added dynamically -->
                </div>
            </div>
            
            <!-- Optimal Sales Mix -->
            <div class="card p-6">
                <h2 class="text-xl font-bold mb-4">💹 Combinaison optimale de ventes</h2>
                
                <form id="optimal-mix-form" class="mb-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium mb-1">Objectif à atteindre (DA)</label>
                        <input type="number" id="target-amount" min="10000" step="10000" class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    
                    <div class="flex items-end">
                        <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200">
                            Calculer
                        </button>
                    </div>
                </form>
                
                <div id="optimal-mix-result" class="bg-gray-50 rounded-lg p-4 min-h-[200px]">
                    <p class="text-gray-500 text-center">Définissez un objectif pour voir la combinaison optimale</p>
                </div>
            </div>
        </div>
        
        
    </div>

    <script>
        

        // Constants
        const BILLION = 10000000; // 1 milliard DA
        const MILLION = 10000;    // 1 million DA
        
        // Initial data
        let products = [ ];
            
       fetch('/pos/products')
    .then(response => response.json())
    .then(data => {
        products = data.map(product => ({
            id: product.id,
            name: product.name,
            price: product.price,
            cost: product.last_price ?? 0,
            icon: "🛒",
            color: "#4f46e5"
        }));

        console.log("✅ Produits POS chargés:", products);

        
        
    })
    .catch(error => console.error('❌ Erreur chargement produits POS:', error));

      // On initialise la variable sales (vides au départ)
let sales = [];

function loadRealSalesData() {
    fetch('/pos/sales-data')
        .then(response => response.json())
        .then(data => {
            // On remplit "sales" avec les vraies ventes POS
            sales = data.map((item, index) => ({
                id: index + 1,
                productId: 1,  // Valeur par défaut
                quantity: 1,   // Valeur par défaut
                amount: item.amount,
                date: item.date
            }));

            console.log("Ventes POS chargées :", sales);

            // On met à jour le tableau de bord avec les vraies données
            updateProgressBars();
            updateObjectiveMeter();
            updateStatusMessage();
            updateRecoveryPlan();
        })
        .catch(error => console.error('Erreur chargement des ventes POS:', error));
}
function saveGoals() {
    try {
        localStorage.setItem('currentGoal', currentGoal.toString());
        localStorage.setItem('dailyGoal', dailyGoal.toString());
        console.log("Objectifs sauvegardés:", currentGoal, dailyGoal);
    } catch (error) {
        console.error("Erreur lors de la sauvegarde des objectifs:", error);
    }
}
function loadGoals() {
    try {
        const savedGoal = localStorage.getItem('currentGoal');
        const savedDailyGoal = localStorage.getItem('dailyGoal');

        if (savedGoal && !isNaN(parseInt(savedGoal))) {
            currentGoal = parseInt(savedGoal);
            const goalInput = document.getElementById('goalInput');
            if (goalInput) {
                goalInput.value = currentGoal;
            }
        }

        if (savedDailyGoal && !isNaN(parseInt(savedDailyGoal))) {
            dailyGoal = parseInt(savedDailyGoal);
            const dailyGoalSlider = document.getElementById('daily-goal-slider');
            if (dailyGoalSlider) {
                dailyGoalSlider.value = dailyGoal;
                const dailyGoalValue = document.getElementById('daily-goal-value');
                if (dailyGoalValue) {
                    dailyGoalValue.textContent = formatCurrency(dailyGoal);
                }
            }
        }

        console.log("Objectifs chargés:", currentGoal, dailyGoal);
        
        // Mise à jour du dashboard après chargement
        setTimeout(() => {
            updateProgressBars();
            updateObjectiveMeter();
            updateStatusMessage();
            updateRecoveryPlan();
        }, 500); // Petit délai pour s'assurer que le DOM est prêt
    } catch (error) {
        console.error("Erreur lors du chargement des objectifs:", error);
    }
}

// Lancement automatique quand la page est chargée
document.addEventListener('DOMContentLoaded', () => {
    console.log("DOM chargé, initialisation du dashboard...");
    
    // Initialiser l'objectifomètre
    initializeObjectiveMeter();
    
    // Charger les données réelles
    loadRealSalesData();
    
    // Charger les objectifs sauvegardés
    loadGoals();
    
    // Mettre à jour l'interface
    setTimeout(() => {
        updateProgressBars();
        updateObjectiveMeter();
        updateStatusMessage();
        updateRecoveryPlan();
    }, 1000);
});

// Initialiser l'objectifomètre
function initializeObjectiveMeter() {
    console.log("Initialisation de l'objectifomètre...");
    
    // Initialiser le slider d'objectif journalier
    const dailyGoalSlider = document.getElementById('daily-goal-slider');
    if (dailyGoalSlider) {
        dailyGoalSlider.value = dailyGoal;
        dailyGoalSlider.min = "10000";
        dailyGoalSlider.max = "1000000";
        dailyGoalSlider.step = "10000";
        
        const dailyGoalValue = document.getElementById('daily-goal-value');
        if (dailyGoalValue) {
            dailyGoalValue.textContent = formatCurrency(dailyGoal);
        }
        
        // Ajouter l'écouteur d'événements
        dailyGoalSlider.addEventListener('input', (e) => {
            dailyGoal = parseInt(e.target.value);
            if (dailyGoalValue) {
                dailyGoalValue.textContent = formatCurrency(dailyGoal);
            }
            
            // Mettre à jour l'interface
            updateProgressBars();
            updateObjectiveMeter();
            updateStatusMessage();
            updateRecoveryPlan();
            
            // Sauvegarder
            saveGoals();
        });
    }
    
    // Initialiser l'input d'objectif mensuel
    const goalInput = document.getElementById('goalInput');
    if (goalInput) {
        goalInput.value = currentGoal;
    }
}

        let selectedIcon = "🎓";
        let selectedIconColor = "#4f46e5";
        let dailyGoal = 10000; // 100,000 DA par jour
        
        // Milestones for progress bars (in DA)
        const milestones = {
            day: [10000, 50000, 100000, 500000],
            week: [50000, 250000, 500000, 1000000],
            month: [250000, 1000000, 5000000, 10000000],
            year: [1000000, 10000000, 100000000, 500000000]
        };
        
        // Milestones for the objective meter (in DA)
        const objectiveMilestones = [
            { value: 10000, label: "10K" },
            { value: 100000, label: "100K" },
            { value: 1000000, label: "1M" },
            { value: 10000000, label: "10M" },
            { value: 100000000, label: "100M" },
            { value: 500000000, label: "500M" },
            { value: BILLION, label: "1B" }
        ];
        
        // Icons for product selection
        const icons = [
            { icon: "🎓", color: "#4f46e5" },
            { icon: "💼", color: "#06b6d4" },
            { icon: "🌐", color: "#10b981" },
            { icon: "📱", color: "#f59e0b" },
            { icon: "📣", color: "#ef4444" },
            { icon: "💻", color: "#8b5cf6" },
            { icon: "📊", color: "#ec4899" },
            { icon: "🛒", color: "#14b8a6" },
            { icon: "📝", color: "#f97316" },
            { icon: "🔍", color: "#6366f1" }
        ];
        
        // Initialize the application
        document.addEventListener('DOMContentLoaded', () => {
              loadGoals();
            // Set today's date as default
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('sale-date').value = today;
            
            // Generate sample sales data
            generateSampleSales();
            
            // Initialize UI components
            initializeIconSelector();
            updateProductsList();
            updateSalesDropdown();
            updateTopProducts();
            updateProgressBars();
            updateSalesHistory();
            updateObjectiveMeter();
            updateStatusMessage();
            updateRecoveryPlan();
            
            // Set daily goal slider
            const dailyGoalSlider = document.getElementById('daily-goal-slider');
            dailyGoalSlider.value = dailyGoal;
            document.getElementById('daily-goal-value').textContent = formatCurrency(dailyGoal);
            
            // Add event listeners
            document.getElementById('add-sale-form').addEventListener('submit', handleAddSale);
            document.getElementById('add-product-form').addEventListener('submit', handleAddProduct);
            document.getElementById('optimal-mix-form').addEventListener('submit', handleCalculateOptimalMix);
            
            // Tab event listeners
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('tab-active'));
                    e.target.classList.add('tab-active');
                    updateSalesHistory(e.target.dataset.tab);
                });
            });
            
           // Recovery plan tab event listeners
  document.addEventListener('click', function(e) {
    if (e.target && e.target.classList.contains('recovery-tab-btn')) {
        console.log("Recovery tab clicked:", e.target.dataset.tab);

        // Enlever les autres "tab-active"
        document.querySelectorAll('.recovery-tab-btn').forEach(b => b.classList.remove('tab-active'));

        // Ajouter le "tab-active" au bouton cliqué
        e.target.classList.add('tab-active');

        // Appeler updateRecoveryPlan avec le bon paramètre
        const period = e.target.dataset.tab;
        updateRecoveryPlan(period);
    }
});



    // Daily goal slider event listener
    dailyGoalSlider.addEventListener('input', (e) => {
        dailyGoal = parseInt(e.target.value);
        document.getElementById('daily-goal-value').textContent = formatCurrency(dailyGoal);
        updateProgressBars();
        updateStatusMessage();
        updateRecoveryPlan(); // Ici c'est OK
    });
});
        // Generate sample sales data
        function generateSampleSales() {
            const now = new Date();
            
            // Generate sales for the past 60 days
            for (let i = 0; i < 60; i++) {
                const date = new Date(now);
                date.setDate(date.getDate() - i);
                
                // 1-3 sales per day
                const salesPerDay = Math.floor(Math.random() * 3) + 1;
                
                for (let j = 0; j < salesPerDay; j++) {
                    const productIndex = Math.floor(Math.random() * products.length);
                    const product = products[productIndex];
                    const quantity = Math.floor(Math.random() * 3) + 1;
                    const adCost = Math.floor(Math.random() * 10000);
                    
                    sales.push({
                        id: sales.length + 1,
                        productId: product.id,
                        quantity: quantity,
                        amount: product.price * quantity,
                        adCost: adCost,
                        date: date.toISOString().split('T')[0]
                    });
                }
            }
        }
        
        // Initialize icon selector
        function initializeIconSelector() {
            const iconSelector = document.getElementById('icon-selector');
            iconSelector.innerHTML = '';
            
            icons.forEach(iconObj => {
                const iconElement = document.createElement('div');
                iconElement.className = `icon-option ${iconObj.icon === selectedIcon ? 'selected' : ''}`;
                iconElement.style.backgroundColor = iconObj.color;
                iconElement.innerHTML = iconObj.icon;
                iconElement.dataset.icon = iconObj.icon;
                iconElement.dataset.color = iconObj.color;
                
                iconElement.addEventListener('click', () => {
                    document.querySelectorAll('.icon-option').forEach(opt => opt.classList.remove('selected'));
                    iconElement.classList.add('selected');
                    selectedIcon = iconObj.icon;
                    selectedIconColor = iconObj.color;
                });
                
                iconSelector.appendChild(iconElement);
            });
        }
        
        // Update products list
       function updateProductsList() {
    const productsTableBody = document.querySelector('.table.mb-0 tbody');
    if (!productsTableBody) {
        console.warn('Tableau des produits non trouvé.');
        return;
    }

    productsTableBody.innerHTML = '';

    products.forEach(product => {
        const margin = product.price - product.cost;
        const marginPercent = ((margin / product.price) * 100).toFixed(1);

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                <div class="d-flex align-items-center">
                    <div class="theme-avtar me-2">
                        <img src="${product.image_url || '/uploads/is_cover_image/default.jpg'}" alt="" />
                    </div>
                    <a href="#" class=" text-dark f-w-600">${product.name}</a>
                </div>
            </td>
            <td>${product.quantity || '-'}</td>
            <td>${formatCurrency(product.price)}</td>
            <td>
                <span class="font-medium ${margin > 0 ? 'text-success' : 'text-danger'}">
                    ${formatCurrency(margin)} (${marginPercent}%)
                </span>
            </td>
        `;
        productsTableBody.appendChild(row);
    });
}

        
        // Update sales dropdown
        function updateSalesDropdown() {
            const dropdown = document.getElementById('sale-product');
            dropdown.innerHTML = '';
            
            products.forEach(product => {
                const option = document.createElement('option');
                option.value = product.id;
                option.textContent = `${product.icon} ${product.name} - ${formatCurrency(product.price)}`;
                dropdown.appendChild(option);
            });
            
            // Set the amount field based on the selected product
            dropdown.addEventListener('change', () => {
                const selectedProduct = products.find(p => p.id === parseInt(dropdown.value));
                if (selectedProduct) {
                    document.getElementById('sale-amount').value = selectedProduct.price;
                }
            });
            
            // Set initial value
            if (products.length > 0) {
                document.getElementById('sale-amount').value = products[0].price;
            }
        }
        
        // Update top products
        function updateTopProducts() {
            const topProductsContainer = document.getElementById('top-products');
            topProductsContainer.innerHTML = '';
            
            // Sort products by margin
            const sortedProducts = [...products].sort((a, b) => {
                const marginA = a.price - a.cost;
                const marginB = b.price - b.cost;
                return marginB - marginA;
            });
            
            // Display top products
            sortedProducts.forEach(product => {
                const margin = product.price - product.cost;
                const marginPercent = ((margin / product.price) * 100).toFixed(1);
                
                const productCard = document.createElement('div');
                productCard.className = 'product-card flex-shrink-0 w-64 bg-white border border-gray-200 shadow-sm';
                productCard.innerHTML = `
                    <div class="p-4 border-b" style="background-color: ${product.color}20">
                        <div class="flex justify-between items-center">
                            <div class="product-icon" style="background-color: ${product.color}">
                                ${product.icon}
                            </div>
                            <div class="text-xs font-semibold px-2 py-1 bg-white rounded-full text-gray-700">
                                Marge: ${marginPercent}%
                            </div>
                        </div>
                        <h3 class="font-semibold mt-2 text-gray-800">${product.name}</h3>
                    </div>
                    <div class="p-4">
                        <div class="flex justify-between text-sm mb-1">
                            <span class="text-gray-600">Prix:</span>
                            <span class="font-medium">${formatCurrency(product.price)}</span>
                        </div>
                        <div class="flex justify-between text-sm mb-1">
                            <span class="text-gray-600">Coût:</span>
                            <span class="font-medium">${formatCurrency(product.cost)}</span>
                        </div>
                        <div class="flex justify-between text-sm pt-1 border-t mt-1">
                            <span class="text-gray-600">Bénéfice:</span>
                            <span class="font-medium text-green-600">${formatCurrency(margin)}</span>
                        </div>
                    </div>
                `;
                topProductsContainer.appendChild(productCard);
            });
        }
        
        // Update progress bars
        function updateProgressBars() {
            // Calculate current values
            const stats = calculateSalesStats();
            
            // Update today's progress
            updateProgressBar('today', stats.today, dailyGoal, milestones.day);
            
            // Update this week's progress
            updateProgressBar('week', stats.week, dailyGoal * 7, milestones.week);
            
            // Update this month's progress
            updateProgressBar('month', stats.month, dailyGoal * 30, milestones.month);
            
            // Update this year's progress
            updateProgressBar('year', stats.year, dailyGoal * 365, milestones.year);
            
            // Update global progress
            const totalSales = stats.total;
            const globalPercentage = Math.min(100, (totalSales / BILLION) * 100);
            document.getElementById('global-progress').textContent = `${formatCurrency(totalSales)} / ${formatCurrency(BILLION)} (${globalPercentage.toFixed(1)}%)`;
            document.getElementById('global-progress-bar').style.width = `${globalPercentage}%`;
            
            // Update daily progress
            const todayPercentage = Math.min(100, (stats.today / dailyGoal) * 100);
            document.getElementById('daily-progress-bar').style.width = `${todayPercentage}%`;
        }
        
        // Update a specific progress bar
        function updateProgressBar(id, current, target, milestones) {
            const percentage = Math.min(100, (current / target) * 100);
            document.getElementById(`${id}-progress`).textContent = `${formatCurrency(current)} / ${formatCurrency(target)} (${percentage.toFixed(1)}%)`;
            document.getElementById(`${id}-progress-bar`).style.width = `${percentage}%`;
            
            // Add milestones
            const progressContainer = document.getElementById(`${id}-progress-bar`).parentElement;
            
            // Clear existing milestones
            progressContainer.querySelectorAll('.milestone, .milestone-label, .trophy').forEach(el => el.remove());
            
            // Add new milestones
            milestones.forEach((milestone, index) => {
                const milestonePercentage = (milestone / target) * 100;
                if (milestonePercentage <= 100) {
                    // Add milestone marker
                    const milestoneElement = document.createElement('div');
                    milestoneElement.className = 'milestone';
                    milestoneElement.style.left = `${milestonePercentage}%`;
                    progressContainer.appendChild(milestoneElement);
                    
                    // Add milestone label
                    const milestoneLabel = document.createElement('div');
                    milestoneLabel.className = 'milestone-label';
                    milestoneLabel.textContent = formatCurrency(milestone, true);
                    milestoneLabel.style.left = `${milestonePercentage}%`;
                    progressContainer.appendChild(milestoneLabel);
                    
                    // Add trophy if milestone is reached
                    if (current >= milestone) {
                        const trophy = document.createElement('div');
                        trophy.className = 'trophy';
                        trophy.innerHTML = '🏆';
                        trophy.style.left = `${milestonePercentage}%`;
                        trophy.dataset.tooltip = `Palier ${formatCurrency(milestone, true)} atteint !`;
                        trophy.classList.add('tooltip');
                        progressContainer.appendChild(trophy);
                    }
                }
            });
        }
        
        // Update objective meter
        function updateObjectiveMeter() {
            console.log("Mise à jour de l'objectifomètre...");
            
            const objectiveMeter = document.querySelector('.objective-meter');
            if (!objectiveMeter) {
                console.error("Élément .objective-meter non trouvé");
                return;
            }
            
            objectiveMeter.innerHTML = '';
            
            // Calculer les statistiques
            const stats = calculateSalesStats();
            const totalSales = stats.total;
            
            // Ajouter les jalons
            objectiveMilestones.forEach((milestone, index) => {
                const milestonePercentage = Math.min(100, (milestone.value / BILLION) * 100);
                
                // Ajouter le marqueur de jalon
                const milestoneElement = document.createElement('div');
                milestoneElement.className = 'objective-marker';
                milestoneElement.style.left = `${milestonePercentage}%`;
                objectiveMeter.appendChild(milestoneElement);
                
                // Ajouter l'étiquette du jalon
                const milestoneLabel = document.createElement('div');
                milestoneLabel.className = 'absolute text-xs font-semibold';
                milestoneLabel.textContent = milestone.label;
                milestoneLabel.style.left = `${milestonePercentage}%`;
                milestoneLabel.style.bottom = '-20px';
                milestoneLabel.style.transform = 'translateX(-50%)';
                objectiveMeter.appendChild(milestoneLabel);
                
                // Ajouter un trophée ou un cadenas
                if (totalSales >= milestone.value) {
                    const trophy = document.createElement('div');
                    trophy.className = 'absolute -top-4 z-10';
                    trophy.innerHTML = '🏆';
                    trophy.style.left = `${milestonePercentage}%`;
                    trophy.style.transform = 'translateX(-50%)';
                    objectiveMeter.appendChild(trophy);
                } else {
                    const lock = document.createElement('div');
                    lock.className = 'absolute -top-4 z-10 locked';
                    lock.innerHTML = '🔒';
                    lock.style.left = `${milestonePercentage}%`;
                    lock.style.transform = 'translateX(-50%)';
                    objectiveMeter.appendChild(lock);
                }
            });
            
            // Mettre à jour la position actuelle
            const percentage = Math.min(100, (totalSales / BILLION) * 100);
            
            const currentMarker = document.getElementById('objective-current');
            if (currentMarker) {
                currentMarker.style.left = `${percentage}%`;
            }
            
            // Mettre à jour la barre de progression globale
            const globalProgressBar = document.getElementById('global-progress-bar');
            const globalProgress = document.getElementById('global-progress');
            if (globalProgressBar && globalProgress) {
                globalProgressBar.style.width = `${percentage}%`;
                globalProgress.textContent = `${formatCurrency(totalSales)} / ${formatCurrency(BILLION)} (${percentage.toFixed(1)}%)`;
            }
            
            // Mettre à jour la barre de progression journalière
            const todayPercentage = Math.min(100, (stats.today / dailyGoal) * 100);
            const dailyProgressBar = document.getElementById('daily-progress-bar');
            if (dailyProgressBar) {
                dailyProgressBar.style.width = `${todayPercentage}%`;
            }
            
            console.log("Objectifomètre mis à jour avec succès");
        }
        
        // Update status message
        function updateStatusMessage() {
            const statusMessage = document.getElementById('status-message');
            
            // Calculate stats
            const stats = calculateSalesStats();
            const today = stats.today;
            
            // Calculate days ahead/behind
            const difference = today - dailyGoal;
            const daysEquivalent = Math.abs(Math.round(difference / dailyGoal * 10) / 10);
            
            if (difference >= 0) {
                statusMessage.className = 'px-6 py-3 rounded-full text-white font-semibold bg-green-600 pulse-animation';
                statusMessage.innerHTML = `
                    🚀 Tu es en avance de +${formatCurrency(difference)} (équivaut à ${daysEquivalent} jours)
                `;
            } else {
                statusMessage.className = 'px-6 py-3 rounded-full text-white font-semibold bg-amber-600';
                statusMessage.innerHTML = `
                    🔻 Tu es en retard de -${formatCurrency(Math.abs(difference))} (rattrapage en ${daysEquivalent} jours)
                `;
            }
        }
        
        // Update sales history
        function updateSalesHistory(filter = 'all') {
            const salesHistoryContainer = document.getElementById('sales-history');
            salesHistoryContainer.innerHTML = '';
            
            // Filter sales based on selected tab
            let filteredSales = [...sales];
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            
            if (filter === 'day') {
                filteredSales = sales.filter(sale => {
                    const saleDate = new Date(sale.date);
                    return saleDate.toDateString() === today.toDateString();
                });
            } else if (filter === 'week') {
                const weekStart = new Date(today);
                weekStart.setDate(today.getDate() - today.getDay());
                
                filteredSales = sales.filter(sale => {
                    const saleDate = new Date(sale.date);
                    return saleDate >= weekStart;
                });
            } else if (filter === 'month') {
                const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
                
                filteredSales = sales.filter(sale => {
                    const saleDate = new Date(sale.date);
                    return saleDate >= monthStart;
                });
            }
            
            // Sort by date (most recent first)
            filteredSales.sort((a, b) => new Date(b.date) - new Date(a.date));
            
            // Display sales
            filteredSales.forEach(sale => {
                const product = products.find(p => p.id === sale.productId);
                if (product) {
                    const cost = product.cost * sale.quantity;
                    const profit = sale.amount - cost - sale.adCost;
                    
                    const row = document.createElement('tr');
                    row.className = 'sales-history-item';
                    row.innerHTML = `
                        <td class="px-4 py-3">${formatDate(sale.date)}</td>
                        <td class="px-4 py-3">
                            <div class="flex items-center">
                                <div class="product-icon mr-2" style="background-color: ${product.color}">
                                    ${product.icon}
                                </div>
                                <span>${product.name}</span>
                            </div>
                        </td>
                        <td class="px-4 py-3">${formatCurrency(sale.amount)}</td>
                        <td class="px-4 py-3">${formatCurrency(cost)}</td>
                        <td class="px-4 py-3">${formatCurrency(sale.adCost)}</td>
                        <td class="px-4 py-3">
                            <span class="${profit >= 0 ? 'text-green-600' : 'text-red-600'} font-medium">
                                ${formatCurrency(profit)}
                            </span>
                        </td>
                        <td class="px-4 py-3">
                            <button class="delete-btn text-red-500 hover:text-red-700" data-id="${sale.id}">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" />
                                </svg>
                            </button>
                        </td>
                    `;
                    salesHistoryContainer.appendChild(row);
                }
            });
            
            // Add event listeners for delete buttons
            document.querySelectorAll('.delete-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const saleId = parseInt(btn.dataset.id);
                    deleteSale(saleId);
                });
            });
            
            // Update sales statistics
            updateSalesStatistics(filteredSales);
        }
        
        // Update sales statistics
        function updateSalesStatistics(filteredSales) {
            const statsContainer = document.getElementById('sales-stats');
            statsContainer.innerHTML = '';
            
            // Calculate statistics
            let totalRevenue = 0;
            let totalCost = 0;
            let totalAdCost = 0;
            let totalProfit = 0;
            
            filteredSales.forEach(sale => {
                const product = products.find(p => p.id === sale.productId);
                if (product) {
                    totalRevenue += sale.amount;
                    totalCost += product.cost * sale.quantity;
                    totalAdCost += sale.adCost;
                    totalProfit += sale.amount - (product.cost * sale.quantity) - sale.adCost;
                }
            });
            
            // Create statistics cards
            const revenueCard = document.createElement('div');
            revenueCard.className = 'bg-blue-50 p-3 rounded-lg';
            revenueCard.innerHTML = `
                <div class="text-sm text-blue-600 font-medium">Chiffre d'affaires</div>
                <div class="text-xl font-bold text-blue-800">${formatCurrency(totalRevenue)}</div>
            `;
            
            const costCard = document.createElement('div');
            costCard.className = 'bg-amber-50 p-3 rounded-lg';
            costCard.innerHTML = `
                <div class="text-sm text-amber-600 font-medium">Coûts totaux</div>
                <div class="text-xl font-bold text-amber-800">${formatCurrency(totalCost + totalAdCost)}</div>
                <div class="text-xs text-amber-600">Production: ${formatCurrency(totalCost)} | Pub: ${formatCurrency(totalAdCost)}</div>
            `;
            
            const profitCard = document.createElement('div');
            profitCard.className = 'bg-green-50 p-3 rounded-lg';
            profitCard.innerHTML = `
                <div class="text-sm text-green-600 font-medium">Bénéfice net</div>
                <div class="text-xl font-bold ${totalProfit >= 0 ? 'text-green-800' : 'text-red-800'}">${formatCurrency(totalProfit)}</div>
                <div class="text-xs text-green-600">Marge: ${totalRevenue > 0 ? ((totalProfit / totalRevenue) * 100).toFixed(1) : 0}%</div>
            `;
            
            statsContainer.appendChild(revenueCard);
            statsContainer.appendChild(costCard);
            statsContainer.appendChild(profitCard);
        }
        
        // Update recovery plan
        function updateRecoveryPlan(period = 'day') {
            const recoveryPlanContainer = document.getElementById('recovery-plan');
            recoveryPlanContainer.innerHTML = '';
            
            // Calculate stats
            const stats = calculateSalesStats();
            
            // Calculate target based on period
            let target, current, periodLabel, daysInPeriod;
            
            if (period === 'day') {
                target = dailyGoal;
                current = stats.today;
                periodLabel = "aujourd'hui";
                daysInPeriod = 1;
            } else if (period === 'week') {
                target = dailyGoal * 7;
                current = stats.week;
                periodLabel = "cette semaine";
                daysInPeriod = 7;
            } else if (period === 'month') {
                target = dailyGoal * 30;
                current = stats.month;
                periodLabel = "ce mois";
                daysInPeriod = 30;
            }
            
            // Calculate difference
            const difference = target - current;
            
            // Create header
            const header = document.createElement('div');
            header.className = 'mb-4';
            
            if (difference <= 0) {
                header.innerHTML = `
                    <div class="flex items-center mb-2">
                        <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
                            <span class="text-xl">🎉</span>
                        </div>
                        <div>
                            <h3 class="font-semibold text-green-700">Objectif ${periodLabel} atteint !</h3>
                            <p class="text-sm text-green-600">Tu as dépassé ton objectif de ${formatCurrency(Math.abs(difference))}</p>
                        </div>
                    </div>
                `;
            } else {
                header.innerHTML = `
                    <div class="flex items-center mb-2">
                        <div class="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center mr-3">
                            <span class="text-xl">⚠️</span>
                        </div>
                        <div>
                            <h3 class="font-semibold text-amber-700">Objectif ${periodLabel} non atteint</h3>
                            <p class="text-sm text-amber-600">Il te manque ${formatCurrency(difference)} pour atteindre ton objectif</p>
                        </div>
                    </div>
                `;
            }
            
            recoveryPlanContainer.appendChild(header);
            
            // Create recovery plan
            if (difference > 0) {
                // Calculate remaining days in period
                let remainingDays;
                
                if (period === 'day') {
                    remainingDays = 1;
                } else if (period === 'week') {
                    const today = new Date();
                    const dayOfWeek = today.getDay(); // 0 = Sunday, 1 = Monday, etc.
                    remainingDays = 7 - dayOfWeek;
                    if (remainingDays === 0) remainingDays = 7; // If today is Sunday
                } else if (period === 'month') {
                    const today = new Date();
                    const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
                    remainingDays = lastDay - today.getDate() + 1;
                }
                
                // Calculate daily amount needed
                const dailyNeeded = difference / remainingDays;
                
                // Create plan card
                const planCard = document.createElement('div');
                planCard.className = 'bg-white border border-gray-200 rounded-lg p-4 mb-4';
                planCard.innerHTML = `
                    <h4 class="font-medium text-gray-800 mb-2">Plan de rattrapage</h4>
                    <p class="text-sm text-gray-600 mb-3">
                        Pour atteindre ton objectif ${periodLabel}, tu dois générer <span class="font-semibold text-indigo-600">${formatCurrency(dailyNeeded)}</span> 
                        par jour pendant les ${remainingDays} jour${remainingDays > 1 ? 's' : ''} restant${remainingDays > 1 ? 's' : ''}.
                    </p>
                    <div class="flex items-center justify-between bg-indigo-50 p-3 rounded-md">
                        <div>
                            <div class="text-sm text-indigo-600">Objectif journalier normal</div>
                            <div class="font-medium">${formatCurrency(dailyGoal)}</div>
                        </div>
                        <div class="text-2xl">→</div>
                        <div>
                            <div class="text-sm text-indigo-600">Objectif journalier ajusté</div>
                            <div class="font-bold text-indigo-700">${formatCurrency(dailyNeeded)}</div>
                        </div>
                    </div>
                `;
                
                recoveryPlanContainer.appendChild(planCard);
                
                // Calculate optimal product mix
                const optimalMix = calculateOptimalMix(dailyNeeded);
                
                if (optimalMix.length > 0) {
                    const mixCard = document.createElement('div');
                    mixCard.className = 'bg-white border border-gray-200 rounded-lg p-4';
                    mixCard.innerHTML = `
                        <h4 class="font-medium text-gray-800 mb-2">Suggestion de ventes</h4>
                        <p class="text-sm text-gray-600 mb-3">
                            Voici une combinaison optimale de produits pour atteindre ton objectif journalier ajusté:
                        </p>
                    `;
                    
                    const mixList = document.createElement('ul');
                    mixList.className = 'space-y-2';
                    
                    optimalMix.forEach(item => {
                        const li = document.createElement('li');
                        li.className = 'flex items-center';
                        li.innerHTML = `
                            <div class="product-icon mr-3" style="background-color: ${item.product.color}">
                                ${item.product.icon}
                            </div>
                            <div>
                                <div class="font-medium">${item.quantity} × ${item.product.name}</div>
                                <div class="text-sm text-gray-600">${formatCurrency(item.product.price * item.quantity)}</div>
                            </div>
                        `;
                        mixList.appendChild(li);
                    });
                    
                    mixCard.appendChild(mixList);
                    recoveryPlanContainer.appendChild(mixCard);
                }
            } else {
                // Create success card
                const successCard = document.createElement('div');
                successCard.className = 'bg-white border border-gray-200 rounded-lg p-4';
                successCard.innerHTML = `
                    <div class="flex items-center justify-center flex-col py-4">
                        <div class="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-3">
                            <span class="text-3xl">🏆</span>
                        </div>
                        <h4 class="font-medium text-gray-800 mb-1">Félicitations !</h4>
                        <p class="text-sm text-gray-600 text-center">
                            Tu as déjà atteint ton objectif ${periodLabel}. Continue sur cette lancée !
                        </p>
                    </div>
                `;
                
                recoveryPlanContainer.appendChild(successCard);
            }
        }
        
        // Calculate optimal mix of products to reach a target amount
        function calculateOptimalMix(targetAmount) {
            // Sort products by profit margin (descending)
            const sortedProducts = [...products].sort((a, b) => {
                const marginA = (a.price - a.cost) / a.price;
                const marginB = (b.price - b.cost) / b.price;
                return marginB - marginA;
            });
            
            const result = [];
            let remaining = targetAmount;
            
            // First pass: add high-margin products
            sortedProducts.forEach(product => {
                if (remaining > 0 && product.price <= remaining) {
                    const quantity = Math.floor(remaining / product.price);
                    if (quantity > 0) {
                        result.push({
                            product,
                            quantity: Math.min(quantity, 3) // Limit to 3 units per product
                        });
                        remaining -= product.price * Math.min(quantity, 3);
                    }
                }
            });
            
            // Second pass: add any product that fits
            if (remaining > 0) {
                const cheapestProduct = [...products].sort((a, b) => a.price - b.price)[0];
                if (cheapestProduct && cheapestProduct.price <= remaining) {
                    const quantity = Math.ceil(remaining / cheapestProduct.price);
                    result.push({
                        product: cheapestProduct,
                        quantity
                    });
                    remaining = 0;
                }
            }
            
            return result;
        }
        
        // Handle adding a sale
        function handleAddSale(e) {
            e.preventDefault();
            
            const productId = parseInt(document.getElementById('sale-product').value);
            const amount = parseFloat(document.getElementById('sale-amount').value);
            const quantity = parseInt(document.getElementById('sale-quantity').value);
            const adCost = parseFloat(document.getElementById('sale-ad-cost').value) || 0;
            const date = document.getElementById('sale-date').value;
            
            if (productId && amount > 0 && quantity > 0 && date) {
                const newSale = {
                    id: sales.length + 1,
                    productId,
                    amount,
                    quantity,
                    adCost,
                    date
                };
                
                sales.push(newSale);
                
                // Update UI
                updateProgressBars();
                updateSalesHistory();
                updateObjectiveMeter();
                updateStatusMessage();
                updateRecoveryPlan();
                
                // Reset form
                document.getElementById('sale-quantity').value = 1;
                document.getElementById('sale-ad-cost').value = 0;
                
                // Show notification
                showNotification('Vente ajoutée avec succès !', 'success');
            } else {
                showNotification('Veuillez remplir tous les champs requis.', 'error');
            }
        }
        
        // Handle adding a product
        function handleAddProduct(e) {
            e.preventDefault();
            
            const name = document.getElementById('product-name').value;
            const price = parseFloat(document.getElementById('product-price').value);
            const cost = parseFloat(document.getElementById('product-cost').value);
            
            if (name && price > 0 && cost >= 0) {
                const newProduct = {
                    id: products.length + 1,
                    name,
                    price,
                    cost,
                    icon: selectedIcon,
                    color: selectedIconColor
                };
                
                products.push(newProduct);
                
                // Update UI
                updateProductsList();
                updateSalesDropdown();
                updateTopProducts();
                
                // Reset form
                document.getElementById('product-name').value = '';
                document.getElementById('product-price').value = '';
                document.getElementById('product-cost').value = '';
                
                // Show notification
                showNotification('Produit ajouté avec succès !', 'success');
            } else {
                showNotification('Veuillez remplir tous les champs requis.', 'error');
            }
        }
        
        // Handle calculating optimal mix
        function handleCalculateOptimalMix(e) {
            e.preventDefault();
            
            const targetAmount = parseFloat(document.getElementById('target-amount').value);
            
            if (targetAmount > 0) {
                const optimalMix = calculateOptimalMix(targetAmount);
                const resultContainer = document.getElementById('optimal-mix-result');
                
                if (optimalMix.length > 0) {
                    let totalAmount = 0;
                    let totalProfit = 0;
                    
                    optimalMix.forEach(item => {
                        const amount = item.product.price * item.quantity;
                        const profit = (item.product.price - item.product.cost) * item.quantity;
                        totalAmount += amount;
                        totalProfit += profit;
                    });
                    
                    resultContainer.innerHTML = `
                        <h4 class="font-medium text-gray-800 mb-3">Pour atteindre ${formatCurrency(targetAmount)}, il te faut vendre:</h4>
                        <ul class="space-y-3 mb-4">
                            ${optimalMix.map(item => `
                                <li class="flex items-center bg-white p-2 rounded-md border border-gray-200">
                                    <div class="product-icon mr-3" style="background-color: ${item.product.color}">
                                        ${item.product.icon}
                                    </div>
                                    <div class="flex-1">
                                        <div class="font-medium">${item.quantity} × ${item.product.name}</div>
                                        <div class="text-sm text-gray-600">
                                            ${formatCurrency(item.product.price * item.quantity)} 
                                            (Bénéfice: ${formatCurrency((item.product.price - item.product.cost) * item.quantity)})
                                        </div>
                                    </div>
                                </li>
                            `).join('')}
                        </ul>
                        <div class="bg-indigo-50 p-3 rounded-md">
                            <div class="flex justify-between mb-1">
                                <span class="text-sm text-indigo-600">Total des ventes:</span>
                                <span class="font-medium">${formatCurrency(totalAmount)}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm text-indigo-600">Bénéfice estimé:</span>
                                <span class="font-medium text-green-600">${formatCurrency(totalProfit)}</span>
                            </div>
                        </div>
                    `;
                } else {
                    resultContainer.innerHTML = `
                        <div class="text-center py-4">
                            <p class="text-gray-600">Aucune combinaison optimale n'a pu être calculée.</p>
                        </div>
                    `;
                }
            } else {
                showNotification('Veuillez entrer un montant cible valide.', 'error');
            }
        }
        
        // Delete a sale
        function deleteSale(saleId) {
            const index = sales.findIndex(sale => sale.id === saleId);
            if (index !== -1) {
                sales.splice(index, 1);
                
                // Update UI
                updateProgressBars();
                updateSalesHistory();
                updateObjectiveMeter();
                updateStatusMessage();
                updateRecoveryPlan();
                
                // Show notification
                showNotification('Vente supprimée avec succès !', 'info');
            }
        }
        
        // Calculate sales statistics
        function calculateSalesStats() {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            
            const weekStart = new Date(today);
            weekStart.setDate(today.getDate() - today.getDay());
            
            const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
            
            const yearStart = new Date(today.getFullYear(), 0, 1);
            
            let todaySales = 0;
            let weekSales = 0;
            let monthSales = 0;
            let yearSales = 0;
            let totalSales = 0;
            
            sales.forEach(sale => {
                const saleDate = new Date(sale.date);
                totalSales += sale.amount;
                
                if (saleDate.toDateString() === today.toDateString()) {
                    todaySales += sale.amount;
                }
                
                if (saleDate >= weekStart) {
                    weekSales += sale.amount;
                }
                
                if (saleDate >= monthStart) {
                    monthSales += sale.amount;
                }
                
                if (saleDate >= yearStart) {
                    yearSales += sale.amount;
                }
            });
            
            return {
                today: todaySales,
                week: weekSales,
                month: monthSales,
                year: yearSales,
                total: totalSales
            };
        }
        
        // Show notification
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `fixed bottom-4 right-4 px-6 py-3 rounded-lg shadow-lg text-white font-medium z-50 ${
                type === 'success' ? 'bg-green-600' : 
                type === 'error' ? 'bg-red-600' : 
                'bg-blue-600'
            }`;
            notification.textContent = message;
            
            document.body.appendChild(notification);
            
            // Fade out after 3 seconds
            setTimeout(() => {
                notification.style.opacity = '0';
                notification.style.transition = 'opacity 0.5s ease-in-out';
                
                setTimeout(() => {
                    document.body.removeChild(notification);
                }, 500);
            }, 3000);
        }
        
        // Format currency
        function formatCurrency(amount, short = false) {
            if (short) {
                if (amount >= BILLION) {
                    return (amount / BILLION).toFixed(1) + ' B';
                } else if (amount >= MILLION) {
                    return (amount / MILLION).toFixed(1) + ' M';
                } else if (amount >= 1000) {
                    return (amount / 1000).toFixed(1) + ' K';
                } else {
                    return amount.toString();
                }
            }
            
            return new Intl.NumberFormat('fr-DZ', {
                style: 'currency',
                currency: 'DZD',
                maximumFractionDigits: 0
            }).format(amount);
        }
        
        // Format date
        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
        }
    </script>
<script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'94c5754ba143ba95',t:'MTc0OTM1NDk3NC4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>
@push('script-page')
<script>
    document.addEventListener('click', function(e) {
        if (e.target && e.target.classList.contains('recovery-tab-btn')) {
            console.log("Recovery tab clicked:", e.target.dataset.tab);

            // Enlever les autres "tab-active"
            document.querySelectorAll('.recovery-tab-btn').forEach(b => b.classList.remove('tab-active'));

            // Ajouter le "tab-active" au bouton cliqué
            e.target.classList.add('tab-active');

            // Appeler updateRecoveryPlan avec le bon paramètre
            const period = e.target.dataset.tab;
            updateRecoveryPlan(period);
        }
    });
</script>
@endpush

</html>



            
        
    

            
            
            <div class="col-lg-4">
                <h4 >{{ __('Storage Status') }} <small>({{ $users->storage_limit . 'MB' }} / {{ $plan->storage_limit . 'MB' }})</small></h4>

                <div class="card shadow-none mb-0">
                    <div class="card-body border rounded  p-3">
                        <div id="device-chart"></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <h4 >{{ __('Top Products') }}</h4>
                <div class="card mb-0 shadow-none">
                    <div class="card-body border border-bottom-0 overflow-hidden rounded pb-0 table-border-style">
                        <div class="table-responsive">
                            <table class="table mb-0">
                                <thead>
                                    <tr>
                                        <th class="bg-transparent">{{ __('Product') }}</th>
                                        <th class="bg-transparent"> {{ __('Quantity') }}</th>
                                        <th class="bg-transparent">{{ __('Price') }}</th>
                                        <th class="bg-transparent"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if(!empty($item_id))
                                        @foreach ($products as $product)
                                            @foreach ($item_id as $k => $item)
                                                @if ($product->id == $item)
                                                    <tr>
                                                        <td>
                                                            <div class="d-flex align-items-center">
                                                                <div class="theme-avtar me-2">
                                                                    @if (!empty($product->is_cover))
                                                                        <img src="{{ $logo1 . $product->is_cover }}" alt="">
                                                                    @else
                                                                        <img src="{{ asset(Storage::url('uploads/is_cover_image/default.jpg')) }}" alt="">
                                                                    @endif                                                                
                                                                </div>
                                                                <a href="#" class=" text-dark f-w-600">{{ $product->name }}</a>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            @if($product->enable_product_variant == 'on')
                                                                {{ __("In Variant") }}
                                                            @else   
                                                                {{ $product->quantity }}
                                                            @endif  
                                                        </td>
                                                        <td>
                                                            <span class="f-w-700">
                                                                @if($product->enable_product_variant == 'on')
                                                                    {{ __("In Variant") }}
                                                                @else   
                                                                    {{ \App\Models\Utility::priceFormat($product->price) }}
                                                                @endif  
                                                            </span>
                                                        </td>
                                                        <td><span class="badge rounded p-2 f-10 bg-light-primary">{{ $totle_qty[$k] }}
                                                            {{ __('Sold') }}</span></td>
                                                    </tr>
                                                @endif
                                            @endforeach
                                        @endforeach
                                    @else
                                        <tr height="150px">
                                            <td class="dataTables-empty" colspan="4"> 
                                                {{ __('No data available in table.') }}
                                            </td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <h4>{{ __('Orders') }}</h4>
                <div class="card shadow-none mb-0">
                    <div class="card-body p-3 rounded border">
                        <div id="traffic-chart"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <h2 class="f-w-900 mb-3">{{ __('Recent Orders') }}</h2>
            </div>
            <div class="col-12">
                <div class="card mb-0 shadow-none">
                    <div class="card-body border border-bottom-0 overflow-hidden rounded pb-0 table-border-style">
                        <div class="table-responsive">
                            <table class="table mb-0">
                                <thead>
                                    <tr>
                                        <th class="bg-transparent">{{ __('Orders') }}</th>
                                        <th class="bg-transparent">{{ __('Date') }}</th>
                                        <th class="bg-transparent">{{ __('Name') }}</th>
                                        <th class="bg-transparent">{{ __('Value') }}</th>
                                        <th class="bg-transparent">{{ __('Payment Type') }}</th>
                                        <th class="bg-transparent">{{ __('Status') }}</th>
                                        <th class="bg-transparent">{{ __('Action') }}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if (!empty($new_orders))
                                        @foreach ($new_orders as $order)
                                            @if ($order->status != 'Cancel Order')
                                                <tr>
                                                    <td>
                                                    <a href="{{ route('orders.show', \Illuminate\Support\Facades\Crypt::encrypt($order->id)) }}" class="btn  btn-outline-primary"  data-link="{{ $store_id['store_url'] }}" data-bs-toggle="tooltip" data-toggle="tooltip" data-bs-original-title="{{__('Details')}}" title="{{__('Details')}}">{{ $order->order_id }}</a>
                                                    </td>
                                                    <td> {{ \App\Models\Utility::dateFormat($order->created_at) }}</td>
                                                    <td>{{ $order->name }}</td>
                                                    <td> {{ \App\Models\Utility::priceFormat($order->price) }}</td>
                                                    <td>{{ $order->payment_type }}</td>
                                                    <td>
                                                        @if ($order->payment_status == 'approved' && $order->status == 'pending')
                                                            <span class="badge me-2 rounded p-2  bg-light-secondary">{{ __('Pending') }}</span>
                                                            {{ \App\Models\Utility::dateFormat($order->created_at) }}
                                                        @else
                                                            <span class="badge me-2 rounded p-2  bg-light-primary">{{ __('Delivered') }}</span>
                                                            {{ \App\Models\Utility::dateFormat($order->updated_at) }}
                                                        @endif
                                                    </td>
                                                    <td>
                                                        <a href="{{ route('orders.show', \Illuminate\Support\Facades\Crypt::encrypt($order->id)) }}" class="btn btn-sm btn-icon  bg-light-secondary me-2" data-bs-toggle="tooltip" data-bs-placement="top" title="{{ __('Details') }}"> <i  class="ti ti-eye f-20"></i></a>
                                                    </td>
                                                </tr>        
                                            @endif
                                        @endforeach
                                    @endif
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- [ sample-page ] end -->
</div>
<!-- [ Main Content ] end -->


@endif
@endsection
@push('script-page')
<style>
    /* Styles pour le calendrier */
    .progress-container {
        height: 12px;
        background-color: #e5e7eb;
        border-radius: 6px;
        overflow: hidden;
    }
    .progress-bar {
        height: 100%;
        border-radius: 6px;
        transition: width 0.5s ease-in-out;
    }
    .calendar-day {
        min-width: 36px;
        transition: all 0.2s ease;
    }
    .calendar-day:hover {
        transform: translateY(-3px);
    }
    .week-container {
        background-color: white;
        border-radius: 0.75rem;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        transition: all 0.3s ease;
    }
    .week-container:hover {
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        transform: translateY(-2px);
    }
    .week-label {
        background: linear-gradient(to right, #6366f1, #8b5cf6);
        color: white;
        border-radius: 0.5rem 0.5rem 0 0;
        font-weight: 600;
        text-align: center;
        padding: 0.25rem 0;
        font-size: 0.875rem;
    }
    .week-total {
        background-color: #f3f4f6;
        border-radius: 0 0 0.5rem 0.5rem;
        text-align: center;
        padding: 0.25rem 0;
        font-weight: 500;
        font-size: 0.875rem;
    }
    .current-day {
        position: relative;
    }
    .current-day::after {
        content: '';
        position: absolute;
        bottom: -2px;
        left: 50%;
        transform: translateX(-50%);
        width: 6px;
        height: 6px;
        background-color: #3b82f6;
        border-radius: 50%;
    }
    .day-capsule {
        background-color: #f9fafb;
        border-radius: 0.5rem;
        margin: 0.15rem;
        padding: 0.25rem;
        transition: all 0.2s ease;
        transform-origin: center;
        box-shadow: 0 1px 2px rgba(0,0,0,0.05);
    }
    .day-capsule:hover {
        transform: scale(1.08);
        background-color: #f3f4f6;
        box-shadow: 0 3px 6px rgba(0,0,0,0.1);
        z-index: 10;
    }
    #today-progress-bar {
        background: linear-gradient(to right, #4ade80, #10b981);
    }
    #week-progress-bar {
        background: linear-gradient(to right, #60a5fa, #3b82f6);
    }
    #month-progress-bar {
        background: linear-gradient(to right, #c084fc, #8b5cf6);
    }
    #year-progress-bar {
        background: linear-gradient(to right, #fb7185, #e11d48);
    }
    .milestone {
        position: absolute;
        top: -4px;
        width: 4px;
        height: 20px;
        background-color: rgba(0, 0, 0, 0.3);
        z-index: 2;
    }
    .milestone-label {
        position: absolute;
        top: -25px;
        transform: translateX(-50%);
        font-size: 10px;
        color: #64748b;
        font-weight: 600;
    }
    .trophy {
        position: absolute;
        width: 20px;
        height: 20px;
        background-color: #fbbf24;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: bold;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transform: translateY(-50%);
        z-index: 10;
    }
</style>

<script>
    // Script pour le calendrier
    document.addEventListener('DOMContentLoaded', function() {
        // Charger les données de ventes réelles
        loadRealSalesData();
        
        // Charger les objectifs sauvegardés
        loadGoals();
        
        // Générer le calendrier du mois
        generateSimplifiedCalendar();
        
        // Initialiser les barres de progression
        updateProgressBars();
        
        // Afficher un message motivant
        displayMotivationalMessage();
    });

    function generateSimplifiedCalendar() {
        const today = new Date();
        const currentMonth = today.getMonth();
        const currentYear = today.getFullYear();
        
        // Déterminer le nombre de jours dans le mois actuel
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
        
        // Générer des données fictives pour les montants gagnés
        const dailyEarnings = generateDailyEarnings(daysInMonth);
        
        // Calculer le total mensuel
        const monthlyTotal = dailyEarnings.reduce((sum, amount) => sum + amount, 0);
        document.getElementById('monthly-total').textContent = `Total: ${formatCurrency(monthlyTotal)}`;
        
        // Jours de la semaine
        const weekdayNames = ['Lu', 'Ma', 'Me', 'Je', 'Ve', 'Sa', 'Di'];
        
        // Diviser le mois en 4 semaines exactement
        // Calculer le nombre de jours par semaine (arrondi)
        const daysPerWeek = Math.ceil(daysInMonth / 4);
        
        // Créer 4 semaines
        for (let weekIndex = 0; weekIndex < 4; weekIndex++) {
            const weekContainer = document.getElementById(`week${weekIndex + 1}`);
            if (!weekContainer) continue;
            
            let weekTotal = 0;
            
            // Ajouter les en-têtes des jours de la semaine
            weekdayNames.forEach(dayName => {
                const dayHeader = document.createElement('div');
                dayHeader.className = 'text-xs text-muted py-1';
                dayHeader.textContent = dayName;
                weekContainer.appendChild(dayHeader);
            });
            
            // Calculer les jours pour cette semaine
            const startDay = weekIndex * daysPerWeek + 1;
            const endDay = Math.min(daysInMonth, (weekIndex + 1) * daysPerWeek);
            
            // Créer un tableau pour les jours de cette semaine
            const weekDays = [];
            for (let day = startDay; day <= endDay; day++) {
                weekDays.push(day);
            }
            
            // Ajouter des espaces vides au début si nécessaire pour aligner sur les jours de la semaine
            if (weekIndex === 0) {
                const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
                const firstDayIndex = firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1; // Convertir en format lundi=0, dimanche=6
                
                for (let i = 0; i < firstDayIndex; i++) {
                    weekDays.unshift(null); // Ajouter des jours vides au début
                }
            }
            
            // S'assurer qu'il y a exactement 7 jours dans la semaine
            while (weekDays.length < 7) {
                weekDays.push(null); // Ajouter des jours vides à la fin
            }
            while (weekDays.length > 7) {
                weekDays.pop(); // Supprimer les jours excédentaires
            }
            
            // Ajouter les jours à la semaine
            weekDays.forEach(day => {
                if (day === null) {
                    // Jour vide
                    const emptyDay = document.createElement('div');
                    emptyDay.className = 'day-capsule opacity-30';
                    emptyDay.innerHTML = '<div class="text-xs text-center">-</div>';
                    weekContainer.appendChild(emptyDay);
                } else {
                    const date = new Date(currentYear, currentMonth, day);
                    const isPast = date < new Date(today.setHours(0, 0, 0, 0));
                    const isToday = day === today.getDate();
                    const amount = dailyEarnings[day - 1];
                    
                    if (isPast && amount > 0) {
                        weekTotal += amount;
                    }
                    
                    const dayElement = document.createElement('div');
                    dayElement.className = `day-capsule ${isToday ? 'ring-2 ring-primary' : ''} ${isPast ? 'bg-light' : 'bg-white'}`;
                    
                    // Numéro du jour
                    const dayNumberElement = document.createElement('div');
                    dayNumberElement.className = `text-sm font-medium ${isToday ? 'current-day text-primary' : ''}`;
                    dayNumberElement.textContent = day;
                    
                    // Indicateur de jour passé
                    const checkElement = document.createElement('div');
                    if (isPast) {
                        // Ajouter des indicateurs visuels basés sur le montant
                        if (amount > 100) {
                            checkElement.className = 'text-warning font-bold text-xs';
                            checkElement.innerHTML = '🌟';
                        } else if (amount > 50) {
                            checkElement.className = 'text-success font-bold text-xs';
                            checkElement.innerHTML = '✓✓';
                        } else if (amount > 0) {
                            checkElement.className = 'text-success font-bold text-xs';
                            checkElement.innerHTML = '✓';
                        } else {
                            checkElement.className = 'text-muted text-xs';
                            checkElement.innerHTML = '✗';
                        }
                    } else {
                        checkElement.className = 'text-transparent text-xs';
                        checkElement.innerHTML = '·';
                    }
                    
                    // Montant gagné avec code couleur
                    const amountElement = document.createElement('div');
                    amountElement.className = `text-xs ${getAmountColorClass(amount)}`;
                    amountElement.textContent = amount > 0 ? formatCurrency(amount) : '-';
                    
                    // Assembler les éléments
                    dayElement.appendChild(dayNumberElement);
                    dayElement.appendChild(checkElement);
                    dayElement.appendChild(amountElement);
                    
                    weekContainer.appendChild(dayElement);
                }
            });
            
            // Mettre à jour le total de la semaine
            const weekTotalElement = document.getElementById(`week${weekIndex + 1}-total`);
            if (weekTotalElement) {
                weekTotalElement.textContent = `Total: ${formatCurrency(weekTotal)}`;
            }
        }
        
        // Mettre en évidence la semaine actuelle
        const currentWeekIndex = Math.min(3, Math.floor((today.getDate() - 1) / daysPerWeek));
        const weekContainers = document.querySelectorAll('.week-container');
        if (weekContainers.length > currentWeekIndex) {
            weekContainers[currentWeekIndex].classList.add('border', 'border-primary');
        }
    }
    
    function getAmountColorClass(amount) {
        const dailyTarget = 100; // Objectif journalier par défaut
        if (amount > dailyTarget) return 'text-warning font-bold';
        if (amount > dailyTarget * 0.75) return 'text-success';
        if (amount > dailyTarget * 0.5) return 'text-success';
        if (amount > dailyTarget * 0.3) return 'text-primary';
        return 'text-muted';
    }
    
    function formatCurrency(amount, short = false) {
        const BILLION = 1000000000; // 1 milliard DA
        const MILLION = 1000000;    // 1 million DA
        
        if (short) {
            if (amount >= BILLION) {
                return (amount / BILLION).toFixed(1) + ' B';
            } else if (amount >= MILLION) {
                return (amount / MILLION).toFixed(1) + ' M';
            } else if (amount >= 1000) {
                return (amount / 1000).toFixed(1) + ' K';
            } else {
                return amount.toString();
            }
        }
        
        return new Intl.NumberFormat('fr-DZ', {
            style: 'currency',
            currency: 'DZD',
            maximumFractionDigits: 0
        }).format(amount);
    }
    
    // Variable globale pour stocker les gains journaliers
    let globalDailyEarnings = [];
    
    function generateDailyEarnings(days) {
        // Si les données sont déjà générées, les retourner
        if (globalDailyEarnings.length === days) {
            return globalDailyEarnings;
        }
        
        // Utiliser les données de ventes réelles du système
        const earnings = new Array(days).fill(0);
        
        // Remplir le tableau avec les données de ventes réelles
        if (sales && sales.length > 0) {
            // Regrouper les ventes par jour
            sales.forEach(sale => {
                const saleDate = new Date(sale.date);
                const day = saleDate.getDate() - 1; // Les jours commencent à 1, les indices à 0
                
                // S'assurer que la vente est pour le mois en cours et que l'indice est valide
                const today = new Date();
                if (saleDate.getMonth() === today.getMonth() && 
                    saleDate.getFullYear() === today.getFullYear() && 
                    day >= 0 && day < days) {
                    earnings[day] += sale.amount;
                }
            });
        } else {
            // Si aucune donnée n'est disponible, utiliser le total des ventes du système
            const totalSale = {{ $totle_sale ?? 0 }};
            const today = new Date();
            const currentDay = today.getDate();
            
            // Répartir le montant total sur les jours écoulés du mois
            if (currentDay > 0) {
                const dailyAverage = totalSale / currentDay;
                
                for (let i = 0; i < days; i++) {
                    if (i < currentDay) {
                        // Ajouter une variation aléatoire pour les jours passés
                        const variation = 0.7 + (Math.random() * 0.6); // Entre 0.7 et 1.3
                        earnings[i] = Math.round(dailyAverage * variation);
                    } else {
                        // Jours futurs à zéro
                        earnings[i] = 0;
                    }
                }
            }
        }
        
        // Stocker les données pour une utilisation ultérieure
        globalDailyEarnings = earnings;
        return earnings;
    }
    
    function updateProgressBars() {
        // Récupérer les données réelles du système
        const totalSale = {{ $totle_sale ?? 0 }};
        const totalOrder = {{ $totle_order ?? 0 }};
        
        // Générer les données de gains pour le mois
        const today = new Date();
        const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
        const dailyEarnings = generateDailyEarnings(daysInMonth);
        
        // Calculer l'objectif journalier basé sur le total des ventes
        // Nous utilisons le total des ventes divisé par le nombre de jours dans l'année
        // multiplié par un facteur de croissance pour fixer un objectif ambitieux
        const growthFactor = 1.2; // 20% de croissance visée
        const daysInYear = new Date(today.getFullYear(), 11, 31).getDate() === 31 ? 365 : 366;
        const annualTarget = totalSale * growthFactor;
        const dailyGoal = Math.round(annualTarget / daysInYear);
        
        // Calculer les statistiques basées sur les gains
        const todayEarnings = today.getDate() > 0 ? dailyEarnings[today.getDate() - 1] || 0 : 0;
        
        // Calculer les gains de la semaine
        const dayOfWeek = today.getDay() || 7; // 0 = dimanche, donc on le transforme en 7
        let weekEarnings = 0;
        for (let i = 0; i < dayOfWeek; i++) {
            const dayIndex = today.getDate() - dayOfWeek + i;
            if (dayIndex >= 0 && dayIndex < dailyEarnings.length) {
                weekEarnings += dailyEarnings[dayIndex] || 0;
            }
        }
        const weekGoal = dailyGoal * 7;
        
        // Calculer les gains du mois
        let monthEarnings = 0;
        for (let i = 0; i < today.getDate(); i++) {
            monthEarnings += dailyEarnings[i] || 0;
        }
        const monthGoal = dailyGoal * daysInMonth;
        
        // Calculer les gains de l'année
        // Nous utilisons le total des ventes réelles pour l'année en cours
        const yearEarnings = totalSale;
        const yearGoal = dailyGoal * daysInYear;
        
        // Mise à jour des barres de progression
        
        // Progression journalière
        const todayPercentage = Math.min(100, (todayEarnings / dailyGoal) * 100);
        const todayProgressBar = document.getElementById('today-progress-bar');
        const todayProgress = document.getElementById('today-progress');
        if (todayProgressBar && todayProgress) {
            todayProgressBar.style.width = `${todayPercentage}%`;
            todayProgress.textContent = `${formatCurrency(todayEarnings)} / ${formatCurrency(dailyGoal)} (${Math.round(todayPercentage)}%)`;
        }
        
        // Progression hebdomadaire
        const weekPercentage = Math.min(100, (weekEarnings / weekGoal) * 100);
        const weekProgressBar = document.getElementById('week-progress-bar');
        const weekProgressElement = document.getElementById('week-progress');
        if (weekProgressBar && weekProgressElement) {
            weekProgressBar.style.width = `${weekPercentage}%`;
            weekProgressElement.textContent = `${formatCurrency(weekEarnings)} / ${formatCurrency(weekGoal)} (${Math.round(weekPercentage)}%)`;
        }
        
        // Progression mensuelle
        const monthPercentage = Math.min(100, (monthEarnings / monthGoal) * 100);
        const monthProgressBar = document.getElementById('month-progress-bar');
        const monthProgressElement = document.getElementById('month-progress');
        if (monthProgressBar && monthProgressElement) {
            monthProgressBar.style.width = `${monthPercentage}%`;
            monthProgressElement.textContent = `${formatCurrency(monthEarnings)} / ${formatCurrency(monthGoal)} (${Math.round(monthPercentage)}%)`;
        }
        
        // Progression annuelle
        const yearPercentage = Math.min(100, (yearEarnings / yearGoal) * 100);
        const yearProgressBar = document.getElementById('year-progress-bar');
        const yearProgressElement = document.getElementById('year-progress');
        if (yearProgressBar && yearProgressElement) {
            yearProgressBar.style.width = `${yearPercentage}%`;
            yearProgressElement.textContent = `${formatCurrency(yearEarnings)} / ${formatCurrency(yearGoal)} (${Math.round(yearPercentage)}%)`;
        }
        
        // Mise à jour des milestones pour chaque barre de progression
        updateProgressBarMilestones('today', todayEarnings, dailyGoal, [dailyGoal * 0.25, dailyGoal * 0.5, dailyGoal * 0.75, dailyGoal]);
        updateProgressBarMilestones('week', weekEarnings, weekGoal, [weekGoal * 0.25, weekGoal * 0.5, weekGoal * 0.75, weekGoal]);
        updateProgressBarMilestones('month', monthEarnings, monthGoal, [monthGoal * 0.25, monthGoal * 0.5, monthGoal * 0.75, monthGoal]);
        updateProgressBarMilestones('year', yearEarnings, yearGoal, [yearGoal * 0.25, yearGoal * 0.5, yearGoal * 0.75, yearGoal]);
    }
    
    function updateProgressBarMilestones(id, current, target, milestones) {
        const progressContainer = document.getElementById(`${id}-progress-bar`).parentElement;
        
        // Clear existing milestones
        progressContainer.querySelectorAll('.milestone, .milestone-label, .trophy').forEach(el => el.remove());
        
        // Add new milestones
        milestones.forEach((milestone, index) => {
            const milestonePercentage = (milestone / target) * 100;
            if (milestonePercentage <= 100) {
                // Add milestone marker
                const milestoneElement = document.createElement('div');
                milestoneElement.className = 'milestone';
                milestoneElement.style.left = `${milestonePercentage}%`;
                progressContainer.appendChild(milestoneElement);
                
                // Add milestone label
                const milestoneLabel = document.createElement('div');
                milestoneLabel.className = 'milestone-label';
                milestoneLabel.textContent = formatCurrency(milestone, true);
                milestoneLabel.style.left = `${milestonePercentage}%`;
                progressContainer.appendChild(milestoneLabel);
                
                // Add trophy if milestone is reached
                if (current >= milestone) {
                    const trophy = document.createElement('div');
                    trophy.className = 'trophy';
                    trophy.innerHTML = '🏆';
                    trophy.style.left = `${milestonePercentage}%`;
                    trophy.dataset.tooltip = `Palier ${formatCurrency(milestone, true)} atteint !`;
                    trophy.classList.add('tooltip');
                    progressContainer.appendChild(trophy);
                }
            }
        });
    }
    
    function displayMotivationalMessage() {
        const messages = [
            "Continuez comme ça ! Chaque semaine vous rapproche de vos objectifs 💪",
            "Vous êtes sur la bonne voie ! Concentrez-vous sur une semaine à la fois 🚀",
            "Votre constance paie, gardez le rythme ! ✨",
            "Bravo pour votre progression ! Une semaine après l'autre 🎯",
            "Petit à petit, l'oiseau fait son nid ! 🌟"
        ];
        
        const messageElement = document.getElementById('motivation-message');
        if (messageElement) {
            const randomIndex = Math.floor(Math.random() * messages.length);
            messageElement.textContent = messages[randomIndex];
        }
    }
</script>

@if (\Auth::user()->type == 'super admin')
<script>
    (function() {
        var options = {
            chart: {
                height: 250,
                type: 'area',
                toolbar: {
                    show: false,
                },
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                width: 2,
                curve: 'smooth'
            },


            series: [{
                name: "{{ __('Order') }}",
                data: {!! json_encode($chartData['data']) !!}
            }],

            xaxis: {
                axisBorder: {
                    show: !1
                },
                type: "MMM",
                categories: {!! json_encode($chartData['label']) !!},
                title: {
                    text: '{{ __("Days") }}'
                }
            },
            colors: ['#e83e8c'],

            grid: {
                strokeDashArray: 4,
            },
            legend: {
                show: false,
            },
            // markers: {
            //     size: 4,
            //     colors: ['#FFA21D'],
            //     opacity: 0.9,
            //     strokeWidth: 2,
            //     hover: {
            //         size: 7,
            //     }
            // },
            yaxis: {
                tickAmount: 3,
                title: {
                text: '{{ __("Amount") }}'
            },
            }
        };
        var chart = new ApexCharts(document.querySelector("#plan_order"), options);
        chart.render();
    })();
   
</script>
@else
<script>
    $(document).ready(function() {
        $('.cp_link').on('click', function() {
            var value = $(this).attr('data-link');
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val(value).select();
            document.execCommand("copy");
            $temp.remove();
            show_toastr('Success', '{{ __('Link copied') }}', 'success')
        });
    });
    (function () {
        var options = {
            chart: {
                height: 250,
                type: 'area',
                toolbar: {
                    show: false,
                },
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                width: 2,
                curve: 'smooth'
            },
            series: [{
                name: "{{ __('Order') }}",
                data: {!! json_encode($chartData['data']) !!}
            }],
            xaxis: {
                axisBorder: {
                    show: !1
                },
                type: "MMM",
                categories: {!! json_encode($chartData['label']) !!},
                title: {
                    text: '{{ __("Days") }}'
                }
            },
            colors: ['#ffa21d', '#FF3A6E'],

            grid: {
                strokeDashArray: 4,
            },
            legend: {
                show: false,
            },
            yaxis: {
                tickAmount: 3,
                title: {
                text: '{{ __("Amount") }}'
            },
            }
        };
        var chart = new ApexCharts(document.querySelector("#traffic-chart"), options);
        chart.render();
    })();
    (function () {
        var options = {
            chart: {
                height: 80,
                type: 'area',
                toolbar: {
                    show: false,
                },
            },
            dataLabels: {
                enabled: false,
                show:false,
            },
            stroke: {
                width: 2,
                curve: 'smooth',
            },
            series: [{
                name: "{{ __('Sales') }}",
                data: {!! json_encode($saleData['data']) !!}
            }],
            colors: ['#6FD943'],
            grid: {
                strokeDashArray: 4,
                show: false,
            },
            legend: {
                show: false,
            },
            markers: {
                enabled: false
            },
            yaxis: {
                show: false,
            },
            xaxis: {
                labels: {
                    show: false,
                },
                axisBorder: {
                    show: false,
                },
                axisTicks: {
                    show: false,
                },
                tooltip: {
                    enabled: false,
                }
            },
            tooltip: {
                enabled: false,
            },
            fill: {
                type: 'gradient',
                gradient: {
                    shade: 'dark',
                    type: "horizontal",
                    shadeIntensity: 0,
                    gradientToColors: undefined, 
                    inverseColors: true,
                    opacityFrom: 0,
                    opacityTo: 0,
                    stops: [0, 50, 100],
                    colorStops: []
                }
            }
        };
        var chart = new ApexCharts(document.querySelector("#TotalSales"), options);
        chart.render();
    })();
    (function () {
        var options = {
            chart: {
                height: 80,
                type: 'area',
                toolbar: {
                    show: false,
                },
            },
            dataLabels: {
                enabled: false,
                show:false,
            },
            stroke: {
                width: 2,
                curve: 'smooth',
            },
            series: [{
                name: "{{ __('Order') }}",
                data: {!! json_encode($chartData['data']) !!}
            }],
            colors: ['#6FD943'],
            grid: {
                strokeDashArray: 4,
                show: false,
            },
            legend: {
                show: false,
            },
            markers: {
                enabled: false
            },
            yaxis: {
                show: false,
            },
            xaxis: {
                labels: {
                    show: false,
                },
                axisBorder: {
                    show: false,
                },
                axisTicks: {
                    show: false,
                },
                tooltip: {
                    enabled: false,
                }
            },
            tooltip: {
                enabled: false,
            },
            fill: {
                type: 'gradient',
                gradient: {
                    shade: 'dark',
                    type: "horizontal",
                    shadeIntensity: 0,
                    gradientToColors: undefined, 
                    inverseColors: true,
                    opacityFrom: 0,
                    opacityTo: 0,
                    stops: [0, 50, 100],
                    colorStops: []
                }
            }
        };
        var chart = new ApexCharts(document.querySelector("#TotalOrders"), options);
        chart.render();
    })();
    (function () {
        var options = {
            chart: {
                height: 80,
                type: 'area',
                toolbar: {
                    show: false,
                },
            },
            dataLabels: {
                enabled: false,
                show:false,
            },
            stroke: {
                width: 2,
                curve: 'smooth',
            },
            series: [{
                name: "{{ __('Order') }}",
                data: []
            }],
            colors: ['#6FD943'],
            grid: {
                strokeDashArray: 4,
                show: false,
            },
            legend: {
                show: false,
            },
            markers: {
                enabled: false
            },
            yaxis: {
                show: false,
            },
            xaxis: {
                labels: {
                    show: false,
                },
                axisBorder: {
                    show: false,
                },
                axisTicks: {
                    show: false,
                },
                tooltip: {
                    enabled: false,
                }
            },
            tooltip: {
                enabled: false,
            },
            fill: {
                type: 'gradient',
                gradient: {
                    shade: 'dark',
                    type: "horizontal",
                    shadeIntensity: 0,
                    gradientToColors: undefined, 
                    inverseColors: true,
                    opacityFrom: 0,
                    opacityTo: 0,
                    stops: [0, 50, 100],
                    colorStops: []
                }
            }
        };
        var chart = new ApexCharts(document.querySelector("#TotalProducts"), options);
        chart.render();
    })();

    (function () {
        var options = {
            series: [{{ round($storage_limit,2) }}],
            chart: {
                height: 350,
                type: 'radialBar',
                offsetY: -20,
                sparkline: {
                    enabled: true
                }
            },
            plotOptions: {
                radialBar: {
                    startAngle: -90,
                    endAngle: 90,
                    track: {
                        background: "#e7e7e7",
                        strokeWidth: '97%',
                        margin: 5, // margin is in pixels
                    },
                    dataLabels: {
                        name: {
                            show: true
                        },
                        value: {
                            offsetY: -50,
                            fontSize: '20px'
                        }
                    }
                }
            },
            grid: {
                padding: {
                    top: -10
                }
            },
            colors: ["#6FD943"],
            labels: ['Used'],
        };
        var chart = new ApexCharts(document.querySelector("#device-chart"), options);
        chart.render();
    })();
</script>
@endif
@endpush
