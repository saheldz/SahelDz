<?php
/**
 * Version simplifiée pour diagnostic
 */

// Activer les erreurs pour debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!-- Test 1: PHP fonctionne -->\n";

try {
    require_once 'config/database.php';
    echo "<!-- Test 2: database.php chargé -->\n";
    
    require_once 'config/auth-check.php';
    echo "<!-- Test 3: auth-check.php chargé -->\n";
    
    // Vérifier si l'utilisateur est connecté
    if (!isset($_SESSION['user_id'])) {
        die('<h1>Erreur: Vous devez être connecté</h1><a href="/login.html">Se connecter</a>');
    }
    echo "<!-- Test 4: Utilisateur connecté -->\n";
    
    $pdo = getDB();
    echo "<!-- Test 5: Connexion DB établie -->\n";
    
    // Vérifier si les tables existent
    $tables = ['subscription_plans', 'subscriptions'];
    foreach ($tables as $table) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        if (!$stmt->fetch()) {
            die("<h1>Erreur: Table '$table' n'existe pas</h1>
                 <p>Installez l'addon d'abord: <a href='/addons/subscriptions/install.php'>Installer</a></p>");
        }
    }
    echo "<!-- Test 6: Tables existent -->\n";
    
    $userId = $_SESSION['user_id'];
    
    // Essayer de récupérer les plans
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM subscription_plans WHERE status = 'active'");
    $result = $stmt->fetch();
    $planCount = $result['count'];
    echo "<!-- Test 7: $planCount plans trouvés -->\n";
    
} catch (Exception $e) {
    die("<h1>Erreur</h1><pre>" . htmlspecialchars($e->getMessage()) . "</pre>");
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test - Abonnements</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 p-8">
    <div class="max-w-4xl mx-auto">
        <div class="bg-white rounded-lg shadow-lg p-8">
            <h1 class="text-3xl font-bold mb-4">✅ Diagnostic Réussi</h1>
            
            <div class="space-y-2 mb-6">
                <p>✅ PHP fonctionne</p>
                <p>✅ Base de données connectée</p>
                <p>✅ Utilisateur connecté (ID: <?php echo $userId; ?>)</p>
                <p>✅ Tables installées</p>
                <p>✅ <?php echo $planCount; ?> plan(s) disponible(s)</p>
            </div>
            
            <?php if ($planCount === 0): ?>
            <div class="bg-yellow-100 border-l-4 border-yellow-500 p-4 mb-6">
                <p class="font-bold">⚠️ Aucun plan disponible</p>
                <p>Créez des plans d'abord : <a href="/addons/subscriptions/admin/dashboard.php" class="text-blue-600 underline">Dashboard Admin</a></p>
            </div>
            <?php else: ?>
            <div class="bg-green-100 border-l-4 border-green-500 p-4 mb-6">
                <p class="font-bold">✅ Tout est prêt !</p>
                <p>Le système fonctionne correctement</p>
            </div>
            <?php endif; ?>
            
            <div class="flex gap-4">
                <a href="/client-subscriptions.php" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                    Aller aux Abonnements
                </a>
                <a href="/client-dashboard.php" class="bg-gray-600 text-white px-6 py-2 rounded hover:bg-gray-700">
                    Retour Dashboard
                </a>
            </div>
        </div>
    </div>
</body>
</html>
