<?php
/**
 * Créer la table wallet_transactions manquante
 */

require_once 'config/database.php';

$pdo = getDB();

echo "=== CREATION TABLE WALLET_TRANSACTIONS ===\n\n";

try {
    // Vérifier si la table existe
    $stmt = $pdo->query("SHOW TABLES LIKE 'wallet_transactions'");
    
    if ($stmt->rowCount() > 0) {
        echo "✅ Table wallet_transactions existe déjà\n";
    } else {
        echo "📝 Création de la table wallet_transactions...\n";
        
        $sql = "CREATE TABLE wallet_transactions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            type ENUM('credit', 'debit') NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user (user_id),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $pdo->exec($sql);
        echo "✅ Table wallet_transactions créée avec succès\n";
    }
    
    // Vérifier la structure de la table orders
    echo "\n📋 Vérification de la table orders...\n";
    $stmt = $pdo->query("DESCRIBE orders");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $required_columns = ['id', 'user_id', 'item_id', 'order_number', 'item_name', 'price', 'status', 'created_at'];
    $missing = array_diff($required_columns, $columns);
    
    if (empty($missing)) {
        echo "✅ Table orders a toutes les colonnes requises\n";
    } else {
        echo "⚠️  Colonnes manquantes dans orders: " . implode(', ', $missing) . "\n";
    }
    
    echo "\n=== FIN ===\n";
    echo "\nMaintenant, essayez de créer une commande à nouveau.\n";
    
} catch (PDOException $e) {
    echo "❌ ERREUR: " . $e->getMessage() . "\n";
}
