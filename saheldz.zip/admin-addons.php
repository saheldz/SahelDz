<?php
/**
 * Gestionnaire d'Addons - Admin
 * Version améliorée avec gestion d'erreurs robuste
 */
require_once 'config/auth-check.php';
require_once 'config/database.php';

if (!isAdmin()) {
    header('Location: /index.php');
    exit;
}

// Créer le dossier addons s'il n'existe pas
if (!file_exists('addons')) {
    mkdir('addons', 0755, true);
}

$pdo = getDB();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionnaire d'Addons - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <?php include 'config/impersonation-banner.php'; ?>
    
    <nav class="bg-gradient-to-r from-purple-600 to-blue-600 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <a href="/admin-dashboard.php" class="text-white hover:text-purple-200 font-medium">← Dashboard</a>
                    <h1 class="text-2xl font-bold text-white">🧩 Gestionnaire d'Addons</h1>
                </div>
                <div class="text-white text-sm"><?php echo htmlspecialchars($GLOBALS['current_user']['full_name']); ?></div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        
        <!-- Section Upload avec barre de progression -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h2 class="text-xl font-bold mb-4">📦 Installer un nouveau addon</h2>
            
            <div id="upload-area" class="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <div class="mb-4">
                    <svg class="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48">
                        <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </div>
                <label class="cursor-pointer">
                    <span class="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 inline-block font-semibold">
                        📁 Sélectionner un fichier ZIP
                    </span>
                    <input type="file" id="addon-file" accept=".zip" class="hidden" onchange="handleFileSelect(event)">
                </label>
                <p class="text-sm text-gray-500 mt-4">
                    Formats acceptés : .zip (max 50MB)<br>
                    Le fichier ZIP doit contenir un fichier addon.json
                </p>
            </div>

            <!-- Barre de progression -->
            <div id="upload-progress" class="hidden mt-4">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-sm font-medium text-gray-700" id="upload-status">Upload en cours...</span>
                    <span class="text-sm font-medium text-gray-700" id="upload-percent">0%</span>
                </div>
                <div class="w-full bg-gray-200 rounded-full h-2.5">
                    <div id="upload-bar" class="bg-purple-600 h-2.5 rounded-full transition-all duration-300" style="width: 0%"></div>
                </div>
            </div>

            <!-- Informations du fichier -->
            <div id="file-info" class="hidden mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h3 class="font-semibold text-blue-900 mb-2">📄 Fichier sélectionné</h3>
                <div class="text-sm text-blue-800 space-y-1">
                    <p><strong>Nom :</strong> <span id="file-name"></span></p>
                    <p><strong>Taille :</strong> <span id="file-size"></span></p>
                </div>
                <button onclick="uploadAddon()" class="mt-3 bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700 font-semibold">
                    🚀 Installer maintenant
                </button>
                <button onclick="cancelUpload()" class="mt-3 ml-2 bg-gray-300 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-400 font-semibold">
                    ✕ Annuler
                </button>
            </div>
        </div>

        <!-- Tabs -->
        <div class="bg-white rounded-xl shadow-lg mb-6">
            <div class="flex border-b">
                <button onclick="showTab('installed')" id="tab-installed" class="flex-1 px-6 py-4 font-semibold border-b-2 border-purple-600 text-purple-600">
                    🟢 Installés
                </button>
                <button onclick="showTab('documentation')" id="tab-documentation" class="flex-1 px-6 py-4 font-semibold text-gray-500 hover:text-gray-700">
                    📚 Documentation
                </button>
            </div>
        </div>

        <!-- Tab: Installés -->
        <div id="content-installed" class="tab-content">
            <div class="mb-4 flex justify-between items-center">
                <div>
                    <h2 class="text-xl font-bold text-gray-800">Addons Installés</h2>
                    <p class="text-sm text-gray-600">Gérez vos addons actifs et inactifs</p>
                </div>
                <button onclick="loadInstalledAddons()" class="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 font-semibold">
                    🔄 Actualiser
                </button>
            </div>
            
            <div id="installed-addons" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div class="col-span-full text-center py-12">
                    <div class="text-4xl mb-4">⏳</div>
                    <p class="text-gray-600">Chargement...</p>
                </div>
            </div>
        </div>

        <!-- Tab: Documentation -->
        <div id="content-documentation" class="tab-content hidden">
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h2 class="text-2xl font-bold mb-6">📚 Documentation : Créer un addon</h2>
                
                <div class="space-y-6">
                    <div class="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                        <h3 class="font-bold text-blue-900 mb-2">📁 Structure d'un addon</h3>
                        <pre class="bg-blue-900 text-blue-100 p-4 rounded text-sm overflow-x-auto"><code>mon-addon/
├── addon.json          # ✅ Métadonnées (OBLIGATOIRE)
├── install.php         # ✅ Installation des tables/données
├── uninstall.php       # Désinstallation propre
├── activate.php        # Exécuté lors de l'activation
├── deactivate.php      # Exécuté lors de la désactivation
├── README.md           # Documentation utilisateur
├── admin/              # Interface d'administration
│   ├── dashboard.php   # Page principale
│   └── settings.php    # Configuration
├── api/                # Endpoints API
│   └── endpoints.php
└── assets/             # Ressources (optionnel)
    ├── style.css
    └── script.js</code></pre>
                    </div>

                    <div class="bg-green-50 border-l-4 border-green-500 p-4 rounded">
                        <h3 class="font-bold text-green-900 mb-2">📄 Fichier addon.json (OBLIGATOIRE)</h3>
                        <pre class="bg-green-900 text-green-100 p-4 rounded text-sm overflow-x-auto"><code>{
  "name": "mon-addon",
  "display_name": "Mon Super Addon",
  "description": "Description courte de l'addon",
  "version": "1.0.0",
  "author": "Votre Nom",
  "author_url": "https://votresite.com",
  "icon": "🔧",
  "min_system_version": "1.0.0",
  "requires": [],
  "permissions": ["manage_data"],
  "tables": ["mon_addon_table"],
  "admin_page": {
    "title": "Mon Addon",
    "icon": "🔧",
    "url": "/addons/mon-addon/admin/dashboard.php",
    "permission": "manage_data"
  }
}</code></pre>
                    </div>

                    <div class="bg-purple-50 border-l-4 border-purple-500 p-4 rounded">
                        <h3 class="font-bold text-purple-900 mb-2">🔌 Script d'installation (install.php)</h3>
                        <pre class="bg-purple-900 text-purple-100 p-4 rounded text-sm overflow-x-auto"><code>&lt;?php
require_once __DIR__ . '/../../config/database.php';

try {
    $pdo = getDB();
    
    // Créer les tables
    $pdo->exec("CREATE TABLE IF NOT EXISTS mon_addon_table (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Insérer des données de base
    $pdo->exec("INSERT INTO mon_addon_table (name) VALUES ('Exemple')");
    
    echo json_encode(['success' => true, 'message' => 'Installation réussie']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}</code></pre>
                    </div>

                    <div class="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded">
                        <h3 class="font-bold text-yellow-900 mb-2">✅ Checklist avant publication</h3>
                        <ul class="list-disc list-inside space-y-1 text-yellow-900 text-sm">
                            <li>✅ Le fichier addon.json est présent et valide</li>
                            <li>✅ Le nom de l'addon est unique (pas de conflits)</li>
                            <li>✅ Les chemins utilisent __DIR__ pour être portables</li>
                            <li>✅ L'installation/désinstallation fonctionne correctement</li>
                            <li>✅ Les permissions sont vérifiées dans les pages admin</li>
                            <li>✅ Les erreurs SQL sont gérées proprement</li>
                            <li>✅ Le code est documenté et testé</li>
                        </ul>
                    </div>

                    <div class="bg-red-50 border-l-4 border-red-500 p-4 rounded">
                        <h3 class="font-bold text-red-900 mb-2">⚠️ Erreurs courantes à éviter</h3>
                        <ul class="list-disc list-inside space-y-1 text-red-900 text-sm">
                            <li>❌ Utiliser des chemins relatifs sans __DIR__</li>
                            <li>❌ Oublier de vérifier si les tables existent</li>
                            <li>❌ Ne pas gérer les erreurs SQL</li>
                            <li>❌ Conflits de noms de tables avec d'autres addons</li>
                            <li>❌ Oublier les autorisations admin</li>
                            <li>❌ Ne pas valider les entrées utilisateur</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Modal Détails Addon -->
    <div id="addon-details-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-xl shadow-2xl max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto m-4">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-2xl font-bold">📋 Détails de l'addon</h3>
                <button onclick="closeDetailsModal()" class="text-gray-400 hover:text-gray-600 text-2xl">×</button>
            </div>
            <div id="addon-details-content">
                <!-- Chargé via JS -->
            </div>
        </div>
    </div>

    <!-- Notification -->
    <div id="notification" class="hidden fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50"></div>

    <script>
        let selectedFile = null;

        window.addEventListener('load', loadInstalledAddons);

        // Gestion de la sélection de fichier
        function handleFileSelect(event) {
            const file = event.target.files[0];
            if (!file) return;

            // Vérifier la taille (50MB max)
            const maxSize = 50 * 1024 * 1024;
            if (file.size > maxSize) {
                showNotification('❌ Fichier trop volumineux (max 50MB)', 'error');
                event.target.value = '';
                return;
            }

            // Vérifier l'extension
            if (!file.name.endsWith('.zip')) {
                showNotification('❌ Le fichier doit être un ZIP', 'error');
                event.target.value = '';
                return;
            }

            selectedFile = file;
            document.getElementById('file-name').textContent = file.name;
            document.getElementById('file-size').textContent = formatFileSize(file.size);
            document.getElementById('file-info').classList.remove('hidden');
        }

        function cancelUpload() {
            selectedFile = null;
            document.getElementById('addon-file').value = '';
            document.getElementById('file-info').classList.add('hidden');
        }

        function formatFileSize(bytes) {
            if (bytes < 1024) return bytes + ' B';
            if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
            return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
        }

        // Charger les addons installés
        async function loadInstalledAddons() {
            try {
                const response = await fetch('/api/addons.php?action=get_installed');
                const result = await response.json();
                
                const container = document.getElementById('installed-addons');
                
                if (result.success && result.addons.length > 0) {
                    container.innerHTML = result.addons.map(addon => `
                        <div class="bg-white rounded-xl shadow-lg p-6 border-2 ${addon.active ? 'border-green-500' : 'border-gray-200'} hover:shadow-xl transition">
                            <div class="flex items-start justify-between mb-4">
                                <div class="w-12 h-12 ${addon.active ? 'bg-green-100' : 'bg-gray-100'} rounded-lg flex items-center justify-center text-2xl">
                                    ${addon.icon || '🧩'}
                                </div>
                                <span class="px-3 py-1 rounded-full text-xs font-semibold ${addon.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}">
                                    ${addon.active ? '✓ Actif' : 'Inactif'}
                                </span>
                            </div>
                            
                            <h3 class="text-lg font-bold mb-2">${addon.display_name}</h3>
                            <p class="text-sm text-gray-600 mb-4 line-clamp-2">${addon.description || 'Aucune description'}</p>
                            
                            <div class="flex items-center gap-2 text-xs text-gray-500 mb-4">
                                <span>👤 ${addon.author}</span>
                                <span>•</span>
                                <span>v${addon.version}</span>
                            </div>
                            
                            <div class="flex flex-wrap gap-2">
                                ${addon.active ? 
                                    `<button onclick="toggleAddon('${addon.name}', false)" class="flex-1 bg-yellow-100 text-yellow-700 py-2 rounded-lg hover:bg-yellow-200 font-semibold text-sm">
                                        ⏸ Désactiver
                                    </button>` :
                                    `<button onclick="toggleAddon('${addon.name}', true)" class="flex-1 bg-green-100 text-green-700 py-2 rounded-lg hover:bg-green-200 font-semibold text-sm">
                                        ▶ Activer
                                    </button>`
                                }
                                ${addon.admin_page && addon.active ? 
                                    `<button onclick="openAddon('${addon.admin_page.url}')" class="flex-1 bg-purple-100 text-purple-700 py-2 rounded-lg hover:bg-purple-200 font-semibold text-sm">
                                        🚀 Ouvrir
                                    </button>` : 
                                    `<button onclick="configureAddon('${addon.name}')" class="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 font-semibold text-sm">
                                        ⚙️
                                    </button>`
                                }
                                <button onclick="showAddonDetails('${addon.name}')" class="bg-blue-100 text-blue-700 px-4 py-2 rounded-lg hover:bg-blue-200 font-semibold text-sm">
                                    ℹ️
                                </button>
                                <button onclick="deleteAddon('${addon.name}')" class="bg-red-100 text-red-700 px-4 py-2 rounded-lg hover:bg-red-200 font-semibold text-sm">
                                    🗑️
                                </button>
                            </div>
                        </div>
                    `).join('');
                } else {
                    container.innerHTML = `
                        <div class="col-span-full text-center py-12">
                            <div class="text-6xl mb-4">📦</div>
                            <h3 class="text-xl font-bold text-gray-800 mb-2">Aucun addon installé</h3>
                            <p class="text-gray-600 mb-4">Uploadez votre premier addon pour commencer</p>
                            <button onclick="document.getElementById('addon-file').click()" class="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 font-semibold">
                                📁 Installer un addon
                            </button>
                        </div>
                    `;
                }
            } catch (error) {
                document.getElementById('installed-addons').innerHTML = `
                    <div class="col-span-full text-center py-12">
                        <div class="text-6xl mb-4">❌</div>
                        <h3 class="text-xl font-bold text-gray-800 mb-2">Erreur de chargement</h3>
                        <p class="text-gray-600 mb-4">${error.message}</p>
                        <button onclick="loadInstalledAddons()" class="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 font-semibold">
                            🔄 Réessayer
                        </button>
                    </div>
                `;
            }
        }

        // Upload addon avec progression
        async function uploadAddon() {
            if (!selectedFile) {
                showNotification('❌ Aucun fichier sélectionné', 'error');
                return;
            }
            
            const formData = new FormData();
            formData.append('addon_file', selectedFile);
            formData.append('action', 'upload_addon');
            
            // Afficher la barre de progression
            document.getElementById('upload-progress').classList.remove('hidden');
            document.getElementById('file-info').classList.add('hidden');
            
            try {
                const xhr = new XMLHttpRequest();
                
                // Suivi de progression
                xhr.upload.addEventListener('progress', (e) => {
                    if (e.lengthComputable) {
                        const percent = Math.round((e.loaded / e.total) * 100);
                        document.getElementById('upload-bar').style.width = percent + '%';
                        document.getElementById('upload-percent').textContent = percent + '%';
                        document.getElementById('upload-status').textContent = 'Upload en cours...';
                    }
                });
                
                // Fin de l'upload
                xhr.addEventListener('load', async () => {
                    if (xhr.status === 200) {
                        const result = JSON.parse(xhr.responseText);
                        
                        if (result.success) {
                            document.getElementById('upload-status').textContent = '✅ Installation réussie !';
                            showNotification('✅ Addon installé avec succès !', 'success');
                            
                            // Réinitialiser
                            setTimeout(() => {
                                document.getElementById('upload-progress').classList.add('hidden');
                                document.getElementById('addon-file').value = '';
                                selectedFile = null;
                                loadInstalledAddons();
                            }, 2000);
                        } else {
                            document.getElementById('upload-status').textContent = '❌ Erreur';
                            showNotification('❌ ' + result.error, 'error');
                            document.getElementById('upload-progress').classList.add('hidden');
                            document.getElementById('file-info').classList.remove('hidden');
                        }
                    } else {
                        showNotification('❌ Erreur serveur', 'error');
                        document.getElementById('upload-progress').classList.add('hidden');
                        document.getElementById('file-info').classList.remove('hidden');
                    }
                });
                
                xhr.addEventListener('error', () => {
                    showNotification('❌ Erreur lors de l\'upload', 'error');
                    document.getElementById('upload-progress').classList.add('hidden');
                    document.getElementById('file-info').classList.remove('hidden');
                });
                
                xhr.open('POST', '/api/addons.php');
                xhr.send(formData);
                
            } catch (error) {
                showNotification('❌ Erreur: ' + error.message, 'error');
                document.getElementById('upload-progress').classList.add('hidden');
                document.getElementById('file-info').classList.remove('hidden');
            }
        }

        // Activer/Désactiver addon
        async function toggleAddon(name, activate) {
            const formData = new FormData();
            formData.append('action', activate ? 'activate_addon' : 'deactivate_addon');
            formData.append('addon_name', name);
            
            showNotification('⏳ ' + (activate ? 'Activation' : 'Désactivation') + ' en cours...', 'info');
            
            try {
                const response = await fetch('/api/addons.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showNotification(`✅ Addon ${activate ? 'activé' : 'désactivé'} avec succès`, 'success');
                    await loadInstalledAddons();
                } else {
                    showNotification('❌ ' + result.error, 'error');
                }
            } catch (error) {
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        }

        // Ouvrir l'addon
        function openAddon(url) {
            window.location.href = url;
        }

        // Configurer addon
        function configureAddon(name) {
            window.location.href = `/addons/${name}/admin/settings.php`;
        }

        // Afficher détails addon
        async function showAddonDetails(name) {
            try {
                const response = await fetch(`/api/addons.php?action=get_addon_details&addon_name=${name}`);
                const result = await response.json();
                
                if (result.success) {
                    const addon = result.addon;
                    document.getElementById('addon-details-content').innerHTML = `
                        <div class="space-y-4">
                            <div class="flex items-center gap-4">
                                <div class="w-16 h-16 bg-purple-100 rounded-lg flex items-center justify-center text-3xl">
                                    ${addon.icon || '🧩'}
                                </div>
                                <div>
                                    <h4 class="text-xl font-bold">${addon.display_name}</h4>
                                    <p class="text-sm text-gray-600">v${addon.version} • ${addon.author}</p>
                                </div>
                            </div>
                            
                            <div class="border-t pt-4">
                                <h5 class="font-semibold mb-2">Description</h5>
                                <p class="text-sm text-gray-600">${addon.description || 'Aucune description'}</p>
                            </div>
                            
                            ${addon.author_url ? `
                            <div class="border-t pt-4">
                                <h5 class="font-semibold mb-2">Site de l'auteur</h5>
                                <a href="${addon.author_url}" target="_blank" class="text-sm text-purple-600 hover:underline">${addon.author_url}</a>
                            </div>
                            ` : ''}
                            
                            ${addon.tables && addon.tables.length > 0 ? `
                            <div class="border-t pt-4">
                                <h5 class="font-semibold mb-2">Tables créées</h5>
                                <div class="flex flex-wrap gap-2">
                                    ${addon.tables.map(t => `<span class="bg-blue-100 text-blue-700 px-2 py-1 rounded text-xs">${t}</span>`).join('')}
                                </div>
                            </div>
                            ` : ''}
                            
                            ${addon.permissions && addon.permissions.length > 0 ? `
                            <div class="border-t pt-4">
                                <h5 class="font-semibold mb-2">Permissions requises</h5>
                                <div class="flex flex-wrap gap-2">
                                    ${addon.permissions.map(p => `<span class="bg-green-100 text-green-700 px-2 py-1 rounded text-xs">${p}</span>`).join('')}
                                </div>
                            </div>
                            ` : ''}
                            
                            <div class="border-t pt-4">
                                <h5 class="font-semibold mb-2">Informations système</h5>
                                <div class="text-sm text-gray-600 space-y-1">
                                    <p><strong>Nom technique :</strong> ${addon.name}</p>
                                    <p><strong>Statut :</strong> ${addon.active ? '<span class="text-green-600">✓ Actif</span>' : '<span class="text-gray-600">Inactif</span>'}</p>
                                    <p><strong>Dossier :</strong> /addons/${addon.name}/</p>
                                </div>
                            </div>
                        </div>
                    `;
                    document.getElementById('addon-details-modal').classList.remove('hidden');
                } else {
                    showNotification('❌ ' + result.error, 'error');
                }
            } catch (error) {
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        }

        function closeDetailsModal() {
            document.getElementById('addon-details-modal').classList.add('hidden');
        }

        // Supprimer addon
        async function deleteAddon(name) {
            if (!confirm('⚠️ Supprimer cet addon ? Cette action est irréversible et supprimera toutes les données associées.')) {
                return;
            }
            
            showNotification('⏳ Suppression en cours...', 'info');
            
            const formData = new FormData();
            formData.append('action', 'delete_addon');
            formData.append('addon_name', name);
            
            try {
                const response = await fetch('/api/addons.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showNotification('✅ Addon supprimé avec succès', 'success');
                    await loadInstalledAddons();
                } else {
                    showNotification('❌ ' + result.error, 'error');
                }
            } catch (error) {
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        }

        // Tabs
        function showTab(tab) {
            document.querySelectorAll('.tab-content').forEach(c => c.classList.add('hidden'));
            document.querySelectorAll('[id^="tab-"]').forEach(b => {
                b.classList.remove('border-purple-600', 'text-purple-600', 'border-b-2');
                b.classList.add('text-gray-500');
            });
            
            document.getElementById(`content-${tab}`).classList.remove('hidden');
            const activeBtn = document.getElementById(`tab-${tab}`);
            activeBtn.classList.add('border-purple-600', 'text-purple-600', 'border-b-2');
            activeBtn.classList.remove('text-gray-500');
        }

        // Notification
        function showNotification(message, type) {
            const notification = document.getElementById('notification');
            const colors = {
                success: 'border-green-500 bg-green-50 text-green-800',
                error: 'border-red-500 bg-red-50 text-red-800',
                info: 'border-blue-500 bg-blue-50 text-blue-800'
            };
            
            notification.className = `fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50 ${colors[type]}`;
            notification.textContent = message;
            notification.classList.remove('hidden');
            
            setTimeout(() => notification.classList.add('hidden'), 5000);
        }
    </script>
</body>
</html>
