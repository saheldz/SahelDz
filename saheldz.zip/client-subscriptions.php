<?php
/**
 * Page Client - Mes Abonnements (Version Sans Includes Problématiques)
 */
require_once 'config/auth-check.php';
require_once 'config/database.php';

// Vérifier que l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header('Location: /login.html');
    exit;
}

$pdo = getDB();
$userId = $_SESSION['user_id'];

// Récupérer l'abonnement actuel de l'utilisateur
$stmt = $pdo->prepare("
    SELECT s.*, sp.name as plan_name, sp.description as plan_description, 
           sp.features, sp.price, sp.billing_period
    FROM subscriptions s
    JOIN subscription_plans sp ON s.plan_id = sp.id
    WHERE s.user_id = ? AND s.status IN ('trial', 'active')
    ORDER BY s.created_at DESC
    LIMIT 1
");
$stmt->execute([$userId]);
$currentSubscription = $stmt->fetch();

// Récupérer tous les plans disponibles
$stmt = $pdo->query("SELECT * FROM subscription_plans WHERE status = 'active' ORDER BY price ASC");
$availablePlans = $stmt->fetchAll();

// Récupérer l'historique des abonnements
$stmt = $pdo->prepare("
    SELECT s.*, sp.name as plan_name, sp.price, sp.billing_period
    FROM subscriptions s
    JOIN subscription_plans sp ON s.plan_id = sp.id
    WHERE s.user_id = ?
    ORDER BY s.created_at DESC
    LIMIT 10
");
$stmt->execute([$userId]);
$subscriptionHistory = $stmt->fetchAll();

// Nom utilisateur
$userName = $_SESSION['full_name'] ?? $_SESSION['email'] ?? 'Utilisateur';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Abonnements - DigiServices</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    
    <nav class="bg-gradient-to-r from-blue-600 to-indigo-600 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <a href="/client-dashboard.php" class="text-white hover:text-blue-200 font-medium">← Dashboard</a>
                    <h1 class="text-2xl font-bold text-white">📦 Mes Abonnements</h1>
                </div>
                <div class="text-white text-sm"><?php echo htmlspecialchars($userName); ?></div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        
        <!-- Abonnement Actuel -->
        <?php if ($currentSubscription): ?>
        <div class="bg-white rounded-xl shadow-lg p-6 mb-8 border-2 border-green-500">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-2xl font-bold text-gray-800">✅ Mon Abonnement Actuel</h2>
                <span class="px-4 py-2 rounded-full text-sm font-semibold <?php echo $currentSubscription['status'] === 'trial' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'; ?>">
                    <?php echo $currentSubscription['status'] === 'trial' ? '🎁 Essai Gratuit' : '✓ Actif'; ?>
                </span>
            </div>
            
            <div class="grid md:grid-cols-2 gap-6">
                <div>
                    <h3 class="text-xl font-bold text-indigo-600 mb-2"><?php echo htmlspecialchars($currentSubscription['plan_name']); ?></h3>
                    <p class="text-gray-600 mb-4"><?php echo htmlspecialchars($currentSubscription['plan_description']); ?></p>
                    
                    <?php if ($currentSubscription['features']): 
                        $features = json_decode($currentSubscription['features'], true);
                        if ($features):
                    ?>
                    <h4 class="font-semibold text-gray-700 mb-2">📋 Fonctionnalités incluses :</h4>
                    <ul class="space-y-1">
                        <?php foreach ($features as $feature): ?>
                        <li class="flex items-start gap-2">
                            <span class="text-green-600">✓</span>
                            <span class="text-sm text-gray-600"><?php echo htmlspecialchars($feature); ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; endif; ?>
                </div>
                
                <div class="space-y-4">
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <div class="text-sm text-gray-600">Montant</div>
                        <div class="text-2xl font-bold text-gray-800"><?php echo number_format($currentSubscription['amount'], 2); ?> €</div>
                        <div class="text-sm text-gray-600">par <?php 
                            $periods = ['monthly' => 'mois', 'yearly' => 'an', 'quarterly' => 'trimestre', 'weekly' => 'semaine'];
                            echo $periods[$currentSubscription['billing_period']] ?? $currentSubscription['billing_period'];
                        ?></div>
                    </div>
                    
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <div class="text-sm text-gray-600">Date de début</div>
                        <div class="font-semibold"><?php echo date('d/m/Y', strtotime($currentSubscription['start_date'])); ?></div>
                    </div>
                    
                    <?php if ($currentSubscription['next_billing_date']): ?>
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <div class="text-sm text-gray-600">Prochaine facturation</div>
                        <div class="font-semibold"><?php echo date('d/m/Y', strtotime($currentSubscription['next_billing_date'])); ?></div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($currentSubscription['status'] === 'trial' && $currentSubscription['trial_ends_at']): ?>
                    <div class="bg-blue-50 p-4 rounded-lg border border-blue-200">
                        <div class="text-sm text-blue-700">Essai gratuit se termine le</div>
                        <div class="font-semibold text-blue-800"><?php echo date('d/m/Y', strtotime($currentSubscription['trial_ends_at'])); ?></div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Actions Rapides -->
            <div class="mt-6 border-t pt-6">
                <h4 class="font-bold text-gray-800 mb-4">⚡ Actions Rapides</h4>
                <div class="grid md:grid-cols-3 gap-3">
                    <?php if ($currentSubscription['status'] === 'trial'): ?>
                    <button onclick="activateNow(<?php echo $currentSubscription['id']; ?>)" class="bg-green-100 text-green-700 px-4 py-3 rounded-lg hover:bg-green-200 font-semibold text-sm flex items-center justify-center gap-2">
                        <span>✓</span> Activer Maintenant
                    </button>
                    <?php endif; ?>
                    
                    <?php if ($currentSubscription['auto_renew']): ?>
                    <button onclick="toggleAutoRenew(<?php echo $currentSubscription['id']; ?>, 0)" class="bg-orange-100 text-orange-700 px-4 py-3 rounded-lg hover:bg-orange-200 font-semibold text-sm flex items-center justify-center gap-2">
                        <span>⏸</span> Désactiver Auto-Renouvellement
                    </button>
                    <?php else: ?>
                    <button onclick="toggleAutoRenew(<?php echo $currentSubscription['id']; ?>, 1)" class="bg-blue-100 text-blue-700 px-4 py-3 rounded-lg hover:bg-blue-200 font-semibold text-sm flex items-center justify-center gap-2">
                        <span>🔄</span> Activer Auto-Renouvellement
                    </button>
                    <?php endif; ?>
                    
                    <button onclick="showUpgradeOptions(<?php echo $currentSubscription['plan_id']; ?>)" class="bg-purple-100 text-purple-700 px-4 py-3 rounded-lg hover:bg-purple-200 font-semibold text-sm flex items-center justify-center gap-2">
                        <span>⬆️</span> Upgrade/Downgrade
                    </button>
                    
                    <button onclick="renewSubscription(<?php echo $currentSubscription['id']; ?>)" class="bg-teal-100 text-teal-700 px-4 py-3 rounded-lg hover:bg-teal-200 font-semibold text-sm flex items-center justify-center gap-2">
                        <span>🔄</span> Renouveler Maintenant
                    </button>
                    
                    <button onclick="pauseSubscription(<?php echo $currentSubscription['id']; ?>)" class="bg-yellow-100 text-yellow-700 px-4 py-3 rounded-lg hover:bg-yellow-200 font-semibold text-sm flex items-center justify-center gap-2">
                        <span>⏸</span> Mettre en Pause
                    </button>
                    
                    <button onclick="cancelSubscription(<?php echo $currentSubscription['id']; ?>)" class="bg-red-100 text-red-700 px-4 py-3 rounded-lg hover:bg-red-200 font-semibold text-sm flex items-center justify-center gap-2">
                        <span>✖</span> Annuler l'Abonnement
                    </button>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="bg-yellow-50 border-l-4 border-yellow-500 p-6 rounded-lg mb-8">
            <div class="flex items-center gap-3">
                <span class="text-3xl">⚠️</span>
                <div>
                    <h3 class="font-bold text-yellow-800">Aucun abonnement actif</h3>
                    <p class="text-yellow-700">Vous n'avez pas d'abonnement actif actuellement. Choisissez un plan ci-dessous.</p>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Plans Disponibles -->
        <div class="mb-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">📋 Plans Disponibles</h2>
            
            <div class="grid md:grid-cols-3 gap-6">
                <?php foreach ($availablePlans as $plan): 
                    $features = json_decode($plan['features'], true) ?: [];
                    $isCurrent = $currentSubscription && $currentSubscription['plan_id'] == $plan['id'];
                ?>
                <div class="bg-white rounded-xl shadow-lg p-6 border-2 <?php echo $plan['is_popular'] ? 'border-indigo-500' : 'border-gray-200'; ?> hover:shadow-xl transition">
                    <?php if ($plan['is_popular']): ?>
                    <div class="text-center mb-3">
                        <span class="bg-indigo-600 text-white px-3 py-1 rounded-full text-sm font-bold">⭐ POPULAIRE</span>
                    </div>
                    <?php endif; ?>
                    
                    <h3 class="text-2xl font-bold mb-2"><?php echo htmlspecialchars($plan['name']); ?></h3>
                    <p class="text-gray-600 mb-4 h-12 text-sm"><?php echo htmlspecialchars($plan['description']); ?></p>
                    
                    <div class="text-center mb-4">
                        <span class="text-4xl font-bold text-indigo-600"><?php echo number_format($plan['price'], 2); ?> €</span>
                        <span class="text-gray-600">/ <?php 
                            $periods = ['monthly' => 'mois', 'yearly' => 'an', 'quarterly' => 'trimestre', 'weekly' => 'semaine'];
                            echo $periods[$plan['billing_period']] ?? $plan['billing_period'];
                        ?></span>
                    </div>
                    
                    <?php if ($plan['trial_days'] > 0): ?>
                    <div class="text-center text-sm text-green-600 mb-4">
                        🎁 <?php echo $plan['trial_days']; ?> jours d'essai gratuit
                    </div>
                    <?php endif; ?>
                    
                    <ul class="space-y-2 mb-6 min-h-[200px]">
                        <?php foreach ($features as $feature): ?>
                        <li class="flex items-start gap-2">
                            <span class="text-green-600">✓</span>
                            <span class="text-sm text-gray-600"><?php echo htmlspecialchars($feature); ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    
                    <?php if ($isCurrent): ?>
                    <button disabled class="w-full bg-gray-300 text-gray-600 py-3 rounded-lg font-semibold cursor-not-allowed">
                        ✓ Abonnement Actuel
                    </button>
                    <?php else: ?>
                    <button onclick="subscribeToPlan(<?php echo $plan['id']; ?>)" class="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 font-semibold">
                        <?php echo $currentSubscription ? '🔄 Changer de plan' : '✨ S\'abonner'; ?>
                    </button>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Historique -->
        <?php if (count($subscriptionHistory) > 0): ?>
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h2 class="text-xl font-bold mb-4">📜 Historique des Abonnements</h2>
            
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="border-b-2">
                            <th class="text-left p-3">Plan</th>
                            <th class="text-right p-3">Montant</th>
                            <th class="text-center p-3">Période</th>
                            <th class="text-center p-3">Statut</th>
                            <th class="text-center p-3">Date début</th>
                            <th class="text-center p-3">Date fin</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($subscriptionHistory as $sub): ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="p-3 font-medium"><?php echo htmlspecialchars($sub['plan_name']); ?></td>
                            <td class="p-3 text-right"><?php echo number_format($sub['price'], 2); ?> €</td>
                            <td class="p-3 text-center text-sm"><?php echo $sub['billing_period']; ?></td>
                            <td class="p-3 text-center">
                                <span class="px-2 py-1 rounded text-xs <?php 
                                    echo $sub['status'] === 'active' ? 'bg-green-100 text-green-700' : 
                                        ($sub['status'] === 'trial' ? 'bg-blue-100 text-blue-700' :
                                        ($sub['status'] === 'cancelled' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700'));
                                ?>"><?php echo $sub['status']; ?></span>
                            </td>
                            <td class="p-3 text-center text-sm"><?php echo date('d/m/Y', strtotime($sub['start_date'])); ?></td>
                            <td class="p-3 text-center text-sm"><?php echo $sub['end_date'] ? date('d/m/Y', strtotime($sub['end_date'])) : '-'; ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

    </div>

    <!-- Modal Confirmation -->
    <div id="confirm-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-xl shadow-2xl max-w-md w-full p-6 m-4">
            <h3 class="text-xl font-bold mb-4" id="modal-title"></h3>
            <p class="text-gray-600 mb-6" id="modal-message"></p>
            <div class="flex gap-3">
                <button id="modal-confirm" class="flex-1 bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 font-semibold">
                    Confirmer
                </button>
                <button onclick="closeModal()" class="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-semibold">
                    Annuler
                </button>
            </div>
        </div>
    </div>

    <!-- Notification -->
    <div id="notification" class="hidden fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50"></div>

    <script>
        async function subscribeToPlan(planId) {
            document.getElementById('modal-title').textContent = 'Confirmer l\'abonnement';
            document.getElementById('modal-message').textContent = 'Voulez-vous vous abonner à ce plan ?';
            document.getElementById('modal-confirm').onclick = async () => {
                closeModal();
                
                const formData = new FormData();
                formData.append('action', 'subscribe');
                formData.append('plan_id', planId);
                
                try {
                    const response = await fetch('/api/subscriptions.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        showNotification('✅ Abonnement créé avec succès !', 'success');
                        setTimeout(() => location.reload(), 2000);
                    } else {
                        showNotification('❌ ' + result.error, 'error');
                    }
                } catch (error) {
                    showNotification('❌ Erreur: ' + error.message, 'error');
                }
            };
            document.getElementById('confirm-modal').classList.remove('hidden');
        }

        async function cancelSubscription(subscriptionId) {
            document.getElementById('modal-title').textContent = 'Annuler l\'abonnement';
            document.getElementById('modal-message').textContent = 'Êtes-vous sûr de vouloir annuler votre abonnement ? Cette action est irréversible.';
            document.getElementById('modal-confirm').onclick = async () => {
                closeModal();
                
                const formData = new FormData();
                formData.append('action', 'cancel_subscription');
                formData.append('subscription_id', subscriptionId);
                formData.append('reason', 'Annulation par l\'utilisateur');
                
                try {
                    const response = await fetch('/api/subscriptions.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        showNotification('✅ Abonnement annulé', 'success');
                        setTimeout(() => location.reload(), 2000);
                    } else {
                        showNotification('❌ ' + result.error, 'error');
                    }
                } catch (error) {
                    showNotification('❌ Erreur: ' + error.message, 'error');
                }
            };
            document.getElementById('confirm-modal').classList.remove('hidden');
        }

        async function activateNow(subscriptionId) {
            document.getElementById('modal-title').textContent = 'Activer l\'abonnement maintenant';
            document.getElementById('modal-message').textContent = 'Voulez-vous activer votre abonnement maintenant ? L\'essai gratuit prendra fin immédiatement.';
            document.getElementById('modal-confirm').onclick = async () => {
                closeModal();
                
                const formData = new FormData();
                formData.append('action', 'activate_now');
                formData.append('subscription_id', subscriptionId);
                
                try {
                    const response = await fetch('/api/subscriptions.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        showNotification('✅ Abonnement activé !', 'success');
                        setTimeout(() => location.reload(), 2000);
                    } else {
                        showNotification('❌ ' + result.error, 'error');
                    }
                } catch (error) {
                    showNotification('❌ Erreur: ' + error.message, 'error');
                }
            };
            document.getElementById('confirm-modal').classList.remove('hidden');
        }

        async function toggleAutoRenew(subscriptionId, value) {
            const action = value ? 'activer' : 'désactiver';
            document.getElementById('modal-title').textContent = `${action.charAt(0).toUpperCase() + action.slice(1)} le renouvellement automatique`;
            document.getElementById('modal-message').textContent = `Voulez-vous ${action} le renouvellement automatique de votre abonnement ?`;
            document.getElementById('modal-confirm').onclick = async () => {
                closeModal();
                
                const formData = new FormData();
                formData.append('action', 'toggle_auto_renew');
                formData.append('subscription_id', subscriptionId);
                formData.append('auto_renew', value);
                
                try {
                    const response = await fetch('/api/subscriptions.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        showNotification(`✅ Renouvellement automatique ${value ? 'activé' : 'désactivé'}`, 'success');
                        setTimeout(() => location.reload(), 2000);
                    } else {
                        showNotification('❌ ' + result.error, 'error');
                    }
                } catch (error) {
                    showNotification('❌ Erreur: ' + error.message, 'error');
                }
            };
            document.getElementById('confirm-modal').classList.remove('hidden');
        }

        async function showUpgradeOptions(currentPlanId) {
            try {
                const response = await fetch('/api/subscriptions.php?action=get_plans');
                const result = await response.json();
                
                if (result.success) {
                    const plans = result.plans.filter(p => p.id != currentPlanId);
                    
                    if (plans.length === 0) {
                        showNotification('ℹ️ Aucun autre plan disponible', 'info');
                        return;
                    }
                    
                    document.getElementById('modal-title').textContent = 'Changer de plan';
                    document.getElementById('modal-message').textContent = 'Sélectionnez votre nouveau plan parmi ceux disponibles ci-dessous.';
                    document.getElementById('modal-confirm').onclick = () => {
                        closeModal();
                        document.querySelector('.grid.md\\:grid-cols-3').scrollIntoView({ behavior: 'smooth' });
                        showNotification('👇 Sélectionnez un plan ci-dessous', 'info');
                    };
                    document.getElementById('confirm-modal').classList.remove('hidden');
                }
            } catch (error) {
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        }

        async function renewSubscription(subscriptionId) {
            document.getElementById('modal-title').textContent = 'Renouveler l\'abonnement';
            document.getElementById('modal-message').textContent = 'Voulez-vous renouveler votre abonnement maintenant ? La nouvelle période démarrera immédiatement.';
            document.getElementById('modal-confirm').onclick = async () => {
                closeModal();
                
                const formData = new FormData();
                formData.append('action', 'renew_subscription');
                formData.append('subscription_id', subscriptionId);
                
                try {
                    const response = await fetch('/api/subscriptions.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        showNotification('✅ Abonnement renouvelé !', 'success');
                        setTimeout(() => location.reload(), 2000);
                    } else {
                        showNotification('❌ ' + result.error, 'error');
                    }
                } catch (error) {
                    showNotification('❌ Erreur: ' + error.message, 'error');
                }
            };
            document.getElementById('confirm-modal').classList.remove('hidden');
        }

        async function pauseSubscription(subscriptionId) {
            document.getElementById('modal-title').textContent = 'Mettre en pause';
            document.getElementById('modal-message').textContent = 'Voulez-vous mettre votre abonnement en pause ? Vous ne serez pas facturé pendant la pause.';
            document.getElementById('modal-confirm').onclick = async () => {
                closeModal();
                
                const formData = new FormData();
                formData.append('action', 'pause_subscription');
                formData.append('subscription_id', subscriptionId);
                
                try {
                    const response = await fetch('/api/subscriptions.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        showNotification('✅ Abonnement mis en pause', 'success');
                        setTimeout(() => location.reload(), 2000);
                    } else {
                        showNotification('❌ ' + result.error, 'error');
                    }
                } catch (error) {
                    showNotification('❌ Erreur: ' + error.message, 'error');
                }
            };
            document.getElementById('confirm-modal').classList.remove('hidden');
        }

        function closeModal() {
            document.getElementById('confirm-modal').classList.add('hidden');
        }

        function showNotification(message, type) {
            const notification = document.getElementById('notification');
            const colors = {
                success: 'border-green-500 bg-green-50 text-green-800',
                error: 'border-red-500 bg-red-50 text-red-800',
                info: 'border-blue-500 bg-blue-50 text-blue-800'
            };
            
            notification.className = `fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50 ${colors[type]}`;
            notification.textContent = message;
            notification.classList.remove('hidden');
            
            setTimeout(() => notification.classList.add('hidden'), 5000);
        }
    </script>
</body>
</html>
