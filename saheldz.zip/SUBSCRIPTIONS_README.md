# 📦 Module de Gestion des Abonnements

## Vue d'ensemble

Le module de gestion des abonnements est un addon complet pour DigiServices qui permet de créer et gérer des plans d'abonnement pour vos clients. Il inclut la gestion des périodes d'essai, des renouvellements automatiques, et l'intégration avec le système de wallet existant.

## 🚀 Installation

### 1. Exécuter le script d'installation

```bash
php install-subscriptions.php
```

Ce script va :
- Créer les tables nécessaires dans la base de données
- Insérer 3 plans d'exemple (Starter, Pro, Enterprise)
- Configurer les relations entre tables

### 2. Vérifier l'installation

Accédez à `/admin-subscriptions.php` pour vérifier que le module fonctionne correctement.

## 📊 Structure de la base de données

### Table `subscription_plans`

Stocke les différents plans d'abonnement disponibles.

| Colonne | Type | Description |
|---------|------|-------------|
| id | INT | Identifiant unique |
| name | VARCHAR(255) | Nom du plan |
| description | TEXT | Description du plan |
| price | DECIMAL(10,2) | Prix du plan |
| billing_period | ENUM | Période de facturation (daily, weekly, monthly, quarterly, yearly) |
| trial_days | INT | Nombre de jours d'essai gratuit |
| features | JSON | Liste des fonctionnalités incluses |
| max_users | INT | Nombre maximum d'utilisateurs (NULL = illimité) |
| max_storage | INT | Stockage maximum en MB (NULL = illimité) |
| status | ENUM | Statut du plan (active, inactive, archived) |
| is_popular | BOOLEAN | Badge "populaire" |
| sort_order | INT | Ordre d'affichage |

### Table `subscriptions`

Gère les abonnements des clients.

| Colonne | Type | Description |
|---------|------|-------------|
| id | INT | Identifiant unique |
| user_id | INT | ID de l'utilisateur |
| plan_id | INT | ID du plan souscrit |
| status | ENUM | Statut (trial, active, suspended, cancelled, expired) |
| start_date | DATE | Date de début |
| end_date | DATE | Date de fin |
| next_billing_date | DATE | Prochaine date de facturation |
| trial_ends_at | DATE | Fin de la période d'essai |
| cancelled_at | TIMESTAMP | Date d'annulation |
| cancel_reason | TEXT | Raison de l'annulation |
| amount | DECIMAL(10,2) | Montant de l'abonnement |
| billing_period | ENUM | Période de facturation |
| auto_renew | BOOLEAN | Renouvellement automatique |
| payment_method | VARCHAR(50) | Méthode de paiement |
| notes | TEXT | Notes internes |

### Table `subscription_items`

Items/services additionnels inclus dans un abonnement.

| Colonne | Type | Description |
|---------|------|-------------|
| id | INT | Identifiant unique |
| subscription_id | INT | ID de l'abonnement |
| item_type | ENUM | Type (service, product, feature) |
| item_name | VARCHAR(255) | Nom de l'item |
| item_description | TEXT | Description |
| quantity | INT | Quantité |
| unit_price | DECIMAL(10,2) | Prix unitaire |
| total_price | DECIMAL(10,2) | Prix total |
| metadata | JSON | Métadonnées additionnelles |

### Table `subscription_history`

Historique des modifications d'abonnements.

| Colonne | Type | Description |
|---------|------|-------------|
| id | INT | Identifiant unique |
| subscription_id | INT | ID de l'abonnement |
| action | VARCHAR(50) | Action (created, renewed, suspended, cancelled, etc.) |
| old_status | VARCHAR(50) | Ancien statut |
| new_status | VARCHAR(50) | Nouveau statut |
| amount | DECIMAL(10,2) | Montant associé |
| description | TEXT | Description de l'action |
| created_by | INT | ID de l'utilisateur ayant effectué l'action |
| created_at | TIMESTAMP | Date de l'action |

## 🎯 Fonctionnalités

### Gestion des Plans

- ✅ Créer/modifier/supprimer des plans d'abonnement
- ✅ Définir des périodes de facturation (jour, semaine, mois, trimestre, an)
- ✅ Configurer des périodes d'essai gratuites
- ✅ Limiter le nombre d'utilisateurs et le stockage
- ✅ Marquer un plan comme "populaire"
- ✅ Liste de fonctionnalités personnalisable
- ✅ Activer/désactiver des plans

### Gestion des Abonnements

- ✅ Créer des abonnements pour les clients
- ✅ Gestion automatique des périodes d'essai
- ✅ Calcul automatique des dates de renouvellement
- ✅ Intégration avec le système de wallet
- ✅ Suspendre/réactiver des abonnements
- ✅ Annuler des abonnements
- ✅ Historique complet des actions
- ✅ Filtrage par statut

### Items et Services

- ✅ Ajouter des services/produits aux abonnements
- ✅ Gestion des quantités et prix
- ✅ Métadonnées personnalisables

## 📋 API Endpoints

### Plans

#### GET /api/subscriptions.php?action=get_plans
Récupère tous les plans actifs.

**Paramètres:**
- `status` (optionnel) : Filtrer par statut (active, inactive, archived)

**Réponse:**
```json
{
  "success": true,
  "plans": [
    {
      "id": 1,
      "name": "Plan Pro",
      "price": 29.99,
      "billing_period": "monthly",
      "trial_days": 14,
      "features": ["Feature 1", "Feature 2"],
      ...
    }
  ]
}
```

#### POST /api/subscriptions.php (action=create_plan)
Crée un nouveau plan (admin seulement).

**Paramètres:**
- `name` * : Nom du plan
- `description` : Description
- `price` * : Prix
- `billing_period` * : Période de facturation
- `trial_days` : Jours d'essai
- `features` : JSON des fonctionnalités
- `max_users` : Nombre max d'utilisateurs
- `max_storage` : Stockage max en MB
- `is_popular` : Badge populaire (1/0)

#### POST /api/subscriptions.php (action=update_plan)
Met à jour un plan existant (admin seulement).

#### POST /api/subscriptions.php (action=delete_plan)
Archive un plan (admin seulement).

### Abonnements

#### GET /api/subscriptions.php?action=get_subscriptions
Récupère les abonnements.

**Paramètres:**
- `status` (optionnel) : Filtrer par statut

**Réponse:**
```json
{
  "success": true,
  "subscriptions": [
    {
      "id": 1,
      "user_id": 5,
      "plan_name": "Plan Pro",
      "amount": 29.99,
      "status": "active",
      "next_billing_date": "2025-11-23",
      ...
    }
  ]
}
```

#### GET /api/subscriptions.php?action=get_subscription&subscription_id=X
Récupère les détails d'un abonnement spécifique.

#### POST /api/subscriptions.php (action=create_subscription)
Crée un nouvel abonnement.

**Paramètres:**
- `user_id` * : ID de l'utilisateur
- `plan_id` * : ID du plan
- `start_date` : Date de début (par défaut: aujourd'hui)
- `payment_method` : wallet ou manual
- `notes` : Notes internes

**Traitement automatique:**
- Calcul de la période d'essai
- Calcul de la prochaine date de facturation
- Déduction du wallet si payment_method = wallet
- Création d'une transaction
- Enregistrement dans l'historique

#### POST /api/subscriptions.php (action=suspend_subscription)
Suspend un abonnement (admin seulement).

#### POST /api/subscriptions.php (action=reactivate_subscription)
Réactive un abonnement suspendu (admin seulement).

#### POST /api/subscriptions.php (action=cancel_subscription)
Annule un abonnement.

### Items

#### POST /api/subscriptions.php (action=add_item)
Ajoute un item à un abonnement (admin seulement).

#### POST /api/subscriptions.php (action=update_item)
Met à jour un item (admin seulement).

#### POST /api/subscriptions.php (action=delete_item)
Supprime un item (admin seulement).

### Statistiques

#### GET /api/subscriptions.php?action=get_stats
Récupère les statistiques globales (admin seulement).

**Réponse:**
```json
{
  "success": true,
  "stats": {
    "total_subscriptions": 150,
    "by_status": [
      {"status": "active", "count": 120},
      {"status": "trial", "count": 20},
      ...
    ],
    "monthly_revenue": 3599.80,
    "popular_plans": [...]
  }
}
```

## 🎨 Interface d'administration

L'interface `/admin-subscriptions.php` offre deux onglets principaux :

### Onglet "Plans d'Abonnement"

- Affichage en grille des plans disponibles
- Badge "POPULAIRE" pour les plans marqués
- Boutons pour modifier/supprimer chaque plan
- Modal de création/édition avec :
  - Informations de base (nom, description, prix)
  - Configuration de la période de facturation
  - Période d'essai
  - Limites (utilisateurs, stockage)
  - Gestion dynamique des fonctionnalités
  - Statut et badge populaire

### Onglet "Abonnements Clients"

- Tableau récapitulatif de tous les abonnements
- Filtrage par statut
- Actions selon le statut :
  - Voir les détails
  - Suspendre (si actif)
  - Réactiver (si suspendu)
- Modal de détails avec :
  - Informations client et plan
  - Fonctionnalités incluses
  - Liste des items/services
  - Actions (suspendre, réactiver, annuler)

## 💡 Cas d'usage

### Créer un plan d'abonnement

1. Accédez à `/admin-subscriptions.php`
2. Cliquez sur "➕ Nouveau Plan"
3. Remplissez les informations :
   - Nom : "Plan Premium"
   - Prix : 49.99 €
   - Période : Mensuel
   - Jours d'essai : 30
   - Fonctionnalités : Ajoutez-les une par une
4. Marquez comme "populaire" si souhaité
5. Enregistrez

### Souscrire un client à un plan

1. Onglet "Abonnements Clients"
2. Cliquez sur "➕ Nouvel Abonnement"
3. Sélectionnez :
   - Le client dans la liste
   - Le plan souhaité
   - Date de début (aujourd'hui par défaut)
   - Méthode de paiement (wallet ou manuel)
4. Créez l'abonnement

**Si wallet :**
- Le montant sera déduit automatiquement
- Une transaction sera créée
- Si période d'essai, pas de déduction immédiate

### Suspendre un abonnement problématique

1. Dans la liste des abonnements, cliquez sur "⏸️ Suspendre"
2. Entrez une raison de suspension
3. L'abonnement passe en statut "suspendu"
4. L'action est enregistrée dans l'historique

### Réactiver un abonnement

1. Pour un abonnement suspendu, cliquez sur "▶️ Réactiver"
2. Confirmez l'action
3. L'abonnement repasse en statut "actif"

## 🔄 Intégration avec le système existant

### Wallet

Le module s'intègre automatiquement avec le système de wallet :
- Déduction automatique lors de la création d'abonnement
- Création de transactions dans la table `transactions`
- Vérification du solde avant création

### Utilisateurs

- Utilise la table `users` existante
- Respect des permissions (admin uniquement)
- Historique lié aux utilisateurs

### Authentification

- Utilise `config/auth-check.php`
- Vérification des rôles
- Sessions sécurisées

## 🛠️ Personnalisation

### Ajouter une nouvelle période de facturation

Dans `install-subscriptions.php` et `api/subscriptions.php`, ajoutez votre période dans l'ENUM `billing_period`.

### Modifier les statuts d'abonnement

Éditez l'ENUM `status` dans la table `subscriptions`.

### Ajouter des métadonnées personnalisées

Utilisez le champ JSON `metadata` dans `subscription_items` pour stocker des informations supplémentaires.

## ⚠️ Notes importantes

### Sécurité

- Toutes les actions sensibles sont protégées par authentification
- Seuls les admins peuvent gérer les plans et suspendre/réactiver
- Les utilisateurs ne peuvent voir que leurs propres abonnements

### Performances

- Index sur les colonnes fréquemment utilisées
- Requêtes optimisées avec JOINs appropriés
- Pas de cascade DELETE sur les plans avec abonnements actifs

### Maintenance

- L'historique conserve toutes les actions pour audit
- Les plans ne sont pas supprimés mais archivés
- Les dates de renouvellement sont calculées automatiquement

## 🎓 Exemples de code

### Créer un plan par API

```php
$data = [
    'action' => 'create_plan',
    'name' => 'Plan Custom',
    'description' => 'Plan personnalisé',
    'price' => 19.99,
    'billing_period' => 'monthly',
    'trial_days' => 7,
    'features' => json_encode(['Feature 1', 'Feature 2'])
];

$response = file_get_contents(
    'http://yoursite.com/api/subscriptions.php',
    false,
    stream_context_create([
        'http' => [
            'method' => 'POST',
            'content' => http_build_query($data)
        ]
    ])
);

$result = json_decode($response, true);
```

### Vérifier les abonnements d'un utilisateur

```php
require_once 'config/database.php';
$pdo = getDB();

$stmt = $pdo->prepare("
    SELECT s.*, p.name as plan_name
    FROM subscriptions s
    JOIN subscription_plans p ON s.plan_id = p.id
    WHERE s.user_id = ? AND s.status IN ('active', 'trial')
");

$stmt->execute([$userId]);
$activeSubscriptions = $stmt->fetchAll();
```

## 📞 Support

Pour toute question ou problème avec le module d'abonnements, consultez la documentation du projet principal ou contactez l'équipe de support.

## 📝 Changelog

### Version 1.0.0 (2025-10-23)
- Première version du module
- Gestion complète des plans d'abonnement
- Gestion des abonnements clients
- Intégration wallet
- Interface d'administration
- API REST complète
- Historique des actions

---

**Développé pour DigiServices** 🚀
