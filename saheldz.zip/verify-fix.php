<?php
/**
 * Script de Vérification - Corrections Addon Subscriptions
 * À exécuter localement pour vérifier que les corrections sont présentes
 */

echo "=== VERIFICATION DES CORRECTIONS ===\n\n";

$files = [
    'api/addons.php' => [
        'check' => 'function getAddonDetails()',
        'description' => 'Fonction get_addon_details ajoutée'
    ],
    'addons/subscriptions/admin/dashboard.php' => [
        'check' => 'Vérifier si les tables existent',
        'description' => 'Vérification des tables avant requêtes SQL'
    ],
    'admin-addons.php' => [
        'check' => 'upload-progress',
        'description' => 'Barre de progression pour uploads'
    ]
];

$allGood = true;

foreach ($files as $file => $check) {
    echo "Vérification: $file\n";
    
    if (!file_exists($file)) {
        echo "  ❌ ERREUR: Fichier non trouvé\n\n";
        $allGood = false;
        continue;
    }
    
    $content = file_get_contents($file);
    
    if (strpos($content, $check['check']) !== false) {
        echo "  ✅ OK: {$check['description']}\n\n";
    } else {
        echo "  ❌ ERREUR: Correction non trouvée\n\n";
        $allGood = false;
    }
}

echo "\n=== RÉSULTAT ===\n\n";

if ($allGood) {
    echo "✅ Tous les fichiers sont correctement corrigés localement !\n\n";
    echo "⚠️  IMPORTANT: Vous devez maintenant uploader ces fichiers sur votre serveur:\n\n";
    echo "Via FTP/SFTP:\n";
    echo "  1. api/addons.php → /public_html/api/addons.php\n";
    echo "  2. addons/subscriptions/admin/dashboard.php → /public_html/addons/subscriptions/admin/dashboard.php\n";
    echo "  3. admin-addons.php → /public_html/admin-addons.php\n\n";
    echo "Sinon l'erreur 500 persistera car le serveur a toujours les anciens fichiers.\n";
} else {
    echo "❌ Certains fichiers ont des problèmes. Vérifiez les messages ci-dessus.\n";
}

echo "\n";
