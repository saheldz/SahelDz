# 🔐 Système d'Authentification DigiServices

Documentation complète du système d'authentification multi-rôles avec wallet

---

## 📋 Table des matières

1. [Vue d'ensemble](#vue-densemble)
2. [Installation](#installation)
3. [Structure de la base de données](#structure-de-la-base-de-données)
4. [API d'authentification](#api-dauthentification)
5. [API Wallet](#api-wallet)
6. [API Admin](#api-admin)
7. [Rôles et permissions](#rôles-et-permissions)
8. [Exemples d'utilisation](#exemples-dutilisation)

---

## 🎯 Vue d'ensemble

Le système d'authentification DigiServices offre :

✅ **Inscription/Connexion** - Register et Login avec validation  
✅ **Multi-rôles** - 4 rôles par défaut (Super Admin, Admin, Client, Employé)  
✅ **Wallet intégré** - Chaque utilisateur a un portefeuille  
✅ **Gestion des transactions** - Historique complet des mouvements  
✅ **Admin Dashboard** - Gestion utilisateurs, rôles et soldes  
✅ **Sessions sécurisées** - Tokens avec expiration  

---

## 🚀 Installation

### Étape 1: Installer la base de données

```bash
# Ouvrez dans votre navigateur
http://localhost:8003/install-auth.php
```

**Réponse attendue:**
```json
{
  "success": true,
  "message": "✅ Système d'authentification installé avec succès!",
  "tables": ["roles", "users", "wallets", "transactions", "user_sessions"],
  "default_admin": {
    "email": "admin@digiservices.com",
    "password": "admin123"
  }
}
```

### Étape 2: Test de connexion

```bash
# Ouvrez la page de login
http://localhost:8003/login.html
```

**Compte admin par défaut:**
- 📧 Email: `admin@digiservices.com`
- 🔒 Mot de passe: `admin123`

⚠️ **Changez ce mot de passe après la première connexion!**

---

## 🗄️ Structure de la base de données

### Table: `roles`

Définit les différents rôles dans le système.

| Colonne | Type | Description |
|---------|------|-------------|
| id | INT | ID unique du rôle |
| name | VARCHAR(50) | Nom technique (ex: super_admin) |
| display_name | VARCHAR(100) | Nom affiché (ex: Super Administrateur) |
| description | TEXT | Description du rôle |
| permissions | JSON | Permissions (ex: {"all": true}) |

**Rôles par défaut:**
1. **Super Admin** - Accès complet
2. **Admin** - Gestion utilisateurs et commandes
3. **Client** - Créer commandes, voir wallet
4. **Employé** - Gérer les commandes uniquement

### Table: `users`

Stocke les informations des utilisateurs.

| Colonne | Type | Description |
|---------|------|-------------|
| id | INT | ID unique |
| email | VARCHAR(255) | Email (unique) |
| password | VARCHAR(255) | Mot de passe hashé (bcrypt) |
| full_name | VARCHAR(255) | Nom complet |
| phone | VARCHAR(50) | Téléphone |
| company | VARCHAR(255) | Entreprise |
| role_id | INT | Référence vers `roles` |
| status | ENUM | active, inactive, suspended |
| email_verified | BOOLEAN | Email vérifié ou non |
| last_login | DATETIME | Dernière connexion |

### Table: `wallets`

Portefeuille de chaque utilisateur.

| Colonne | Type | Description |
|---------|------|-------------|
| id | INT | ID unique |
| user_id | INT | Référence vers `users` |
| balance | DECIMAL(10,2) | Solde actuel |
| currency | VARCHAR(3) | Devise (EUR par défaut) |
| status | ENUM | active, frozen, closed |

### Table: `transactions`

Historique de toutes les transactions.

| Colonne | Type | Description |
|---------|------|-------------|
| id | INT | ID unique |
| wallet_id | INT | Référence vers `wallets` |
| type | ENUM | credit, debit, refund, fee |
| amount | DECIMAL(10,2) | Montant |
| balance_before | DECIMAL(10,2) | Solde avant |
| balance_after | DECIMAL(10,2) | Solde après |
| description | TEXT | Description |
| reference | VARCHAR(100) | Référence unique |
| order_id | VARCHAR(100) | Lié à une commande |
| status | ENUM | pending, completed, failed, cancelled |
| created_by | INT | ID de l'admin (pour credit/debit) |

### Table: `user_sessions`

Gestion des sessions utilisateur.

| Colonne | Type | Description |
|---------|------|-------------|
| id | INT | ID unique |
| user_id | INT | Référence vers `users` |
| session_token | VARCHAR(255) | Token de session (unique) |
| ip_address | VARCHAR(45) | Adresse IP |
| user_agent | TEXT | Navigateur/appareil |
| expires_at | DATETIME | Expiration (30 jours) |

---

## 🔌 API d'authentification

**Fichier:** `/api/auth.php`

### 1. Inscription (Register)

**Endpoint:** `POST /api/auth.php`

**Paramètres:**
```javascript
{
  action: 'register',
  email: 'user@example.com',
  password: 'password123',      // Min 6 caractères
  full_name: 'Jean Dupont',
  phone: '+33612345678',         // Optionnel
  company: 'Ma Société'          // Optionnel
}
```

**Réponse succès:**
```json
{
  "success": true,
  "message": "Inscription réussie!",
  "user": {
    "id": 2,
    "email": "user@example.com",
    "full_name": "Jean Dupont",
    "role": "client"
  }
}
```

**Effets:**
- ✅ Crée l'utilisateur avec rôle "client" par défaut
- ✅ Crée un wallet avec solde 0.00
- ✅ Démarre une session automatiquement

### 2. Connexion (Login)

**Endpoint:** `POST /api/auth.php`

**Paramètres:**
```javascript
{
  action: 'login',
  email: 'user@example.com',
  password: 'password123'
}
```

**Réponse succès:**
```json
{
  "success": true,
  "message": "Connexion réussie!",
  "user": {
    "id": 2,
    "email": "user@example.com",
    "full_name": "Jean Dupont",
    "phone": "+33612345678",
    "company": "Ma Société",
    "role": "client",
    "role_display": "Client",
    "permissions": {
      "create_orders": true,
      "view_wallet": true
    },
    "wallet": {
      "balance": "150.00",
      "currency": "EUR"
    }
  }
}
```

### 3. Vérifier la session

**Endpoint:** `GET /api/auth.php?action=check_session`

**Réponse:**
```json
{
  "success": true,
  "authenticated": true,
  "user": {
    "id": 2,
    "email": "user@example.com",
    "full_name": "Jean Dupont",
    "role": "client",
    "wallet": {
      "balance": "150.00",
      "currency": "EUR"
    }
  }
}
```

### 4. Déconnexion (Logout)

**Endpoint:** `POST /api/auth.php`

**Paramètres:**
```javascript
{
  action: 'logout'
}
```

---

## 💰 API Wallet

**Fichier:** `/api/wallet.php`

⚠️ Nécessite une session active

### 1. Récupérer le solde

**Endpoint:** `GET /api/wallet.php?action=get_balance`

**Réponse:**
```json
{
  "success": true,
  "wallet": {
    "balance": "150.00",
    "currency": "EUR",
    "status": "active"
  }
}
```

### 2. Historique des transactions

**Endpoint:** `GET /api/wallet.php?action=get_transactions&limit=50&offset=0`

**Réponse:**
```json
{
  "success": true,
  "transactions": [
    {
      "id": 1,
      "type": "credit",
      "amount": "100.00",
      "balance_before": "50.00",
      "balance_after": "150.00",
      "description": "Ajout de fonds par administrateur",
      "reference": "CREDIT-1234567890-2",
      "created_by_name": "Administrateur",
      "created_at": "2025-10-23 08:30:00",
      "status": "completed"
    }
  ],
  "total": 10,
  "limit": 50,
  "offset": 0
}
```

### 3. Ajouter des fonds (Admin seulement)

**Endpoint:** `POST /api/wallet.php`

**Paramètres:**
```javascript
{
  action: 'add_funds',
  user_id: 2,
  amount: 100.00,
  description: 'Recharge client'  // Optionnel
}
```

**Réponse:**
```json
{
  "success": true,
  "message": "Fonds ajoutés avec succès",
  "wallet": {
    "balance_before": "50.00",
    "balance_after": "150.00",
    "amount_added": "100.00"
  },
  "transaction_id": 15
}
```

### 4. Retirer des fonds (Admin seulement)

**Endpoint:** `POST /api/wallet.php`

**Paramètres:**
```javascript
{
  action: 'deduct_funds',
  user_id: 2,
  amount: 50.00,
  description: 'Paiement commande'  // Optionnel
}
```

**Réponse:**
```json
{
  "success": true,
  "message": "Fonds retirés avec succès",
  "wallet": {
    "balance_before": "150.00",
    "balance_after": "100.00",
    "amount_deducted": "50.00"
  },
  "transaction_id": 16
}
```

### 5. Liste de tous les wallets (Admin seulement)

**Endpoint:** `GET /api/wallet.php?action=get_all_wallets`

**Réponse:**
```json
{
  "success": true,
  "wallets": [
    {
      "id": 1,
      "email": "admin@digiservices.com",
      "full_name": "Administrateur",
      "company": null,
      "balance": "0.00",
      "currency": "EUR",
      "wallet_status": "active",
      "role": "Super Administrateur"
    },
    {
      "id": 2,
      "email": "client@example.com",
      "full_name": "Jean Dupont",
      "company": "Ma Société",
      "balance": "150.00",
      "currency": "EUR",
      "wallet_status": "active",
      "role": "Client"
    }
  ]
}
```

---

## 👥 API Admin

**Fichier:** `/api/admin.php`

⚠️ **Nécessite une session active ET des droits admin**

### 1. Liste de tous les utilisateurs

**Endpoint:** `GET /api/admin.php?action=get_all_users`

**Réponse:**
```json
{
  "success": true,
  "users": [
    {
      "id": 2,
      "email": "client@example.com",
      "full_name": "Jean Dupont",
      "phone": "+33612345678",
      "company": "Ma Société",
      "status": "active",
      "email_verified": false,
      "last_login": "2025-10-23 08:30:00",
      "created_at": "2025-10-22 10:00:00",
      "role_name": "client",
      "role_display": "Client",
      "balance": "150.00",
      "currency": "EUR"
    }
  ],
  "total": 5
}
```

### 2. Modifier le rôle d'un utilisateur

**Endpoint:** `POST /api/admin.php`

**Paramètres:**
```javascript
{
  action: 'update_user_role',
  user_id: 2,
  role_id: 4  // 1=Super Admin, 2=Admin, 3=Client, 4=Employé
}
```

### 3. Modifier le statut d'un utilisateur

**Endpoint:** `POST /api/admin.php`

**Paramètres:**
```javascript
{
  action: 'update_user_status',
  user_id: 2,
  status: 'suspended'  // active, inactive, suspended
}
```

### 4. Supprimer un utilisateur

**Endpoint:** `POST /api/admin.php`

**Paramètres:**
```javascript
{
  action: 'delete_user',
  user_id: 2
}
```

⚠️ **Note:** Impossible de supprimer le super admin (ID 1)

### 5. Liste des rôles

**Endpoint:** `GET /api/admin.php?action=get_all_roles`

### 6. Créer un rôle

**Endpoint:** `POST /api/admin.php`

**Paramètres:**
```javascript
{
  action: 'create_role',
  name: 'manager',
  display_name: 'Manager',
  description: 'Gestionnaire de projets',
  permissions: '{"manage_projects": true, "view_reports": true}'
}
```

---

## 🎭 Rôles et Permissions

### Rôles par défaut

| ID | Nom | Affichage | Permissions |
|----|-----|-----------|-------------|
| 1 | super_admin | Super Administrateur | `{"all": true}` |
| 2 | admin | Administrateur | `{"manage_users": true, "manage_orders": true, "view_reports": true}` |
| 3 | client | Client | `{"create_orders": true, "view_wallet": true}` |
| 4 | employee | Employé | `{"manage_orders": true, "view_orders": true}` |

### Vérification des permissions

```javascript
// Côté client (après login)
if (user.permissions.all || user.permissions.manage_users) {
  // Afficher le panneau admin
}
```

---

## 💻 Exemples d'utilisation

### Exemple 1: Page de connexion complète

```html
<form id="login-form">
  <input type="email" name="email" required>
  <input type="password" name="password" required>
  <button type="submit">Connexion</button>
</form>

<script>
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const formData = new FormData(e.target);
  formData.append('action', 'login');
  
  const response = await fetch('/api/auth.php', {
    method: 'POST',
    body: formData
  });
  
  const result = await response.json();
  
  if (result.success) {
    console.log('Connecté!', result.user);
    window.location.href = '/dashboard.php';
  } else {
    alert(result.error);
  }
});
</script>
```

### Exemple 2: Vérifier la session au chargement

```javascript
// Au chargement de chaque page
window.addEventListener('load', async () => {
  const response = await fetch('/api/auth.php?action=check_session');
  const result = await response.json();
  
  if (!result.authenticated) {
    // Rediriger vers login
    window.location.href = '/login.html';
  } else {
    // Utilisateur connecté
    console.log('User:', result.user);
    updateUserUI(result.user);
  }
});
```

### Exemple 3: Admin ajoute du solde à un client

```javascript
async function addFundsToUser(userId, amount) {
  const formData = new FormData();
  formData.append('action', 'add_funds');
  formData.append('user_id', userId);
  formData.append('amount', amount);
  formData.append('description', 'Recharge manuelle par admin');
  
  const response = await fetch('/api/wallet.php', {
    method: 'POST',
    body: formData
  });
  
  const result = await response.json();
  
  if (result.success) {
    console.log('Fonds ajoutés!', result.wallet);
    alert(`Nouveau solde: ${result.wallet.balance_after}€`);
  } else {
    alert(result.error);
  }
}

// Utilisation
addFundsToUser(2, 100.00);
```

### Exemple 4: Afficher le wallet de l'utilisateur

```javascript
async function displayWallet() {
  const response = await fetch('/api/wallet.php?action=get_balance');
  const result = await response.json();
  
  if (result.success) {
    document.getElementById('balance').textContent = 
      `${result.wallet.balance} ${result.wallet.currency}`;
  }
}
```

### Exemple 5: Historique des transactions

```javascript
async function loadTransactions() {
  const response = await fetch('/api/wallet.php?action=get_transactions&limit=20');
  const result = await response.json();
  
  if (result.success) {
    const tbody = document.getElementById('transactions');
    tbody.innerHTML = '';
    
    result.transactions.forEach(t => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${t.created_at}</td>
        <td>${t.type}</td>
        <td>${t.amount}€</td>
        <td>${t.balance_after}€</td>
        <td>${t.description}</td>
      `;
      tbody.appendChild(tr);
    });
  }
}
```

---

## 🔒 Sécurité

### Bonnes pratiques

✅ **Mots de passe hashés** - Bcrypt avec salt automatique  
✅ **Sessions sécurisées** - Tokens uniques avec expiration  
✅ **Validation des entrées** - Email, longueur mot de passe, etc.  
✅ **SQL Préparé** - Protection contre injection SQL  
✅ **Vérification des rôles** - Chaque action sensible vérifie les permissions  
✅ **HTTPS recommandé** - En production, utilisez toujours HTTPS  

### Recommandations

1. **Changez le mot de passe admin** après installation
2. **Utilisez HTTPS** en production
3. **Limitez les tentatives** de connexion (à implémenter)
4. **Activez la vérification** email (à implémenter)
5. **Logs d'audit** - Enregistrez les actions sensibles

---

## 🐛 Troubleshooting

### Erreur: "Non authentifié"

**Solution:** Vérifiez que la session PHP est active. Les cookies doivent être acceptés.

### Erreur: "Accès refusé - Admin seulement"

**Solution:** Connectez-vous avec un compte admin ou super admin.

### Le solde ne se met pas à jour

**Solution:** Vérifiez les transactions dans la table `transactions`. Le solde est mis à jour de manière transactionnelle.

### Session expirée trop rapidement

**Solution:** Les sessions durent 30 jours. Vérifiez que le navigateur accepte les cookies.

---

## 📚 Ressources

- `login.html` - Page de connexion/inscription
- `install-auth.php` - Installation des tables
- `api/auth.php` - API d'authentification
- `api/wallet.php` - API de gestion wallet
- `api/admin.php` - API d'administration
- `AUTH_README.md` - Cette documentation

---

## ✨ Prochaines étapes

Vous pouvez maintenant :

1. ✅ **Installer** le système avec `install-auth.php`
2. ✅ **Tester** la connexion sur `login.html`
3. ✅ **Intégrer** l'authentification dans vos pages existantes
4. ✅ **Personnaliser** les rôles et permissions selon vos besoins
5. ✅ **Créer** un dashboard admin pour gérer utilisateurs et wallets

**Bon développement ! 🚀**
