<?php
/**
 * Contenu de la boutique Services & Produits avec filtrage par catégories
 */
?>

<!-- Services Tab Content -->
<div id="services-tab" class="shop-tab-content">
    <div class="bg-white rounded-xl shadow-lg p-6 max-h-[calc(100vh-300px)] overflow-y-auto">
        <h3 class="text-2xl font-bold text-gray-800 mb-6 sticky top-0 bg-white pb-4 border-b">Services Professionnels</h3>
        
        <!-- Filtres catégories -->
        <div class="mb-6 flex flex-wrap gap-2">
            <button onclick="filterServices('all')" class="service-filter-btn px-4 py-2 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700 transition-colors">
                Tous
            </button>
            <button onclick="filterServices('design')" class="service-filter-btn px-4 py-2 rounded-lg bg-gray-100 text-gray-700 font-medium hover:bg-gray-200 transition-colors">
                🎨 Design & Branding
            </button>
            <button onclick="filterServices('dev')" class="service-filter-btn px-4 py-2 rounded-lg bg-gray-100 text-gray-700 font-medium hover:bg-gray-200 transition-colors">
                💻 Développement Web
            </button>
            <button onclick="filterServices('marketing')" class="service-filter-btn px-4 py-2 rounded-lg bg-gray-100 text-gray-700 font-medium hover:bg-gray-200 transition-colors">
                📢 Marketing Digital
            </button>
        </div>
        
        <!-- Grille des services -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <!-- Logo Design -->
            <div class="service-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="design">
                <div class="h-40 bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                    <span class="text-6xl">🎨</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Logo Design Premium</h5>
                        <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-semibold">Disponible</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Création de logo professionnel</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">150€</div>
                        <div class="text-xs text-gray-500">5-7 jours</div>
                    </div>
                    <button onclick="orderService('logo-premium', 'Logo Design Premium', 150)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Commander
                    </button>
                </div>
            </div>

            <!-- Brochure -->
            <div class="service-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="design">
                <div class="h-40 bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                    <span class="text-6xl">📄</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Brochure Entreprise</h5>
                        <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-semibold">Disponible</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Conception de brochure professionnelle</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">200€</div>
                        <div class="text-xs text-gray-500">7-10 jours</div>
                    </div>
                    <button onclick="orderService('brochure', 'Brochure Entreprise', 200)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Commander
                    </button>
                </div>
            </div>

            <!-- Identité Visuelle -->
            <div class="service-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="design">
                <div class="h-40 bg-gradient-to-br from-pink-500 to-rose-500 flex items-center justify-center">
                    <span class="text-6xl">🎭</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Identité Visuelle Complète</h5>
                        <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-semibold">Disponible</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Logo, charte graphique, cartes</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">500€</div>
                        <div class="text-xs text-gray-500">15-20 jours</div>
                    </div>
                    <button onclick="orderService('identite-complete', 'Identité Visuelle Complète', 500)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Commander
                    </button>
                </div>
            </div>

            <!-- Site Vitrine -->
            <div class="service-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="dev">
                <div class="h-40 bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center">
                    <span class="text-6xl">🌐</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Site Vitrine</h5>
                        <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-semibold">Disponible</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Site web responsive de 5 pages</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">800€</div>
                        <div class="text-xs text-gray-500">10-15 jours</div>
                    </div>
                    <button onclick="orderService('site-vitrine', 'Site Vitrine', 800)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Commander
                    </button>
                </div>
            </div>

            <!-- Site E-commerce -->
            <div class="service-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="dev">
                <div class="h-40 bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center">
                    <span class="text-6xl">🛒</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Site E-commerce</h5>
                        <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-semibold">Disponible</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Boutique en ligne complète</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">1500€</div>
                        <div class="text-xs text-gray-500">20-30 jours</div>
                    </div>
                    <button onclick="orderService('site-ecommerce', 'Site E-commerce', 1500)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Commander
                    </button>
                </div>
            </div>

            <!-- Application Mobile -->
            <div class="service-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="dev">
                <div class="h-40 bg-gradient-to-br from-yellow-500 to-orange-500 flex items-center justify-center">
                    <span class="text-6xl">📱</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Application Mobile</h5>
                        <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-semibold">Disponible</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">App iOS/Android personnalisée</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">2500€</div>
                        <div class="text-xs text-gray-500">30-45 jours</div>
                    </div>
                    <button onclick="orderService('app-mobile', 'Application Mobile', 2500)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Commander
                    </button>
                </div>
            </div>

            <!-- Campagne SEO -->
            <div class="service-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="marketing">
                <div class="h-40 bg-gradient-to-br from-red-500 to-pink-500 flex items-center justify-center">
                    <span class="text-6xl">📊</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Campagne SEO</h5>
                        <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-semibold">Disponible</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Optimisation SEO complète</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">300€/mois</div>
                        <div class="text-xs text-gray-500">3-6 mois</div>
                    </div>
                    <button onclick="orderService('seo-campaign', 'Campagne SEO', 300)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Commander
                    </button>
                </div>
            </div>

            <!-- Gestion Réseaux Sociaux -->
            <div class="service-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="marketing">
                <div class="h-40 bg-gradient-to-br from-blue-400 to-cyan-400 flex items-center justify-center">
                    <span class="text-6xl">📱</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Gestion Réseaux Sociaux</h5>
                        <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-semibold">Disponible</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Gestion complète réseaux sociaux</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">250€/mois</div>
                        <div class="text-xs text-gray-500">3 posts/semaine</div>
                    </div>
                    <button onclick="orderService('social-media', 'Gestion Réseaux Sociaux', 250)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Commander
                    </button>
                </div>
            </div>

            <!-- Email Marketing -->
            <div class="service-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="marketing">
                <div class="h-40 bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
                    <span class="text-6xl">✉️</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Email Marketing</h5>
                        <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-semibold">Disponible</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Campagnes email ciblées</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">180€/mois</div>
                        <div class="text-xs text-gray-500">2 campagnes/mois</div>
                    </div>
                    <button onclick="orderService('email-marketing', 'Email Marketing', 180)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Commander
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Products Tab Content -->
<div id="products-tab" class="shop-tab-content hidden">
    <div class="bg-white rounded-xl shadow-lg p-6 max-h-[calc(100vh-300px)] overflow-y-auto">
        <h3 class="text-2xl font-bold text-gray-800 mb-6 sticky top-0 bg-white pb-4 border-b">Produits Numériques</h3>
        
        <!-- Filtres catégories -->
        <div class="mb-6 flex flex-wrap gap-2">
            <button onclick="filterProducts('all')" class="product-filter-btn px-4 py-2 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700 transition-colors">
                Tous
            </button>
            <button onclick="filterProducts('templates')" class="product-filter-btn px-4 py-2 rounded-lg bg-gray-100 text-gray-700 font-medium hover:bg-gray-200 transition-colors">
                🎨 Templates & Thèmes
            </button>
            <button onclick="filterProducts('software')" class="product-filter-btn px-4 py-2 rounded-lg bg-gray-100 text-gray-700 font-medium hover:bg-gray-200 transition-colors">
                💻 Logiciels & Outils
            </button>
        </div>
        
        <!-- Grille des produits -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <!-- WordPress Template -->
            <div class="product-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="templates">
                <div class="h-40 bg-gradient-to-br from-violet-500 to-purple-500 flex items-center justify-center">
                    <span class="text-6xl">🎨</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Template WordPress Premium</h5>
                        <span class="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-semibold">Téléchargement</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Thème WordPress complet</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">59€</div>
                        <div class="text-xs text-gray-500">Instantané</div>
                    </div>
                    <button onclick="orderProduct('wordpress-template', 'Template WordPress Premium', 59)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Acheter
                    </button>
                </div>
            </div>

            <!-- Email Templates -->
            <div class="product-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="templates">
                <div class="h-40 bg-gradient-to-br from-green-500 to-teal-500 flex items-center justify-center">
                    <span class="text-6xl">📱</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Pack Templates Email</h5>
                        <span class="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-semibold">Téléchargement</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">20 templates email responsive</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">39€</div>
                        <div class="text-xs text-gray-500">Instantané</div>
                    </div>
                    <button onclick="orderProduct('email-templates', 'Pack Templates Email', 39)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Acheter
                    </button>
                </div>
            </div>

            <!-- Social Kit -->
            <div class="product-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="templates">
                <div class="h-40 bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center">
                    <span class="text-6xl">🎭</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Kit Réseaux Sociaux</h5>
                        <span class="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-semibold">Téléchargement</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">50 templates réseaux sociaux</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">49€</div>
                        <div class="text-xs text-gray-500">Instantané</div>
                    </div>
                    <button onclick="orderProduct('social-kit', 'Kit Réseaux Sociaux', 49)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Acheter
                    </button>
                </div>
            </div>

            <!-- WordPress SEO Plugin -->
            <div class="product-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="software">
                <div class="h-40 bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center">
                    <span class="text-6xl">⚙️</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Plugin WordPress SEO</h5>
                        <span class="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-semibold">Licence</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">Plugin SEO complet</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">79€</div>
                        <div class="text-xs text-gray-500">1 an</div>
                    </div>
                    <button onclick="orderProduct('wp-seo-plugin', 'Plugin WordPress SEO', 79)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Acheter
                    </button>
                </div>
            </div>

            <!-- Icons Pack -->
            <div class="product-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="software">
                <div class="h-40 bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center">
                    <span class="text-6xl">🎨</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Pack Icônes Pro</h5>
                        <span class="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-semibold">Téléchargement</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">5000+ icônes vectorielles</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">29€</div>
                        <div class="text-xs text-gray-500">Instantané</div>
                    </div>
                    <button onclick="orderProduct('icons-pack', 'Pack Icônes Pro', 29)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Acheter
                    </button>
                </div>
            </div>

            <!-- Photo Library -->
            <div class="product-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all border border-gray-200" data-category="software">
                <div class="h-40 bg-gradient-to-br from-pink-500 to-rose-500 flex items-center justify-center">
                    <span class="text-6xl">🖼️</span>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-2">
                        <h5 class="font-bold text-gray-800 text-lg">Bibliothèque Photos HD</h5>
                        <span class="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-semibold">Accès</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-3">10,000+ photos haute qualité</p>
                    <div class="flex items-center justify-between mb-4">
                        <div class="text-2xl font-bold text-blue-600">99€/an</div>
                        <div class="text-xs text-gray-500">Illimité</div>
                    </div>
                    <button onclick="orderProduct('photo-library', 'Bibliothèque Photos HD', 99)" class="w-full bg-blue-600 text-white py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        S'abonner
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Shop Tab Management
function showShopTab(tab) {
    document.getElementById('services-tab').classList.add('hidden');
    document.getElementById('products-tab').classList.add('hidden');
    document.getElementById(tab + '-tab').classList.remove('hidden');
    
    document.querySelectorAll('.shop-tab').forEach(btn => {
        btn.classList.remove('bg-white', 'text-gray-800', 'font-medium', 'shadow-sm');
        btn.classList.add('text-gray-600');
    });
    event.target.classList.add('bg-white', 'text-gray-800', 'font-medium', 'shadow-sm');
    event.target.classList.remove('text-gray-600');
}

// Filter Services by Category
function filterServices(category) {
    const cards = document.querySelectorAll('.service-card');
    const buttons = document.querySelectorAll('.service-filter-btn');
    
    // Update button styles
    buttons.forEach(btn => {
        btn.classList.remove('bg-blue-600', 'text-white');
        btn.classList.add('bg-gray-100', 'text-gray-700');
    });
    event.target.classList.remove('bg-gray-100', 'text-gray-700');
    event.target.classList.add('bg-blue-600', 'text-white');
    
    // Filter cards
    cards.forEach(card => {
        if (category === 'all' || card.dataset.category === category) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

// Filter Products by Category
function filterProducts(category) {
    const cards = document.querySelectorAll('.product-card');
    const buttons = document.querySelectorAll('.product-filter-btn');
    
    // Update button styles
    buttons.forEach(btn => {
        btn.classList.remove('bg-blue-600', 'text-white');
        btn.classList.add('bg-gray-100', 'text-gray-700');
    });
    event.target.classList.remove('bg-gray-100', 'text-gray-700');
    event.target.classList.add('bg-blue-600', 'text-white');
    
    // Filter cards
    cards.forEach(card => {
        if (category === 'all' || card.dataset.category === category) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

// Order Service
async function orderService(serviceId, serviceName, price) {
    if (confirm(`Commander le service "${serviceName}" pour ${price}€ ?\n\nLe montant sera débité de votre wallet.`)) {
        try {
            showToast('⏳ Traitement de votre commande...', 'info');
            const formData = new FormData();
            formData.append('action', 'order_service');
            formData.append('service_id', serviceId);
            formData.append('service_name', serviceName);
            formData.append('price', price);
            const response = await fetch('/api/shop.php', { method: 'POST', body: formData });
            const data = await response.json();
            if (data.success) {
                showToast(`✅ Commande créée avec succès !`, 'success');
                setTimeout(() => {
                    alert(`🎉 Commande confirmée !\n\nService: ${serviceName}\nPrix: ${price}€\n\nUn employé va prendre en charge votre projet sous peu.`);
                }, 500);
            } else {
                showToast(`❌ Erreur : ${data.message}`, 'error');
            }
        } catch (error) {
            showToast('❌ Erreur lors de la commande', 'error');
        }
    }
}

// Order Product
async function orderProduct(productId, productName, price) {
    if (confirm(`Acheter "${productName}" pour ${price}€ ?\n\nLe montant sera débité de votre wallet.`)) {
        try {
            showToast('⏳ Traitement de votre achat...', 'info');
            const formData = new FormData();
            formData.append('action', 'order_product');
            formData.append('product_id', productId);
            formData.append('product_name', productName);
            formData.append('price', price);
            const response = await fetch('/api/shop.php', { method: 'POST', body: formData });
            const data = await response.json();
            if (data.success) {
                showToast(`✅ Achat effectué avec succès !`, 'success');
                setTimeout(() => {
                    if (confirm(`🎉 Achat confirmé !\n\nProduit: ${productName}\nPrix: ${price}€\n\nVoulez-vous télécharger le produit maintenant ?`)) {
                        window.open(data.download_url, '_blank');
                        showToast('📥 Téléchargement démarré !', 'success');
                    }
                }, 500);
            } else {
                showToast(`❌ Erreur : ${data.message}`, 'error');
            }
        } catch (error) {
            showToast('❌ Erreur lors de l\'achat', 'error');
        }
    }
}
</script>
