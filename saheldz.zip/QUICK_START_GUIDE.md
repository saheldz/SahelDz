# 🚀 Guide de Démarrage Rapide - DigiServices

## Configuration Initiale (Une Seule Fois)

### Étape 1: Initialiser les Rôles Par Défaut

Exécutez ce script pour créer/mettre à jour les 4 rôles de base :

```bash
cd /Users/mac15/Desktop/localhost-system-backup
php init-default-roles.php
```

Ce script va :
- ✅ Créer ou mettre à jour les rôles : Super Admin, Admin, Employé, Client
- ✅ Configurer les permissions appropriées pour chaque rôle
- ✅ Assigner automatiquement le rôle "Client" aux utilisateurs sans rôle

### Résultat Attendu

Vous devriez voir :
```
=== INITIALISATION DES RÔLES PAR DÉFAUT ===

✓ Rôle créé/mis à jour: Super Administrateur
✓ Rôle créé/mis à jour: Administrateur
✓ Rôle créé/mis à jour: Employé
✓ Rôle créé/mis à jour: Client

✅ Initialisation terminée avec succès!
```

## Comment Ça Fonctionne Maintenant

### 📝 Inscription / Création d'Utilisateur

**Tous les nouveaux utilisateurs sont automatiquement des CLIENTS par défaut !**

#### Via Inscription (Register)
1. Un utilisateur s'inscrit via la page d'inscription
2. ✅ Il reçoit automatiquement le rôle "Client"
3. ✅ Un wallet est créé automatiquement (solde: 0.00€)
4. ✅ Il est redirigé vers `/client-dashboard.php`

#### Via Admin (Création Manuelle)
1. Admin crée un utilisateur dans `/admin-users.php`
2. ✅ Si aucun rôle n'est spécifié → rôle "Client" par défaut
3. ✅ Si un rôle est spécifié → utilise ce rôle
4. ✅ Un wallet est créé automatiquement

### 🔄 Connexion et Redirection Automatique

Quand un utilisateur se connecte, il est **automatiquement redirigé** vers l'interface appropriée :

| Rôle | Redirection | Interface |
|------|-------------|-----------|
| **Super Admin** | `/admin-dashboard.php` | Dashboard administrateur complet |
| **Admin** | `/admin-dashboard.php` | Dashboard administrateur complet |
| **Employé** | `/employee-dashboard.php` | Dashboard employé avec gestion des tâches |
| **Client** | `/client-dashboard.php` | Dashboard client avec services |

### 🎯 Interfaces Disponibles

#### 1. Dashboard Admin (`/admin-dashboard.php`)
**Pour:** Super Admin & Admin

**Fonctionnalités:**
- 📊 Stats globales (utilisateurs, wallets, transactions)
- 👥 Gestion des utilisateurs
- 🔐 Gestion des rôles et permissions
- 💰 Gestion des wallets (ajouter/retirer des fonds)
- 📦 Gestion des commandes
- 📧 Configuration SMTP
- 🧩 Gestion des addons
- 👤 Impersonation (se connecter en tant qu'utilisateur)

#### 2. Dashboard Employé (`/employee-dashboard.php`)
**Pour:** Employés

**Fonctionnalités:**
- 📋 Tâches assignées
- 📁 Projets en cours
- 📦 Commandes à traiter
- 🎨 Accès aux outils de travail (Branding, etc.)
- 💬 Messages et notifications
- 📊 Statistiques personnelles

#### 3. Dashboard Client (`/client-dashboard.php`)
**Pour:** Clients

**Fonctionnalités:**
- 💰 Consultation du wallet et solde
- 📦 Mes commandes
- 📁 Mes projets
- 🎨 Services disponibles (Branding, Développement, Marketing, Multimédia)
- 💳 Historique des transactions
- 💵 Demande de rechargement de compte

## 🔐 Système de Permissions

### Permissions par Rôle

**Super Admin & Admin:**
```json
{ "all": true }
```
→ Accès complet à toutes les fonctionnalités

**Employé:**
```json
{
  "view_users": true,
  "view_orders": true,
  "manage_orders": true,
  "create_orders": true,
  "view_wallet": true,
  "manage_projects": true,
  "upload_files": true,
  "view_reports": true
}
```

**Client:**
```json
{
  "view_wallet": true,
  "view_orders": true,
  "create_orders": true,
  "upload_files": true
}
```

## 🔧 Gestion des Rôles par l'Admin

### Modifier les Rôles Existants

1. Connectez-vous en tant qu'Admin
2. Allez sur `/admin-roles.php`
3. Cliquez sur "✏️ Modifier" sur le rôle souhaité
4. Ajustez les permissions selon vos besoins
5. Sauvegardez

### Créer un Nouveau Rôle

1. Connectez-vous en tant qu'Admin
2. Allez sur `/admin-roles.php`
3. Cliquez sur "➕ Créer un rôle"
4. Définissez :
   - Nom technique (ex: `manager`)
   - Nom d'affichage (ex: `Manager de Projets`)
   - Description
   - Permissions spécifiques
5. Sauvegardez

### Changer le Rôle d'un Utilisateur

1. Connectez-vous en tant qu'Admin
2. Allez sur `/admin-users.php`
3. Cliquez sur un utilisateur
4. Changez son rôle dans le menu déroulant
5. Sauvegardez

## 🧪 Tests Recommandés

### Test 1: Inscription d'un Nouveau Client
```
1. Allez sur la page d'inscription
2. Créez un compte
3. ✅ Vérifiez que vous êtes redirigé vers /client-dashboard.php
4. ✅ Vérifiez que votre rôle est "Client"
5. ✅ Vérifiez que votre wallet existe (0.00€)
```

### Test 2: Connexions avec Différents Rôles
```
1. Connectez-vous avec un compte Admin
   ✅ Devrait rediriger vers /admin-dashboard.php
   
2. Connectez-vous avec un compte Employé
   ✅ Devrait rediriger vers /employee-dashboard.php
   
3. Connectez-vous avec un compte Client
   ✅ Devrait rediriger vers /client-dashboard.php
```

### Test 3: Impersonation (Admin)
```
1. Connectez-vous en tant qu'Admin
2. Allez sur /admin-users.php
3. Cliquez sur "Se connecter en tant que" pour un client
4. ✅ Vous devriez voir l'interface client
5. ✅ Une bannière orange apparaît en haut
6. Cliquez sur "Retour Admin"
7. ✅ Vous revenez au dashboard admin
```

### Test 4: Modification de Rôle
```
1. Connectez-vous en tant qu'Admin
2. Allez sur /admin-users.php
3. Modifiez le rôle d'un utilisateur (Client → Employé)
4. Déconnectez cet utilisateur s'il est connecté
5. Reconnectez-vous avec ce compte
6. ✅ Devrait rediriger vers /employee-dashboard.php
```

## 📝 Fichiers Importants

| Fichier | Description |
|---------|-------------|
| `init-default-roles.php` | Script d'initialisation des rôles (à exécuter une fois) |
| `index.php` | Point d'entrée avec redirection automatique |
| `client-dashboard.php` | Interface client |
| `employee-dashboard.php` | Interface employé |
| `admin-dashboard.php` | Interface administrateur |
| `api/auth.php` | API d'authentification (rôle client par défaut) |
| `api/admin.php` | API d'administration (création users, impersonation) |
| `admin-roles.php` | Gestion des rôles par l'admin |
| `admin-users.php` | Gestion des utilisateurs par l'admin |

## 🎨 Personnalisation

### Changer le Rôle Par Défaut

Si vous voulez que les nouveaux utilisateurs soient des "Employés" au lieu de "Clients" :

1. Modifiez `api/auth.php` ligne ~110 :
```php
// Remplacer 'client' par 'employee'
$stmt = $pdo->prepare("SELECT id FROM roles WHERE name = 'employee' LIMIT 1");
```

2. Modifiez `api/admin.php` ligne ~203 :
```php
// Remplacer 'client' par 'employee'
$stmt = $pdo->prepare("SELECT id FROM roles WHERE name = 'employee' LIMIT 1");
```

## ✅ Résumé

✨ **Fonctionnalités Principales:**
- ✅ Rôle par défaut "Client" pour tous les nouveaux utilisateurs
- ✅ Interfaces dédiées pour chaque type d'utilisateur
- ✅ Redirection automatique selon le rôle
- ✅ Système de permissions granulaire
- ✅ Gestion complète des rôles par l'admin
- ✅ Impersonation sécurisée pour les admins
- ✅ Création automatique du wallet à l'inscription

🎯 **À Retenir:**
- **Nouveaux utilisateurs = Clients automatiquement**
- **Admin peut modifier n'importe quel rôle à tout moment**
- **3 interfaces différentes selon le rôle**
- **Les permissions sont personnalisables via `/admin-roles.php`**

## 🆘 Support

Pour toute question ou problème:
1. Consultez `ROLES_AND_PERMISSIONS.md` pour la documentation complète
2. Vérifiez que `init-default-roles.php` a été exécuté
3. Vérifiez que les rôles existent dans la base de données
4. Testez avec différents comptes pour valider les redirections

---

**Bon démarrage avec DigiServices ! 🚀**
