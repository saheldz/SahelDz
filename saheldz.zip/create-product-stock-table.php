<?php
/**
 * Créer la table product_stock pour gérer les codes/clés de produits
 */

require_once 'config/database.php';

$pdo = getDB();

echo "=== CREATION TABLE PRODUCT_STOCK ===\n\n";

try {
    echo "📝 Création de la table product_stock...\n";
    
    $sql = "CREATE TABLE IF NOT EXISTS product_stock (
        id INT AUTO_INCREMENT PRIMARY KEY,
        item_id INT NOT NULL,
        product_code VARCHAR(255) NOT NULL,
        product_key TEXT,
        status ENUM('available', 'sold', 'reserved') DEFAULT 'available',
        sold_to_user_id INT NULL,
        sold_at TIMESTAMP NULL,
        order_id INT NULL,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (item_id) REFERENCES shop_items(id) ON DELETE CASCADE,
        INDEX idx_item (item_id),
        INDEX idx_status (status),
        INDEX idx_sold_to (sold_to_user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $pdo->exec($sql);
    echo "✅ Table product_stock créée avec succès\n\n";
    
    // Vérifier la structure
    echo "📋 Vérification de la structure...\n";
    $stmt = $pdo->query("DESCRIBE product_stock");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($columns as $col) {
        echo "  ✓ {$col['Field']} ({$col['Type']})\n";
    }
    
    echo "\n✅ TABLE PRÊTE !\n\n";
    echo "Pour ajouter des produits au stock, utilisez admin-shop.php\n";
    echo "ou insérez directement dans la table product_stock.\n\n";
    
    echo "Exemple d'insertion :\n";
    echo "INSERT INTO product_stock (item_id, product_code, product_key)\n";
    echo "VALUES (1, 'NETFLIX-ABC123', 'Compte: user@example.com / Pass: 123456');\n";
    
} catch (PDOException $e) {
    echo "❌ ERREUR: " . $e->getMessage() . "\n";
}
