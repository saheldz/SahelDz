<?php
/**
 * Application Client - Interface complète pour les clients
 */
require_once '../config/auth-check.php';

// Récupérer les informations du client
require_once '../config/database.php';
$pdo = getDB();

// Wallet info
$stmt = $pdo->prepare("SELECT balance, currency FROM wallets WHERE user_id = ? AND status = 'active'");
$stmt->execute([$GLOBALS['current_user']['id']]);
$wallet = $stmt->fetch();

// Abonnement actif
$stmt = $pdo->prepare("SELECT * FROM subscriptions WHERE user_id = ? AND status IN ('active', 'trialing') ORDER BY created_at DESC LIMIT 1");
$stmt->execute([$GLOBALS['current_user']['id']]);
$activeSubscription = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="fr" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Espace Client - DigiServices</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        * { box-sizing: border-box; }
        body, html { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; }
        .sidebar-item:hover { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .card-hover:hover { transform: translateY(-2px); box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .gradient-bg { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
    </style>
</head>
<body class="h-full bg-gray-50 font-sans overflow-hidden">
    <?php include '../config/impersonation-banner.php'; ?>
    <div class="flex h-full w-full">
        <!-- Sidebar -->
        <div id="sidebar" class="w-64 gradient-bg text-white flex-shrink-0 overflow-y-auto transition-all duration-300">
            <div class="p-6">
                <h1 class="text-2xl font-bold">DigiServices</h1>
                <p class="text-sm opacity-80 mt-1">Espace Client</p>
                <div class="mt-4 bg-white/10 rounded-lg p-3">
                    <p class="text-xs opacity-70">Solde</p>
                    <p class="text-xl font-bold"><?php echo number_format($wallet['balance'] ?? 0, 2); ?> €</p>
                </div>
            </div>
            
            <nav class="mt-6">
                <div class="px-4 space-y-2">
                    <button onclick="showSection('dashboard')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3 bg-white bg-opacity-20">
                        <span>📊</span>
                        <span>Tableau de Bord</span>
                    </button>
                    
                    <button onclick="showSection('subscriptions')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3">
                        <span>📦</span>
                        <span>Mes Abonnements</span>
                    </button>
                    
                    <button onclick="showSection('orders')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3">
                        <span>📋</span>
                        <span>Mes Commandes</span>
                    </button>
                    
                    <button onclick="showSection('wallet')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3">
                        <span>💰</span>
                        <span>Mon Wallet</span>
                    </button>
                    
                    <button onclick="showSection('projects')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3">
                        <span>🎨</span>
                        <span>Mes Projets</span>
                    </button>
                    
                    <button onclick="showSection('services')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3">
                        <span>🛍️</span>
                        <span>Services et Produits</span>
                    </button>
                    
                    <button onclick="showSection('profile')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3">
                        <span>👤</span>
                        <span>Mon Profil</span>
                    </button>
                    
                    <button onclick="showSection('support')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3">
                        <span>💬</span>
                        <span>Support</span>
                    </button>
                    
                    <button onclick="logout()" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3 mt-4 bg-white/10">
                        <span>🚪</span>
                        <span>Déconnexion</span>
                    </button>
                </div>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 overflow-x-hidden overflow-y-auto">
            <!-- Top Header with Profile -->
            <div class="bg-white border-b border-gray-200 px-8 py-4 sticky top-0 z-40">
                <div class="flex items-center justify-between">
                    <!-- Hamburger Menu Button -->
                    <button onclick="toggleSidebar()" class="text-gray-600 hover:text-gray-800 focus:outline-none">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                        </svg>
                    </button>
                    
                    <div class="flex items-center">
                    <div class="relative">
                        <button onclick="toggleProfileMenu()" class="flex items-center space-x-3 hover:bg-gray-50 rounded-lg px-3 py-2 transition-colors">
                            <span class="text-sm font-medium text-gray-700">
                                <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Utilisateur'); ?>
                            </span>
                            <div class="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-white font-semibold">
                                <?php echo strtoupper(substr($_SESSION['user_name'] ?? 'U', 0, 1)); ?>
                            </div>
                        </button>
                        
                        <!-- Profile Dropdown Menu -->
                        <div id="profile-menu" class="hidden absolute right-0 top-full mt-2 w-64 bg-white rounded-lg shadow-xl border border-gray-200 py-2">
                            <div class="px-4 py-3 border-b border-gray-100">
                                <p class="text-sm font-semibold text-gray-800">
                                    <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Utilisateur'); ?>
                                </p>
                                <p class="text-xs text-gray-500">
                                    <?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?>
                                </p>
                            </div>
                            
                            <a href="/settings.php" class="flex items-center space-x-3 px-4 py-3 hover:bg-gray-50 transition-colors">
                                <span class="text-xl">👤</span>
                                <span class="text-sm text-gray-700">Mon Compte</span>
                            </a>
                            
                            <a href="/change-password.php" class="flex items-center space-x-3 px-4 py-3 hover:bg-gray-50 transition-colors">
                                <span class="text-xl">🔐</span>
                                <span class="text-sm text-gray-700">Changer le mot de passe</span>
                            </a>
                            
                            <div class="border-t border-gray-100 mt-2 pt-2">
                                <button onclick="logout()" class="w-full flex items-center space-x-3 px-4 py-3 hover:bg-red-50 transition-colors text-red-600">
                                    <span class="text-xl">🚪</span>
                                    <span class="text-sm font-medium">Déconnexion</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Dashboard Section -->
            <div id="dashboard" class="section p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Bienvenue, <?php echo htmlspecialchars($GLOBALS['current_user']['full_name']); ?> ! 👋</h2>
                    <p class="text-gray-600 mt-2">Voici un aperçu de votre compte</p>
                </div>

                <!-- Stats Cards -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <!-- Wallet -->
                    <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
                        <div class="flex items-center justify-between mb-4">
                            <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                                <span class="text-2xl">💰</span>
                            </div>
                        </div>
                        <h3 class="text-3xl font-bold text-gray-800 mb-1"><?php echo number_format($wallet['balance'] ?? 0, 2); ?> €</h3>
                        <p class="text-gray-600 text-sm">Solde disponible</p>
                        <button onclick="showSection('wallet')" class="mt-4 w-full bg-green-500 text-white py-2 rounded-lg hover:bg-green-600 transition-colors">
                            Gérer mon wallet
                        </button>
                    </div>

                    <!-- Abonnement -->
                    <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
                        <div class="flex items-center justify-between mb-4">
                            <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                                <span class="text-2xl">📦</span>
                            </div>
                        </div>
                        <?php if ($activeSubscription): ?>
                            <h3 class="text-xl font-bold text-gray-800 mb-1"><?php echo htmlspecialchars($activeSubscription['plan_name']); ?></h3>
                            <p class="text-gray-600 text-sm">Abonnement actif</p>
                        <?php else: ?>
                            <h3 class="text-xl font-bold text-gray-800 mb-1">Aucun abonnement</h3>
                            <p class="text-gray-600 text-sm">Choisissez un plan</p>
                        <?php endif; ?>
                        <button onclick="showSection('subscriptions')" class="mt-4 w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition-colors">
                            Mes abonnements
                        </button>
                    </div>

                    <!-- Commandes -->
                    <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
                        <div class="flex items-center justify-between mb-4">
                            <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                                <span class="text-2xl">📋</span>
                            </div>
                        </div>
                        <h3 class="text-3xl font-bold text-gray-800 mb-1">0</h3>
                        <p class="text-gray-600 text-sm">Commandes actives</p>
                        <button onclick="showSection('orders')" class="mt-4 w-full bg-purple-500 text-white py-2 rounded-lg hover:bg-purple-600 transition-colors">
                            Voir mes commandes
                        </button>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <h3 class="text-xl font-semibold mb-4">⚡ Actions rapides</h3>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <button onclick="showSection('subscriptions')" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl hover:shadow-md transition-all">
                            <span class="text-4xl mb-3">📦</span>
                            <span class="font-semibold text-gray-800">Abonnements</span>
                        </button>

                        <button onclick="showSection('services')" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl hover:shadow-md transition-all">
                            <span class="text-4xl mb-3">🎨</span>
                            <span class="font-semibold text-gray-800">Services</span>
                        </button>

                        <button onclick="showSection('wallet')" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-xl hover:shadow-md transition-all">
                            <span class="text-4xl mb-3">💰</span>
                            <span class="font-semibold text-gray-800">Recharger</span>
                        </button>

                        <button onclick="showSection('support')" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-xl hover:shadow-md transition-all">
                            <span class="text-4xl mb-3">💬</span>
                            <span class="font-semibold text-gray-800">Support</span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Subscriptions Section -->
            <div id="subscriptions" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Mes Abonnements</h2>
                    <p class="text-gray-600 mt-2">Gérez vos abonnements et plans</p>
                </div>

                <div class="bg-white rounded-xl shadow-lg p-8 text-center">
                    <div class="text-6xl mb-4">📦</div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-4">Page des Abonnements</h3>
                    <p class="text-gray-600 mb-6">Cette section vous redirige vers la page complète de gestion des abonnements</p>
                    <button onclick="window.location.href='/client-subscriptions.php'" class="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                        Accéder à mes abonnements
                    </button>
                </div>
            </div>

            <!-- Orders Section -->
            <div id="orders" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Mes Commandes</h2>
                    <p class="text-gray-600 mt-2">Historique de vos commandes</p>
                </div>

                <div id="orders-container" class="bg-white rounded-xl shadow-lg p-6">
                    <div class="text-center py-12 text-gray-500">
                        <div class="text-6xl mb-4">⏳</div>
                        <p class="text-xl">Chargement de vos commandes...</p>
                    </div>
                </div>
            </div>

            <!-- Wallet Section -->
            <div id="wallet" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Mon Wallet</h2>
                    <p class="text-gray-600 mt-2">Gérez votre solde</p>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <!-- Balance -->
                    <div class="bg-white rounded-xl shadow-lg p-6">
                        <h3 class="text-xl font-semibold mb-4">💰 Solde actuel</h3>
                        <div class="text-center py-8">
                            <p class="text-5xl font-bold text-green-600"><?php echo number_format($wallet['balance'] ?? 0, 2); ?> €</p>
                            <p class="text-gray-500 mt-2">Solde disponible</p>
                        </div>
                        <button onclick="showRechargeModal()" class="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                            ➕ Recharger mon compte
                        </button>
                    </div>

                    <!-- Transactions -->
                    <div class="bg-white rounded-xl shadow-lg p-6">
                        <h3 class="text-xl font-semibold mb-4">📊 Dernières transactions</h3>
                        <div class="space-y-3">
                            <div class="text-center py-8 text-gray-500">
                                <p>Aucune transaction récente</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Projects Section -->
            <div id="projects" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Mes Projets Branding</h2>
                    <p class="text-gray-600 mt-2">Suivez l'avancement de vos projets et validez les livrables</p>
                </div>

                <!-- Filter Tabs -->
                <div class="mb-6">
                    <div class="flex space-x-1 bg-gray-100 p-1 rounded-lg w-fit">
                        <button onclick="filterProjects('all')" class="project-filter px-4 py-2 rounded-md bg-white text-gray-800 font-medium shadow-sm">
                            Tous
                        </button>
                        <button onclick="filterProjects('in-progress')" class="project-filter px-4 py-2 rounded-md text-gray-600 hover:text-gray-800">
                            En cours
                        </button>
                        <button onclick="filterProjects('pending-validation')" class="project-filter px-4 py-2 rounded-md text-gray-600 hover:text-gray-800">
                            À valider
                        </button>
                        <button onclick="filterProjects('completed')" class="project-filter px-4 py-2 rounded-md text-gray-600 hover:text-gray-800">
                            Terminés
                        </button>
                    </div>
                </div>

                <!-- Projects Grid -->
                <div id="projects-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <!-- Sample Project -->
                    <div class="project-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all" data-status="in-progress">
                        <div class="relative h-48 bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                            <span class="text-6xl">🎨</span>
                            <div class="absolute top-3 right-3">
                                <span class="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-xs font-medium">En cours</span>
                            </div>
                        </div>
                        <div class="p-4">
                            <h3 class="font-semibold text-gray-800 mb-1">Logo Design Premium</h3>
                            <p class="text-sm text-gray-600 mb-2">Démarré le 20/01/2024</p>
                            <div class="mb-4">
                                <div class="flex justify-between text-sm mb-1">
                                    <span class="text-gray-600">Progression</span>
                                    <span class="font-medium">75%</span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-2">
                                    <div class="bg-blue-600 h-2 rounded-full" style="width: 75%"></div>
                                </div>
                            </div>
                            <button onclick="viewProjectDetails('project-1')" class="w-full bg-blue-600 text-white py-2 rounded-lg text-sm hover:bg-blue-700 transition-colors">
                                Voir les détails
                            </button>
                        </div>
                    </div>

                    <!-- Project Pending Validation -->
                    <div class="project-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all" data-status="pending-validation">
                        <div class="relative h-48 bg-gradient-to-br from-green-500 to-teal-600 flex items-center justify-center">
                            <span class="text-6xl">📄</span>
                            <div class="absolute top-3 right-3">
                                <span class="bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-xs font-medium">À valider</span>
                            </div>
                        </div>
                        <div class="p-4">
                            <h3 class="font-semibold text-gray-800 mb-1">Brochure Entreprise</h3>
                            <p class="text-sm text-gray-600 mb-2">Démarré le 15/01/2024</p>
                            <div class="mb-4">
                                <div class="flex justify-between text-sm mb-1">
                                    <span class="text-gray-600">Progression</span>
                                    <span class="font-medium">100%</span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-2">
                                    <div class="bg-green-600 h-2 rounded-full" style="width: 100%"></div>
                                </div>
                            </div>
                            <button onclick="viewProjectDetails('project-2')" class="w-full bg-orange-600 text-white py-2 rounded-lg text-sm hover:bg-orange-700 transition-colors">
                                📋 Valider maintenant
                            </button>
                        </div>
                    </div>

                    <!-- Completed Project -->
                    <div class="project-card bg-white rounded-xl shadow-lg overflow-hidden card-hover transition-all" data-status="completed">
                        <div class="relative h-48 bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                            <span class="text-6xl">✅</span>
                            <div class="absolute top-3 right-3">
                                <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-medium">Terminé</span>
                            </div>
                        </div>
                        <div class="p-4">
                            <h3 class="font-semibold text-gray-800 mb-1">Carte de Visite</h3>
                            <p class="text-sm text-gray-600 mb-2">Livré le 10/01/2024</p>
                            <div class="mb-4">
                                <div class="flex justify-between text-sm mb-1">
                                    <span class="text-gray-600">Progression</span>
                                    <span class="font-medium text-green-600">100%</span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-2">
                                    <div class="bg-green-600 h-2 rounded-full" style="width: 100%"></div>
                                </div>
                            </div>
                            <button onclick="viewProjectDetails('project-3')" class="w-full bg-green-600 text-white py-2 rounded-lg text-sm hover:bg-green-700 transition-colors">
                                Voir le projet
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Project Details Modal -->
            <div id="project-details-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                <div class="bg-white rounded-xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
                    <div class="p-6 border-b border-gray-200 sticky top-0 bg-white z-10">
                        <div class="flex justify-between items-center">
                            <div>
                                <h3 class="text-2xl font-bold text-gray-800">Détails du Projet</h3>
                                <p class="text-gray-600 mt-1">Logo Design Premium</p>
                            </div>
                            <div class="flex items-center space-x-3">
                                <span class="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">En cours</span>
                                <button onclick="closeProjectDetails()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                    </div>

                    <div class="p-6">
                        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                            <!-- Assets & Files -->
                            <div class="lg:col-span-2">
                                <h4 class="text-lg font-semibold text-gray-800 mb-4">📁 Assets du Projet</h4>

                                <!-- Tabs -->
                                <div class="flex space-x-2 mb-4">
                                    <button onclick="showAssetTab('all')" class="asset-tab px-4 py-2 bg-blue-100 text-blue-700 rounded-lg font-medium">
                                        Tous
                                    </button>
                                    <button onclick="showAssetTab('images')" class="asset-tab px-4 py-2 bg-gray-100 text-gray-700 rounded-lg">
                                        Images
                                    </button>
                                    <button onclick="showAssetTab('files')" class="asset-tab px-4 py-2 bg-gray-100 text-gray-700 rounded-lg">
                                        Fichiers
                                    </button>
                                    <button onclick="showAssetTab('final')" class="asset-tab px-4 py-2 bg-gray-100 text-gray-700 rounded-lg">
                                        Livrables Finaux
                                    </button>
                                </div>

                                <!-- Assets Grid -->
                                <div id="assets-grid" class="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                                    <!-- Sample Image Asset avec vraie image -->
                                    <div class="asset-item border-2 border-gray-200 rounded-lg p-3 hover:border-blue-500 transition-all cursor-pointer" data-type="images">
                                        <div class="aspect-square rounded-lg mb-2 overflow-hidden bg-gray-100">
                                            <img src="/uploads/branding/logo_v1.png" 
                                                 alt="logo_v1.png" 
                                                 class="w-full h-full object-cover"
                                                 onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'200\' height=\'200\'%3E%3Crect fill=\'%23667eea\' width=\'200\' height=\'200\'/%3E%3Ctext x=\'50%25\' y=\'50%25\' font-size=\'60\' text-anchor=\'middle\' dy=\'.3em\' fill=\'white\'%3E🎨%3C/text%3E%3C/svg%3E';">
                                        </div>
                                        <p class="text-xs font-medium truncate">logo_v1.png</p>
                                        <p class="text-xs text-gray-500">2.3 MB</p>
                                        <div class="flex gap-1 mt-2">
                                            <button onclick="downloadAsset('logo_v1.png')" class="flex-1 bg-blue-600 text-white px-2 py-1 rounded text-xs hover:bg-blue-700">
                                                ⬇️ Télécharger
                                            </button>
                                            <button onclick="previewAsset('logo_v1.png')" class="flex-1 bg-gray-600 text-white px-2 py-1 rounded text-xs hover:bg-gray-700">
                                                👁️ Voir
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Sample File Asset -->
                                    <div class="asset-item border-2 border-gray-200 rounded-lg p-3 hover:border-blue-500 transition-all cursor-pointer" data-type="files">
                                        <div class="aspect-square bg-gray-100 rounded-lg mb-2 flex items-center justify-center">
                                            <span class="text-4xl">📄</span>
                                        </div>
                                        <p class="text-xs font-medium truncate">logo_v1.ai</p>
                                        <p class="text-xs text-gray-500">5.1 MB</p>
                                        <div class="flex gap-1 mt-2">
                                            <button onclick="downloadAsset('logo_v1.ai')" class="flex-1 bg-blue-600 text-white px-2 py-1 rounded text-xs hover:bg-blue-700">
                                                ⬇️ Télécharger
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Final Deliverable avec preview -->
                                    <div class="asset-item border-2 border-green-300 rounded-lg p-3 hover:border-green-500 transition-all cursor-pointer" data-type="final">
                                        <div class="aspect-square rounded-lg mb-2 overflow-hidden bg-gray-100">
                                            <img src="/uploads/branding/logo_final_preview.png" 
                                                 alt="logo_final.zip" 
                                                 class="w-full h-full object-cover"
                                                 onerror="this.onerror=null; this.parentElement.innerHTML='<div class=\'w-full h-full bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center\'><span class=\'text-4xl\'>✅</span></div>';">
                                        </div>
                                        <p class="text-xs font-medium truncate">logo_final.zip</p>
                                        <p class="text-xs text-gray-500">8.7 MB</p>
                                        <div class="flex gap-1 mt-2">
                                            <button onclick="downloadAsset('logo_final.zip')" class="w-full bg-green-600 text-white px-2 py-1 rounded text-xs hover:bg-green-700">
                                                ⬇️ Télécharger
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <!-- Comments Section -->
                                <div class="bg-gray-50 rounded-lg p-4">
                                    <h4 class="font-semibold text-gray-800 mb-3">💬 Commentaires & Feedback</h4>
                                    <div class="space-y-3 mb-4 max-h-64 overflow-y-auto" id="comments-container">
                                        <!-- Text Message from Designer -->
                                        <div class="bg-white rounded-lg p-3">
                                            <div class="flex justify-between mb-1">
                                                <span class="font-medium text-sm">Designer</span>
                                                <span class="text-xs text-gray-500">Il y a 2h</span>
                                            </div>
                                            <p class="text-sm text-gray-700">Voici la première version du logo. Qu'en pensez-vous ?</p>
                                        </div>

                                        <!-- Voice Message from Client -->
                                        <div class="bg-blue-50 rounded-lg p-3 border-l-4 border-blue-500">
                                            <div class="flex justify-between mb-2">
                                                <span class="font-medium text-sm">Vous</span>
                                                <span class="text-xs text-gray-500">Il y a 1h</span>
                                            </div>
                                            <div class="flex items-center gap-2 bg-white rounded-lg p-2">
                                                <button onclick="playVoiceMessage()" class="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-700">
                                                    <span class="text-xs">▶️</span>
                                                </button>
                                                <div class="flex-1 h-1 bg-blue-200 rounded-full overflow-hidden">
                                                    <div class="h-full bg-blue-600 rounded-full" style="width: 45%"></div>
                                                </div>
                                                <span class="text-xs text-gray-600">0:15</span>
                                            </div>
                                        </div>

                                        <!-- Image Message from Designer -->
                                        <div class="bg-white rounded-lg p-3">
                                            <div class="flex justify-between mb-2">
                                                <span class="font-medium text-sm">Designer</span>
                                                <span class="text-xs text-gray-500">Il y a 45min</span>
                                            </div>
                                            <p class="text-sm text-gray-700 mb-2">Voici une variation avec les couleurs plus vives :</p>
                                            <div class="relative rounded-lg overflow-hidden cursor-pointer hover:opacity-90" onclick="previewMessageImage('logo_v2.png')">
                                                <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='150'%3E%3Crect fill='%23667eea' width='200' height='150'/%3E%3Ctext x='50%25' y='50%25' font-size='40' text-anchor='middle' dy='.3em' fill='white'%3E🎨%3C/text%3E%3C/svg%3E" alt="Logo variation" class="w-full rounded-lg">
                                                <div class="absolute bottom-2 right-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-xs">
                                                    📷 logo_v2.png
                                                </div>
                                            </div>
                                        </div>

                                        <!-- File Message from Client -->
                                        <div class="bg-blue-50 rounded-lg p-3 border-l-4 border-blue-500">
                                            <div class="flex justify-between mb-2">
                                                <span class="font-medium text-sm">Vous</span>
                                                <span class="text-xs text-gray-500">Il y a 30min</span>
                                            </div>
                                            <p class="text-sm text-gray-700 mb-2">Voici mon brief avec plus de détails</p>
                                            <div class="flex items-center gap-3 bg-white rounded-lg p-2">
                                                <div class="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                                                    <span class="text-xl">📄</span>
                                                </div>
                                                <div class="flex-1">
                                                    <p class="text-sm font-medium">brief_detaille.pdf</p>
                                                    <p class="text-xs text-gray-500">245 KB</p>
                                                </div>
                                                <button onclick="downloadMessageFile('brief_detaille.pdf')" class="text-blue-600 hover:text-blue-700">
                                                    <span class="text-xl">⬇️</span>
                                                </button>
                                            </div>
                                        </div>

                                        <!-- Text Message from Client -->
                                        <div class="bg-blue-50 rounded-lg p-3 border-l-4 border-blue-500">
                                            <div class="flex justify-between mb-1">
                                                <span class="font-medium text-sm">Vous</span>
                                                <span class="text-xs text-gray-500">Il y a 20min</span>
                                            </div>
                                            <p class="text-sm text-gray-700">Parfait ! Cette version est exactement ce que je cherchais. ✨</p>
                                        </div>
                                    </div>

                                    <!-- Message Input -->
                                    <div class="space-y-2">
                                        <!-- Text Input -->
                                        <div class="flex gap-2">
                                            <input type="text" id="message-input" placeholder="Écrivez votre message..." class="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm">
                                            <button onclick="sendTextMessage()" class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 flex items-center gap-1">
                                                <span>✉️</span>
                                                <span>Envoyer</span>
                                            </button>
                                        </div>

                                        <!-- Multimedia Options -->
                                        <div class="flex gap-2">
                                            <!-- Voice Message -->
                                            <button onclick="recordVoiceMessage()" class="flex-1 bg-gradient-to-r from-purple-500 to-purple-600 text-white px-3 py-2 rounded-lg text-sm hover:from-purple-600 hover:to-purple-700 flex items-center justify-center gap-2">
                                                <span>🎤</span>
                                                <span>Vocal</span>
                                            </button>

                                            <!-- Photo Upload -->
                                            <label class="flex-1 cursor-pointer">
                                                <input type="file" accept="image/*" onchange="uploadPhoto(event)" class="hidden" id="photo-input">
                                                <div class="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-3 py-2 rounded-lg text-sm hover:from-blue-600 hover:to-blue-700 flex items-center justify-center gap-2">
                                                    <span>📷</span>
                                                    <span>Photo</span>
                                                </div>
                                            </label>

                                            <!-- File Upload -->
                                            <label class="flex-1 cursor-pointer">
                                                <input type="file" onchange="uploadFile(event)" class="hidden" id="file-input">
                                                <div class="bg-gradient-to-r from-green-500 to-green-600 text-white px-3 py-2 rounded-lg text-sm hover:from-green-600 hover:to-green-700 flex items-center justify-center gap-2">
                                                    <span>📎</span>
                                                    <span>Fichier</span>
                                                </div>
                                            </label>
                                        </div>

                                        <!-- Recording Indicator (Hidden by default) -->
                                        <div id="recording-indicator" class="hidden bg-red-50 border-2 border-red-500 rounded-lg p-3 flex items-center justify-between">
                                            <div class="flex items-center gap-3">
                                                <div class="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                                                <span class="text-sm font-medium text-red-700">Enregistrement en cours...</span>
                                                <span id="recording-timer" class="text-sm font-mono text-red-600">0:00</span>
                                            </div>
                                            <button onclick="stopRecording()" class="bg-red-600 text-white px-4 py-1 rounded-lg text-sm hover:bg-red-700">
                                                ⏹️ Arrêter
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Project Info & Actions -->
                            <div class="space-y-6">
                                <!-- Project Info -->
                                <div class="bg-gray-50 rounded-lg p-4">
                                    <h4 class="font-semibold text-gray-800 mb-3">📊 Informations</h4>
                                    <div class="space-y-2 text-sm">
                                        <div class="flex justify-between">
                                            <span class="text-gray-600">Prix:</span>
                                            <span class="font-medium">150€</span>
                                        </div>
                                        <div class="flex justify-between">
                                            <span class="text-gray-600">Démarré:</span>
                                            <span>20/01/2024</span>
                                        </div>
                                        <div class="flex justify-between">
                                            <span class="text-gray-600">Échéance:</span>
                                            <span>27/01/2024</span>
                                        </div>
                                        <div class="flex justify-between">
                                            <span class="text-gray-600">Progression:</span>
                                            <span class="font-medium text-blue-600">75%</span>
                                        </div>
                                    </div>
                                </div>

                                <!-- Services Included -->
                                <div class="bg-gray-50 rounded-lg p-4">
                                    <h4 class="font-semibold text-gray-800 mb-3">📦 Services Inclus</h4>
                                    <div class="space-y-2">
                                        <div class="flex items-center text-sm">
                                            <span class="text-green-500 mr-2">✓</span>
                                            <span>Logo Design</span>
                                        </div>
                                        <div class="flex items-center text-sm">
                                            <span class="text-green-500 mr-2">✓</span>
                                            <span>Fichiers sources</span>
                                        </div>
                                        <div class="flex items-center text-sm">
                                            <span class="text-green-500 mr-2">✓</span>
                                            <span>3 révisions</span>
                                        </div>
                                    </div>
                                </div>

                                <!-- Validation Actions -->
                                <div class="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-lg p-4 border-2 border-orange-200">
                                    <h4 class="font-semibold text-gray-800 mb-3">✅ Validation</h4>
                                    <p class="text-sm text-gray-700 mb-4">Le projet est prêt à être validé. Consultez tous les assets avant de valider.</p>
                                    <div class="space-y-2">
                                        <button onclick="validateProject()" class="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                            ✅ Valider le projet
                                        </button>
                                        <button onclick="requestRevision()" class="w-full bg-yellow-600 text-white py-3 rounded-lg font-semibold hover:bg-yellow-700 transition-colors">
                                            🔄 Demander révision
                                        </button>
                                    </div>
                                </div>

                                <!-- Download All -->
                                <button onclick="downloadAllAssets()" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                                    📦 Télécharger tout
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Services & Products Section -->
            <div id="services" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">🛍️ Boutique Services & Produits</h2>
                    <p class="text-gray-600 mt-2">Découvrez et commandez nos services professionnels et produits numériques</p>
                </div>

                <!-- Tabs -->
                <div class="mb-6">
                    <div class="flex space-x-1 bg-gray-100 p-1 rounded-lg w-fit">
                        <button onclick="showShopTab('services')" class="shop-tab px-6 py-3 rounded-md bg-white text-gray-800 font-medium shadow-sm">
                            🎨 Services
                        </button>
                        <button onclick="showShopTab('products')" class="shop-tab px-6 py-3 rounded-md text-gray-600 hover:text-gray-800">
                            📦 Produits
                        </button>
                    </div>
                </div>

                <!-- Include shop content -->
                <?php include __DIR__ . '/../shop-content-dynamic.php'; ?>

            <!-- Profile Section -->
            <div id="profile" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Mon Profil</h2>
                    <p class="text-gray-600 mt-2">Gérez vos informations personnelles</p>
                </div>

                <div class="max-w-2xl bg-white rounded-xl shadow-lg p-6">
                    <div class="space-y-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Nom complet</label>
                            <input type="text" value="<?php echo htmlspecialchars($GLOBALS['current_user']['full_name']); ?>" class="w-full p-3 border border-gray-300 rounded-lg" readonly>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                            <input type="email" value="<?php echo htmlspecialchars($GLOBALS['current_user']['email']); ?>" class="w-full p-3 border border-gray-300 rounded-lg" readonly>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Rôle</label>
                            <input type="text" value="<?php echo htmlspecialchars($GLOBALS['current_user']['role_name']); ?>" class="w-full p-3 border border-gray-300 rounded-lg" readonly>
                        </div>

                        <button class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                            Modifier mes informations
                        </button>
                    </div>
                </div>
            </div>

            <!-- Support Section -->
            <div id="support" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Support Client</h2>
                    <p class="text-gray-600 mt-2">Besoin d'aide ? Nous sommes là pour vous</p>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div class="bg-white rounded-xl shadow-lg p-6">
                        <h3 class="text-xl font-semibold mb-4">📧 Contactez-nous</h3>
                        <form class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Sujet</label>
                                <input type="text" placeholder="Sujet de votre message" class="w-full p-3 border border-gray-300 rounded-lg">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Message</label>
                                <textarea rows="5" placeholder="Décrivez votre problème ou question..." class="w-full p-3 border border-gray-300 rounded-lg"></textarea>
                            </div>
                            <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                                Envoyer le message
                            </button>
                        </form>
                    </div>

                    <div class="bg-white rounded-xl shadow-lg p-6">
                        <h3 class="text-xl font-semibold mb-4">❓ FAQ</h3>
                        <div class="space-y-4">
                            <div class="border-b pb-4">
                                <h4 class="font-medium mb-2">Comment recharger mon wallet ?</h4>
                                <p class="text-sm text-gray-600">Allez dans la section Wallet et cliquez sur "Recharger mon compte"</p>
                            </div>
                            <div class="border-b pb-4">
                                <h4 class="font-medium mb-2">Comment gérer mon abonnement ?</h4>
                                <p class="text-sm text-gray-600">Rendez-vous dans "Mes Abonnements" pour gérer votre plan</p>
                            </div>
                            <div>
                                <h4 class="font-medium mb-2">Délai de traitement des commandes ?</h4>
                                <p class="text-sm text-gray-600">Les commandes sont traitées sous 24-48h ouvrées</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Container -->
    <div id="toast-container" class="fixed top-4 right-4 z-50 space-y-2"></div>

    <!-- Modal Recharge -->
    <div id="recharge-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-xl shadow-2xl max-w-md w-full mx-4 p-6">
            <h3 class="text-2xl font-bold text-gray-800 mb-4">💰 Recharger mon compte</h3>
            <p class="text-gray-600 mb-6">Contactez un administrateur pour effectuer un rechargement de votre compte.</p>
            <div class="flex gap-3">
                <button onclick="closeRechargeModal()" class="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-300 transition-colors">
                    Fermer
                </button>
                <button class="flex-1 bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                    Contacter Admin
                </button>
            </div>
        </div>
    </div>

    <script>
        // Profile Menu Functions
        function toggleProfileMenu() {
            const menu = document.getElementById('profile-menu');
            menu.classList.toggle('hidden');
        }

        // Close profile menu when clicking outside
        document.addEventListener('click', function(event) {
            const profileMenu = document.getElementById('profile-menu');
            const profileButton = event.target.closest('button[onclick="toggleProfileMenu()"]');
            
            if (profileMenu && !profileMenu.contains(event.target) && !profileButton && !profileMenu.classList.contains('hidden')) {
                profileMenu.classList.add('hidden');
            }
        });

        // Toggle Sidebar
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            
            if (sidebar.classList.contains('w-64')) {
                sidebar.classList.remove('w-64');
                sidebar.classList.add('w-0', 'overflow-hidden');
            } else {
                sidebar.classList.remove('w-0', 'overflow-hidden');
                sidebar.classList.add('w-64');
            }
        }

        function showSection(sectionId) {
            // Hide all sections
            document.querySelectorAll('.section').forEach(section => section.classList.add('hidden'));
            
            // Show selected section
            const section = document.getElementById(sectionId);
            if (section) {
                section.classList.remove('hidden');
            }
            
            // Update sidebar active state
            document.querySelectorAll('.sidebar-item').forEach(item => {
                item.classList.remove('bg-white', 'bg-opacity-20');
            });
            
            // Add active class to the button that triggered this (if called from a button)
            if (window.event && window.event.target) {
                window.event.target.classList.add('bg-white', 'bg-opacity-20');
            }
        }

        async function logout() {
            const formData = new FormData();
            formData.append('action', 'logout');
            await fetch('/api/auth.php', { method: 'POST', body: formData });
            window.location.href = '/login.html';
        }

        function showRechargeModal() {
            document.getElementById('recharge-modal').classList.remove('hidden');
        }

        function closeRechargeModal() {
            document.getElementById('recharge-modal').classList.add('hidden');
        }

        // Projects Functions
        function filterProjects(status) {
            const cards = document.querySelectorAll('.project-card');
            const filters = document.querySelectorAll('.project-filter');
            
            // Update active filter
            filters.forEach(f => {
                f.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');
                f.classList.add('text-gray-600');
            });
            event.target.classList.add('bg-white', 'text-gray-800', 'shadow-sm');
            event.target.classList.remove('text-gray-600');
            
            // Filter cards
            cards.forEach(card => {
                if (status === 'all' || card.dataset.status === status) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        function viewProjectDetails(projectId) {
            document.getElementById('project-details-modal').classList.remove('hidden');
        }

        function closeProjectDetails() {
            document.getElementById('project-details-modal').classList.add('hidden');
        }

        function showAssetTab(type) {
            const assets = document.querySelectorAll('.asset-item');
            const tabs = document.querySelectorAll('.asset-tab');
            
            // Update active tab
            tabs.forEach(t => {
                t.classList.remove('bg-blue-100', 'text-blue-700');
                t.classList.add('bg-gray-100', 'text-gray-700');
            });
            event.target.classList.add('bg-blue-100', 'text-blue-700');
            event.target.classList.remove('bg-gray-100', 'text-gray-700');
            
            // Filter assets
            assets.forEach(asset => {
                if (type === 'all' || asset.dataset.type === type) {
                    asset.style.display = 'block';
                } else {
                    asset.style.display = 'none';
                }
            });
        }

        function downloadAsset(filename) {
            // Créer un lien temporaire et simuler le clic
            const link = document.createElement('a');
            link.href = '/uploads/branding/' + filename;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            // Notification
            showToast('✅ Téléchargement de ' + filename + ' démarré', 'success');
        }

        function previewAsset(filename) {
            // Ouvrir l'image dans un nouvel onglet
            window.open('/uploads/branding/' + filename, '_blank');
            showToast('👁️ Ouverture de ' + filename, 'info');
        }

        function downloadAllAssets() {
            if (confirm('Télécharger tous les assets du projet en un seul fichier ZIP ?')) {
                showToast('📦 Préparation du téléchargement...', 'info');
                
                // Simuler la préparation du ZIP
                setTimeout(() => {
                    const link = document.createElement('a');
                    link.href = '/api/projects.php?action=download_all&project_id=1';
                    link.download = 'projet_assets.zip';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    showToast('✅ Téléchargement démarré', 'success');
                }, 1500);
            }
        }

        function addComment() {
            const input = document.getElementById('message-input');
            const message = input.value.trim();
            
            if (!message) {
                showToast('⚠️ Veuillez saisir un message', 'warning');
                return;
            }
            
            // Simuler l'envoi
            sendTextMessage();
        }

        function validateProject() {
            if (confirm('✅ Êtes-vous sûr de vouloir valider ce projet ?\n\nEn validant, vous confirmez que le travail correspond à vos attentes et que le projet peut être marqué comme terminé.')) {
                alert('🎉 Projet validé avec succès !\n\nLe designer en sera notifié. Vous pouvez toujours accéder aux fichiers dans la section "Projets Terminés".');
                closeProjectDetails();
            }
        }

        function requestRevision() {
            const feedback = prompt('🔄 Demander une révision\n\nVeuillez indiquer les modifications souhaitées :');
            if (feedback && feedback.trim()) {
                alert('✅ Demande de révision envoyée !\n\nLe designer en sera notifié et vous contactera bientôt.\n\nVotre feedback : ' + feedback);
                closeProjectDetails();
            }
        }

        // Messaging Functions
        let mediaRecorder;
        let audioChunks = [];
        let recordingInterval;
        let recordingSeconds = 0;

        function sendTextMessage() {
            const input = document.getElementById('message-input');
            const message = input.value.trim();
            
            if (!message) {
                showToast('⚠️ Veuillez saisir un message', 'warning');
                return;
            }
            
            // Créer le nouvel élément de message
            const container = document.getElementById('comments-container');
            const messageDiv = document.createElement('div');
            messageDiv.className = 'bg-blue-50 rounded-lg p-3 border-l-4 border-blue-500';
            
            const now = new Date();
            const timeStr = 'À l\'instant';
            
            messageDiv.innerHTML = `
                <div class="flex justify-between mb-1">
                    <span class="font-medium text-sm">Vous</span>
                    <span class="text-xs text-gray-500">${timeStr}</span>
                </div>
                <p class="text-sm text-gray-700">${message.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</p>
            `;
            
            // Ajouter à la conversation
            container.appendChild(messageDiv);
            
            // Scroll vers le bas
            container.scrollTop = container.scrollHeight;
            
            // Vider l'input
            input.value = '';
            
            // Toast succès
            showToast('✅ Message envoyé', 'success');
            
            // Simuler une réponse du designer après 2 secondes (optionnel)
            setTimeout(() => {
                const responseDiv = document.createElement('div');
                responseDiv.className = 'bg-white rounded-lg p-3';
                responseDiv.innerHTML = `
                    <div class="flex justify-between mb-1">
                        <span class="font-medium text-sm">Designer</span>
                        <span class="text-xs text-gray-500">À l'instant</span>
                    </div>
                    <p class="text-sm text-gray-700">Message bien reçu ! Je vais y répondre sous peu. 👍</p>
                `;
                container.appendChild(responseDiv);
                container.scrollTop = container.scrollHeight;
            }, 2000);
        }

        async function recordVoiceMessage() {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaRecorder = new MediaRecorder(stream);
                audioChunks = [];
                recordingSeconds = 0;
                
                mediaRecorder.ondataavailable = (event) => {
                    audioChunks.push(event.data);
                };
                
                mediaRecorder.onstop = () => {
                    const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
                    const audioUrl = URL.createObjectURL(audioBlob);
                    
                    // Ajouter le message vocal à la conversation
                    const container = document.getElementById('comments-container');
                    const messageDiv = document.createElement('div');
                    messageDiv.className = 'bg-blue-50 rounded-lg p-3 border-l-4 border-blue-500';
                    
                    const duration = recordingSeconds;
                    const mins = Math.floor(duration / 60);
                    const secs = duration % 60;
                    const durationStr = mins + ':' + (secs < 10 ? '0' : '') + secs;
                    
                    messageDiv.innerHTML = `
                        <div class="flex justify-between mb-2">
                            <span class="font-medium text-sm">Vous</span>
                            <span class="text-xs text-gray-500">À l'instant</span>
                        </div>
                        <div class="flex items-center gap-2 bg-white rounded-lg p-2">
                            <button onclick="playAudio('${audioUrl}')" class="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-700">
                                <span class="text-xs">▶️</span>
                            </button>
                            <div class="flex-1 h-1 bg-blue-200 rounded-full overflow-hidden">
                                <div class="h-full bg-blue-600 rounded-full" style="width: 0%"></div>
                            </div>
                            <span class="text-xs text-gray-600">${durationStr}</span>
                        </div>
                    `;
                    
                    container.appendChild(messageDiv);
                    container.scrollTop = container.scrollHeight;
                    
                    showToast('🎤 Message vocal envoyé (' + duration + 's)', 'success');
                    stream.getTracks().forEach(track => track.stop());
                };
                
                mediaRecorder.start();
                document.getElementById('recording-indicator').classList.remove('hidden');
                
                // Update timer
                recordingInterval = setInterval(() => {
                    recordingSeconds++;
                    const mins = Math.floor(recordingSeconds / 60);
                    const secs = recordingSeconds % 60;
                    document.getElementById('recording-timer').textContent = 
                        mins + ':' + (secs < 10 ? '0' : '') + secs;
                }, 1000);
                
            } catch (error) {
                showToast('❌ Erreur : Impossible d\'accéder au microphone', 'error');
            }
        }

        function stopRecording() {
            if (mediaRecorder && mediaRecorder.state !== 'inactive') {
                mediaRecorder.stop();
                clearInterval(recordingInterval);
                document.getElementById('recording-indicator').classList.add('hidden');
            }
        }

        function playAudio(url) {
            const audio = new Audio(url);
            audio.play();
        }

        function uploadPhoto(event) {
            const file = event.target.files[0];
            if (file) {
                if (file.type.startsWith('image/')) {
                    const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
                    
                    // Lire et afficher l'image
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const container = document.getElementById('comments-container');
                        const messageDiv = document.createElement('div');
                        messageDiv.className = 'bg-blue-50 rounded-lg p-3 border-l-4 border-blue-500';
                        
                        messageDiv.innerHTML = `
                            <div class="flex justify-between mb-2">
                                <span class="font-medium text-sm">Vous</span>
                                <span class="text-xs text-gray-500">À l'instant</span>
                            </div>
                            <div class="relative rounded-lg overflow-hidden cursor-pointer hover:opacity-90" onclick="previewImage('${e.target.result}')">
                                <img src="${e.target.result}" alt="${file.name}" class="w-full rounded-lg max-h-64 object-cover">
                                <div class="absolute bottom-2 right-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-xs">
                                    📷 ${file.name} (${sizeMB} MB)
                                </div>
                            </div>
                        `;
                        
                        container.appendChild(messageDiv);
                        container.scrollTop = container.scrollHeight;
                        
                        showToast('📷 Photo envoyée : ' + file.name, 'success');
                    };
                    reader.readAsDataURL(file);
                } else {
                    showToast('⚠️ Veuillez sélectionner une image valide', 'warning');
                }
                event.target.value = '';
            }
        }

        function uploadFile(event) {
            const file = event.target.files[0];
            if (file) {
                const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
                const sizeKB = (file.size / 1024).toFixed(0);
                const sizeDisplay = sizeMB > 1 ? sizeMB + ' MB' : sizeKB + ' KB';
                
                // Déterminer l'icône selon le type
                let icon = '📄';
                if (file.type.includes('pdf')) icon = '📕';
                else if (file.type.includes('word')) icon = '📘';
                else if (file.type.includes('excel') || file.type.includes('spreadsheet')) icon = '📊';
                else if (file.type.includes('zip') || file.type.includes('rar')) icon = '📦';
                else if (file.type.includes('text')) icon = '📝';
                
                const container = document.getElementById('comments-container');
                const messageDiv = document.createElement('div');
                messageDiv.className = 'bg-blue-50 rounded-lg p-3 border-l-4 border-blue-500';
                
                messageDiv.innerHTML = `
                    <div class="flex justify-between mb-2">
                        <span class="font-medium text-sm">Vous</span>
                        <span class="text-xs text-gray-500">À l'instant</span>
                    </div>
                    <p class="text-sm text-gray-700 mb-2">Fichier joint :</p>
                    <div class="flex items-center gap-3 bg-white rounded-lg p-2">
                        <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <span class="text-xl">${icon}</span>
                        </div>
                        <div class="flex-1">
                            <p class="text-sm font-medium truncate">${file.name}</p>
                            <p class="text-xs text-gray-500">${sizeDisplay}</p>
                        </div>
                        <button onclick="showToast('📥 Fichier disponible', 'info')" class="text-blue-600 hover:text-blue-700">
                            <span class="text-xl">⬇️</span>
                        </button>
                    </div>
                `;
                
                container.appendChild(messageDiv);
                container.scrollTop = container.scrollHeight;
                
                showToast('📎 Fichier envoyé : ' + file.name, 'success');
                event.target.value = '';
            }
        }

        function previewImage(src) {
            window.open(src, '_blank');
        }

        function playVoiceMessage() {
            alert('Lecture du message vocal...\nCette fonctionnalité sera bientôt disponible.');
        }

        function previewMessageImage(filename) {
            alert('Aperçu de l\'image : ' + filename + '\n\nCette fonctionnalité sera bientôt disponible.');
        }

        function downloadMessageFile(filename) {
            const link = document.createElement('a');
            link.href = '/uploads/messages/' + filename;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            showToast('✅ Téléchargement de ' + filename, 'success');
        }

        // Toast Notification System
        function showToast(message, type = 'info') {
            const container = document.getElementById('toast-container');
            const toast = document.createElement('div');
            
            // Colors based on type
            const colors = {
                success: 'bg-green-500',
                error: 'bg-red-500',
                warning: 'bg-yellow-500',
                info: 'bg-blue-500'
            };
            
            toast.className = `${colors[type]} text-white px-6 py-3 rounded-lg shadow-lg transform transition-all duration-300 ease-in-out translate-x-0 opacity-100`;
            toast.textContent = message;
            
            container.appendChild(toast);
            
            // Auto remove after 3 seconds
            setTimeout(() => {
                toast.classList.add('translate-x-full', 'opacity-0');
                setTimeout(() => container.removeChild(toast), 300);
            }, 3000);
        }

        // Load Orders
        async function loadMyOrders() {
            try {
                const response = await fetch('/api/shop-dynamic.php?action=get_my_orders');
                const data = await response.json();
                
                const container = document.getElementById('orders-container');
                
                if (data.success && data.orders && data.orders.length > 0) {
                    container.innerHTML = `
                        <div class="space-y-4">
                            ${data.orders.map(order => `
                                <div class="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-all">
                                    <div class="flex justify-between items-start mb-4">
                                        <div>
                                            <h4 class="font-bold text-lg text-gray-800">${order.item_name}</h4>
                                            <p class="text-sm text-gray-500">Commande #${order.order_number}</p>
                                        </div>
                                        <span class="px-3 py-1 rounded-full text-xs font-semibold ${
                                            order.status === 'completed' ? 'bg-green-100 text-green-800' :
                                            order.status === 'processing' ? 'bg-blue-100 text-blue-800' :
                                            order.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                                            'bg-yellow-100 text-yellow-800'
                                        }">
                                            ${order.status === 'completed' ? '✅ Terminée' :
                                              order.status === 'processing' ? '⏳ En cours' :
                                              order.status === 'cancelled' ? '❌ Annulée' :
                                              '⏳ En attente'}
                                        </span>
                                    </div>
                                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                                        <div>
                                            <p class="text-xs text-gray-500">Prix</p>
                                            <p class="font-semibold text-gray-800">${order.price}€</p>
                                        </div>
                                        <div>
                                            <p class="text-xs text-gray-500">Type</p>
                                            <p class="font-semibold text-gray-800">${order.type === 'service' ? '🎨 Service' : '📦 Produit'}</p>
                                        </div>
                                        <div>
                                            <p class="text-xs text-gray-500">Date</p>
                                            <p class="font-semibold text-gray-800">${new Date(order.created_at).toLocaleDateString('fr-FR')}</p>
                                        </div>
                                        <div>
                                            <p class="text-xs text-gray-500">Heure</p>
                                            <p class="font-semibold text-gray-800">${new Date(order.created_at).toLocaleTimeString('fr-FR', {hour: '2-digit', minute: '2-digit'})}</p>
                                        </div>
                                    </div>
                                    ${order.notes ? `<p class="text-sm text-gray-600 mb-4">${order.notes}</p>` : ''}
                                    <div class="flex gap-2">
                                        <button onclick="alert('Détails de la commande #${order.order_number}')" 
                                                class="flex-1 bg-blue-600 text-white py-2 rounded-lg text-sm hover:bg-blue-700 transition-colors">
                                            📋 Détails
                                        </button>
                                        ${order.type === 'service' ? `
                                            <button onclick="alert('Contacter le support pour cette commande')" 
                                                    class="flex-1 bg-gray-600 text-white py-2 rounded-lg text-sm hover:bg-gray-700 transition-colors">
                                                💬 Support
                                            </button>
                                        ` : ''}
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    `;
                } else {
                    container.innerHTML = `
                        <div class="text-center py-12 text-gray-500">
                            <div class="text-6xl mb-4">📋</div>
                            <p class="text-xl">Aucune commande pour le moment</p>
                            <p class="text-sm mt-2">Vos commandes apparaîtront ici après achat</p>
                            <button onclick="showSection('services')" class="mt-4 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                                🛍️ Découvrir la boutique
                            </button>
                        </div>
                    `;
                }
            } catch (error) {
                console.error('Erreur chargement commandes:', error);
                const container = document.getElementById('orders-container');
                container.innerHTML = `
                    <div class="text-center py-12 text-red-500">
                        <div class="text-6xl mb-4">❌</div>
                        <p class="text-xl">Erreur de chargement</p>
                        <button onclick="loadMyOrders()" class="mt-4 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                            🔄 Réessayer
                        </button>
                    </div>
                `;
            }
        }

        // Show dashboard by default
        document.addEventListener('DOMContentLoaded', () => {
            // Hide all sections
            document.querySelectorAll('.section').forEach(section => section.classList.add('hidden'));
            
            // Show dashboard
            const dashboard = document.getElementById('dashboard');
            if (dashboard) {
                dashboard.classList.remove('hidden');
            }
            
            // Set first sidebar item as active
            const firstSidebarItem = document.querySelector('.sidebar-item');
            if (firstSidebarItem) {
                firstSidebarItem.classList.add('bg-white', 'bg-opacity-20');
            }
            
            // Load orders when navigating to orders section
            const ordersButton = document.querySelector('button[onclick="showSection(\'orders\')"]');
            if (ordersButton) {
                ordersButton.addEventListener('click', () => {
                    setTimeout(() => loadMyOrders(), 100);
                });
            }
        });
    </script>
</body>
</html>
