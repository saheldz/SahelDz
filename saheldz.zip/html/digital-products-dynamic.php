<?php
/**
 * Section Produits Digitaux - VERSION DYNAMIQUE
 * Remplace la section digital-products hardcodée dans 1a.php
 */
require_once '../config/database.php';

// Charger les catégories
$categories_query = $pdo->query("SELECT * FROM shop_categories ORDER BY name");
$db_categories = $categories_query->fetchAll(PDO::FETCH_ASSOC);

// Charger les produits avec leur stock
$products_query = $pdo->query("
    SELECT si.*, 
           sc.name as category_name,
           COUNT(ps.id) as stock_available
    FROM shop_items si
    LEFT JOIN shop_categories sc ON si.category_id = sc.id
    LEFT JOIN product_stock ps ON si.id = ps.product_id AND ps.status = 'available'
    GROUP BY si.id
    ORDER BY si.name
");
$db_products = $products_query->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Digital Products Section - VERSION DYNAMIQUE DB -->
<div id="digital-products" class="section hidden p-8">
    <div class="flex gap-6">
        <!-- Sidebar Catégories -->
        <div class="w-1/4 bg-white rounded-lg shadow-lg p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-semibold text-gray-800">Catégories</h2>
                <a href="/admin-shop.php#categories" class="bg-blue-500 text-white px-3 py-1 rounded-md text-sm hover:bg-blue-600">
                    ⚙️ Gérer
                </a>
            </div>
            
            <div class="category-tree" style="max-height: 400px; overflow-y: auto;">
                <?php if (empty($db_categories)): ?>
                    <p class="text-gray-500 text-sm text-center py-4">Aucune catégorie</p>
                <?php else: ?>
                    <?php foreach ($db_categories as $cat): ?>
                    <div class="mb-2">
                        <div class="flex items-center justify-between p-2 rounded hover:bg-gray-50 cursor-pointer">
                            <span class="flex items-center gap-2">
                                <span><?php echo $cat['icon'] ?? '📦'; ?></span>
                                <span class="font-medium"><?php echo htmlspecialchars($cat['name']); ?></span>
                            </span>
                            <span class="text-xs bg-gray-200 px-2 py-1 rounded-full">
                                <?php 
                                $count = $pdo->query("SELECT COUNT(*) FROM shop_items WHERE category_id = {$cat['id']}")->fetchColumn();
                                echo $count;
                                ?>
                            </span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Zone principale des produits -->
        <div class="flex-1">
            <div class="bg-white rounded-lg shadow-lg p-6">
                <div class="flex justify-between items-center mb-6">
                    <div class="flex items-center gap-4">
                        <h2 class="text-2xl font-semibold text-gray-800">Produits Digitaux</h2>
                        <span class="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-sm">
                            <?php echo count($db_products); ?> produits
                        </span>
                    </div>
                    <a href="/admin-shop.php" class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 flex items-center gap-2">
                        <span>⚙️</span> Gérer la Boutique
                    </a>
                </div>

                <!-- Grille des produits -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php if (empty($db_products)): ?>
                        <div class="col-span-full text-center py-12">
                            <div class="text-6xl mb-4">🛍️</div>
                            <h3 class="text-xl font-semibold text-gray-600 mb-2">Aucun produit</h3>
                            <p class="text-gray-500 mb-4">Créez vos premiers produits via l'admin boutique</p>
                            <a href="/admin-shop.php" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">
                                Aller à la boutique
                            </a>
                        </div>
                    <?php else: ?>
                        <?php foreach ($db_products as $product): ?>
                        <div class="bg-white border border-gray-200 rounded-lg p-4 shadow-sm card-hover transition-all duration-200">
                            <div class="flex items-start justify-between mb-3">
                                <div class="flex items-center gap-2">
                                    <span class="text-2xl"><?php echo $product['icon'] ?? '📦'; ?></span>
                                    <div>
                                        <h3 class="font-semibold text-gray-800"><?php echo htmlspecialchars($product['name']); ?></h3>
                                        <p class="text-sm text-gray-500"><?php echo htmlspecialchars($product['category_name'] ?? 'Sans catégorie'); ?></p>
                                    </div>
                                </div>
                                <span class="px-2 py-1 rounded-full text-xs font-medium <?php echo $product['type'] === 'product' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'; ?>">
                                    <?php echo $product['type'] === 'product' ? 'Digital' : 'Service'; ?>
                                </span>
                            </div>
                            
                            <p class="text-sm text-gray-600 mb-3"><?php echo htmlspecialchars($product['description'] ?? ''); ?></p>
                            
                            <div class="flex items-center justify-between text-sm text-gray-500 mb-3">
                                <span><?php echo $product['status'] === 'available' ? '✅ Disponible' : '⚠️ Rupture'; ?></span>
                                <span class="flex items-center gap-1">
                                    <span>🔑</span>
                                    <span class="<?php echo $product['stock_available'] > 0 ? 'text-green-600' : 'text-red-600'; ?> font-medium">
                                        <?php echo $product['stock_available']; ?> codes
                                    </span>
                                </span>
                            </div>
                            
                            <div class="flex items-center justify-between">
                                <span class="text-xl font-bold text-green-600"><?php echo number_format($product['price'], 2); ?>€</span>
                                <div class="flex gap-2">
                                    <a href="/verify-and-add-stock.php?product=<?php echo $product['id']; ?>" 
                                       class="px-3 py-1 bg-purple-500 text-white rounded text-sm hover:bg-purple-600">
                                        Stock
                                    </a>
                                    <a href="/admin-shop.php#product-<?php echo $product['id']; ?>" 
                                       class="px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600">
                                        Éditer
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
