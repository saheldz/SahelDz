<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get POST data from either FormData or JSON
    $data = $_POST;
    
    // If no POST data, try to get JSON from body
    if (empty($data)) {
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);
    }
    
    if (!$data) {
        echo json_encode(['error' => 'No data received']);
        exit;
    }
    
    $ch = curl_init('https://ytresellers.com/api/v2');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    http_response_code($httpCode);
    echo $response;
}
?>
