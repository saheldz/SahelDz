<?php
/**
 * Vérification rapide du mapping produits/stock
 * URL: https://saheldz.mpsdash.com/html/check-stock-mapping.php
 */
header('Content-Type: text/html; charset=utf-8');
require_once '../config/database.php';

$pdo = getDB();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Check Stock Mapping</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background: #4CAF50; color: white; }
        .error { background: #ffebee; color: #c62828; }
        .success { background: #e8f5e9; color: #2e7d32; }
        .warning { background: #fff3e0; color: #e65100; }
        h1 { color: #333; }
        .status { padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold; }
    </style>
</head>
<body>
<div class="container">
    <h1>🔍 Diagnostic Stock Mapping</h1>
    
    <h2>📦 Produits dans shop_items (type='product')</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Prix</th>
            <th>Status</th>
            <th>Stock Disponible</th>
        </tr>
        <?php
        $stmt = $pdo->query("
            SELECT id, name, price, status
            FROM shop_items 
            WHERE type = 'product'
            ORDER BY id
        ");
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($products as $product) {
            // Check stock for this product
            $stmt2 = $pdo->prepare("
                SELECT COUNT(*) 
                FROM product_stock 
                WHERE item_id = ? AND status = 'available'
            ");
            $stmt2->execute([$product['id']]);
            $stockCount = $stmt2->fetchColumn();
            
            $rowClass = $stockCount > 0 ? 'success' : 'error';
            echo "<tr class='$rowClass'>";
            echo "<td><b>{$product['id']}</b></td>";
            echo "<td>{$product['name']}</td>";
            echo "<td>{$product['price']}€</td>";
            echo "<td>{$product['status']}</td>";
            echo "<td><b>$stockCount codes</b></td>";
            echo "</tr>";
        }
        ?>
    </table>
    
    <h2>📊 Stock dans product_stock</h2>
    <table>
        <tr>
            <th>item_id</th>
            <th>Nom Produit</th>
            <th>Total</th>
            <th>Disponibles</th>
            <th>Vendus</th>
        </tr>
        <?php
        $stmt = $pdo->query("
            SELECT 
                ps.item_id,
                si.name,
                COUNT(*) as total,
                SUM(CASE WHEN ps.status = 'available' THEN 1 ELSE 0 END) as available,
                SUM(CASE WHEN ps.status = 'sold' THEN 1 ELSE 0 END) as sold
            FROM product_stock ps
            LEFT JOIN shop_items si ON ps.item_id = si.id
            GROUP BY ps.item_id, si.name
            ORDER BY ps.item_id
        ");
        $stocks = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($stocks as $stock) {
            $productName = $stock['name'] ?? '<span style="color:red">⚠️ PRODUIT INEXISTANT</span>';
            $rowClass = $stock['available'] > 0 ? '' : 'warning';
            echo "<tr class='$rowClass'>";
            echo "<td><b>{$stock['item_id']}</b></td>";
            echo "<td>$productName</td>";
            echo "<td>{$stock['total']}</td>";
            echo "<td><b>{$stock['available']}</b></td>";
            echo "<td>{$stock['sold']}</td>";
            echo "</tr>";
        }
        ?>
    </table>
    
    <h2>🧪 Test de la requête API</h2>
    <p>Simulation de ce que fait l'API lors d'un achat:</p>
    <?php
    if (!empty($products)) {
        $testProduct = $products[0];
        echo "<div style='background: #e3f2fd; padding: 15px; border-radius: 4px; margin: 10px 0;'>";
        echo "<b>Test avec produit ID {$testProduct['id']}: {$testProduct['name']}</b><br><br>";
        
        echo "Query: <code>SELECT COUNT(*) FROM product_stock WHERE item_id = {$testProduct['id']} AND status = 'available'</code><br><br>";
        
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as count
            FROM product_stock 
            WHERE item_id = ? AND status = 'available'
        ");
        $stmt->execute([$testProduct['id']]);
        $count = $stmt->fetchColumn();
        
        echo "Résultat: <b>$count codes disponibles</b><br><br>";
        
        if ($count > 0) {
            echo "<span style='color: green; font-weight: bold;'>✅ L'ACHAT DEVRAIT FONCTIONNER</span><br>";
            
            // Show what code would be delivered
            $stmt = $pdo->prepare("
                SELECT product_code, product_key
                FROM product_stock 
                WHERE item_id = ? AND status = 'available'
                LIMIT 1
            ");
            $stmt->execute([$testProduct['id']]);
            $code = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($code) {
                echo "<br>Code qui serait livré:<br>";
                echo "<div style='background: white; padding: 10px; margin-top: 10px; border-left: 4px solid #4CAF50;'>";
                echo "<b>{$code['product_code']}</b><br>";
                if ($code['product_key']) {
                    echo "<small>{$code['product_key']}</small>";
                }
                echo "</div>";
            }
        } else {
            echo "<span style='color: red; font-weight: bold;'>❌ L'ACHAT VA ÉCHOUER (Pas de stock)</span>";
        }
        echo "</div>";
    }
    ?>
    
    <h2>💡 Problèmes Détectés</h2>
    <?php
    $problems = [];
    
    // Check products without stock
    foreach ($products as $product) {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) 
            FROM product_stock 
            WHERE item_id = ? AND status = 'available'
        ");
        $stmt->execute([$product['id']]);
        $stockCount = $stmt->fetchColumn();
        
        if ($stockCount == 0) {
            $problems[] = "❌ Produit ID {$product['id']} '{$product['name']}' n'a AUCUN stock disponible";
        }
    }
    
    // Check stock without matching products
    foreach ($stocks as $stock) {
        if ($stock['name'] === null) {
            $problems[] = "⚠️ Stock pour item_id {$stock['item_id']} : Le produit n'existe plus dans shop_items";
        }
    }
    
    if (empty($problems)) {
        echo "<div class='success' style='padding: 15px; border-radius: 4px;'>";
        echo "<b>✅ Aucun problème détecté!</b><br>";
        echo "Tous les produits ont du stock disponible.";
        echo "</div>";
    } else {
        echo "<div class='error' style='padding: 15px; border-radius: 4px;'>";
        foreach ($problems as $problem) {
            echo "$problem<br>";
        }
        echo "</div>";
    }
    ?>
</div>
</body>
</html>
