<?php
session_start();

// Prevent caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.html');
    exit();
}

// Check user role and redirect admins to admin dashboard
require_once '../config/database.php';
try {
    $pdo = getDB();
    $stmt = $pdo->prepare("
        SELECT r.name as role_name
        FROM users u
        LEFT JOIN roles r ON u.role_id = r.id
        WHERE u.id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    // Redirect admins to admin dashboard
    if ($user && in_array($user['role_name'], ['super_admin', 'admin'])) {
        header('Location: ../admin-dashboard.php');
        exit();
    }
} catch (PDOException $e) {
    // Continue if error checking role
}
?>
<!DOCTYPE html>
<html lang="fr" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DigiServices Pro - Gestion Complète</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        * {
            box-sizing: border-box;
        }
        
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
        }
        
        body {
            box-sizing: border-box;
        }
        
        /* Force all elements to stay within bounds */
        * {
            max-width: 100%;
        }
        
        .sidebar-item:hover {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .card-hover:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        /* Ensure main container doesn't overflow */
        #main-container {
            max-width: 100vw;
            overflow-x: hidden;
        }
        
        /* Ensure tables are responsive */
        table {
            width: 100%;
            table-layout: fixed;
        }
        
        /* Make sure grids don't overflow */
        .grid {
            width: 100%;
        }
        
        /* Force sections to use full width */
        .section {
            width: 100% !important;
            max-width: 100% !important;
        }
        
        /* Ensure main content area uses full available width */
        .flex-1 {
            flex: 1 1 0% !important;
            min-width: 0 !important;
        }
    </style>
</head>
<body class="h-full bg-gray-50 font-sans overflow-hidden">
    <div id="main-container" class="flex h-full w-full max-w-full">
        <!-- Top Bar with Profile Menu -->
        <div class="fixed top-4 right-4 z-50">
            <div class="relative">
                <button onclick="toggleProfileMenu()" class="flex items-center space-x-2 bg-white rounded-full shadow-lg p-2 hover:shadow-xl transition-all">
                    <div class="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold">
                        A
                    </div>
                </button>
                
                <div id="profileMenu" class="hidden absolute right-0 mt-2 w-56 bg-white rounded-lg shadow-xl border border-gray-200 py-2" style="right: 0;">
                    <div class="px-4 py-3 border-b border-gray-200">
                        <p class="text-sm font-semibold text-gray-800">Admin</p>
                        <p class="text-xs text-gray-500">admin@digiservices.com</p>
                    </div>
                    <a href="#" onclick="showSection('dashboard'); toggleProfileMenu(); return false;" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center space-x-2">
                        <span>👤</span>
                        <span>Mon Compte</span>
                    </a>
                    <a href="#" onclick="showSection('settings'); toggleProfileMenu(); return false;" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center space-x-2">
                        <span>⚙️</span>
                        <span>Paramètres</span>
                    </a>
                    <div class="border-t border-gray-200 mt-2"></div>
                    <a href="../logout.php" onclick="return confirmLogout(event)" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center space-x-2">
                        <span>🚪</span>
                        <span>Se déconnecter</span>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="w-64 gradient-bg text-white flex-shrink-0 overflow-y-auto">
            <div class="p-6">
                <h1 class="text-2xl font-bold">DigiServices Pro</h1>
                <p class="text-sm opacity-80 mt-1">Gestion Complète</p>
            </div>
            
            <nav class="mt-6">
                <div class="px-4 space-y-2">
                    <button onclick="showSection('dashboard')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3">
                        <span>📊</span>
                        <span>Tableau de Bord</span>
                    </button>
                    
                    <button onclick="showSection('pos')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3">
                        <span>💳</span>
                        <span>Système POS</span>
                    </button>
                    
                    <div class="smm-dropdown">
                        <button onclick="toggleSMMDropdown()" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center justify-between">
                            <div class="flex items-center space-x-3">
                                <span>📱</span>
                                <span>Commandes SMM</span>
                            </div>
                            <span id="smm-arrow" class="transform transition-transform duration-200">▼</span>
                        </button>
                        
                        <div id="smm-submenu" class="hidden ml-6 mt-2 space-y-1">
                            <button onclick="showSMMPage('api-config')" class="smm-sub-item w-full text-left px-3 py-2 rounded-lg text-sm hover:bg-white hover:bg-opacity-10 transition-all duration-200 flex items-center space-x-2">
                                <span class="text-xs">🔑</span>
                                <span>API Configuration</span>
                            </button>
                            
                            <button onclick="showSMMPage('new-order')" class="smm-sub-item w-full text-left px-3 py-2 rounded-lg text-sm hover:bg-white hover:bg-opacity-10 transition-all duration-200 flex items-center space-x-2">
                                <span class="text-xs">🏠</span>
                                <span>New Order</span>
                            </button>
                            
                            <button onclick="showSMMPage('my-orders')" class="smm-sub-item w-full text-left px-3 py-2 rounded-lg text-sm hover:bg-white hover:bg-opacity-10 transition-all duration-200 flex items-center space-x-2">
                                <span class="text-xs">📋</span>
                                <span>My Orders</span>
                            </button>
                            
                            <button onclick="showSMMPage('services-list')" class="smm-sub-item w-full text-left px-3 py-2 rounded-lg text-sm hover:bg-white hover:bg-opacity-10 transition-all duration-200 flex items-center space-x-2">
                                <span class="text-xs">📄</span>
                                <span>Services List</span>
                            </button>
                            
                            <button onclick="showSMMPage('add-funds')" class="smm-sub-item w-full text-left px-3 py-2 rounded-lg text-sm hover:bg-white hover:bg-opacity-10 transition-all duration-200 flex items-center space-x-2">
                                <span class="text-xs">💰</span>
                                <span>Add Funds</span>
                            </button>
                            
                            <button onclick="showSMMPage('support')" class="smm-sub-item w-full text-left px-3 py-2 rounded-lg text-sm hover:bg-white hover:bg-opacity-10 transition-all duration-200 flex items-center space-x-2">
                                <span class="text-xs">💬</span>
                                <span>Support</span>
                            </button>
                            
                            <button onclick="showSMMPage('affiliate')" class="smm-sub-item w-full text-left px-3 py-2 rounded-lg text-sm hover:bg-white hover:bg-opacity-10 transition-all duration-200 flex items-center space-x-2">
                                <span class="text-xs">🔗</span>
                                <span>Affiliate Program</span>
                            </button>
                            
                            <button onclick="showSMMPage('reseller')" class="smm-sub-item w-full text-left px-3 py-2 rounded-lg text-sm hover:bg-white hover:bg-opacity-10 transition-all duration-200 flex items-center space-x-2">
                                <span class="text-xs">🏪</span>
                                <span>Reseller Program</span>
                            </button>
                            
                            <button onclick="showSMMPage('faq')" class="smm-sub-item w-full text-left px-3 py-2 rounded-lg text-sm hover:bg-white hover:bg-opacity-10 transition-all duration-200 flex items-center space-x-2">
                                <span class="text-xs">❓</span>
                                <span>FAQ</span>
                            </button>
                            
                            <button onclick="showSMMPage('api')" class="smm-sub-item w-full text-left px-3 py-2 rounded-lg text-sm hover:bg-white hover:bg-opacity-10 transition-all duration-200 flex items-center space-x-2">
                                <span class="text-xs">⚙️</span>
                                <span>API</span>
                            </button>
                        </div>
                    </div>
                    
                    <button onclick="showSection('branding')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3">
                        <span>🎨</span>
                        <span>Branding</span>
                    </button>
                    
                    <button onclick="showSection('websites')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3">
                        <span>🌐</span>
                        <span>Sites Web</span>
                    </button>
                    
                    <button onclick="showSection('digital-products')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3">
                        <span>📦</span>
                        <span>Produits Digitaux</span>
                    </button>
                    
                    <button onclick="showSection('orders')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3">
                        <span>📋</span>
                        <span>Gestion Commandes</span>
                    </button>
                    
                    <button onclick="showSection('clients')" class="sidebar-item w-full text-left px-4 py-3 rounded-lg transition-all duration-200 flex items-center space-x-3">
                        <span>👥</span>
                        <span>Clients</span>
                    </button>
                </div>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="flex-1 overflow-x-hidden overflow-y-auto w-0">
            <!-- Dashboard Section -->
            <div id="dashboard" class="section p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Tableau de Bord</h2>
                    <p class="text-gray-600 mt-2">Vue d'ensemble de vos activités</p>
                </div>

                <!-- Stats Cards -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <div class="bg-white p-6 rounded-xl shadow-sm card-hover transition-all duration-200">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-600">Revenus Aujourd'hui</p>
                                <p class="text-2xl font-bold text-green-600">2,450 €</p>
                            </div>
                            <div class="bg-green-100 p-3 rounded-full">
                                <span class="text-2xl">💰</span>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white p-6 rounded-xl shadow-sm card-hover transition-all duration-200">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-600">Commandes SMM</p>
                                <p class="text-2xl font-bold text-blue-600">47</p>
                            </div>
                            <div class="bg-blue-100 p-3 rounded-full">
                                <span class="text-2xl">📱</span>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white p-6 rounded-xl shadow-sm card-hover transition-all duration-200">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-600">Clients Actifs</p>
                                <p class="text-2xl font-bold text-purple-600">156</p>
                            </div>
                            <div class="bg-purple-100 p-3 rounded-full">
                                <span class="text-2xl">👥</span>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white p-6 rounded-xl shadow-sm card-hover transition-all duration-200">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-600">Comptes Disponibles</p>
                                <p class="text-2xl font-bold text-orange-600">234</p>
                            </div>
                            <div class="bg-orange-100 p-3 rounded-full">
                                <span class="text-2xl">📦</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="bg-white rounded-xl shadow-sm p-6">
                    <h3 class="text-xl font-semibold mb-4">Activité Récente</h3>
                    <div class="space-y-4">
                        <div class="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                            <span class="text-2xl">📱</span>
                            <div class="flex-1">
                                <p class="font-medium">Nouvelle commande SMM - Instagram</p>
                                <p class="text-sm text-gray-600">5000 abonnés pour @client_exemple</p>
                            </div>
                            <span class="text-sm text-gray-500">Il y a 5 min</span>
                        </div>
                        
                        <div class="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                            <span class="text-2xl">🎨</span>
                            <div class="flex-1">
                                <p class="font-medium">Projet Branding terminé</p>
                                <p class="text-sm text-gray-600">Logo + identité visuelle</p>
                            </div>
                            <span class="text-sm text-gray-500">Il y a 15 min</span>
                        </div>
                        
                        <div class="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                            <span class="text-2xl">📦</span>
                            <div class="flex-1">
                                <p class="font-medium">Vente compte Netflix Premium</p>
                                <p class="text-sm text-gray-600">Compte 4K - 12 mois</p>
                            </div>
                            <span class="text-sm text-gray-500">Il y a 32 min</span>
                        </div>
                    </div>
                </div>

                <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- POS Section -->
            <div id="pos" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Système POS</h2>
                    <p class="text-gray-600 mt-2">Point de vente et facturation</p>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <!-- Product Selection -->
                    <div class="lg:col-span-2">
                        <div class="bg-white rounded-xl shadow-sm p-6">
                            <h3 class="text-xl font-semibold mb-4">Sélection Produits/Services</h3>
                            
                            <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                                <button onclick="addToCart('SMM Instagram', 25)" class="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors">
                                    <div class="text-center">
                                        <span class="text-2xl block mb-2">📱</span>
                                        <p class="font-medium">SMM Instagram</p>
                                        <p class="text-sm text-gray-600">1000 abonnés</p>
                                        <p class="text-lg font-bold text-blue-600">25€</p>
                                    </div>
                                </button>

                                <button onclick="addToCart('Logo Design', 150)" class="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors">
                                    <div class="text-center">
                                        <span class="text-2xl block mb-2">🎨</span>
                                        <p class="font-medium">Logo Design</p>
                                        <p class="text-sm text-gray-600">Création logo</p>
                                        <p class="text-lg font-bold text-blue-600">150€</p>
                                    </div>
                                </button>

                                <button onclick="addToCart('Site Vitrine', 500)" class="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors">
                                    <div class="text-center">
                                        <span class="text-2xl block mb-2">🌐</span>
                                        <p class="font-medium">Site Vitrine</p>
                                        <p class="text-sm text-gray-600">5 pages</p>
                                        <p class="text-lg font-bold text-blue-600">500€</p>
                                    </div>
                                </button>

                                <button onclick="addToCart('Netflix Premium', 15)" class="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors">
                                    <div class="text-center">
                                        <span class="text-2xl block mb-2">🎬</span>
                                        <p class="font-medium">Netflix Premium</p>
                                        <p class="text-sm text-gray-600">1 mois</p>
                                        <p class="text-lg font-bold text-blue-600">15€</p>
                                    </div>
                                </button>

                                <button onclick="addToCart('IPTV Premium', 25)" class="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors">
                                    <div class="text-center">
                                        <span class="text-2xl block mb-2">📺</span>
                                        <p class="font-medium">IPTV Premium</p>
                                        <p class="text-sm text-gray-600">1 mois</p>
                                        <p class="text-lg font-bold text-blue-600">25€</p>
                                    </div>
                                </button>

                                <button onclick="addToCart('Adobe CC', 35)" class="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors">
                                    <div class="text-center">
                                        <span class="text-2xl block mb-2">🎨</span>
                                        <p class="font-medium">Adobe CC</p>
                                        <p class="text-sm text-gray-600">1 mois</p>
                                        <p class="text-lg font-bold text-blue-600">35€</p>
                                    </div>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Cart & Checkout -->
                    <div class="lg:col-span-1">
                        <div class="bg-white rounded-xl shadow-sm p-6">
                            <h3 class="text-xl font-semibold mb-4">Panier</h3>
                            
                            <div id="cart-items" class="space-y-3 mb-6">
                                <p class="text-gray-500 text-center py-8">Panier vide</p>
                            </div>

                            <div class="border-t pt-4">
                                <div class="flex justify-between items-center mb-4">
                                    <span class="text-lg font-semibold">Total:</span>
                                    <span id="cart-total" class="text-2xl font-bold text-green-600">0€</span>
                                </div>

                                <div class="space-y-3">
                                    <input type="text" id="client-name" placeholder="Nom du client" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    
                                    <select id="payment-method" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                        <option value="">Mode de paiement</option>
                                        <option value="cash">Espèces</option>
                                        <option value="card">Carte bancaire</option>
                                        <option value="transfer">Virement</option>
                                        <option value="paypal">PayPal</option>
                                    </select>

                                    <button onclick="processPayment()" class="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                        Finaliser la Vente
                                    </button>

                                    <button onclick="clearCart()" class="w-full bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition-colors">
                                        Vider le Panier
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- SMM API Configuration Section -->
            <div id="smm-api-config" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Configuration API SMM</h2>
                    <p class="text-gray-600 mt-2">Connectez votre clé API ytresellers.com</p>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <!-- API Configuration Form -->
                    <div class="bg-white rounded-xl shadow-sm p-6">
                        <h3 class="text-xl font-semibold mb-4">🔑 Clé API</h3>
                        
                        <form id="api-config-form" class="space-y-4">
                            <div>
                                <label for="api-key" class="block text-sm font-medium text-gray-700 mb-2">Votre clé API ytresellers.com</label>
                                <input type="text" id="api-key" placeholder="Entrez votre clé API" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                <p class="text-xs text-gray-500 mt-1">Vous pouvez obtenir votre clé API depuis votre compte ytresellers.com</p>
                            </div>

                            <div class="flex gap-3">
                                <button type="button" onclick="testAPIConnection()" class="flex-1 bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                                    Tester la connexion
                                </button>
                                <button type="button" onclick="saveAPIKey()" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Sauvegarder
                                </button>
                            </div>
                        </form>

                        <div id="api-status" class="mt-4 hidden">
                            <!-- Status will be shown here -->
                        </div>
                    </div>

                    <!-- API Information -->
                    <div class="bg-white rounded-xl shadow-sm p-6">
                        <h3 class="text-xl font-semibold mb-4">📊 Informations du compte</h3>
                        
                        <div id="api-info" class="space-y-4">
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <p class="text-sm text-gray-600 mb-2">Statut de la connexion</p>
                                <p id="connection-status" class="text-lg font-semibold text-gray-400">Non connecté</p>
                            </div>

                            <div class="bg-gray-50 p-4 rounded-lg">
                                <p class="text-sm text-gray-600 mb-2">Solde disponible</p>
                                <p id="account-balance" class="text-2xl font-bold text-green-600">--</p>
                            </div>

                            <div class="bg-gray-50 p-4 rounded-lg">
                                <p class="text-sm text-gray-600 mb-2">Services disponibles</p>
                                <p id="services-count" class="text-lg font-semibold">--</p>
                            </div>

                            <button onclick="refreshAPIInfo()" class="w-full bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 transition-colors">
                                🔄 Rafraîchir les informations
                            </button>
                        </div>
                    </div>
                </div>

                <!-- API Documentation -->
                <div class="mt-8 bg-white rounded-xl shadow-sm p-6">
                    <h3 class="text-xl font-semibold mb-4">📖 Documentation API</h3>
                    
                    <div class="space-y-4">
                        <div class="bg-blue-50 p-4 rounded-lg">
                            <h4 class="font-semibold text-blue-900 mb-2">Endpoint API</h4>
                            <code class="text-sm text-blue-800">https://ytresellers.com/api/v2</code>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <h4 class="font-semibold text-gray-800 mb-2">Actions disponibles</h4>
                                <ul class="text-sm space-y-1 text-gray-600">
                                    <li>• <code>services</code> - Liste des services</li>
                                    <li>• <code>add</code> - Créer une commande</li>
                                    <li>• <code>status</code> - Statut d'une commande</li>
                                    <li>• <code>balance</code> - Consulter le solde</li>
                                </ul>
                            </div>

                            <div class="bg-gray-50 p-4 rounded-lg">
                                <h4 class="font-semibold text-gray-800 mb-2">Format de réponse</h4>
                                <p class="text-sm text-gray-600">Toutes les réponses sont au format JSON</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- SMM Sections -->
            <div id="smm-new-order" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Nouvelle Commande SMM</h2>
                    <p class="text-gray-600 mt-2">Créer une nouvelle commande de services SMM</p>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <!-- New SMM Order Form -->
                    <div class="bg-white rounded-xl shadow-sm p-6">
                        <h3 class="text-xl font-semibold mb-4">Détails de la Commande</h3>
                        
                        <form onsubmit="createSMMOrderSimple(event)" class="space-y-4">
                            <div>
                                <label for="service-search-input" class="block text-sm font-medium text-gray-700 mb-2">🔍 Rechercher un service (ID ou Nom)</label>
                                <div class="relative">
                                    <input 
                                        type="text" 
                                        id="service-search-input" 
                                        placeholder="Tapez l'ID (ex: 12345) ou le nom du service..."
                                        oninput="searchServices(this.value)"
                                        onfocus="showSearchResults()"
                                        class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    >
                                    <div id="search-results" class="hidden absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">
                                        <!-- Les résultats de recherche apparaîtront ici -->
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label for="smm-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="smm-category" onchange="updateServicesDropdown()" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="">Sélectionner une catégorie</option>
                                </select>
                            </div>

                            <div>
                                <label for="smm-service-select" class="block text-sm font-medium text-gray-700 mb-2">Service</label>
                                <select id="smm-service-select" onchange="updateServiceDetails()" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="">Sélectionner un service</option>
                                </select>
                                <div id="service-avgtime-display" class="hidden mt-2 text-sm">
                                    <span class="text-gray-600">⏱️ Temps moyen: </span>
                                    <span id="service-avgtime-value" class="font-medium text-blue-600"></span>
                                </div>
                            </div>

                            <div id="service-details-simple" class="hidden bg-blue-50 border border-blue-200 p-3 rounded-lg text-sm">
                                <div class="grid grid-cols-2 gap-2 text-xs">
                                    <div>
                                        <span class="text-gray-600">Prix:</span>
                                        <div id="service-rate-simple" class="font-medium text-blue-800"></div>
                                    </div>
                                    <div>
                                        <span class="text-gray-600">Min/Max:</span>
                                        <div id="service-minmax-simple" class="font-medium text-blue-800"></div>
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label for="smm-quantity" class="block text-sm font-medium text-gray-700 mb-2">Quantité</label>
                                <input type="number" id="smm-quantity" placeholder="Ex: 1000" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            </div>

                            <div>
                                <label for="smm-url" class="block text-sm font-medium text-gray-700 mb-2">URL/Nom d'utilisateur</label>
                                <input type="text" id="smm-url" placeholder="@username ou URL" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            </div>

                            <div>
                                <label for="smm-client" class="block text-sm font-medium text-gray-700 mb-2">Client</label>
                                <input type="text" id="smm-client" placeholder="Nom du client" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            </div>

                            <div class="bg-blue-50 p-4 rounded-lg">
                                <div class="flex justify-between items-center">
                                    <span class="font-medium">Coût estimé:</span>
                                    <span id="order-cost-simple" class="text-xl font-bold text-blue-600">0.00€</span>
                                </div>
                            </div>

                            <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                                Lancer la Commande SMM
                            </button>
                        </form>
                    </div>

                    <!-- Order Summary -->
                    <div class="bg-white rounded-xl shadow-sm p-6">
                        <h3 class="text-xl font-semibold mb-4">Résumé</h3>
                        
                        <div class="space-y-4">
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <h4 class="font-medium mb-2">Solde Actuel</h4>
                                <p id="balance-summary" class="text-2xl font-bold text-green-600">--</p>
                            </div>
                            
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <h4 class="font-medium mb-2">Commandes ce Mois</h4>
                                <p id="orders-count-summary" class="text-xl font-semibold">-- commandes</p>
                            </div>
                            
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <h4 class="font-medium mb-2">Services Populaires</h4>
                                <div class="space-y-2 text-sm">
                                    <div class="flex justify-between">
                                        <span>Instagram</span>
                                        <span class="text-blue-600">📱</span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span>TikTok</span>
                                        <span class="text-blue-600">🎵</span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span>YouTube</span>
                                        <span class="text-blue-600">📹</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- My Orders Section -->
            <div id="smm-my-orders" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Mes Commandes SMM</h2>
                    <p class="text-gray-600 mt-2">Suivi de toutes vos commandes SMM</p>
                </div>

                <div class="mb-6">
                    <div class="bg-white rounded-lg shadow-sm p-4">
                        <form onsubmit="searchOrders(event)" class="flex gap-2">
                            <input type="text" id="order-search-input" placeholder="Search" 
                                   class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                                <span class="fas fa-search">🔍</span>
                            </button>
                        </form>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-gray-50 border-b border-gray-200">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">ID</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Date</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Link</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Charge</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider nowrap">Start count</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Quantity</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Service</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Status</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Remains</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">&nbsp;</th>
                                </tr>
                            </thead>
                            <tbody id="orders-table-body" class="bg-white divide-y divide-gray-200">
                                <!-- Les commandes seront insérées ici -->
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="mt-6 flex justify-between items-center">
                    <div id="orders-pagination" class="flex gap-2">
                        <!-- Pagination sera générée ici -->
                    </div>
                </div>

                <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Services List Section -->
            <div id="smm-services-list" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Liste des Services</h2>
                    <p class="text-gray-600 mt-2">Tous les services SMM disponibles</p>
                </div>

                <div class="bg-white rounded-xl shadow-sm p-6">
                    <div class="mb-6">
                        <input type="text" placeholder="Rechercher un service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                            <div class="flex items-center space-x-3 mb-3">
                                <span class="text-2xl">❤️</span>
                                <div>
                                    <h4 class="font-medium">TikTok Likes [ Max 1M ] | LQ Accounts</h4>
                                    <p class="text-sm text-gray-600">60 Days ♻️ | Day 100K 🚀</p>
                                </div>
                            </div>
                            <div class="space-y-2 text-sm">
                                <div class="flex justify-between">
                                    <span>ID:</span>
                                    <span class="font-mono text-blue-600">6835</span>
                                </div>
                                <div class="flex justify-between">
                                    <span>Min:</span>
                                    <span>10</span>
                                </div>
                                <div class="flex justify-between">
                                    <span>Max:</span>
                                    <span>1,000,000</span>
                                </div>
                                <div class="flex justify-between">
                                    <span>Prix:</span>
                                    <span class="font-medium text-blue-600">$0.0107 / 1000</span>
                                </div>
                                <div class="flex justify-between">
                                    <span>Temps moyen:</span>
                                    <span class="text-green-600">⏱️ 4h 12min</span>
                                </div>
                                <div class="flex gap-1 mt-2 flex-wrap">
                                    <span class="bg-green-100 text-green-700 px-2 py-0.5 rounded text-xs">✓ Cancel</span>
                                    <span class="bg-blue-100 text-blue-700 px-2 py-0.5 rounded text-xs">♻️ 60 Days</span>
                                    <span class="bg-orange-100 text-orange-700 px-2 py-0.5 rounded text-xs">🚀 Instant</span>
                                </div>
                            </div>
                        </div>

                        <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                            <div class="flex items-center space-x-3 mb-3">
                                <span class="text-2xl">❤️</span>
                                <div>
                                    <h4 class="font-medium">TikTok Likes [ Max 1M ] | LQ Accounts</h4>
                                    <p class="text-sm text-gray-600">90 Days ♻️ | Day 100K 🚀</p>
                                </div>
                            </div>
                            <div class="space-y-2 text-sm">
                                <div class="flex justify-between">
                                    <span>ID:</span>
                                    <span class="font-mono text-blue-600">6836</span>
                                </div>
                                <div class="flex justify-between">
                                    <span>Min:</span>
                                    <span>10</span>
                                </div>
                                <div class="flex justify-between">
                                    <span>Max:</span>
                                    <span>1,000,000</span>
                                </div>
                                <div class="flex justify-between">
                                    <span>Prix:</span>
                                    <span class="font-medium text-blue-600">$0.0108 / 1000</span>
                                </div>
                                <div class="flex justify-between">
                                    <span>Temps moyen:</span>
                                    <span class="text-green-600">⏱️ 1h 38min</span>
                                </div>
                                <div class="flex gap-1 mt-2 flex-wrap">
                                    <span class="bg-green-100 text-green-700 px-2 py-0.5 rounded text-xs">✓ Cancel</span>
                                    <span class="bg-blue-100 text-blue-700 px-2 py-0.5 rounded text-xs">♻️ 90 Days</span>
                                    <span class="bg-orange-100 text-orange-700 px-2 py-0.5 rounded text-xs">🚀 Instant</span>
                                </div>
                            </div>
                        </div>

                        <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                            <div class="flex items-center space-x-3 mb-3">
                                <span class="text-2xl">🎵</span>
                                <div>
                                    <h4 class="font-medium">Plus de services disponibles</h4>
                                    <p class="text-sm text-gray-600">Connectez votre API pour voir tous les services</p>
                                </div>
                            </div>
                            <div class="space-y-2 text-sm">
                                <div class="bg-blue-50 p-3 rounded-lg text-center">
                                    <p class="text-blue-800 mb-2">🔑 Configurez votre clé API dans la section "API Configuration" pour accéder à tous les services disponibles</p>
                                    <button onclick="showSMMPage('api-config')" class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 transition-colors">
                                        Configurer l'API
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Add Funds Section -->
            <div id="smm-add-funds" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Ajouter des Fonds</h2>
                    <p class="text-gray-600 mt-2">Rechargez votre solde pour les services SMM</p>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div class="bg-white rounded-xl shadow-sm p-6">
                        <h3 class="text-xl font-semibold mb-4">Recharge Rapide</h3>
                        
                        <div class="grid grid-cols-2 gap-4 mb-6">
                            <button class="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center">
                                <p class="text-2xl font-bold text-blue-600">50€</p>
                                <p class="text-sm text-gray-600">Bonus: +2€</p>
                            </button>
                            <button class="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center">
                                <p class="text-2xl font-bold text-blue-600">100€</p>
                                <p class="text-sm text-gray-600">Bonus: +5€</p>
                            </button>
                            <button class="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center">
                                <p class="text-2xl font-bold text-blue-600">250€</p>
                                <p class="text-sm text-gray-600">Bonus: +15€</p>
                            </button>
                            <button class="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center">
                                <p class="text-2xl font-bold text-blue-600">500€</p>
                                <p class="text-sm text-gray-600">Bonus: +35€</p>
                            </button>
                        </div>

                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Montant personnalisé</label>
                                <input type="number" placeholder="Montant en €" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Mode de paiement</label>
                                <select class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option>PayPal</option>
                                    <option>Carte bancaire</option>
                                    <option>Virement</option>
                                    <option>Crypto</option>
                                </select>
                            </div>

                            <button class="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                Ajouter les Fonds
                            </button>
                        </div>
                    </div>

                    <div class="bg-white rounded-xl shadow-sm p-6">
                        <h3 class="text-xl font-semibold mb-4">Historique des Transactions</h3>
                        
                        <div class="space-y-4">
                            <div class="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                                <div>
                                    <p class="font-medium text-green-800">+250.00€</p>
                                    <p class="text-sm text-gray-600">PayPal • 14/01/2024</p>
                                </div>
                                <span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Confirmé</span>
                            </div>

                            <div class="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                                <div>
                                    <p class="font-medium text-red-800">-125.00€</p>
                                    <p class="text-sm text-gray-600">Commande SMM • 15/01/2024</p>
                                </div>
                                <span class="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs">Débité</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Other SMM sections -->
            <div id="smm-support" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Support Client</h2>
                    <p class="text-gray-600 mt-2">Besoin d'aide ? Contactez notre équipe</p>
                </div>
                <div class="bg-white rounded-xl shadow-sm p-6">
                    <p class="text-gray-600">Section Support en cours de développement...</p>
                </div>

                <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div id="smm-affiliate" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Programme d'Affiliation</h2>
                    <p class="text-gray-600 mt-2">Gagnez des commissions en parrainant</p>
                </div>
                <div class="bg-white rounded-xl shadow-sm p-6">
                    <p class="text-gray-600">Section Affiliation en cours de développement...</p>
                </div>

                <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div id="smm-reseller" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Programme Revendeur</h2>
                    <p class="text-gray-600 mt-2">Devenez revendeur de nos services</p>
                </div>
                <div class="bg-white rounded-xl shadow-sm p-6">
                    <p class="text-gray-600">Section Revendeur en cours de développement...</p>
                </div>

                <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div id="smm-faq" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">FAQ</h2>
                    <p class="text-gray-600 mt-2">Questions fréquemment posées</p>
                </div>
                <div class="bg-white rounded-xl shadow-sm p-6">
                    <p class="text-gray-600">Section FAQ en cours de développement...</p>
                </div>

                <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div id="smm-api" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Documentation API</h2>
                    <p class="text-gray-600 mt-2">Intégrez nos services via API</p>
                </div>
                <div class="bg-white rounded-xl shadow-sm p-6">
                    <p class="text-gray-600">Section API en cours de développement...</p>
                </div>

                <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Branding Section -->
            <div id="branding" class="section hidden p-8">
                <div class="mb-8 flex justify-between items-center">
                    <div>
                        <h2 class="text-3xl font-bold text-gray-800">Services Branding</h2>
                        <p class="text-gray-600 mt-2">Création d'identité visuelle et design</p>
                    </div>
                    <div class="relative">
                        <button onclick="toggleAddMenu()" class="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors flex items-center space-x-2">
                            <span class="text-xl">+</span>
                            <span>Ajouter</span>
                            <span class="text-sm">▼</span>
                        </button>
                        
                        <div id="add-menu" class="hidden absolute right-0 top-full mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-50 min-w-[200px]">
                            <button onclick="showNewProjectModal(); hideAddMenu()" class="w-full text-left px-4 py-3 hover:bg-gray-100 flex items-center space-x-3">
                                <span>🎨</span>
                                <span>Ajouter un Projet</span>
                            </button>
                            <button onclick="showNewServiceModal(); hideAddMenu();" class="w-full text-left px-4 py-3 hover:bg-gray-100 flex items-center space-x-3">
                                <span>⚙️</span>
                                <span>Ajouter un Service</span>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Dashboard Summary -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div class="bg-white p-6 rounded-xl shadow-sm">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-600">Projets Actifs</p>
                                <p class="text-2xl font-bold text-blue-600">12</p>
                            </div>
                            <span class="text-3xl">🎨</span>
                        </div>
                    </div>
                    
                    <div class="bg-white p-6 rounded-xl shadow-sm">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-600">En Cours</p>
                                <p class="text-2xl font-bold text-yellow-600">8</p>
                            </div>
                            <span class="text-3xl">⏳</span>
                        </div>
                    </div>
                    
                    <div class="bg-white p-6 rounded-xl shadow-sm">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-600">Terminés ce Mois</p>
                                <p class="text-2xl font-bold text-green-600">15</p>
                            </div>
                            <span class="text-3xl">✅</span>
                        </div>
                    </div>
                    
                    <div class="bg-white p-6 rounded-xl shadow-sm">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-600">Revenus Mois</p>
                                <p class="text-2xl font-bold text-purple-600">3,450€</p>
                            </div>
                            <span class="text-3xl">💰</span>
                        </div>
                    </div>
                </div>

                <!-- Filter Tabs -->
                <div class="mb-6">
                    <div class="flex space-x-1 bg-gray-100 p-1 rounded-lg w-fit">
                        <button onclick="filterBrandingProjects('all')" class="branding-filter active px-4 py-2 rounded-md bg-white text-gray-800 font-medium shadow-sm">
                            Tous les Projets
                        </button>
                        <button onclick="filterBrandingProjects('active')" class="branding-filter px-4 py-2 rounded-md text-gray-600 hover:text-gray-800">
                            En Cours
                        </button>
                        <button onclick="filterBrandingProjects('completed')" class="branding-filter px-4 py-2 rounded-md text-gray-600 hover:text-gray-800">
                            Terminés
                        </button>
                        <button onclick="filterBrandingProjects('templates')" class="branding-filter px-4 py-2 rounded-md text-gray-600 hover:text-gray-800">
                            Modèles
                        </button>
                    </div>
                </div>

                <!-- Projects Grid -->
                <div id="branding-projects-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    <!-- Sample Active Project -->
                    <div class="project-card active bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden card-hover transition-all duration-200" data-project='{"id":"project-1","name":"Logo Restaurant Le Gourmet","client":"Pierre Martin","services":[{"id":"logo","name":"Logo Design","price":150}],"price":150,"status":"En cours","date":"15/01/2024","description":"Création d\'un logo moderne pour restaurant gastronomique","facebook":"https://facebook.com/legourmet"}'>
                        <div class="relative">
                            <div class="h-48 bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                                <span class="text-6xl">🎨</span>
                            </div>
                            <div class="absolute top-3 right-3">
                                <span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium">En cours</span>
                            </div>
                            <div class="absolute top-3 left-3">
                                <button onclick="toggleProjectFavorite(this)" class="text-white hover:text-yellow-300 text-xl">☆</button>
                            </div>
                        </div>
                        <div class="p-4">
                            <h3 class="font-semibold text-gray-800 mb-1">Logo Restaurant Le Gourmet</h3>
                            <p class="text-sm text-gray-600 mb-2">Client: Pierre Martin</p>
                            <div class="flex justify-between items-center text-sm text-gray-500 mb-3">
                                <span>Démarré: 15/01/2024</span>
                                <span class="font-medium text-green-600">150€</span>
                            </div>
                            <div class="flex space-x-2">
                                <button onclick="openProjectDetails(this)" class="flex-1 bg-blue-600 text-white py-2 px-3 rounded-lg text-sm hover:bg-blue-700 transition-colors">
                                    Ouvrir
                                </button>
                                <button onclick="showProjectMenu(this)" class="bg-gray-100 text-gray-600 py-2 px-3 rounded-lg text-sm hover:bg-gray-200 transition-colors">
                                    ⋯
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Sample Completed Project -->
                    <div class="project-card completed bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden card-hover transition-all duration-200" data-project='{"id":"project-2","name":"Identité Visuelle TechStart","client":"Sophie Laurent","services":[{"id":"identite","name":"Identité Complète","price":350}],"price":350,"status":"Terminé","date":"12/01/2024","description":"Identité visuelle complète pour startup tech","facebook":""}'>
                        <div class="relative">
                            <div class="h-48 bg-gradient-to-br from-green-500 to-teal-600 flex items-center justify-center">
                                <span class="text-6xl">📱</span>
                            </div>
                            <div class="absolute top-3 right-3">
                                <span class="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">Terminé</span>
                            </div>
                            <div class="absolute top-3 left-3">
                                <button onclick="toggleProjectFavorite(this)" class="text-white hover:text-yellow-300 text-xl">★</button>
                            </div>
                        </div>
                        <div class="p-4">
                            <h3 class="font-semibold text-gray-800 mb-1">Identité Visuelle TechStart</h3>
                            <p class="text-sm text-gray-600 mb-2">Client: Sophie Laurent</p>
                            <div class="flex justify-between items-center text-sm text-gray-500 mb-3">
                                <span>Livré: 12/01/2024</span>
                                <span class="font-medium text-green-600">350€</span>
                            </div>
                            <div class="flex space-x-2">
                                <button onclick="openProjectDetails(this)" class="flex-1 bg-blue-600 text-white py-2 px-3 rounded-lg text-sm hover:bg-blue-700 transition-colors">
                                    Voir
                                </button>
                                <button onclick="showProjectMenu(this)" class="bg-gray-100 text-gray-600 py-2 px-3 rounded-lg text-sm hover:bg-gray-200 transition-colors">
                                    ⋯
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Sample Template -->
                    <div class="project-card templates bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden card-hover transition-all duration-200" data-project='{"id":"template-1","name":"Carte de Visite Moderne","client":"Modèle","services":[{"id":"carte-visite","name":"Carte de Visite","price":50}],"price":50,"status":"Modèle","date":"10/01/2024","description":"Modèle de carte de visite moderne et élégant","facebook":""}'>
                        <div class="relative">
                            <div class="h-48 bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                                <span class="text-6xl">📄</span>
                            </div>
                            <div class="absolute top-3 right-3">
                                <span class="bg-purple-100 text-purple-800 px-2 py-1 rounded-full text-xs font-medium">Modèle</span>
                            </div>
                            <div class="absolute top-3 left-3">
                                <button onclick="toggleProjectFavorite(this)" class="text-white hover:text-yellow-300 text-xl">☆</button>
                            </div>
                        </div>
                        <div class="p-4">
                            <h3 class="font-semibold text-gray-800 mb-1">Carte de Visite Moderne</h3>
                            <p class="text-sm text-gray-600 mb-2">Modèle réutilisable</p>
                            <div class="flex justify-between items-center text-sm text-gray-500 mb-3">
                                <span>Créé: 10/01/2024</span>
                                <span class="font-medium text-blue-600">Modèle</span>
                            </div>
                            <div class="flex space-x-2">
                                <button onclick="useTemplate('template-1')" class="flex-1 bg-purple-600 text-white py-2 px-3 rounded-lg text-sm hover:bg-purple-700 transition-colors">
                                    Utiliser
                                </button>
                                <button onclick="showProjectMenu(this)" class="bg-gray-100 text-gray-600 py-2 px-3 rounded-lg text-sm hover:bg-gray-200 transition-colors">
                                    ⋯
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- New Project Modal -->
                <div id="new-project-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Projet Branding</h3>
                                <button onclick="hideNewProjectModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewProject(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                                <!-- Project Info -->
                                <div class="space-y-6">
                                    <div>
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">Informations du Projet</h4>
                                        
                                        <div class="space-y-4">
                                            <div>
                                                <label for="project-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Projet</label>
                                                <input type="text" id="project-name" placeholder="Ex: Logo Restaurant Le Gourmet" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                            </div>

                                            <div>
                                                <label class="block text-sm font-medium text-gray-700 mb-3">Services Demandés</label>
                                                <div class="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
                                                    <div onclick="toggleService(this, 'logo', 150)" class="service-card cursor-pointer p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center">
                                                        <span class="text-2xl block mb-1">🎨</span>
                                                        <p class="text-sm font-medium">Logo Design</p>
                                                        <p class="text-xs text-blue-600">150€</p>
                                                    </div>
                                                    
                                                    <div onclick="toggleService(this, 'carte-visite', 50)" class="service-card cursor-pointer p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center">
                                                        <span class="text-2xl block mb-1">💼</span>
                                                        <p class="text-sm font-medium">Carte de Visite</p>
                                                        <p class="text-xs text-blue-600">50€</p>
                                                    </div>
                                                    
                                                    <div onclick="toggleService(this, 'flyer', 80)" class="service-card cursor-pointer p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center">
                                                        <span class="text-2xl block mb-1">📄</span>
                                                        <p class="text-sm font-medium">Flyer/Brochure</p>
                                                        <p class="text-xs text-blue-600">80€</p>
                                                    </div>
                                                    
                                                    <div onclick="toggleService(this, 'identite', 350)" class="service-card cursor-pointer p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center">
                                                        <span class="text-2xl block mb-1">📱</span>
                                                        <p class="text-sm font-medium">Identité Complète</p>
                                                        <p class="text-xs text-blue-600">350€</p>
                                                    </div>
                                                    
                                                    <div onclick="toggleService(this, 'packaging', 200)" class="service-card cursor-pointer p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center">
                                                        <span class="text-2xl block mb-1">📦</span>
                                                        <p class="text-sm font-medium">Packaging</p>
                                                        <p class="text-xs text-blue-600">200€</p>
                                                    </div>
                                                    
                                                    <div onclick="toggleService(this, 'social-media', 120)" class="service-card cursor-pointer p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center">
                                                        <span class="text-2xl block mb-1">📸</span>
                                                        <p class="text-sm font-medium">Kit Réseaux Sociaux</p>
                                                        <p class="text-xs text-blue-600">120€</p>
                                                    </div>
                                                </div>
                                                
                                                <div class="bg-blue-50 p-3 rounded-lg">
                                                    <div class="flex justify-between items-center">
                                                        <span class="font-medium">Total Services:</span>
                                                        <span id="services-total" class="text-xl font-bold text-blue-600">0€</span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="grid grid-cols-2 gap-4">
                                                <div>
                                                    <label for="project-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                                    <input type="number" id="project-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                                </div>
                                                <div>
                                                    <label for="project-deadline" class="block text-sm font-medium text-gray-700 mb-2">Date Limite</label>
                                                    <input type="date" id="project-deadline" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                                </div>
                                            </div>

                                            <div>
                                                <label for="project-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                                <textarea id="project-description" rows="3" placeholder="Description détaillée du projet..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                                            </div>

                                            <div>
                                                <label for="project-facebook" class="block text-sm font-medium text-gray-700 mb-2">Page Facebook (optionnel)</label>
                                                <input type="url" id="project-facebook" placeholder="https://facebook.com/page-client" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Client Info -->
                                    <div>
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">Informations Client</h4>
                                        
                                        <div class="space-y-4">
                                            <div class="grid grid-cols-2 gap-4">
                                                <div>
                                                    <label for="client-name-project" class="block text-sm font-medium text-gray-700 mb-2">Nom du Client</label>
                                                    <input type="text" id="client-name-project" placeholder="Nom complet" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                                </div>
                                                <div>
                                                    <label for="client-company-project" class="block text-sm font-medium text-gray-700 mb-2">Entreprise</label>
                                                    <input type="text" id="client-company-project" placeholder="Nom de l'entreprise" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                                </div>
                                            </div>
                                            
                                            <div class="grid grid-cols-2 gap-4">
                                                <div>
                                                    <label for="client-email-project" class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                                                    <input type="email" id="client-email-project" placeholder="email@exemple.com" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                                </div>
                                                <div>
                                                    <label for="client-phone-project" class="block text-sm font-medium text-gray-700 mb-2">Téléphone</label>
                                                    <input type="tel" id="client-phone-project" placeholder="+33 6 12 34 56 78" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Files & Assets -->
                                <div class="space-y-6">
                                    <div>
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">Fichiers & Ressources</h4>
                                        
                                        <div class="space-y-4">
                                            <div>
                                                <label class="block text-sm font-medium text-gray-700 mb-2">Fichiers de Référence</label>
                                                <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors">
                                                    <input type="file" id="reference-files" multiple accept="image/*,.pdf,.ai,.psd" class="hidden" onchange="handleFileUpload(this, 'reference-preview')">
                                                    <label for="reference-files" class="cursor-pointer">
                                                        <span class="text-4xl text-gray-400 block mb-2">📁</span>
                                                        <span class="text-gray-600">Cliquez pour ajouter des fichiers</span>
                                                        <p class="text-xs text-gray-500 mt-1">Images, PDF, AI, PSD acceptés</p>
                                                    </label>
                                                </div>
                                                <div id="reference-preview" class="mt-3 grid grid-cols-3 gap-2"></div>
                                            </div>

                                            <div>
                                                <label class="block text-sm font-medium text-gray-700 mb-2">Logo/Éléments Existants</label>
                                                <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors">
                                                    <input type="file" id="existing-assets" multiple accept="image/*,.pdf,.ai,.psd,.svg" class="hidden" onchange="handleFileUpload(this, 'assets-preview')">
                                                    <label for="existing-assets" class="cursor-pointer">
                                                        <span class="text-4xl text-gray-400 block mb-2">🎨</span>
                                                        <span class="text-gray-600">Logos ou éléments existants</span>
                                                        <p class="text-xs text-gray-500 mt-1">Optionnel</p>
                                                    </label>
                                                </div>
                                                <div id="assets-preview" class="mt-3 grid grid-cols-3 gap-2"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Project Requirements -->
                                    <div>
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">Exigences du Projet</h4>
                                        
                                        <div class="space-y-4">


                                            <div>
                                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                                <div id="project-deliverables" class="space-y-2">
                                                    <div class="flex items-center space-x-2">
                                                        <input type="text" placeholder="Ex: Logo en format vectoriel" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                                        <button type="button" onclick="removeDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                                    </div>
                                                </div>
                                                <button type="button" onclick="addDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                                            </div>

                                            <div>
                                                <label for="project-colors" class="block text-sm font-medium text-gray-700 mb-2">Couleurs Préférées</label>
                                                <input type="text" id="project-colors" placeholder="Ex: Bleu, Blanc, Rouge" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Action Buttons -->
                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewProjectModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Projet
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Project Details Modal -->
                <div id="project-details-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <div>
                                    <h3 id="project-details-title" class="text-2xl font-bold text-gray-800">Détails du Projet</h3>
                                    <p id="project-details-client" class="text-gray-600 mt-1">Client: Pierre Martin</p>
                                </div>
                                <div class="flex items-center space-x-3">
                                    <span id="project-details-status" class="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-medium">En cours</span>
                                    <button onclick="hideProjectDetailsModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                                </div>
                            </div>
                        </div>
                        
                        <div class="p-6">
                            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                                <!-- Project Files -->
                                <div class="lg:col-span-2">
                                    <h4 class="text-lg font-semibold text-gray-800 mb-4">Fichiers du Projet</h4>
                                    
                                    <div class="space-y-4">
                                        <!-- Upload New Files -->
                                        <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors">
                                            <input type="file" id="project-files" multiple accept="image/*,.pdf,.ai,.psd,.svg" class="hidden" onchange="handleProjectFileUpload(this)">
                                            <label for="project-files" class="cursor-pointer">
                                                <span class="text-3xl text-gray-400 block mb-2">📎</span>
                                                <span class="text-gray-600">Ajouter des fichiers au projet</span>
                                                <p class="text-xs text-gray-500 mt-1">Glissez-déposez ou cliquez pour sélectionner</p>
                                            </label>
                                        </div>

                                        <!-- Existing Files -->
                                        <div id="project-files-grid" class="grid grid-cols-2 md:grid-cols-3 gap-4">
                                            <!-- Sample files will be populated here -->
                                        </div>
                                    </div>
                                </div>

                                <!-- Project Info -->
                                <div class="space-y-6">
                                    <!-- Services Commandés -->
                                    <div>
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">Services Commandés</h4>
                                        <div id="project-services-list" class="space-y-3">
                                            <!-- Services will be populated here -->
                                        </div>
                                    </div>

                                    <!-- Informations Générales -->
                                    <div>
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">Informations</h4>
                                        <div class="space-y-3 text-sm">
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Prix Total:</span>
                                                <span id="project-details-price" class="font-medium text-green-600">150€</span>
                                            </div>
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Démarré:</span>
                                                <span id="project-details-date">15/01/2024</span>
                                            </div>
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Échéance:</span>
                                                <span id="project-details-deadline">20/01/2024</span>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Description -->
                                    <div>
                                        <h4 class="text-lg font-semibold text-gray-800 mb-2">Description</h4>
                                        <p id="project-details-description" class="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                                            Description du projet...
                                        </p>
                                    </div>

                                    <!-- Page Facebook -->
                                    <div id="project-facebook-section" class="hidden">
                                        <h4 class="text-lg font-semibold text-gray-800 mb-2">Page Facebook</h4>
                                        <a id="project-facebook-link" href="#" target="_blank" class="text-blue-600 hover:text-blue-800 text-sm break-all">
                                            Lien Facebook
                                        </a>
                                    </div>

                                    <!-- Actions -->
                                    <div>
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">Actions</h4>
                                        <div class="space-y-2">
                                            <button onclick="updateProjectStatus('completed')" class="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition-colors">
                                                Marquer Terminé
                                            </button>
                                            <button onclick="updateProjectStatus('revision')" class="w-full bg-yellow-600 text-white py-2 rounded-lg hover:bg-yellow-700 transition-colors">
                                                Demander Révision
                                            </button>
                                            <button onclick="sendProjectToClient()" class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors">
                                                Envoyer au Client
                                            </button>
                                            <button onclick="duplicateProject()" class="w-full bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 transition-colors">
                                                Dupliquer Projet
                                            </button>
                                        </div>
                                    </div>

                                    <!-- Notes -->
                                    <div>
                                        <h4 class="text-lg font-semibold text-gray-800 mb-4">Notes</h4>
                                        <textarea id="project-notes" placeholder="Ajouter des notes sur le projet..." class="w-full p-3 border border-gray-300 rounded-lg text-sm" rows="4"></textarea>
                                        <button onclick="saveProjectNotes()" class="mt-2 w-full bg-gray-600 text-white py-2 rounded-lg hover:bg-gray-700 transition-colors text-sm">
                                            Sauvegarder Notes
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Websites Section -->
            <div id="websites" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Création de Sites Web</h2>
                    <p class="text-gray-600 mt-2">Sites vitrines et boutiques en ligne</p>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div class="bg-white rounded-xl shadow-sm p-6 card-hover transition-all duration-200">
                        <div class="text-center mb-6">
                            <span class="text-4xl">🌐</span>
                            <h3 class="text-2xl font-semibold mt-2">Site Vitrine</h3>
                        </div>
                        <ul class="space-y-3 text-gray-600 mb-6">
                            <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Design responsive</li>
                            <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> 5 pages incluses</li>
                            <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Formulaire de contact</li>
                            <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Optimisation SEO</li>
                            <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Hébergement 1 an</li>
                        </ul>
                        <div class="text-center">
                            <p class="text-3xl font-bold text-blue-600 mb-4">500€</p>
                            <button onclick="startWebProject('vitrine')" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                                Commander
                            </button>
                        </div>
                    </div>

                    <div class="bg-white rounded-xl shadow-sm p-6 card-hover transition-all duration-200">
                        <div class="text-center mb-6">
                            <span class="text-4xl">🛒</span>
                            <h3 class="text-2xl font-semibold mt-2">Boutique en Ligne</h3>
                        </div>
                        <ul class="space-y-3 text-gray-600 mb-6">
                            <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> E-commerce complet</li>
                            <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Gestion produits</li>
                            <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Paiement sécurisé</li>
                            <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Tableau de bord admin</li>
                            <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Formation incluse</li>
                        </ul>
                        <div class="text-center">
                            <p class="text-3xl font-bold text-blue-600 mb-4">1200€</p>
                            <button onclick="startWebProject('ecommerce')" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                                Commander
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Active Web Projects -->
                <div class="mt-8 bg-white rounded-xl shadow-sm p-6">
                    <h3 class="text-xl font-semibold mb-4">Projets Web en Cours</h3>
                    <div class="space-y-4">
                        <div class="border border-gray-200 rounded-lg p-4">
                            <div class="flex justify-between items-center mb-2">
                                <div>
                                    <p class="font-medium">Boutique Mode - FashionStyle</p>
                                    <p class="text-sm text-gray-600">E-commerce • Démarré le 10/01/2024</p>
                                </div>
                                <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">Développement</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-blue-600 h-2 rounded-full" style="width: 75%"></div>
                            </div>
                            <p class="text-sm text-gray-600 mt-2">Progression: 75% • Livraison prévue: 25/01/2024</p>
                        </div>
                    </div>
                </div>

                <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Digital Products Section -->
            <div id="digital-products" class="section hidden p-8">
                <div class="flex gap-6">
                    <!-- Sidebar Catégories -->
                    <div class="w-1/4 bg-white rounded-lg shadow-lg p-6">
                        <div class="flex justify-between items-center mb-4">
                            <h2 class="text-xl font-semibold text-gray-800">Catégories</h2>
                            <button onclick="openCategoryModal()" class="bg-blue-500 text-white px-3 py-1 rounded-md text-sm hover:bg-blue-600">
                                + Nouvelle
                            </button>
                        </div>
                        
                        <div class="category-tree" id="categoryTree" style="max-height: 400px; overflow-y: auto;">
                            <!-- Les catégories seront générées ici -->
                        </div>
                    </div>

                    <!-- Zone principale des produits -->
                    <div class="flex-1">
                        <div class="bg-white rounded-lg shadow-lg p-6">
                            <div class="flex justify-between items-center mb-6">
                                <div class="flex items-center gap-4">
                                    <h2 class="text-2xl font-semibold text-gray-800">Mes Produits Digitaux</h2>
                                    <span id="productCount" class="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-sm">0 produits</span>
                                </div>
                                <button onclick="openProductModal()" class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 flex items-center gap-2">
                                    <span>+</span> Nouveau Produit
                                </button>
                            </div>

                            <!-- Filtres et recherche -->
                            <div class="flex gap-4 mb-6">
                                <input type="text" id="searchInput" placeholder="Rechercher un produit..." 
                                       class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                <select id="typeFilter" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                                    <option value="">Tous les types</option>
                                    <option value="abonnement">🎬 Abonnements</option>
                                    <option value="licence">💻 Licences</option>
                                    <option value="formation">🎓 Formations</option>
                                    <option value="giftcard">🎁 Gift Cards</option>
                                </select>
                            </div>

                            <!-- Grille des produits -->
                            <div id="productsGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                <!-- Les produits seront générés ici -->
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal Nouvelle Catégorie -->
                <div id="categoryModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50" style="backdrop-filter: blur(5px);">
                    <div class="bg-white rounded-lg p-6 w-96 max-w-90vw">
                        <h3 class="text-xl font-semibold mb-4">Nouvelle Catégorie</h3>
                        <form id="categoryForm">
                            <div class="mb-4">
                                <label for="categoryName" class="block text-sm font-medium text-gray-700 mb-2">Nom de la catégorie</label>
                                <input type="text" id="categoryName" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                            </div>
                            <div class="mb-4">
                                <label for="categoryIcon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <select id="categoryIcon" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                                    <option value="🎬">🎬 Streaming</option>
                                    <option value="💻">💻 Logiciels</option>
                                    <option value="🎓">🎓 Formations</option>
                                    <option value="🎁">🎁 Gift Cards</option>
                                    <option value="🔑">🔑 Comptes</option>
                                    <option value="📱">📱 Applications</option>
                                    <option value="🎮">🎮 Jeux</option>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label for="parentCategory" class="block text-sm font-medium text-gray-700 mb-2">Catégorie parente (optionnel)</label>
                                <select id="parentCategory" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                                    <option value="">Catégorie principale</option>
                                </select>
                            </div>
                            <div class="flex gap-3">
                                <button type="button" onclick="closeCategoryModal()" class="flex-1 px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50">Annuler</button>
                                <button type="submit" class="flex-1 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">Créer</button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Modal Vente Produit -->
                <div id="saleModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50" style="backdrop-filter: blur(5px);">
                    <div class="bg-white rounded-lg p-6 w-96 max-w-90vw">
                        <h3 class="text-xl font-semibold mb-4 flex items-center gap-2">
                            <span>💰</span> Vente Réussie !
                        </h3>
                        <div id="saleContent" class="mb-6">
                            <!-- Le contenu de la vente sera injecté ici -->
                        </div>
                        <div class="flex gap-3">
                            <button onclick="closeSaleModal()" class="flex-1 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">Fermer</button>
                            <button onclick="copyAccountInfo()" class="flex-1 px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600">📋 Copier</button>
                        </div>
                    </div>
                </div>

                <!-- Modal Gestion des Comptes -->
                <div id="accountsModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50" style="backdrop-filter: blur(5px);">
                    <div class="bg-white rounded-lg p-6 w-2/3 max-w-4xl max-h-90vh overflow-y-auto">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-xl font-semibold flex items-center gap-2">
                                <span>🔑</span> Gestion des Comptes
                            </h3>
                            <button onclick="closeAccountsModal()" class="text-gray-500 hover:text-gray-700">✕</button>
                        </div>
                        <div id="accountsContent">
                            <!-- Le contenu sera généré ici -->
                        </div>
                    </div>
                </div>

                <!-- Modal Nouveau Produit -->
                <div id="productModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50" style="backdrop-filter: blur(5px);">
                    <div class="bg-white rounded-lg p-6 w-96 max-w-90vw max-h-90vh overflow-y-auto">
                        <h3 class="text-xl font-semibold mb-4">Nouveau Produit Digital</h3>
                        <form id="productForm">
                            <div class="mb-4">
                                <label for="productName" class="block text-sm font-medium text-gray-700 mb-2">Nom du produit</label>
                                <input type="text" id="productName" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                            </div>
                            <div class="mb-4">
                                <label for="productType" class="block text-sm font-medium text-gray-700 mb-2">Type de produit</label>
                                <select id="productType" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                                    <option value="">Sélectionner un type</option>
                                    <option value="abonnement">🎬 Abonnement</option>
                                    <option value="licence">💻 Licence</option>
                                    <option value="formation">🎓 Formation</option>
                                    <option value="giftcard">🎁 Gift Card</option>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label for="productCategory" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="productCategory" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                                    <option value="">Sélectionner une catégorie</option>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label for="productPrice" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                <input type="number" id="productPrice" step="0.01" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                            </div>
                            <div class="mb-4">
                                <label for="productStock" class="block text-sm font-medium text-gray-700 mb-2">Stock disponible</label>
                                <input type="number" id="productStock" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                            </div>
                            <div class="mb-4">
                                <label for="productDuration" class="block text-sm font-medium text-gray-700 mb-2">Durée/Validité</label>
                                <select id="productDuration" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500">
                                    <option value="1 mois">1 mois</option>
                                    <option value="3 mois">3 mois</option>
                                    <option value="6 mois">6 mois</option>
                                    <option value="1 an">1 an</option>
                                    <option value="2 ans">2 ans</option>
                                    <option value="À vie">À vie</option>
                                    <option value="Variable">Variable</option>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label for="productDescription" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="productDescription" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"></textarea>
                            </div>
                            <div class="flex gap-3">
                                <button type="button" onclick="closeProductModal()" class="flex-1 px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50">Annuler</button>
                                <button type="submit" class="flex-1 px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600">Créer</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Orders Section -->
            <div id="orders" class="section hidden p-8">
                <div class="max-w-4xl mx-auto">
                    <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
                        <h1 class="text-2xl font-bold text-gray-800 mb-4">🧪 Gestion des Commandes</h1>
                        
                        <div class="space-y-4">
                            <div class="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                                <h3 class="font-semibold text-blue-800 mb-2">Informations de debug</h3>
                                <p class="text-sm"><strong>Commandes en mémoire:</strong> <span id="debug-count" class="text-blue-600">-</span></p>
                                <p class="text-sm"><strong>LocalStorage:</strong> <span id="debug-storage" class="text-blue-600">-</span></p>
                            </div>

                            <div class="flex gap-3">
                                <button onclick="addTestOrderManually()" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                                    ➕ Ajouter une commande test
                                </button>
                                <button onclick="clearOrdersManually()" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">
                                    🗑️ Effacer toutes les commandes
                                </button>
                                <button onclick="loadOrdersManually()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                                    🔄 Recharger
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white rounded-xl shadow-lg">
                        <div class="p-6 border-b border-gray-200">
                            <h2 class="text-xl font-semibold">📋 Liste des Commandes</h2>
                        </div>
                        
                        <div id="orders-container" class="divide-y divide-gray-200">
                            <!-- Les commandes apparaîtront ici -->
                        </div>
                    </div>
                </div>

                <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Clients Section -->
            <div id="clients" class="section hidden p-8">
                <div class="mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">Gestion Clients</h2>
                    <p class="text-gray-600 mt-2">Base de données clients et historique</p>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <!-- Add New Client -->
                    <div class="bg-white rounded-xl shadow-sm p-6">
                        <h3 class="text-xl font-semibold mb-4">Nouveau Client</h3>
                        
                        <form onsubmit="addClient(event)" class="space-y-4">
                            <div>
                                <label for="client-name-new" class="block text-sm font-medium text-gray-700 mb-2">Nom complet</label>
                                <input type="text" id="client-name-new" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            </div>

                            <div>
                                <label for="client-email" class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                                <input type="email" id="client-email" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            </div>

                            <div>
                                <label for="client-phone" class="block text-sm font-medium text-gray-700 mb-2">Téléphone</label>
                                <input type="tel" id="client-phone" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            </div>

                            <div>
                                <label for="client-company" class="block text-sm font-medium text-gray-700 mb-2">Entreprise (optionnel)</label>
                                <input type="text" id="client-company" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            </div>

                            <button type="submit" class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                                Ajouter Client
                            </button>
                        </form>
                    </div>

                    <!-- Client List -->
                    <div class="lg:col-span-2 bg-white rounded-xl shadow-sm p-6">
                        <div class="flex justify-between items-center mb-6">
                            <h3 class="text-xl font-semibold">Liste des Clients</h3>
                            <input type="text" placeholder="Rechercher un client..." class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        </div>

                        <div class="space-y-4">
                            <div class="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <p class="font-semibold">Marie Dubois</p>
                                        <p class="text-sm text-gray-600">marie.dubois@email.com</p>
                                        <p class="text-sm text-gray-500">+33 6 12 34 56 78</p>
                                    </div>
                                    <div class="text-right">
                                        <p class="text-sm font-medium text-green-600">3 commandes</p>
                                        <p class="text-sm text-gray-500">Total: 290€</p>
                                    </div>
                                </div>
                            </div>

                            <div class="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <p class="font-semibold">Pierre Martin</p>
                                        <p class="text-sm text-gray-600">pierre.martin@restaurant.fr</p>
                                        <p class="text-sm text-gray-500">+33 6 98 76 54 32</p>
                                        <p class="text-xs text-blue-600">Restaurant Le Gourmet</p>
                                    </div>
                                    <div class="text-right">
                                        <p class="text-sm font-medium text-green-600">2 commandes</p>
                                        <p class="text-sm text-gray-500">Total: 650€</p>
                                    </div>
                                </div>
                            </div>

                            <div class="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <p class="font-semibold">Sophie Laurent</p>
                                        <p class="text-sm text-gray-600">sophie.laurent@gmail.com</p>
                                        <p class="text-sm text-gray-500">+33 7 11 22 33 44</p>
                                    </div>
                                    <div class="text-right">
                                        <p class="text-sm font-medium text-green-600">5 commandes</p>
                                        <p class="text-sm text-gray-500">Total: 125€</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- New Service Modal for Branding -->
                <div id="new-service-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
                    <div class="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div class="p-6 border-b border-gray-200">
                            <div class="flex justify-between items-center">
                                <h3 class="text-2xl font-bold text-gray-800">Nouveau Service</h3>
                                <button onclick="hideNewServiceModal()" class="text-gray-500 hover:text-gray-700 text-2xl">×</button>
                            </div>
                        </div>
                        
                        <form onsubmit="createNewService(event)" class="p-6 space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label for="service-name" class="block text-sm font-medium text-gray-700 mb-2">Nom du Service</label>
                                    <input type="text" id="service-name" placeholder="Ex: Logo Design Premium" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>

                                <div>
                                    <label for="service-price" class="block text-sm font-medium text-gray-700 mb-2">Prix (€)</label>
                                    <input type="number" id="service-price" placeholder="150" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                </div>
                            </div>

                            <div>
                                <label for="service-category" class="block text-sm font-medium text-gray-700 mb-2">Catégorie</label>
                                <select id="service-category" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <option value="logo">Logo & Identité</option>
                                    <option value="print">Supports Print</option>
                                    <option value="digital">Digital & Web</option>
                                    <option value="packaging">Packaging</option>
                                    <option value="autre">Autre</option>
                                </select>
                            </div>

                            <div>
                                <label for="service-icon" class="block text-sm font-medium text-gray-700 mb-2">Icône</label>
                                <div class="grid grid-cols-8 gap-3 mb-3">
                                    <button type="button" onclick="selectServiceIcon(this, '🎨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🎨</button>
                                    <button type="button" onclick="selectServiceIcon(this, '💼')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">💼</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📄')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📄</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📱')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📱</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📦')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📦</button>
                                    <button type="button" onclick="selectServiceIcon(this, '📸')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">📸</button>
                                    <button type="button" onclick="selectServiceIcon(this, '🌐')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">🌐</button>
                                    <button type="button" onclick="selectServiceIcon(this, '✨')" class="service-icon-btn p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center text-2xl">✨</button>
                                </div>
                                <input type="hidden" id="selected-service-icon" value="🎨">
                            </div>

                            <div>
                                <label for="service-description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="service-description" rows="3" placeholder="Description détaillée du service..." class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"></textarea>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Livrables Inclus</label>
                                <div id="service-deliverables" class="space-y-2">
                                    <div class="flex items-center space-x-2">
                                        <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                                        <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                                    </div>
                                </div>
                                <button type="button" onclick="addServiceDeliverable()" class="mt-2 text-blue-600 hover:text-blue-800 text-sm">+ Ajouter un livrable</button>
                            </div>

                            <div class="flex space-x-4 pt-6 border-t">
                                <button type="button" onclick="hideNewServiceModal()" class="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button type="submit" class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                                    Créer le Service
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Global variables
        let cart = [];
        let cartTotal = 0;
        let selectedServices = [];
        let draggedCategory = null;

        // Centralized orders storage
        let allOrders = JSON.parse(localStorage.getItem('all_orders') || '[]');
        
        // Initialize with sample orders if empty
        if (allOrders.length === 0) {
            allOrders = [
                {
                    id: '#POS-001',
                    name: 'Netflix Premium',
                    description: 'Paiement: Espèces',
                    client: 'Marie Dubois',
                    price: 15,
                    status: 'completed',
                    date: new Date().toISOString(),
                    type: 'POS',
                    icon: '🎬'
                },
                {
                    id: '#SMM-12345',
                    name: 'Instagram Likes Premium',
                    description: '5000 unités - https://instagram.com/example',
                    client: 'Pierre Martin',
                    price: 25.50,
                    status: 'Pending',
                    date: new Date(Date.now() - 3600000).toISOString(),
                    type: 'SMM',
                    icon: '📱'
                },
                {
                    id: '#POS-002',
                    name: 'Adobe CC',
                    description: 'Paiement: Carte bancaire',
                    client: 'Sophie Laurent',
                    price: 35,
                    status: 'completed',
                    date: new Date(Date.now() - 7200000).toISOString(),
                    type: 'POS',
                    icon: '🎨'
                }
            ];
            localStorage.setItem('all_orders', JSON.stringify(allOrders));
        }
        
        // Function to save order to centralized storage
        function saveOrder(orderData) {
            allOrders.push(orderData);
            localStorage.setItem('all_orders', JSON.stringify(allOrders));
            updateOrdersDisplay();
        }
        
        // Force reload orders - from test-orders.html
        function forceReloadOrders() {
            console.log('Force reloading orders...');
            const stored = localStorage.getItem('all_orders');
            console.log('LocalStorage content:', stored);
            
            if (stored) {
                try {
                    allOrders = JSON.parse(stored);
                    console.log('Loaded orders:', allOrders);
                } catch (e) {
                    console.error('Error parsing orders:', e);
                    allOrders = [];
                }
            } else {
                console.log('No orders in localStorage');
                allOrders = [];
            }
            
            updateOrdersDisplay();
            updateDebugInfo();
            showNotification('🔄 Commandes rechargées: ' + allOrders.length + ' trouvée(s)', 'success');
        }
        
        // Clear all orders
        function clearAllOrders() {
            if (confirm('Êtes-vous sûr de vouloir effacer toutes les commandes ?')) {
                localStorage.removeItem('all_orders');
                allOrders = [];
                updateOrdersDisplay();
                updateDebugInfo();
                showNotification('🗑️ Toutes les commandes ont été effacées', 'success');
            }
        }
        
        // Update debug info
        function updateDebugInfo() {
            const debugCount = document.getElementById('debug-count');
            const debugStorage = document.getElementById('debug-storage');
            
            if (debugCount) debugCount.textContent = allOrders.length;
            
            const stored = localStorage.getItem('all_orders');
            if (debugStorage) debugStorage.textContent = stored ? `${stored.length} caractères` : 'Vide';
        }
        
        // Manual load orders - EXACT COPY FROM test-orders.html
        function loadOrdersManually() {
            const stored = localStorage.getItem('all_orders');
            console.log('LocalStorage content:', stored);
            
            if (stored) {
                try {
                    allOrders = JSON.parse(stored);
                    console.log('Loaded orders:', allOrders);
                } catch (e) {
                    console.error('Error parsing orders:', e);
                    allOrders = [];
                }
            } else {
                console.log('No orders in localStorage');
                allOrders = [];
            }
            
            updateOrdersDisplay();
            updateDebugInfo();
        }
        
        // Add test order manually - EXACT COPY FROM test-orders.html
        function addTestOrderManually() {
            const testOrder = {
                id: '#TEST-' + Date.now(),
                name: 'Commande Test',
                description: 'Commande de test créée à ' + new Date().toLocaleTimeString(),
                client: 'Client Test',
                price: Math.floor(Math.random() * 100) + 10,
                status: 'completed',
                date: new Date().toISOString(),
                type: 'TEST',
                icon: '🧪'
            };
            
            allOrders.push(testOrder);
            localStorage.setItem('all_orders', JSON.stringify(allOrders));
            
            console.log('Test order added:', testOrder);
            loadOrdersManually();
            
            showNotification('✅ Commande test ajoutée !', 'success');
        }
        
        // Manual clear orders - EXACT COPY FROM test-orders.html
        function clearOrdersManually() {
            if (confirm('Êtes-vous sûr de vouloir effacer toutes les commandes ?')) {
                localStorage.removeItem('all_orders');
                allOrders = [];
                loadOrdersManually();
                alert('🗑️ Toutes les commandes ont été effacées');
            }
        }
        
        // Function to update orders display - CODE TESTÉ ET FONCTIONNEL  
        function updateOrdersDisplay() {
            console.log('=== updateOrdersDisplay called ===');
            console.log('Total orders in allOrders:', allOrders.length);
            
            const ordersContainer = document.getElementById('orders-container');
            const ordersTotalCount = document.getElementById('orders-total-count');
            
            if (!ordersContainer) {
                console.error('Orders container not found!');
                return;
            }
            
            console.log('Container found!');
            
            // ALWAYS update the count
            if (ordersTotalCount) {
                ordersTotalCount.textContent = allOrders.length;
                console.log('Updated count to:', allOrders.length);
            }
            
            // Clear container
            ordersContainer.innerHTML = '';
            console.log('Container cleared');
            
            if (allOrders.length === 0) {
                ordersContainer.innerHTML = `
                    <div class="p-8 text-center text-gray-500">
                        <div class="text-4xl mb-3">📋</div>
                        <p>Aucune commande trouvée</p>
                        <p class="text-sm mt-2">Créez une vente POS pour tester le système</p>
                    </div>
                `;
                console.log('No orders - displayed empty message');
                return;
            }
            
            // Sort orders by date (most recent first)
            const sortedOrders = [...allOrders].sort((a, b) => {
                const dateA = new Date(a.date);
                const dateB = new Date(b.date);
                return dateB - dateA;
            });
            
            console.log('Sorted', sortedOrders.length, 'orders, now displaying...');
            
            // Display each order
            sortedOrders.forEach((order, index) => {
                console.log(`Creating div for order ${index + 1}:`, order.id);
                
                const orderDiv = document.createElement('div');
                orderDiv.className = 'p-6 hover:bg-gray-50 border-b border-gray-100';
                
                const statusColors = {
                    'pending': 'bg-yellow-100 text-yellow-800',
                    'processing': 'bg-blue-100 text-blue-800',
                    'completed': 'bg-green-100 text-green-800',
                    'Pending': 'bg-yellow-100 text-yellow-800',
                    'In progress': 'bg-blue-100 text-blue-800',
                    'Completed': 'bg-green-100 text-green-800',
                    'Partial': 'bg-orange-100 text-orange-800',
                    'Canceled': 'bg-red-100 text-red-800'
                };
                
                const statusColor = statusColors[order.status] || 'bg-gray-100 text-gray-800';
                const orderDate = new Date(order.date).toLocaleString('fr-FR');
                
                orderDiv.innerHTML = `
                    <div class="flex justify-between items-start">
                        <div class="flex-1">
                            <div class="flex items-center space-x-4">
                                <span class="text-2xl">${order.icon || '📦'}</span>
                                <div>
                                    <p class="font-semibold">${order.id} - ${order.name}</p>
                                    <p class="text-sm text-gray-600">${order.description || ''}</p>
                                    <p class="text-sm text-gray-500">Client: ${order.client} • ${orderDate}</p>
                                    ${order.type ? `<span class="inline-block text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded mt-1">${order.type}</span>` : ''}
                                </div>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="font-semibold text-green-600">${order.price}€</p>
                            <span class="${statusColor} px-2 py-1 rounded-full text-xs">${order.status}</span>
                        </div>
                    </div>
                `;
                
                ordersContainer.appendChild(orderDiv);
            });
            
            console.log('✅ All orders displayed successfully!');
            console.log('Final container children count:', ordersContainer.children.length);
        }

        // Show section function
        function showSection(sectionId, clickEvent) {
            console.log('=== SHOWING SECTION:', sectionId, '===');
            
            try {
                // Hide all sections
                const sections = document.querySelectorAll('.section');
                sections.forEach(section => section.classList.add('hidden'));
                
                // Show selected section
                const targetSection = document.getElementById(sectionId);
                if (!targetSection) {
                    console.error('Section not found:', sectionId);
                    return;
                }
                targetSection.classList.remove('hidden');
            
                // Update sidebar active state
                const sidebarItems = document.querySelectorAll('.sidebar-item');
                sidebarItems.forEach(item => item.classList.remove('bg-white', 'bg-opacity-20'));
                if (clickEvent && clickEvent.target) {
                    clickEvent.target.classList.add('bg-white', 'bg-opacity-20');
                }
                
                // Force update orders display when showing orders section
                if (sectionId === 'orders') {
                console.log('Orders section opened - forcing update');
                console.log('Current allOrders:', allOrders);
                
                // Force reload from localStorage
                const stored = localStorage.getItem('all_orders');
                console.log('LocalStorage content:', stored);
                
                if (stored) {
                    allOrders = JSON.parse(stored);
                    console.log('Reloaded', allOrders.length, 'orders from storage');
                }
                
                // Force display update with a small delay to ensure DOM is ready
                setTimeout(() => {
                    console.log('Calling updateOrdersDisplay...');
                    updateOrdersDisplay();
                    updateDebugInfo();
                }, 100);
                }
            } catch (error) {
                console.error('Error in showSection:', error);
                showNotification('❌ Erreur lors du changement de section', 'error');
            }
        }

        // POS Functions
        function addToCart(productName, price) {
            cart.push({ name: productName, price: price });
            updateCartDisplay();
        }

        function updateCartDisplay() {
            const cartItems = document.getElementById('cart-items');
            const cartTotalElement = document.getElementById('cart-total');
            
            if (cart.length === 0) {
                cartItems.innerHTML = '<p class="text-gray-500 text-center py-8">Panier vide</p>';
                cartTotal = 0;
            } else {
                cartItems.innerHTML = cart.map((item, index) => `
                    <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span class="font-medium">${item.name}</span>
                        <div class="flex items-center space-x-2">
                            <span class="font-bold text-green-600">${item.price}€</span>
                            <button onclick="removeFromCart(${index})" class="text-red-500 hover:text-red-700">
                                <span class="text-sm">✕</span>
                            </button>
                        </div>
                    </div>
                `).join('');
                
                cartTotal = cart.reduce((sum, item) => sum + item.price, 0);
            }
            
            cartTotalElement.textContent = `${cartTotal}€`;
        }

        function removeFromCart(index) {
            cart.splice(index, 1);
            updateCartDisplay();
        }

        function clearCart() {
            cart = [];
            updateCartDisplay();
        }

        function processPayment() {
            const clientName = document.getElementById('client-name').value;
            const paymentMethod = document.getElementById('payment-method').value;
            
            if (!clientName || !paymentMethod || cart.length === 0) {
                showNotification('Veuillez remplir tous les champs et ajouter des produits au panier', 'error');
                return;
            }
            
            // Create order for each cart item
            cart.forEach((item, index) => {
                const orderData = {
                    id: `#POS-${Date.now()}-${index}`,
                    name: item.name,
                    description: `Paiement: ${paymentMethod}`,
                    client: clientName,
                    price: item.price,
                    status: 'completed',
                    date: new Date().toISOString(),
                    type: 'POS',
                    icon: item.name.includes('SMM') ? '📱' : 
                          item.name.includes('Logo') ? '🎨' :
                          item.name.includes('Site') ? '🌐' :
                          item.name.includes('Netflix') ? '🎬' :
                          item.name.includes('IPTV') ? '📺' :
                          item.name.includes('Adobe') ? '🎨' : '📦'
                };
                saveOrder(orderData);
            });
            
            // Simulate payment processing
            showNotification(`✅ Vente de ${cartTotal}€ enregistrée pour ${clientName}`, 'success');
            showNotification(`📋 ${cart.length} commande(s) ajoutée(s) à Gestion des Commandes`, 'info');
            
            // Clear form and cart
            document.getElementById('client-name').value = '';
            document.getElementById('payment-method').value = '';
            clearCart();
        }

        // SMM Functions
        function toggleSMMDropdown() {
            const submenu = document.getElementById('smm-submenu');
            const arrow = document.getElementById('smm-arrow');
            
            if (submenu.classList.contains('hidden')) {
                submenu.classList.remove('hidden');
                arrow.style.transform = 'rotate(180deg)';
            } else {
                submenu.classList.add('hidden');
                arrow.style.transform = 'rotate(0deg)';
            }
        }

        function showSMMPage(pageId) {
            // Hide all sections first
            const sections = document.querySelectorAll('.section');
            sections.forEach(section => section.classList.add('hidden'));
            
            // Show the specific SMM page
            document.getElementById(`smm-${pageId}`).classList.remove('hidden');
            
            // Update SMM submenu active state
            const smmSubItems = document.querySelectorAll('.smm-sub-item');
            smmSubItems.forEach(item => {
                item.classList.remove('bg-white', 'bg-opacity-10');
            });
            event.target.classList.add('bg-white', 'bg-opacity-10');
            
            // Update main sidebar active state
            const sidebarItems = document.querySelectorAll('.sidebar-item');
            sidebarItems.forEach(item => item.classList.remove('bg-white', 'bg-opacity-20'));
            document.querySelector('.smm-dropdown .sidebar-item').classList.add('bg-white', 'bg-opacity-20');
        }

        function createSMMOrder(event) {
            event.preventDefault();
            
            const platform = document.getElementById('smm-platform').value;
            const service = document.getElementById('smm-service').value;
            const quantity = document.getElementById('smm-quantity').value;
            const url = document.getElementById('smm-url').value;
            const client = document.getElementById('smm-client').value;
            
            if (!platform || !service || !quantity || !url || !client) {
                showNotification('Veuillez remplir tous les champs', 'error');
                return;
            }
            
            showNotification(`Commande SMM lancée: ${quantity} ${service} pour ${platform}`, 'success');
            
            // Clear form
            event.target.reset();
        }

        // Add Menu Functions
        function toggleAddMenu() {
            const menu = document.getElementById('add-menu');
            menu.classList.toggle('hidden');
        }

        function hideAddMenu() {
            document.getElementById('add-menu').classList.add('hidden');
        }

        function showNewServiceModal() {
            const modal = document.getElementById('new-service-modal');
            if (modal) {
                modal.classList.remove('hidden');
                
                // Reset form
                const form = modal.querySelector('form');
                if (form) {
                    form.reset();
                }
                
                // Reset selected icon
                const iconInput = document.getElementById('selected-service-icon');
                if (iconInput) {
                    iconInput.value = '🎨';
                }
                
                // Reset icon selection
                const iconButtons = modal.querySelectorAll('.service-icon-btn');
                iconButtons.forEach(btn => {
                    btn.classList.remove('border-blue-500', 'bg-blue-50');
                    btn.classList.add('border-gray-200');
                });
                
                // Select first icon by default
                const firstIconBtn = modal.querySelector('.service-icon-btn');
                if (firstIconBtn) {
                    firstIconBtn.classList.remove('border-gray-200');
                    firstIconBtn.classList.add('border-blue-500', 'bg-blue-50');
                }
                
                // Reset deliverables to one field
                const deliverablesContainer = modal.querySelector('#service-deliverables');
                if (deliverablesContainer) {
                    deliverablesContainer.innerHTML = `
                        <div class="flex items-center space-x-2">
                            <input type="text" placeholder="Ex: Fichiers sources vectoriels" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                            <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                        </div>
                    `;
                }
                
                console.log('Modal de service ouvert');
            } else {
                console.error('Modal new-service-modal non trouvé');
                showNotification('Erreur: impossible d\'ouvrir le modal de service', 'error');
            }
        }

        function hideNewServiceModal() {
            document.getElementById('new-service-modal').classList.add('hidden');
        }

        function selectServiceIcon(button, icon) {
            // Reset all icon buttons
            document.querySelectorAll('.service-icon-btn').forEach(btn => {
                btn.classList.remove('border-blue-500', 'bg-blue-50');
                btn.classList.add('border-gray-200');
            });
            
            // Select clicked button
            button.classList.remove('border-gray-200');
            button.classList.add('border-blue-500', 'bg-blue-50');
            
            // Update hidden input
            document.getElementById('selected-service-icon').value = icon;
        }

        function addServiceDeliverable() {
            const deliverablesContainer = document.getElementById('service-deliverables');
            const newDeliverable = document.createElement('div');
            newDeliverable.className = 'flex items-center space-x-2';
            newDeliverable.innerHTML = `
                <input type="text" placeholder="Ex: Révisions incluses" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                <button type="button" onclick="removeServiceDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
            `;
            deliverablesContainer.appendChild(newDeliverable);
        }

        function removeServiceDeliverable(button) {
            const deliverablesContainer = document.getElementById('service-deliverables');
            if (deliverablesContainer.children.length > 1) {
                button.parentElement.remove();
            }
        }

        function createNewService(event) {
            event.preventDefault();
            
            try {
                const modal = document.getElementById('new-service-modal');
                const serviceName = modal.querySelector('#service-name').value.trim();
                const servicePrice = modal.querySelector('#service-price').value.trim();
                const serviceCategory = modal.querySelector('#service-category').value;
                const serviceIcon = modal.querySelector('#selected-service-icon').value;
                const serviceDescription = modal.querySelector('#service-description').value.trim();
                
                if (!serviceName || !servicePrice || !serviceCategory) {
                    showNotification('Veuillez remplir tous les champs obligatoires (nom, prix, catégorie)', 'error');
                    return;
                }
                
                const priceValue = parseFloat(servicePrice);
                if (isNaN(priceValue) || priceValue <= 0) {
                    showNotification('Veuillez entrer un prix valide', 'error');
                    return;
                }
                
                // Get deliverables
                const deliverableInputs = modal.querySelectorAll('#service-deliverables input');
                const deliverables = Array.from(deliverableInputs)
                    .map(input => input.value.trim())
                    .filter(value => value !== '');
                
                // Add new service to the services selection in project modal
                const servicesGrid = document.querySelector('#new-project-modal .grid.grid-cols-2.md\\:grid-cols-3.gap-3');
                if (servicesGrid) {
                    const serviceId = serviceName.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
                    const newServiceCard = document.createElement('div');
                    newServiceCard.setAttribute('onclick', `toggleService(this, '${serviceId}', ${priceValue})`);
                    newServiceCard.className = 'service-card cursor-pointer p-3 border-2 border-gray-200 rounded-lg hover:border-blue-500 transition-colors text-center';
                    newServiceCard.innerHTML = `
                        <span class="text-2xl block mb-1">${serviceIcon}</span>
                        <p class="text-sm font-medium">${serviceName}</p>
                        <p class="text-xs text-blue-600">${priceValue}€</p>
                    `;
                    servicesGrid.appendChild(newServiceCard);
                }
                
                showNotification(`Service "${serviceName}" créé avec succès! Il est maintenant disponible dans la création de projets.`, 'success');
                hideNewServiceModal();
                
            } catch (error) {
                console.error('Erreur lors de la création du service:', error);
                showNotification('Erreur lors de la création du service', 'error');
            }
        }

        function saveProjectNotes() {
            const notes = document.getElementById('project-notes').value;
            if (notes.trim()) {
                showNotification('Notes sauvegardées avec succès', 'success');
            } else {
                showNotification('Aucune note à sauvegarder', 'info');
            }
        }

        // Service Selection Functions
        function toggleService(element, serviceId, price) {
            const isSelected = element.classList.contains('border-blue-500');
            
            if (isSelected) {
                // Deselect service
                element.classList.remove('border-blue-500', 'bg-blue-50');
                element.classList.add('border-gray-200');
                selectedServices = selectedServices.filter(s => s.id !== serviceId);
            } else {
                // Select service
                element.classList.remove('border-gray-200');
                element.classList.add('border-blue-500', 'bg-blue-50');
                selectedServices.push({ id: serviceId, price: price });
            }
            
            updateServicesTotal();
        }

        function updateServicesTotal() {
            const total = selectedServices.reduce((sum, service) => sum + service.price, 0);
            document.getElementById('services-total').textContent = total + '€';
        }

        // Branding Functions
        function showNewProjectModal() {
            document.getElementById('new-project-modal').classList.remove('hidden');
            // Reset selected services
            selectedServices = [];
            document.querySelectorAll('.service-card').forEach(card => {
                card.classList.remove('border-blue-500', 'bg-blue-50');
                card.classList.add('border-gray-200');
            });
            updateServicesTotal();
        }

        function hideNewProjectModal() {
            document.getElementById('new-project-modal').classList.add('hidden');
            // Reset form
            document.querySelector('#new-project-modal form').reset();
            // Reset deliverables to one field
            const deliverablesContainer = document.getElementById('project-deliverables');
            deliverablesContainer.innerHTML = `
                <div class="flex items-center space-x-2">
                    <input type="text" placeholder="Ex: Logo en format vectoriel" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                    <button type="button" onclick="removeDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
                </div>
            `;
            // Clear file previews
            document.getElementById('reference-preview').innerHTML = '';
            document.getElementById('assets-preview').innerHTML = '';
        }

        function filterBrandingProjects(filter) {
            const projects = document.querySelectorAll('.project-card');
            const filters = document.querySelectorAll('.branding-filter');
            
            // Update filter buttons
            filters.forEach(f => {
                f.classList.remove('bg-white', 'text-gray-800', 'shadow-sm');
                f.classList.add('text-gray-600');
            });
            event.target.classList.remove('text-gray-600');
            event.target.classList.add('bg-white', 'text-gray-800', 'shadow-sm');
            
            // Show/hide projects
            projects.forEach(project => {
                if (filter === 'all' || project.classList.contains(filter)) {
                    project.style.display = 'block';
                } else {
                    project.style.display = 'none';
                }
            });
        }

        function toggleProjectFavorite(button) {
            if (button.textContent === '☆') {
                button.textContent = '★';
                button.classList.add('text-yellow-400');
            } else {
                button.textContent = '☆';
                button.classList.remove('text-yellow-400');
            }
        }

        function openProjectDetails(button) {
            // Get project data from the clicked element
            const projectCard = button.closest('.project-card');
            const projectData = JSON.parse(projectCard.getAttribute('data-project'));
            
            // Populate modal with project data
            document.getElementById('project-details-title').textContent = projectData.name;
            document.getElementById('project-details-client').textContent = `Client: ${projectData.client}`;
            document.getElementById('project-details-status').textContent = projectData.status;
            document.getElementById('project-details-price').textContent = projectData.price + '€';
            document.getElementById('project-details-date').textContent = projectData.date;
            document.getElementById('project-details-deadline').textContent = projectData.deadline || 'Non définie';
            document.getElementById('project-details-description').textContent = projectData.description || 'Aucune description disponible';
            
            // Handle Facebook link
            const facebookSection = document.getElementById('project-facebook-section');
            const facebookLink = document.getElementById('project-facebook-link');
            if (projectData.facebook && projectData.facebook.trim() !== '') {
                facebookSection.classList.remove('hidden');
                facebookLink.href = projectData.facebook;
                facebookLink.textContent = projectData.facebook;
            } else {
                facebookSection.classList.add('hidden');
            }
            
            // Populate services list
            const servicesList = document.getElementById('project-services-list');
            servicesList.innerHTML = '';
            
            if (projectData.services && projectData.services.length > 0) {
                projectData.services.forEach(service => {
                    const serviceEmojis = {
                        'logo': '🎨',
                        'carte-visite': '💼',
                        'flyer': '📄',
                        'identite': '📱',
                        'packaging': '📦',
                        'social-media': '📸'
                    };
                    
                    const serviceDiv = document.createElement('div');
                    serviceDiv.className = 'flex items-center justify-between p-3 bg-blue-50 border border-blue-200 rounded-lg';
                    serviceDiv.innerHTML = `
                        <div class="flex items-center space-x-3">
                            <span class="text-2xl">${serviceEmojis[service.id] || '✨'}</span>
                            <span class="font-medium text-gray-800">${service.name}</span>
                        </div>
                        <span class="font-bold text-blue-600">${service.price}€</span>
                    `;
                    servicesList.appendChild(serviceDiv);
                });
            } else {
                servicesList.innerHTML = '<p class="text-gray-500 text-sm">Aucun service défini</p>';
            }
            
            // Update status styling
            const statusElement = document.getElementById('project-details-status');
            statusElement.className = 'px-3 py-1 rounded-full text-sm font-medium';
            
            switch(projectData.status) {
                case 'En cours':
                    statusElement.classList.add('bg-yellow-100', 'text-yellow-800');
                    break;
                case 'Terminé':
                    statusElement.classList.add('bg-green-100', 'text-green-800');
                    break;
                case 'Modèle':
                    statusElement.classList.add('bg-purple-100', 'text-purple-800');
                    break;
                default:
                    statusElement.classList.add('bg-gray-100', 'text-gray-800');
            }
            
            // Populate sample files for demo
            const filesGrid = document.getElementById('project-files-grid');
            filesGrid.innerHTML = `
                <div class="bg-gray-100 rounded-lg p-4 text-center">
                    <span class="text-2xl block mb-2">🎨</span>
                    <p class="text-xs text-gray-600">logo_v1.ai</p>
                    <p class="text-xs text-gray-500">2.3 MB</p>
                </div>
                <div class="bg-gray-100 rounded-lg p-4 text-center">
                    <span class="text-2xl block mb-2">📄</span>
                    <p class="text-xs text-gray-600">brief_client.pdf</p>
                    <p class="text-xs text-gray-500">1.1 MB</p>
                </div>
                <div class="bg-gray-100 rounded-lg p-4 text-center">
                    <span class="text-2xl block mb-2">🖼️</span>
                    <p class="text-xs text-gray-600">reference.jpg</p>
                    <p class="text-xs text-gray-500">856 KB</p>
                </div>
            `;
            
            document.getElementById('project-details-modal').classList.remove('hidden');
        }

        function hideProjectDetailsModal() {
            document.getElementById('project-details-modal').classList.add('hidden');
        }

        function showProjectMenu(button) {
            const projectCard = button.closest('.project-card');
            
            // Create context menu
            const menu = document.createElement('div');
            menu.className = 'absolute bg-white border border-gray-200 rounded-lg shadow-lg z-50 py-2 min-w-[150px]';
            menu.innerHTML = `
                <button onclick="editProject(this.closest('.project-card') || document.querySelector('.project-card[data-project]'))" class="w-full text-left px-4 py-2 hover:bg-gray-100 text-sm">Modifier</button>
                <button onclick="duplicateProject(this.closest('.project-card') || document.querySelector('.project-card[data-project]'))" class="w-full text-left px-4 py-2 hover:bg-gray-100 text-sm">Dupliquer</button>
                <button onclick="archiveProject(this.closest('.project-card') || document.querySelector('.project-card[data-project]'))" class="w-full text-left px-4 py-2 hover:bg-gray-100 text-sm">Archiver</button>
                <hr class="my-1">
                <button onclick="deleteProject(this.closest('.project-card') || document.querySelector('.project-card[data-project]'))" class="w-full text-left px-4 py-2 hover:bg-gray-100 text-sm text-red-600">Supprimer</button>
            `;
            
            // Store reference to project card in menu
            menu.projectCard = projectCard;
            
            // Position menu
            const rect = button.getBoundingClientRect();
            menu.style.position = 'fixed';
            menu.style.top = rect.bottom + 'px';
            menu.style.left = rect.left + 'px';
            
            document.body.appendChild(menu);
            
            // Update menu buttons to use the stored project card
            menu.querySelectorAll('button').forEach(btn => {
                const originalOnclick = btn.getAttribute('onclick');
                btn.setAttribute('onclick', originalOnclick.replace('this.closest(\'.project-card\') || document.querySelector(\'.project-card[data-project]\')', 'arguments[0]'));
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const funcName = originalOnclick.match(/(\w+)\(/)[1];
                    window[funcName](projectCard);
                    menu.remove();
                });
            });
            
            // Remove menu on click outside
            setTimeout(() => {
                document.addEventListener('click', function removeMenu(e) {
                    if (!menu.contains(e.target)) {
                        menu.remove();
                        document.removeEventListener('click', removeMenu);
                    }
                });
            }, 100);
        }

        function createNewProject(event) {
            event.preventDefault();
            
            const projectName = document.getElementById('project-name').value;
            const projectPrice = document.getElementById('project-price').value;
            const clientName = document.getElementById('client-name-project').value;
            
            if (!projectName || !clientName || selectedServices.length === 0) {
                showNotification('Veuillez remplir le nom du projet, le client et sélectionner au moins un service', 'error');
                return;
            }
            
            // Get first service emoji or default
            const serviceEmojis = {
                'logo': '🎨',
                'carte-visite': '💼',
                'flyer': '📄',
                'identite': '📱',
                'packaging': '📦',
                'social-media': '📸'
            };
            const firstService = selectedServices[0];
            const projectEmoji = serviceEmojis[firstService.id] || '✨';
            const totalPrice = selectedServices.reduce((sum, service) => sum + service.price, 0);
            
            // Create new project card
            const projectsGrid = document.getElementById('branding-projects-grid');
            const newProjectCard = document.createElement('div');
            newProjectCard.className = 'project-card active bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden card-hover transition-all duration-200';
            
            const projectId = 'project-' + Date.now();
            const projectDescription = document.getElementById('project-description').value || 'Nouveau projet créé';
            const projectFacebook = document.getElementById('project-facebook').value || '';
            
            // Create services array for data attribute
            const servicesData = selectedServices.map(service => {
                const serviceNames = {
                    'logo': 'Logo Design',
                    'carte-visite': 'Carte de Visite',
                    'flyer': 'Flyer/Brochure',
                    'identite': 'Identité Complète',
                    'packaging': 'Packaging',
                    'social-media': 'Kit Réseaux Sociaux'
                };
                return {
                    id: service.id,
                    name: serviceNames[service.id] || 'Service personnalisé',
                    price: service.price
                };
            });
            
            const projectDataObj = {
                id: projectId,
                name: projectName,
                client: clientName,
                services: servicesData,
                price: totalPrice,
                status: 'En cours',
                date: new Date().toLocaleDateString('fr-FR'),
                description: projectDescription,
                facebook: projectFacebook
            };
            
            newProjectCard.setAttribute('data-project', JSON.stringify(projectDataObj));
            
            newProjectCard.innerHTML = `
                <div class="relative">
                    <div class="h-48 bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                        <span class="text-6xl">${projectEmoji}</span>
                    </div>
                    <div class="absolute top-3 right-3">
                        <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">Nouveau</span>
                    </div>
                    <div class="absolute top-3 left-3">
                        <button onclick="toggleProjectFavorite(this)" class="text-white hover:text-yellow-300 text-xl">☆</button>
                    </div>
                </div>
                <div class="p-4">
                    <h3 class="font-semibold text-gray-800 mb-1">${projectName}</h3>
                    <p class="text-sm text-gray-600 mb-2">Client: ${clientName}</p>
                    <div class="flex justify-between items-center text-sm text-gray-500 mb-3">
                        <span>Créé: ${new Date().toLocaleDateString('fr-FR')}</span>
                        <span class="font-medium text-green-600">${totalPrice}€</span>
                    </div>
                    <div class="flex space-x-2">
                        <button onclick="openProjectDetails(this)" class="flex-1 bg-blue-600 text-white py-2 px-3 rounded-lg text-sm hover:bg-blue-700 transition-colors">
                            Ouvrir
                        </button>
                        <button onclick="showProjectMenu(this)" class="bg-gray-100 text-gray-600 py-2 px-3 rounded-lg text-sm hover:bg-gray-200 transition-colors">
                            ⋯
                        </button>
                    </div>
                </div>
            `;
            
            // Insert at the beginning
            projectsGrid.insertBefore(newProjectCard, projectsGrid.firstChild);
            
            showNotification(`Projet "${projectName}" créé avec succès!`, 'success');
            hideNewProjectModal();
        }

        function addService() {
            const servicesContainer = document.getElementById('project-services');
            const newService = document.createElement('div');
            newService.className = 'flex items-center space-x-2';
            newService.innerHTML = `
                <select class="flex-1 p-2 border border-gray-300 rounded-lg text-sm" onchange="updateServicePrice(this)">
                    <option value="">Sélectionner un service</option>
                    <option value="logo" data-price="150">Logo Design - 150€</option>
                    <option value="carte-visite" data-price="50">Carte de Visite - 50€</option>
                    <option value="flyer" data-price="80">Flyer/Brochure - 80€</option>
                    <option value="identite" data-price="350">Identité Complète - 350€</option>
                    <option value="packaging" data-price="200">Packaging - 200€</option>
                    <option value="social-media" data-price="120">Kit Réseaux Sociaux - 120€</option>
                    <option value="autre" data-price="0">Autre (prix personnalisé)</option>
                </select>
                <input type="number" placeholder="Prix" class="w-20 p-2 border border-gray-300 rounded-lg text-sm" onchange="calculateTotal()">
                <button type="button" onclick="removeService(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
            `;
            servicesContainer.appendChild(newService);
        }

        function removeService(button) {
            const servicesContainer = document.getElementById('project-services');
            if (servicesContainer.children.length > 1) {
                button.parentElement.remove();
                calculateTotal();
            }
        }

        function updateServicePrice(select) {
            const priceInput = select.parentElement.querySelector('input[type="number"]');
            const selectedOption = select.options[select.selectedIndex];
            const price = selectedOption.getAttribute('data-price');
            
            if (price && price !== '0') {
                priceInput.value = price;
            } else {
                priceInput.value = '';
            }
            
            calculateTotal();
        }

        function calculateTotal() {
            const servicesContainer = document.getElementById('project-services');
            const priceInputs = servicesContainer.querySelectorAll('input[type="number"]');
            let total = 0;
            
            priceInputs.forEach(input => {
                const value = parseFloat(input.value) || 0;
                total += value;
            });
            
            document.getElementById('total-price').textContent = total + '€';
        }

        function addDeliverable() {
            const deliverablesContainer = document.getElementById('project-deliverables');
            const newDeliverable = document.createElement('div');
            newDeliverable.className = 'flex items-center space-x-2';
            newDeliverable.innerHTML = `
                <input type="text" placeholder="Ex: Fichiers sources" class="flex-1 p-2 border border-gray-300 rounded-lg text-sm">
                <button type="button" onclick="removeDeliverable(this)" class="text-red-500 hover:text-red-700 px-2">×</button>
            `;
            deliverablesContainer.appendChild(newDeliverable);
        }

        function removeDeliverable(button) {
            const deliverablesContainer = document.getElementById('project-deliverables');
            if (deliverablesContainer.children.length > 1) {
                button.parentElement.remove();
            }
        }

        function handleFileUpload(input, previewId) {
            const preview = document.getElementById(previewId);
            const files = Array.from(input.files);
            
            files.forEach(file => {
                const fileDiv = document.createElement('div');
                fileDiv.className = 'bg-gray-100 rounded-lg p-3 text-center relative';
                
                const fileIcon = file.type.startsWith('image/') ? '🖼️' : 
                                file.name.endsWith('.pdf') ? '📄' : 
                                file.name.endsWith('.ai') ? '🎨' : 
                                file.name.endsWith('.psd') ? '🎨' : '📁';
                
                fileDiv.innerHTML = `
                    <span class="text-2xl block mb-1">${fileIcon}</span>
                    <p class="text-xs text-gray-600 truncate">${file.name}</p>
                    <p class="text-xs text-gray-500">${(file.size / 1024 / 1024).toFixed(1)} MB</p>
                    <button onclick="this.parentElement.remove()" class="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-5 h-5 text-xs">×</button>
                `;
                
                preview.appendChild(fileDiv);
            });
        }

        function handleProjectFileUpload(input) {
            const filesGrid = document.getElementById('project-files-grid');
            const files = Array.from(input.files);
            
            files.forEach(file => {
                const fileDiv = document.createElement('div');
                fileDiv.className = 'bg-gray-100 rounded-lg p-4 text-center relative';
                
                const fileIcon = file.type.startsWith('image/') ? '🖼️' : 
                                file.name.endsWith('.pdf') ? '📄' : 
                                file.name.endsWith('.ai') ? '🎨' : 
                                file.name.endsWith('.psd') ? '🎨' : '📁';
                
                fileDiv.innerHTML = `
                    <span class="text-2xl block mb-2">${fileIcon}</span>
                    <p class="text-xs text-gray-600 truncate">${file.name}</p>
                    <p class="text-xs text-gray-500">${(file.size / 1024 / 1024).toFixed(1)} MB</p>
                    <button onclick="this.parentElement.remove()" class="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-5 h-5 text-xs">×</button>
                `;
                
                filesGrid.appendChild(fileDiv);
            });
            
            showNotification(`${files.length} fichier(s) ajouté(s) au projet`, 'success');
        }

        function updateProjectStatus(status) {
            const statusMap = {
                'completed': { text: 'Terminé', class: 'bg-green-100 text-green-800' },
                'revision': { text: 'En révision', class: 'bg-yellow-100 text-yellow-800' }
            };
            
            showNotification(`Projet marqué comme ${statusMap[status].text}`, 'success');
        }

        function sendProjectToClient() {
            showNotification('Projet envoyé au client par email', 'success');
        }

        function duplicateProject(projectCard) {
            try {
                if (projectCard) {
                    const projectData = JSON.parse(projectCard.getAttribute('data-project'));
                    
                    // Create new project data with modified name
                    const newProjectData = {
                        ...projectData,
                        id: 'project-' + Date.now(),
                        name: projectData.name + ' (Copie)',
                        date: new Date().toLocaleDateString('fr-FR'),
                        status: 'En cours'
                    };
                    
                    // Clone the project card
                    const newProjectCard = projectCard.cloneNode(true);
                    newProjectCard.setAttribute('data-project', JSON.stringify(newProjectData));
                    
                    // Update the displayed name
                    const nameElement = newProjectCard.querySelector('h3');
                    if (nameElement) {
                        nameElement.textContent = newProjectData.name;
                    }
                    
                    // Update the date
                    const dateElements = newProjectCard.querySelectorAll('.text-gray-500');
                    dateElements.forEach(element => {
                        if (element.textContent.includes('Démarré:') || element.textContent.includes('Créé:')) {
                            element.textContent = 'Créé: ' + newProjectData.date;
                        }
                    });
                    
                    // Update status badge
                    const statusElement = newProjectCard.querySelector('.absolute.top-3.right-3 span');
                    if (statusElement) {
                        statusElement.textContent = 'En cours';
                        statusElement.className = 'bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium';
                    }
                    
                    // Reset favorite status
                    const favoriteButton = newProjectCard.querySelector('.absolute.top-3.left-3 button');
                    if (favoriteButton) {
                        favoriteButton.textContent = '☆';
                        favoriteButton.classList.remove('text-yellow-400');
                    }
                    
                    // Insert after original project
                    projectCard.parentNode.insertBefore(newProjectCard, projectCard.nextSibling);
                    
                    showNotification('Projet dupliqué avec succès', 'success');
                } else {
                    showNotification('Erreur: projet non trouvé', 'error');
                }
            } catch (error) {
                showNotification('Erreur lors de la duplication', 'error');
                console.error('Duplicate project error:', error);
            }
        }

        function useTemplate(templateId) {
            showNotification('Modèle appliqué au nouveau projet', 'success');
        }

        function editProject(projectCard) {
            try {
                // Get project data
                const projectData = JSON.parse(projectCard.getAttribute('data-project'));
                
                // Pre-fill the new project modal with existing data
                document.getElementById('project-name').value = projectData.name;
                document.getElementById('client-name-project').value = projectData.client;
                document.getElementById('project-price').value = projectData.price;
                document.getElementById('project-description').value = projectData.description || '';
                document.getElementById('project-facebook').value = projectData.facebook || '';
                
                // Pre-select services if they exist
                if (projectData.services && projectData.services.length > 0) {
                    selectedServices = projectData.services.map(service => ({
                        id: service.id,
                        price: service.price
                    }));
                    
                    // Update visual selection
                    document.querySelectorAll('.service-card').forEach(card => {
                        card.classList.remove('border-blue-500', 'bg-blue-50');
                        card.classList.add('border-gray-200');
                    });
                    
                    projectData.services.forEach(service => {
                        const serviceCard = document.querySelector(`[onclick*="${service.id}"]`);
                        if (serviceCard) {
                            serviceCard.classList.remove('border-gray-200');
                            serviceCard.classList.add('border-blue-500', 'bg-blue-50');
                        }
                    });
                    
                    updateServicesTotal();
                }
                
                // Show modal
                showNewProjectModal();
                
                showNotification('Éditeur de projet ouvert avec données pré-remplies', 'info');
            } catch (error) {
                showNotification('Erreur lors de l\'ouverture de l\'éditeur', 'error');
                console.error('Edit project error:', error);
            }
        }

        function archiveProject(projectCard) {
            try {
                if (projectCard) {
                    projectCard.style.opacity = '0.5';
                    const statusElement = projectCard.querySelector('.absolute.top-3.right-3 span');
                    if (statusElement) {
                        statusElement.textContent = 'Archivé';
                        statusElement.className = 'bg-gray-100 text-gray-800 px-2 py-1 rounded-full text-xs font-medium';
                    }
                    
                    // Update project data
                    const projectData = JSON.parse(projectCard.getAttribute('data-project'));
                    projectData.status = 'Archivé';
                    projectCard.setAttribute('data-project', JSON.stringify(projectData));
                }
                showNotification('Projet archivé avec succès', 'success');
            } catch (error) {
                showNotification('Erreur lors de l\'archivage', 'error');
                console.error('Archive project error:', error);
            }
        }

        function deleteProject(projectCard) {
            try {
                if (projectCard) {
                    // Create custom confirmation dialog
                    const confirmDialog = document.createElement('div');
                    confirmDialog.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4';
                    confirmDialog.innerHTML = `
                        <div class="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
                            <h3 class="text-lg font-semibold text-gray-800 mb-4">Confirmer la suppression</h3>
                            <p class="text-gray-600 mb-6">Êtes-vous sûr de vouloir supprimer ce projet ? Cette action est irréversible.</p>
                            <div class="flex space-x-4">
                                <button onclick="this.closest('.fixed').remove()" class="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition-colors">
                                    Annuler
                                </button>
                                <button onclick="confirmDeleteProject(); this.closest('.fixed').remove()" class="flex-1 bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 transition-colors">
                                    Supprimer
                                </button>
                            </div>
                        </div>
                    `;
                    
                    // Store project card reference
                    confirmDialog.projectToDelete = projectCard;
                    
                    // Add confirm function
                    window.confirmDeleteProject = function() {
                        confirmDialog.projectToDelete.remove();
                        showNotification('Projet supprimé avec succès', 'success');
                        delete window.confirmDeleteProject;
                    };
                    
                    document.body.appendChild(confirmDialog);
                }
            } catch (error) {
                showNotification('Erreur lors de la suppression', 'error');
                console.error('Delete project error:', error);
            }
        }

        // Website Functions
        function startWebProject(type) {
            const projectTypes = {
                'vitrine': 'Site Vitrine',
                'ecommerce': 'Boutique en Ligne'
            };
            
            showNotification(`Nouveau projet ${projectTypes[type]} créé`, 'success');
        }

        // Digital Products Functions
        function filterProducts(platform) {
            const products = document.querySelectorAll('.product-card');
            const filters = document.querySelectorAll('.platform-filter');
            
            // Update filter buttons
            filters.forEach(filter => filter.classList.remove('bg-blue-600', 'text-white'));
            event.target.classList.add('bg-blue-600', 'text-white');
            
            // Show/hide products
            products.forEach(product => {
                if (platform === 'all' || product.classList.contains(platform)) {
                    product.style.display = 'block';
                } else {
                    product.style.display = 'none';
                }
            });
        }

        function sellDigitalProduct(productName, price) {
            showNotification(`${productName} vendu pour ${price}€`, 'success');
        }

        // Orders Functions
        function filterOrders(status) {
            const filters = document.querySelectorAll('.order-filter');
            
            filters.forEach(filter => {
                filter.classList.remove('bg-blue-600', 'text-white');
                filter.classList.add('bg-gray-200', 'text-gray-700');
            });
            
            event.target.classList.remove('bg-gray-200', 'text-gray-700');
            event.target.classList.add('bg-blue-600', 'text-white');
            
            showNotification(`Filtrage des commandes: ${status}`, 'info');
        }

        // Client Functions
        function addClient(event) {
            event.preventDefault();
            
            try {
                const name = document.getElementById('client-name-new').value.trim();
                const email = document.getElementById('client-email').value.trim();
                const phone = document.getElementById('client-phone').value.trim();
                const company = document.getElementById('client-company').value.trim();
                
                if (!name || !email || !phone) {
                    showNotification('Veuillez remplir les champs obligatoires (nom, email, téléphone)', 'error');
                    return;
                }
                
                // Validate email format
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(email)) {
                    showNotification('Veuillez entrer un email valide', 'error');
                    return;
                }
                
                // Find the clients list container
                const clientsSection = document.getElementById('clients');
                const clientsList = clientsSection.querySelector('.lg\\:col-span-2 .space-y-4');
                
                if (!clientsList) {
                    showNotification('Erreur: impossible de trouver la liste des clients', 'error');
                    return;
                }
                
                // Create new client element
                const newClientDiv = document.createElement('div');
                newClientDiv.className = 'border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer';
                newClientDiv.innerHTML = `
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="font-semibold">${name}</p>
                            <p class="text-sm text-gray-600">${email}</p>
                            <p class="text-sm text-gray-500">${phone}</p>
                            ${company ? `<p class="text-xs text-blue-600">${company}</p>` : ''}
                        </div>
                        <div class="text-right">
                            <p class="text-sm font-medium text-green-600">0 commandes</p>
                            <p class="text-sm text-gray-500">Total: 0€</p>
                        </div>
                    </div>
                `;
                
                // Insert at the beginning of the list
                clientsList.insertBefore(newClientDiv, clientsList.firstChild);
                
                showNotification(`Client ${name} ajouté avec succès`, 'success');
                
                // Reset form
                document.getElementById('client-name-new').value = '';
                document.getElementById('client-email').value = '';
                document.getElementById('client-phone').value = '';
                document.getElementById('client-company').value = '';
                
            } catch (error) {
                showNotification('Erreur lors de l\'ajout du client', 'error');
                console.error('Add client error:', error);
            }
        }

        // Notification System
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
                type === 'success' ? 'bg-green-500 text-white' :
                type === 'error' ? 'bg-red-500 text-white' :
                type === 'info' ? 'bg-blue-500 text-white' :
                'bg-gray-500 text-white'
            }`;
            notification.textContent = message;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }

        // Profile Menu Functions
        function toggleProfileMenu() {
            const menu = document.getElementById('profileMenu');
            menu.classList.toggle('hidden');
        }

        function confirmLogout(event) {
            if (!confirm('Êtes-vous sûr de vouloir vous déconnecter ?')) {
                event.preventDefault();
                return false;
            }
            return true;
        }

        // Close profile menu when clicking outside
        document.addEventListener('click', function(event) {
            const profileMenu = document.getElementById('profileMenu');
            const profileButton = event.target.closest('button[onclick="toggleProfileMenu()"]');
            
            if (profileMenu && !profileMenu.contains(event.target) && !profileButton) {
                profileMenu.classList.add('hidden');
            }
        });

        // Close add menu when clicking outside
        document.addEventListener('click', function(event) {
            const addMenu = document.getElementById('add-menu');
            const addButton = event.target.closest('button');
            
            if (addMenu && !addMenu.contains(event.target) && (!addButton || !addButton.onclick || !addButton.onclick.toString().includes('toggleAddMenu'))) {
                addMenu.classList.add('hidden');
            }
        });

        // Initialize dashboard on load
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Page loaded, initializing...');
            console.log('Total orders in storage:', allOrders.length);
            
            // Force display orders immediately
            updateOrdersDisplay();
            
            showSection('dashboard');
            
            // Also update after a short delay to ensure DOM is ready
            setTimeout(() => {
                updateOrdersDisplay();
                console.log('Orders display initialized');
            }, 500);
        });

        // ===== DIGITAL PRODUCTS FUNCTIONS - VERSION DYNAMIQUE DB =====
        // Variables chargées depuis DB u497064961_Saheldz via API shop-dynamic.php
        let categories = [];
        let products = [];
        let productAccounts = {}; // Stock et comptes
        let selectedCategory = null;
        let currentSaleInfo = null;

        // Charger les catégories depuis la DB u497064961_Saheldz
        async function loadCategoriesFromDB() {
            try {
                const response = await fetch('../api/shop-dynamic.php?action=getCategories&type=all');
                const data = await response.json();
                
                if (data.success && data.categories) {
                    categories = data.categories.map(cat => ({
                        id: cat.id,
                        name: cat.name,
                        icon: cat.icon,
                        parent: cat.parent_id
                    }));
                    
                    console.log('✅ Catégories chargées depuis u497064961_Saheldz:', categories.length);
                    renderCategories();
                } else {
                    console.error('Erreur chargement catégories:', data.error);
                    showNotification('⚠️ Erreur lors du chargement des catégories', 'error');
                }
            } catch (error) {
                console.error('Erreur chargement catégories:', error);
                showNotification('❌ Impossible de charger les catégories', 'error');
            }
        }
        
        async function loadProductsFromDB() {
    try {
        const response = await fetch('../api/shop-dynamic.php?action=get_items&type=product');
        const data = await response.json();

        if (data.success && data.items) {
            // On map pour uniformiser les données comme pour les catégories
            products = data.items.map(prod => ({
                id: prod.id,
                name: prod.name,
                type: prod.type,
                category: prod.category_id,
                category_name: prod.category_name,
                price: parseFloat(prod.price),
                duration: prod.delivery_time || '1 mois',
                description: prod.description || ''
            }));

            console.log(`✅ Produits chargés depuis shop_items: ${products.length}`);
            
            renderProducts(); // fonction qui affiche les produits dans le DOM
        } else {
            console.error('Erreur chargement produits:', data.error);
            showNotification('⚠️ Erreur lors du chargement des produits', 'error');
        }
    } catch (error) {
        console.error('Erreur chargement produits:', error);
        showNotification('❌ Impossible de charger les produits', 'error');
    }
}

        // Charger les produits depuis la DB u497064961_Saheldz via product_stock
        async function loadProductsFromDB() {
            try {
                const response = await fetch('../api/shop-dynamic.php?action=getProducts');
                const data = await response.json();
                
                if (data.success && data.products) {
                    products = data.products.map(prod => ({
                        id: prod.id,
                        name: prod.name,
                        type: prod.type,
                        category: prod.category_id,
                        price: parseFloat(prod.price),
                        stock: prod.stock || 0,
                        duration: prod.duration || '1 mois',
                        description: prod.description || ''
                    }));
                    
                    // Charger le stock/comptes depuis product_stock pour chaque produit
                    if (data.stock) {
                        productAccounts = {};
                        Object.keys(data.stock).forEach(prodId => {
                            // Mapper les données de product_stock au format attendu
                            productAccounts[prodId] = data.stock[prodId].map(item => ({
                                id: item.id,
                                code: item.product_code,
                                key: item.product_key,
                                email: null,
                                password: null,
                                used: item.status === 'sold',
                                type: 'unique',
                                stock: 1,
                                description: item.notes || ''
                            }));
                        });
                    }
                    
                    console.log('✅ Produits chargés depuis product_stock:', products.length);
                    renderProducts();
                    renderCategories();
                } else {
                    console.error('Erreur chargement produits:', data.message || data.error);
                    showNotification('⚠️ Erreur lors du chargement des produits', 'error');
                }
            } catch (error) {
                console.error('Erreur chargement produits:', error);
                showNotification('❌ Impossible de charger les produits', 'error');
            }
        }

        // Fonctions utilitaires pour produits digitaux
        function getTypeColor(type) {
            const colors = {
                'abonnement': 'bg-purple-100 text-purple-800',
                'licence': 'bg-blue-100 text-blue-800',
                'formation': 'bg-green-100 text-green-800',
                'giftcard': 'bg-yellow-100 text-yellow-800'
            };
            return colors[type] || 'bg-gray-100 text-gray-800';
        }

        function getTypeIcon(type) {
            const icons = {
                'abonnement': '🎬',
                'licence': '💻',
                'formation': '🎓',
                'giftcard': '🎁'
            };
            return icons[type] || '📦';
        }

        // Rendu des catégories
        function renderCategories() {
            const tree = document.getElementById('categoryTree');
            const parentSelect = document.getElementById('parentCategory');
            const productCategorySelect = document.getElementById('productCategory');
            
            if (!tree || !parentSelect || !productCategorySelect) return;
            
            tree.innerHTML = '';
            parentSelect.innerHTML = '<option value="">Catégorie principale</option>';
            productCategorySelect.innerHTML = '<option value="">Sélectionner une catégorie</option>';

const mainCategories = categories.filter(cat => !cat.parent || cat.parent == 0);
            
            mainCategories.forEach(category => {
                const categoryDiv = document.createElement('div');
                categoryDiv.className = 'mb-2';
                categoryDiv.draggable = true;
categoryDiv.ondragstart = () => (draggedCategory = category.id);
categoryDiv.ondragover = e => e.preventDefault();
categoryDiv.ondrop = () => reorderCategory(draggedCategory, category.id);

                
                const productCount = products.filter(p => {
                    const subCats = categories.filter(c => c.parent === category.id);
                    return p.category === category.id || subCats.some(sub => sub.id === p.category);
                }).length;

                categoryDiv.innerHTML = `
    <div class="flex items-center justify-between p-2 rounded hover:bg-gray-50">
        <div class="flex items-center gap-2 cursor-pointer" onclick="selectCategory(${category.id})">
            <span>${category.icon}</span>
            <span class="font-medium">${category.name}</span>
        </div>

        <div class="flex gap-2">
            <span class="text-xs bg-gray-200 px-2 py-1 rounded-full">${productCount}</span>
            <button onclick="deleteCategory(${category.id}, '${category.name}')" class="text-red-500 text-sm hover:text-red-700">🗑</button>
        </div>
    </div>
`;


                const subCategories = categories.filter(cat => cat.parent === category.id);
                if (subCategories.length > 0) {
                    const subDiv = document.createElement('div');
                    subDiv.className = 'ml-4 mt-1';
                    subCategories.forEach(subCat => {
                        const subProductCount = products.filter(p => p.category === subCat.id).length;
                        subDiv.innerHTML += `
                            <div class="flex items-center justify-between p-1 rounded cursor-pointer hover:bg-gray-50 text-sm ${selectedCategory === subCat.id ? 'bg-blue-50 border-l-2 border-blue-300' : ''}" 
                                 onclick="selectCategory(${subCat.id})">
                                <span class="flex items-center gap-2">
                                    <span>${subCat.icon}</span>
                                    <span>${subCat.name}</span>
                                </span>
                                <span class="text-xs bg-gray-200 px-1 py-0.5 rounded">${subProductCount}</span>
                            </div>
                        `;
                    });
                    categoryDiv.appendChild(subDiv);
                }

                tree.appendChild(categoryDiv);
                parentSelect.innerHTML += `<option value="${category.id}">${category.icon} ${category.name}</option>`;
                productCategorySelect.innerHTML += `<option value="${category.id}">${category.icon} ${category.name}</option>`;
                
                subCategories.forEach(subCat => {
                    productCategorySelect.innerHTML += `<option value="${subCat.id}">  └ ${subCat.icon} ${subCat.name}</option>`;
                });
            });
        }
        categories = categories.map(cat => ({
    ...cat,
    parent: cat.parent ?? cat.parent_id ?? null
}));


        // Rendu des produits
        function renderProducts() {
            const grid = document.getElementById('productsGrid');
            const searchInput = document.getElementById('searchInput');
            const typeFilter = document.getElementById('typeFilter');
            
            if (!grid || !searchInput || !typeFilter) return;
            
            const searchTerm = searchInput.value.toLowerCase();
            const typeFilterValue = typeFilter.value;
            
            let filteredProducts = products.filter(product => {
                const matchesSearch = product.name.toLowerCase().includes(searchTerm) || 
                                    product.description.toLowerCase().includes(searchTerm);
                const matchesType = !typeFilterValue || product.type === typeFilterValue;
                const matchesCategory = !selectedCategory || product.category === selectedCategory || 
                                      categories.find(c => c.id === product.category)?.parent === selectedCategory;
                
                return matchesSearch && matchesType && matchesCategory;
            });

            const productCount = document.getElementById('productCount');
            if (productCount) {
                productCount.textContent = `${filteredProducts.length} produit${filteredProducts.length > 1 ? 's' : ''}`;
            }

            grid.innerHTML = '';
            
            if (filteredProducts.length === 0) {
                grid.innerHTML = `
                    <div class="col-span-full text-center py-12">
                        <div class="text-6xl mb-4">📦</div>
                        <h3 class="text-xl font-semibold text-gray-600 mb-2">Aucun produit trouvé</h3>
                        <p class="text-gray-500">Essayez de modifier vos filtres ou ajoutez un nouveau produit</p>
                    </div>
                `;
                return;
            }

            filteredProducts.forEach(product => {
                const category = categories.find(c => c.id === product.category);
                const accounts = productAccounts[product.id] || [];
                
                const availableAccounts = accounts.reduce((total, acc) => {
                    if (acc.type === 'reusable') {
                        return total + acc.stock;
                    } else {
                        return total + (acc.used ? 0 : 1);
                    }
                }, 0);
                
                const productCard = document.createElement('div');
                productCard.className = 'bg-white border border-gray-200 rounded-lg p-4 shadow-sm card-hover transition-all duration-200';
                productCard.style.transition = 'all 0.3s ease';
                
                productCard.innerHTML = `
                    <div class="flex items-start justify-between mb-3">
                        <div class="flex items-center gap-2">
                            <span class="text-2xl">${getTypeIcon(product.type)}</span>
                            <div>
                                <h3 class="font-semibold text-gray-800">${product.name}</h3>
                                <p class="text-sm text-gray-500">${category ? category.name : 'Sans catégorie'}</p>
                            </div>
                        </div>
                        <span class="px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(product.type)}">
                            ${product.type.charAt(0).toUpperCase() + product.type.slice(1)}
                        </span>
                    </div>
                    
                    <p class="text-sm text-gray-600 mb-3">${product.description}</p>
                    
                    <div class="flex items-center justify-between text-sm text-gray-500 mb-3">
                        <span>⏱️ ${product.duration}</span>
                        <span class="flex items-center gap-1">
                            <span>🔑</span>
                            <span class="${availableAccounts === 0 ? 'text-red-500 font-medium' : 'text-green-600 font-medium'}">${availableAccounts} comptes</span>
                        </span>
                    </div>
                    
                    <div class="flex items-center justify-between">
                        <span class="text-xl font-bold text-green-600">${product.price}€</span>
                        <div class="flex gap-2">
                            <button onclick="sellProduct(${product.id})" 
                                    class="px-3 py-1 bg-green-500 text-white rounded text-sm hover:bg-green-600 ${availableAccounts === 0 ? 'opacity-50 cursor-not-allowed' : ''}"
                                    ${availableAccounts === 0 ? 'disabled' : ''}>
                                ${availableAccounts === 0 ? 'Épuisé' : 'Vendre'}
                            </button>
                            <button onclick="manageAccounts(${product.id})" 
                                    class="px-3 py-1 bg-purple-500 text-white rounded text-sm hover:bg-purple-600">
                                Comptes
                            </button>
                            <button onclick="editProduct(${product.id})" 
                                    class="px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600">
                                Éditer
                            </button>
                        </div>
                    </div>
                `;
                
                grid.appendChild(productCard);
            });
        }

        // Sélection de catégorie
        function selectCategory(categoryId) {
            selectedCategory = selectedCategory === categoryId ? null : categoryId;
            renderCategories();
            renderProducts();
        }

        // Vente de produit avec système réutilisable - Connecté à product_stock
        async function sellProduct(productId) {
            const product = products.find(p => p.id === productId);
            const accounts = productAccounts[productId] || [];
            
            if (!product) {
                showNotification('❌ Produit introuvable', 'error');
                return;
            }
            
            if (accounts.length === 0) {
                showNotification('❌ Aucun compte disponible pour ce produit', 'error');
                return;
            }
            
            let selectedAccount = accounts.find(acc => !acc.used);
            
            if (!selectedAccount) {
                showNotification('❌ Stock épuisé pour ce produit', 'error');
                return;
            }
            
            // Ask for client name (optional)
            const clientName = prompt('Nom du client (optionnel):') || 'Client anonyme';
            
            try {
                // Mark account as sold in DB via API
                const formData = new FormData();
                formData.append('action', 'update_stock_status');
                formData.append('stock_id', selectedAccount.id);
                formData.append('status', 'sold');
                formData.append('client_name', clientName.trim());
                
                const response = await fetch('../api/shop-dynamic.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    // Mark locally
                    selectedAccount.used = true;
                    
                    currentSaleInfo = { product: product, account: selectedAccount, client: clientName };
                    showSaleModal(product, selectedAccount);
                    
                    // Reload products to update stock count
                    await loadProductsFromDB();
                    
                    showNotification('✅ Vente enregistrée dans la DB !', 'success');
                } else {
                    throw new Error(data.message || 'Erreur lors de la vente');
                }
            } catch (error) {
                console.error('Erreur:', error);
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        }

        function showSaleModal(product, account) {
            const saleContent = document.getElementById('saleContent');
            let accountInfo = '';
            
            if (account.email && account.password) {
                accountInfo = `
                    <div class="bg-gray-50 p-4 rounded-lg mb-4">
                        <h4 class="font-semibold text-gray-800 mb-3">${getTypeIcon(product.type)} ${product.name}</h4>
                        <div class="space-y-2">
                            <div class="flex justify-between items-center">
                                <span class="text-sm text-gray-600">Email :</span>
                                <span class="font-mono text-sm bg-white px-2 py-1 rounded border">${account.email}</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-sm text-gray-600">Mot de passe :</span>
                                <span class="font-mono text-sm bg-white px-2 py-1 rounded border">${account.password}</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-sm text-gray-600">Durée :</span>
                                <span class="text-sm font-medium text-green-600">${product.duration}</span>
                            </div>
                        </div>
                    </div>
                `;
            } else if (account.key) {
                accountInfo = `
                    <div class="bg-gray-50 p-4 rounded-lg mb-4">
                        <h4 class="font-semibold text-gray-800 mb-3">${getTypeIcon(product.type)} ${product.name}</h4>
                        <div class="space-y-2">
                            <div class="flex justify-between items-center">
                                <span class="text-sm text-gray-600">Clé de licence :</span>
                                <span class="font-mono text-sm bg-white px-2 py-1 rounded border">${account.key}</span>
                            </div>
                            ${account.description ? `
                            <div class="flex justify-between items-center">
                                <span class="text-sm text-gray-600">Description :</span>
                                <span class="text-sm text-gray-800">${account.description}</span>
                            </div>
                            ` : ''}
                            <div class="flex justify-between items-center">
                                <span class="text-sm text-gray-600">Durée :</span>
                                <span class="text-sm font-medium text-green-600">${product.duration}</span>
                            </div>
                            ${account.type === 'reusable' ? `
                            <div class="bg-blue-50 border border-blue-200 p-2 rounded text-xs">
                                <span class="text-blue-800">🔄 Clé réutilisable - Stock restant: ${account.stock}</span>
                            </div>
                            ` : ''}
                        </div>
                    </div>
                `;
            } else if (account.code) {
                accountInfo = `
                    <div class="bg-gray-50 p-4 rounded-lg mb-4">
                        <h4 class="font-semibold text-gray-800 mb-3">${getTypeIcon(product.type)} ${product.name}</h4>
                        <div class="space-y-2">
                            <div class="flex justify-between items-center">
                                <span class="text-sm text-gray-600">Code :</span>
                                <span class="font-mono text-sm bg-white px-2 py-1 rounded border">${account.code}</span>
                            </div>
                            ${account.value ? `
                            <div class="flex justify-between items-center">
                                <span class="text-sm text-gray-600">Valeur :</span>
                                <span class="text-sm font-medium text-green-600">${account.value}</span>
                            </div>
                            ` : ''}
                            ${account.accessUrl ? `
                            <div class="flex justify-between items-center">
                                <span class="text-sm text-gray-600">Accès :</span>
                                <span class="text-sm text-blue-600 break-all">${account.accessUrl}</span>
                            </div>
                            ` : ''}
                            <div class="flex justify-between items-center">
                                <span class="text-sm text-gray-600">Validité :</span>
                                <span class="text-sm font-medium text-green-600">${product.duration}</span>
                            </div>
                            ${account.type === 'reusable' ? `
                            <div class="bg-blue-50 border border-blue-200 p-2 rounded text-xs">
                                <span class="text-blue-800">🔄 Code réutilisable - Stock restant: ${account.stock}</span>
                            </div>
                            ` : ''}
                        </div>
                    </div>
                `;
            }
            
            accountInfo += `
                <div class="bg-green-50 border border-green-200 p-3 rounded-lg">
                    <div class="flex items-center gap-2 text-green-800">
                        <span>💰</span>
                        <span class="font-semibold">Vente réalisée : ${product.price}€</span>
                    </div>
                    <p class="text-sm text-green-700 mt-1">Les informations ci-dessus ont été fournies au client.</p>
                </div>
            `;
            
            saleContent.innerHTML = accountInfo;
            document.getElementById('saleModal').classList.remove('hidden');
        }

        function closeSaleModal() {
            document.getElementById('saleModal').classList.add('hidden');
            currentSaleInfo = null;
        }

        function copyAccountInfo() {
            if (!currentSaleInfo) return;
            
            const { product, account } = currentSaleInfo;
            let textToCopy = `${product.name}\nDurée: ${product.duration}\nPrix: ${product.price}€\n\n`;
            
            if (account.email && account.password) {
                textToCopy += `Email: ${account.email}\nMot de passe: ${account.password}`;
            } else if (account.key) {
                textToCopy += `Clé de licence: ${account.key}`;
                if (account.description) textToCopy += `\nDescription: ${account.description}`;
            } else if (account.code) {
                textToCopy += `Code: ${account.code}`;
                if (account.value) textToCopy += `\nValeur: ${account.value}`;
                if (account.accessUrl) textToCopy += `\nAccès: ${account.accessUrl}`;
            }
            
            navigator.clipboard.writeText(textToCopy).then(() => {
                showNotification('📋 Informations copiées !', 'blue');
            });
        }

        async function editProduct(productId) {
            const product = products.find(p => p.id === productId);
            if (!product) {
                showNotification('❌ Produit introuvable', 'error');
                return;
            }
            
            // Pre-fill the product modal with existing data
            document.getElementById('productName').value = product.name;
            document.getElementById('productType').value = product.type;
            document.getElementById('productCategory').value = product.category;
            document.getElementById('productPrice').value = product.price;
            document.getElementById('productStock').value = product.stock;
            document.getElementById('productDuration').value = product.duration;
            document.getElementById('productDescription').value = product.description;
            
            // Change form submit behavior to update instead of create
            const productForm = document.getElementById('productForm');
            const newSubmitHandler = async function(e) {
                e.preventDefault();
                
                const name = document.getElementById('productName').value;
                const type = document.getElementById('productType').value;
                const category = parseInt(document.getElementById('productCategory').value);
                const price = parseFloat(document.getElementById('productPrice').value);
                const duration = document.getElementById('productDuration').value;
                const description = document.getElementById('productDescription').value;
                
                try {
                    const formData = new FormData();
                    formData.append('action', 'updateProduct');
                    formData.append('id', productId);
                    formData.append('name', name);
                    formData.append('type', type);
                    formData.append('category_id', category);
                    formData.append('price', price);
                    formData.append('duration', duration);
                    formData.append('description', description);
                    
                    const response = await fetch('../api/shop-dynamic.php', {
                        method: 'POST',
                        body: formData
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        await loadProductsFromDB();
                        closeProductModal();
                        showNotification('✅ Produit "' + name + '" mis à jour !', 'success');
                        
                        // Restore original form handler
                        productForm.removeEventListener('submit', newSubmitHandler);
                    } else {
                        throw new Error(data.error || 'Erreur mise à jour produit');
                    }
                } catch (error) {
                    console.error('Erreur:', error);
                    showNotification('❌ Erreur: ' + error.message, 'error');
                }
            };
            
            // Remove old handler and add new one
            const oldHandler = productForm.onsubmit;
            productForm.removeEventListener('submit', oldHandler);
            productForm.addEventListener('submit', newSubmitHandler, { once: true });
            
            // Change modal title
            const modalTitle = document.querySelector('#productModal h3');
            if (modalTitle) {
                modalTitle.textContent = 'Modifier le Produit';
            }
            
            openProductModal();
        }

       async function manageAccounts(productId) {
    currentProductId = productId;

    // Charger stock depuis la DB
    const response = await fetch('../api/shop-dynamic.php?action=get_stock&item_id=' + productId);
    const data = await response.json();
    const stock = data.stock || [];

    let html = `
        <div class="mb-4 flex justify-between items-center">
            <h4 class="text-lg font-semibold">Gestion des comptes / codes</h4>
            <div class="flex gap-2">
                <button onclick="addNewAccount(${productId}, 'unique')" class="bg-green-500 text-white px-3 py-2 rounded hover:bg-green-600 text-sm">
                    + Compte unique
                </button>
                <button onclick="addNewAccount(${productId}, 'reusable')" class="bg-blue-500 text-white px-3 py-2 rounded hover:bg-blue-600 text-sm">
                    + Clé réutilisable
                </button>
            </div>
        </div>
        <div class="grid gap-3">
    `;
    

    if (stock.length === 0) {
        html += `
            <div class="text-center py-8 bg-gray-50 rounded-lg">
                <div class="text-4xl mb-2">🔑</div>
                <p class="text-gray-600">Aucun compte ajouté pour ce produit</p>
                <p class="text-sm text-gray-500">Ajoutez un compte ou une clé ci-dessus</p>
            </div>
            
        `;
    }

    stock.forEach(item => {
        const statusBadge = item.status === 'available'
            ? `<span class="text-sm font-medium text-green-600">✅ Disponible</span>`
            : `<span class="text-sm font-medium text-gray-500">❌ Vendu</span>`;

        let reuseBlock = '';
        if (item.is_reusable == 1) {
            reuseBlock = `
                <div class="text-xs mt-2 bg-blue-50 border border-blue-200 px-2 py-1 rounded">
                    🔁 Réutilisable: <b>${item.used_count}</b> / <b>${item.max_uses}</b>
                    <div class="flex items-center gap-1 mt-1">
                        <input type="number" min="1" value="${item.max_uses}" 
                            class="w-16 px-1 py-0.5 text-xs border rounded"
                            onchange="updateMaxUses(${item.id}, this.value)">
                        <span class="text-gray-500 text-xs">modifier</span>
                    </div>
                </div>
            `;
        }

        html += `
            <div class="border rounded-lg p-4 bg-green-50 border-green-200">
                <div class="flex justify-between items-start">
                    <div class="flex-1">
                        <div class="font-mono bg-white px-2 py-1 rounded border">${item.product_code}</div>
                        ${item.product_key ? `<div class="text-xs mt-1 text-gray-500">${item.product_key}</div>` : ''}
                        ${reuseBlock}
                    </div>
                    <button onclick="removeAccount(${productId}, ${item.id})" class="text-red-500 hover:text-red-700 p-1">🗑️</button>
                </div>
            </div>
        `;
    });

    html += `</div>`;
    
    document.getElementById('accountsContent').innerHTML = html;
    document.getElementById('accountsModal').classList.remove('hidden');
}


        function closeAccountsModal() {
            document.getElementById('accountsModal').classList.add('hidden');
        }
async function reorderCategory(draggedId, targetId) {
    const formData = new FormData();
    formData.append("action", "reorder_category");
    formData.append("dragged", draggedId);
    formData.append("target", targetId);

    await fetch('../api/shop-dynamic.php', { method: 'POST', body: formData });
    await loadCategoriesFromDB();
}

      async function addNewAccount(productId, accountType) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    let productCode = '';
    let productKey = '';
    let notes = '';
    let isReusable = (accountType === 'reusable') ? 1 : 0;
    let maxUses = 1;

    // 🔁 Si réutilisable → demander le nombre d’utilisations
    if (isReusable === 1) {
        const m = prompt("Combien de fois cette clé peut être utilisée ? (ex: 5)");
        if (!m || isNaN(m) || m < 1) return showNotification("❌ Nombre invalide", "error");
        maxUses = parseInt(m);
    }

    // 🔥 Formulaires selon type
    if (product.type === 'abonnement' || product.type === 'licence') {
        const email = prompt('Email du compte:');
        if (!email) return showNotification('❌ Ajout annulé', 'info');

        const password = prompt('Mot de passe du compte:');
        if (!password) return showNotification('❌ Ajout annulé', 'info');

        productCode = email.trim();
        productKey = password.trim();
        notes = isReusable ? 'Clé réutilisable' : 'Compte unique';
    }

    else if (product.type === 'formation') {
        const code = prompt('Code d’accès:');
        if (!code) return showNotification('❌ Ajout annulé', 'info');
        productCode = code.trim();
        notes = isReusable ? 'Clé formation réutilisable' : 'Code formation';
    }

    else if (product.type === 'giftcard') {
        const code = prompt('Code (ex: ABC-123-XYZ):');
        if (!code) return showNotification('❌ Ajout annulé', 'info');

        const value = prompt('Valeur (ex: 50€):');
        if (!value) return showNotification('❌ Ajout annulé', 'info');

        productCode = code.trim();
        productKey = `Valeur: ${value.trim()}`;
        notes = 'Gift Card';
    }

    else {
        const code = prompt('Code / identifiant:');
        if (!code) return showNotification('❌ Ajout annulé', 'info');

        productCode = code.trim();
        notes = isReusable ? 'Clé réutilisable' : 'Compte générique';
    }

    // ✅ Envoi au backend
    try {
        const formData = new FormData();
        formData.append('action', 'add_stock');
        formData.append('item_id', productId);
        formData.append('product_code', productCode);
        formData.append('product_key', productKey);
        formData.append('notes', notes);
        formData.append('is_reusable', isReusable);
        formData.append('max_uses', maxUses);

        const response = await fetch('../api/shop-dynamic.php', { method: 'POST', body: formData });
        const data = await response.json();

        if (data.success) {
            showNotification('✅ Stock ajouté avec succès', 'success');
            await loadProductsFromDB();
            manageAccounts(productId);
        } else {
            throw new Error(data.message || 'Erreur ajout stock');
        }

    } catch (error) {
        console.error('Erreur:', error);
        showNotification('❌ ' + error.message, 'error');
    }
}


        function updateStock(productId, accountIndex, newStock) {
            const accounts = productAccounts[productId];
            if (accounts && accounts[accountIndex]) {
                accounts[accountIndex].stock = parseInt(newStock) || 0;
                renderProducts();
                showNotification('📊 Stock mis à jour !', 'blue');
            }
        }

        async function removeAccount(productId, accountIndex) {
            if (!confirm('Êtes-vous sûr de vouloir supprimer ce compte ?')) {
                return;
            }
            
            try {
                const account = productAccounts[productId][accountIndex];
                
                if (!account.id) {
                    showNotification('❌ ID compte introuvable', 'error');
                    return;
                }
                
                const formData = new FormData();
                formData.append('action', 'remove_stock');
                formData.append('stock_id', account.id);
                
                const response = await fetch('../api/shop-dynamic.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    await loadProductsFromDB(); // Recharger depuis la DB
                    manageAccounts(productId);
                    showNotification('🗑️ Compte supprimé de la DB', 'success');
                } else {
                    throw new Error(data.message || 'Erreur suppression');
                }
            } catch (error) {
                console.error('Erreur:', error);
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        }

        function openCategoryModal() {
            document.getElementById('categoryModal').classList.remove('hidden');
        }

        function closeCategoryModal() {
            document.getElementById('categoryModal').classList.add('hidden');
            document.getElementById('categoryForm').reset();
        }

        function openProductModal() {
            document.getElementById('productModal').classList.remove('hidden');
        }

        function closeProductModal() {
            document.getElementById('productModal').classList.add('hidden');
            document.getElementById('productForm').reset();
        }

        document.getElementById('categoryForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const name = document.getElementById('categoryName').value;
            const icon = document.getElementById('categoryIcon').value;

            try {
                const formData = new FormData();
                formData.append('action', 'createCategory');
                formData.append('name', name);
                formData.append('icon', icon);

                const response = await fetch('../api/shop-dynamic.php', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.success) {
                    await loadCategoriesFromDB(); // Reload from DB u497064961_Saheldz
                    closeCategoryModal();
                    showNotification('✅ Catégorie "' + name + '" créée dans la DB !', 'success');
                } else {
                    throw new Error(data.message || 'Erreur création catégorie');
                }
            } catch (error) {
                console.error('Erreur:', error);
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        });

        document.getElementById('productForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const name = document.getElementById('productName').value;
            const type = document.getElementById('productType').value;
            const category = parseInt(document.getElementById('productCategory').value);
            const price = parseFloat(document.getElementById('productPrice').value);
            const stock = parseInt(document.getElementById('productStock').value);
            const duration = document.getElementById('productDuration').value;
            const description = document.getElementById('productDescription').value;
            
            try {
                const formData = new FormData();
                formData.append('action', 'createProduct');
                formData.append('name', name);
                formData.append('type', type);
                formData.append('category_id', category);
                formData.append('price', price);
                formData.append('duration', duration);
                formData.append('description', description);
                
                const response = await fetch('../api/shop-dynamic.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    await loadProductsFromDB(); // Reload from DB u497064961_Saheldz
                    closeProductModal();
                    showNotification('✅ Produit "' + name + '" créé dans la DB !', 'success');
                } else {
                    throw new Error(data.error || 'Erreur création produit');
                }
            } catch (error) {
                console.error('Erreur:', error);
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        });

        document.getElementById('searchInput').addEventListener('input', renderProducts);
        document.getElementById('typeFilter').addEventListener('change', renderProducts);

        document.getElementById('categoryModal').addEventListener('click', function(e) { if (e.target === this) closeCategoryModal(); });
        document.getElementById('productModal').addEventListener('click', function(e) { if (e.target === this) closeProductModal(); });
        document.getElementById('saleModal').addEventListener('click', function(e) { if (e.target === this) closeSaleModal(); });
        document.getElementById('accountsModal').addEventListener('click', function(e) { if (e.target === this) closeAccountsModal(); });

        // Initialize when digital-products section is shown
        const digitalObserver = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                const digitalProductsSection = document.getElementById('digital-products');
                if (digitalProductsSection && !digitalProductsSection.classList.contains('hidden')) {
                    const categoryTree = document.getElementById('categoryTree');
                    if (categoryTree && categoryTree.children.length === 0) {
                        // Charger depuis DB u497064961_Saheldz au premier affichage
                        console.log('📦 Chargement des produits digitaux depuis DB...');
                        loadCategoriesFromDB();
                        loadProductsFromDB();
                    }
                }
            });
        });
        
        digitalObserver.observe(document.body, { attributes: true, subtree: true, attributeFilter: ['class'] });
        
        // Force load on page ready (backup method)
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                const digitalProductsSection = document.getElementById('digital-products');
                const categoryTree = document.getElementById('categoryTree');
                if (digitalProductsSection && categoryTree && categoryTree.children.length === 0) {
                    console.log('🔄 Force loading categories on page ready...');
                    loadCategoriesFromDB();
                    loadProductsFromDB();
                }
            }, 1000);
        });

        // ===== SMM API FUNCTIONS =====
        const SMM_API_URL = 'api-proxy.php'; // Proxy local pour éviter CORS
        let smmApiKey = localStorage.getItem('smm_api_key') || '';
        let smmServices = [];
        let smmOrders = JSON.parse(localStorage.getItem('smm_orders') || '[]');

        // Load API key on page load
        window.addEventListener('DOMContentLoaded', () => {
            const apiKeyInput = document.getElementById('api-key');
            if (apiKeyInput && smmApiKey) {
                apiKeyInput.value = smmApiKey;
                checkAPIStatus();
            }
        });

        // Save API Key
        function saveAPIKey() {
            const apiKeyInput = document.getElementById('api-key');
            const apiKey = apiKeyInput.value.trim();
            
            if (!apiKey) {
                showNotification('Veuillez entrer une clé API', 'error');
                return;
            }
            
            smmApiKey = apiKey;
            localStorage.setItem('smm_api_key', apiKey);
            showNotification('✅ Clé API sauvegardée avec succès', 'success');
            checkAPIStatus();
        }

        // Test API Connection
        async function testAPIConnection() {
            const apiKeyInput = document.getElementById('api-key');
            const apiKey = apiKeyInput.value.trim();
            
            if (!apiKey) {
                showNotification('Veuillez entrer une clé API', 'error');
                return;
            }
            
            const statusDiv = document.getElementById('api-status');
            statusDiv.innerHTML = '<div class="bg-blue-50 border border-blue-200 p-3 rounded-lg text-blue-800">🔄 Test de connexion en cours...</div>';
            statusDiv.classList.remove('hidden');
            
            try {
                const formData = new FormData();
                formData.append('key', apiKey);
                formData.append('action', 'balance');
                
                const response = await fetch(SMM_API_URL, {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.balance !== undefined) {
                    statusDiv.innerHTML = '<div class="bg-green-50 border border-green-200 p-3 rounded-lg text-green-800">✅ Connexion réussie! Solde: ' + data.balance + ' ' + data.currency + '</div>';
                    document.getElementById('connection-status').textContent = 'Connecté ✅';
                    document.getElementById('connection-status').className = 'text-lg font-semibold text-green-600';
                    document.getElementById('account-balance').textContent = data.balance + ' ' + data.currency;
                    
                    smmApiKey = apiKey;
                    localStorage.setItem('smm_api_key', apiKey);
                    
                    await loadServices();
                } else {
                    throw new Error(data.error || 'Erreur de connexion');
                }
            } catch (error) {
                statusDiv.innerHTML = '<div class="bg-red-50 border border-red-200 p-3 rounded-lg text-red-800">❌ Erreur: ' + error.message + '</div>';
                document.getElementById('connection-status').textContent = 'Erreur ❌';
                document.getElementById('connection-status').className = 'text-lg font-semibold text-red-600';
            }
        }

        // Check API Status
        async function checkAPIStatus() {
            if (!smmApiKey) return;
            
            try {
                const formData = new FormData();
                formData.append('key', smmApiKey);
                formData.append('action', 'balance');
                
                const response = await fetch(SMM_API_URL, {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.balance !== undefined) {
                    document.getElementById('connection-status').textContent = 'Connecté ✅';
                    document.getElementById('connection-status').className = 'text-lg font-semibold text-green-600';
                    document.getElementById('account-balance').textContent = data.balance + ' ' + data.currency;
                    // Don't load services automatically - only on demand
                    // await loadServices();
                } else {
                    document.getElementById('connection-status').textContent = 'Non connecté';
                    document.getElementById('connection-status').className = 'text-lg font-semibold text-gray-400';
                }
            } catch (error) {
                console.error('Error checking API status:', error);
            }
        }

        // Load Services from API
        async function loadServices() {
            if (!smmApiKey) {
                showNotification('Veuillez d\'abord connecter votre clé API', 'error');
                return;
            }
            
            try {
                const formData = new FormData();
                formData.append('key', smmApiKey);
                formData.append('action', 'services');
                
                const response = await fetch(SMM_API_URL, {
                    method: 'POST',
                    body: formData
                });
                
                smmServices = await response.json();
                document.getElementById('services-count').textContent = smmServices.length + ' services disponibles';
                
                showNotification('✅ ' + smmServices.length + ' services chargés', 'success');
                updateServicesListPage();
            } catch (error) {
                showNotification('❌ Erreur lors du chargement des services: ' + error.message, 'error');
            }
        }

        // Refresh API Info
        async function refreshAPIInfo() {
            if (!smmApiKey) {
                showNotification('Veuillez d\'abord connecter votre clé API', 'error');
                return;
            }
            
            showNotification('🔄 Actualisation en cours...', 'info');
            await checkAPIStatus();
        }

        // Update Services List Page
        function updateServicesListPage() {
            const servicesGrid = document.querySelector('#smm-services-list .grid');
            if (!servicesGrid || smmServices.length === 0) return;
            
            servicesGrid.innerHTML = '';
            
            // Group services by category
            const categories = {};
            smmServices.forEach(service => {
                if (!categories[service.category]) {
                    categories[service.category] = [];
                }
                categories[service.category].push(service);
            });
            
            // Display first 20 services as examples
            const servicesToShow = smmServices.slice(0, 20);
            
            servicesToShow.forEach(service => {
                const serviceCard = document.createElement('div');
                serviceCard.className = 'border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow';
                
                const icon = getServiceIcon(service.category);
                
                serviceCard.innerHTML = `
                    <div class="flex items-center space-x-3 mb-3">
                        <span class="text-2xl">${icon}</span>
                        <div>
                            <h4 class="font-medium">${service.name}</h4>
                            <p class="text-sm text-gray-600">${service.category}</p>
                        </div>
                    </div>
                    <div class="space-y-2 text-sm">
                        <div class="flex justify-between">
                            <span>Min:</span>
                            <span>${service.min}</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Max:</span>
                            <span>${service.max}</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Prix:</span>
                            <span class="font-medium text-blue-600">${service.rate}€ / 1000</span>
                        </div>
                        ${service.refill ? '<div class="flex items-center gap-1 text-green-600 text-xs"><span>✓</span><span>Refill disponible</span></div>' : ''}
                        ${service.cancel ? '<div class="flex items-center gap-1 text-orange-600 text-xs"><span>✓</span><span>Annulation disponible</span></div>' : ''}
                    </div>
                    <button onclick="useServiceForOrder(${service.service})" class="mt-3 w-full bg-blue-600 text-white py-2 rounded-lg text-sm hover:bg-blue-700">
                        Commander ce service
                    </button>
                `;
                
                servicesGrid.appendChild(serviceCard);
            });
        }

        // Get Service Icon
        function getServiceIcon(category) {
            const icons = {
                'Instagram': '📱',
                'Facebook': '📘',
                'TikTok': '🎵',
                'YouTube': '📹',
                'Twitter': '🐦',
                'Telegram': '✈️',
                'Spotify': '🎵'
            };
            
            for (const [key, icon] of Object.entries(icons)) {
                if (category.toLowerCase().includes(key.toLowerCase())) {
                    return icon;
                }
            }
            
            return '📱';
        }

        // Use Service for Order
        function useServiceForOrder(serviceId) {
            const service = smmServices.find(s => s.service === serviceId);
            if (!service) return;
            
            // Switch to new order page and pre-select service
            showSMMPage('new-order');
            
            // Pre-fill with service info
            showNotification('Service sélectionné: ' + service.name, 'info');
            
            // Store selected service for the order form
            window.selectedSMMService = service;
            updateOrderFormWithService(service);
        }

        // Update Order Form With Service
        function updateOrderFormWithService(service) {
            // We'll update the form to show service details
            const smmServiceSelect = document.getElementById('smm-service');
            if (smmServiceSelect) {
                showNotification(`Service: ${service.name} | Prix: ${service.rate}€/1000 | Min: ${service.min} | Max: ${service.max}`, 'info');
            }
        }

        // Create SMM Order (Updated)
        async function createSMMOrder(event) {
            event.preventDefault();
            
            if (!smmApiKey) {
                showNotification('❌ Veuillez d\'abord connecter votre clé API', 'error');
                return;
            }
            
            if (smmServices.length === 0) {
                showNotification('❌ Veuillez d\'abord charger les services disponibles', 'error');
                return;
            }
            
            const platform = document.getElementById('smm-platform').value;
            const serviceType = document.getElementById('smm-service').value;
            const quantity = document.getElementById('smm-quantity').value;
            const link = document.getElementById('smm-url').value;
            const client = document.getElementById('smm-client').value;
            
            if (!platform || !serviceType || !quantity || !link || !client) {
                showNotification('❌ Veuillez remplir tous les champs', 'error');
                return;
            }
            
            // Find a matching service
            const searchTerm = `${platform} ${serviceType}`.toLowerCase();
            const matchingService = smmServices.find(s => 
                s.name.toLowerCase().includes(searchTerm) || 
                s.category.toLowerCase().includes(platform.toLowerCase())
            );
            
            if (!matchingService && !window.selectedSMMService) {
                showNotification('❌ Aucun service trouvé pour ' + platform + ' ' + serviceType, 'error');
                showNotification('💡 Allez dans "Services List" pour sélectionner un service spécifique', 'info');
                return;
            }
            
            const serviceToUse = window.selectedSMMService || matchingService;
            
            // Validate quantity
            const qty = parseInt(quantity);
            if (qty < parseInt(serviceToUse.min) || qty > parseInt(serviceToUse.max)) {
                showNotification(`❌ Quantité doit être entre ${serviceToUse.min} et ${serviceToUse.max}`, 'error');
                return;
            }
            
            // Calculate cost
            const cost = (qty / 1000) * parseFloat(serviceToUse.rate);
            
            try {
                const formData = new FormData();
                formData.append('key', smmApiKey);
                formData.append('action', 'add');
                formData.append('service', serviceToUse.service);
                formData.append('link', link);
                formData.append('quantity', quantity);
                
                const response = await fetch(SMM_API_URL, {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.order) {
                    const order = {
                        id: data.order,
                        service: serviceToUse.name,
                        platform: platform,
                        link: link,
                        quantity: quantity,
                        cost: cost.toFixed(2),
                        client: client,
                        status: 'Pending',
                        date: new Date().toISOString(),
                        serviceId: serviceToUse.service
                    };
                    
                    smmOrders.push(order);
                    localStorage.setItem('smm_orders', JSON.stringify(smmOrders));
                    
                    showNotification(`✅ Commande #${data.order} créée avec succès!`, 'success');
                    showNotification(`💰 Coût: ${cost.toFixed(2)}€`, 'info');
                    
                    event.target.reset();
                    window.selectedSMMService = null;
                    
                    // Refresh balance
                    await checkAPIStatus();
                } else {
                    throw new Error(data.error || 'Erreur lors de la création de la commande');
                }
            } catch (error) {
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        }

        // Check Order Status
        async function checkOrderStatus(orderId) {
            if (!smmApiKey) return;
            
            try {
                const formData = new FormData();
                formData.append('key', smmApiKey);
                formData.append('action', 'status');
                formData.append('order', orderId);
                
                const response = await fetch(SMM_API_URL, {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.status) {
                    return {
                        status: data.status,
                        remains: data.remains,
                        start_count: data.start_count,
                        charge: data.charge
                    };
                }
            } catch (error) {
                console.error('Error checking order status:', error);
            }
            
            return null;
        }

        // Update SMM Orders Display (RENOMMÉ pour éviter conflit)
        async function updateSMMOrdersDisplay() {
            const ordersContainer = document.querySelector('#smm-my-orders .space-y-4');
            if (!ordersContainer) return;
            
            ordersContainer.innerHTML = '';
            
            if (smmOrders.length === 0) {
                ordersContainer.innerHTML = `
                    <div class="text-center py-12 bg-gray-50 rounded-lg">
                        <div class="text-4xl mb-2">📋</div>
                        <p class="text-gray-600">Aucune commande pour le moment</p>
                        <p class="text-sm text-gray-500 mt-1">Créez votre première commande SMM</p>
                    </div>
                `;
                return;
            }
            
            // Show orders in reverse chronological order
            const reversedOrders = [...smmOrders].reverse();
            
            for (const order of reversedOrders) {
                // Check status if order is pending or in progress
                if (order.status === 'Pending' || order.status === 'In progress') {
                    const status = await checkOrderStatus(order.id);
                    if (status) {
                        order.status = status.status;
                        order.remains = status.remains;
                        localStorage.setItem('smm_orders', JSON.stringify(smmOrders));
                    }
                }
                
                const statusColors = {
                    'Pending': 'bg-yellow-100 text-yellow-800',
                    'In progress': 'bg-blue-100 text-blue-800',
                    'Completed': 'bg-green-100 text-green-800',
                    'Partial': 'bg-orange-100 text-orange-800',
                    'Canceled': 'bg-red-100 text-red-800'
                };
                
                const statusColor = statusColors[order.status] || 'bg-gray-100 text-gray-800';
                
                const progress = order.remains ? 
                    ((parseInt(order.quantity) - parseInt(order.remains)) / parseInt(order.quantity) * 100).toFixed(0) : 
                    (order.status === 'Completed' ? 100 : 0);
                
                const orderDate = new Date(order.date).toLocaleString('fr-FR');
                
                const orderDiv = document.createElement('div');
                orderDiv.className = 'border border-gray-200 rounded-lg p-4';
                orderDiv.innerHTML = `
                    <div class="flex justify-between items-start mb-2">
                        <div>
                            <p class="font-medium">#${order.id} - ${order.service}</p>
                            <p class="text-sm text-gray-600">${order.link}</p>
                            <p class="text-xs text-gray-500">Client: ${order.client} • ${orderDate}</p>
                        </div>
                        <div class="text-right">
                            <span class="${statusColor} px-2 py-1 rounded-full text-xs">${order.status}</span>
                            <p class="text-sm font-medium mt-1">${order.cost}€</p>
                        </div>
                    </div>
                    ${order.remains !== undefined ? `
                    <div>
                        <div class="flex justify-between text-sm mb-2">
                            <span>Progression: ${parseInt(order.quantity) - parseInt(order.remains)} / ${order.quantity}</span>
                            <span>${progress}%</span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-2">
                            <div class="bg-blue-600 h-2 rounded-full" style="width: ${progress}%"></div>
                        </div>
                    </div>
                    ` : ''}
                `;
                
                ordersContainer.appendChild(orderDiv);
            }
        }

        // Display orders in table format
        async function displayOrdersTable() {
            const tbody = document.getElementById('orders-table-body');
            if (!tbody) return;
            
            tbody.innerHTML = '<tr><td colspan="10" class="text-center py-8 text-gray-500">Chargement des commandes...</td></tr>';
            
            if (smmOrders.length === 0) {
                tbody.innerHTML = '<tr><td colspan="10" class="text-center py-8 text-gray-500">Aucune commande</td></tr>';
                return;
            }
            
            tbody.innerHTML = '';
            
            // Show orders in reverse order (most recent first)
            const ordersToDisplay = [...smmOrders].reverse();
            
            for (const order of ordersToDisplay) {
                // Check status for pending orders
                if (order.status === 'Pending' || order.status === 'In progress') {
                    const status = await checkOrderStatus(order.id);
                    if (status) {
                        order.status = status.status;
                        order.remains = status.remains;
                        order.start_count = status.start_count;
                        order.charge = status.charge;
                        localStorage.setItem('smm_orders', JSON.stringify(smmOrders));
                    }
                }
                
                const tr = document.createElement('tr');
                tr.className = 'hover:bg-gray-50';
                
                // Format date
                const orderDate = new Date(order.date);
                const dateStr = orderDate.toLocaleDateString('fr-FR', { year: 'numeric', month: '2-digit', day: '2-digit' }).split('/').reverse().join('-');
                const timeStr = orderDate.toLocaleTimeString('fr-FR');
                
                // Status styling
                let statusClass = 'text-gray-800';
                if (order.status === 'Completed') statusClass = 'text-green-800';
                else if (order.status === 'Pending') statusClass = 'text-yellow-800';
                else if (order.status === 'In progress') statusClass = 'text-blue-800';
                else if (order.status === 'Partial') statusClass = 'text-orange-800';
                else if (order.status === 'Canceled') statusClass = 'text-red-800';
                
                tr.innerHTML = `
                    <td class="px-4 py-3 text-sm" data-label="ID">${order.id}</td>
                    <td class="px-4 py-3 text-sm" data-label="Date">
                        <span class="block">${dateStr}</span>
                        <span class="block text-gray-500">${timeStr}</span>
                    </td>
                    <td class="px-4 py-3 text-sm max-w-xs" data-label="Link">
                        <a href="${order.link}" target="_blank" class="text-blue-600 hover:underline truncate block">${order.link}</a>
                    </td>
                    <td class="px-4 py-3 text-sm" data-label="Charge">${order.charge || order.cost || '0.00'}€</td>
                    <td class="px-4 py-3 text-sm" data-label="Start count">${order.start_count || '-'}</td>
                    <td class="px-4 py-3 text-sm" data-label="Quantity">${order.quantity}</td>
                    <td class="px-4 py-3 text-sm max-w-md" data-label="Service">
                        <span class="text-gray-600">${order.serviceId || ''}</span> — ${order.service}
                    </td>
                    <td class="px-4 py-3 text-sm ${statusClass}" data-label="Status" nowrap>${order.status}</td>
                    <td class="px-4 py-3 text-sm" data-label="Remains">${order.remains !== undefined ? order.remains : order.quantity}</td>
                    <td class="px-4 py-3 text-sm" data-label="" nowrap>
                        ${(order.status === 'Pending' || order.status === 'In progress') ? `
                        <button onclick="cancelOrder('${order.id}')" class="text-red-600 hover:text-red-800 text-xs px-2 py-1 border border-red-300 rounded hover:bg-red-50">
                            Cancel
                        </button>
                        ` : ''}
                    </td>
                `;
                
                tbody.appendChild(tr);
            }
        }
        
        // Search orders
        function searchOrders(event) {
            event.preventDefault();
            const searchTerm = document.getElementById('order-search-input').value.toLowerCase();
            const rows = document.querySelectorAll('#orders-table-body tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
        
        // Cancel order
        async function cancelOrder(orderId) {
            if (!confirm('Êtes-vous sûr de vouloir annuler cette commande ?')) {
                return;
            }
            
            if (!smmApiKey) {
                showNotification('❌ Clé API non configurée', 'error');
                return;
            }
            
            try {
                const formData = new FormData();
                formData.append('key', smmApiKey);
                formData.append('action', 'cancel');
                formData.append('order', orderId);
                
                const response = await fetch(SMM_API_URL, {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.cancel) {
                    showNotification('✅ Commande annulée avec succès', 'success');
                    
                    // Update local storage
                    const order = smmOrders.find(o => o.id === orderId);
                    if (order) {
                        order.status = 'Canceled';
                        localStorage.setItem('smm_orders', JSON.stringify(smmOrders));
                    }
                    
                    // Refresh display
                    await displayOrdersTable();
                    await checkAPIStatus();
                } else {
                    throw new Error(data.error || 'Erreur lors de l\'annulation');
                }
            } catch (error) {
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        }

        // Update orders display when showing my-orders page
        const originalShowSMMPage = showSMMPage;
        showSMMPage = function(pageId) {
            originalShowSMMPage(pageId);
            
            if (pageId === 'my-orders') {
                displayOrdersTable();
            } else if (pageId === 'services-list' && smmServices.length === 0 && smmApiKey) {
                loadServices();
            } else if (pageId === 'api-config') {
                checkAPIStatus();
            } else if (pageId === 'new-order') {
                loadServicesForSimpleOrder();
            }
        };

        // NEW ORDER FUNCTIONS
        let currentSelectedService = null;
        let currentCategoryFilter = 'all';

        // Load services for new order page
        async function loadServicesForNewOrder() {
            if (!smmApiKey) {
                const browser = document.getElementById('services-browser');
                browser.innerHTML = `
                    <div class="text-center py-12 bg-yellow-50 rounded-lg border border-yellow-200">
                        <div class="text-4xl mb-3">🔑</div>
                        <p class="text-yellow-800 font-medium mb-2">Clé API non configurée</p>
                        <p class="text-sm text-yellow-700">Allez dans "API Configuration" pour connecter votre clé API</p>
                    </div>
                `;
                return;
            }

            if (smmServices.length === 0) {
                const browser = document.getElementById('services-browser');
                browser.innerHTML = '<p class="text-gray-500 text-center py-8">🔄 Chargement des services...</p>';
                await loadServices();
            }

            displayServicesList();
        }

        // Display services list
        function displayServicesList() {
            const browser = document.getElementById('services-browser');
            
            if (smmServices.length === 0) {
                browser.innerHTML = '<p class="text-gray-500 text-center py-8">Aucun service disponible</p>';
                return;
            }

            // Filter services
            let filteredServices = smmServices;
            
            if (currentCategoryFilter !== 'all') {
                filteredServices = smmServices.filter(s => 
                    s.category.toLowerCase().includes(currentCategoryFilter.toLowerCase())
                );
            }

            const searchTerm = document.getElementById('service-search')?.value.toLowerCase() || '';
            if (searchTerm) {
                filteredServices = filteredServices.filter(s =>
                    s.name.toLowerCase().includes(searchTerm) ||
                    s.category.toLowerCase().includes(searchTerm)
                );
            }

            browser.innerHTML = '';

            if (filteredServices.length === 0) {
                browser.innerHTML = '<p class="text-gray-500 text-center py-8">Aucun service trouvé</p>';
                return;
            }

            filteredServices.forEach(service => {
                const serviceDiv = document.createElement('div');
                serviceDiv.className = 'border border-gray-200 rounded-lg p-4 hover:bg-blue-50 cursor-pointer transition-all';
                
                if (currentSelectedService && currentSelectedService.service === service.service) {
                    serviceDiv.classList.add('bg-blue-50', 'border-blue-500', 'border-2');
                }

                const icon = getServiceIcon(service.category);
                const avgTime = service.average_time || 'N/A';

                serviceDiv.innerHTML = `
                    <div class="flex justify-between items-start mb-2">
                        <div class="flex items-center gap-3 flex-1">
                            <span class="text-2xl">${icon}</span>
                            <div class="flex-1">
                                <h4 class="font-medium text-gray-800">${service.name}</h4>
                                <p class="text-xs text-gray-500">${service.category}</p>
                            </div>
                        </div>
                        <span class="text-lg font-bold text-blue-600">${service.rate}€/1K</span>
                    </div>
                    <div class="grid grid-cols-3 gap-2 text-xs text-gray-600 mt-3">
                        <div class="bg-gray-50 p-2 rounded text-center">
                            <div class="text-gray-500">Min</div>
                            <div class="font-medium">${service.min}</div>
                        </div>
                        <div class="bg-gray-50 p-2 rounded text-center">
                            <div class="text-gray-500">Max</div>
                            <div class="font-medium">${service.max}</div>
                        </div>
                        <div class="bg-gray-50 p-2 rounded text-center">
                            <div class="text-gray-500">⏱️ Avg</div>
                            <div class="font-medium">${avgTime}</div>
                        </div>
                    </div>
                    <div class="flex gap-2 mt-3 text-xs">
                        ${service.refill ? '<span class="bg-green-100 text-green-700 px-2 py-1 rounded">✓ Refill</span>' : ''}
                        ${service.cancel ? '<span class="bg-orange-100 text-orange-700 px-2 py-1 rounded">✓ Cancel</span>' : ''}
                    </div>
                `;

                serviceDiv.onclick = () => selectServiceForOrder(service);
                browser.appendChild(serviceDiv);
            });
        }

        // Select service for order
        function selectServiceForOrder(service) {
            currentSelectedService = service;
            
            // Update service info display
            const serviceInfo = document.getElementById('selected-service-info');
            serviceInfo.classList.remove('hidden');
            
            document.getElementById('selected-service-name').textContent = service.name + ' - ' + service.category;
            document.getElementById('selected-service-rate').textContent = service.rate + '€ / 1000';
            document.getElementById('selected-service-minmax').textContent = service.min + ' - ' + service.max;
            document.getElementById('selected-service-avgtime').textContent = service.average_time || 'Non spécifié';
            
            // Update quantity hint
            document.getElementById('quantity-hint').textContent = `Min: ${service.min} | Max: ${service.max}`;
            
            // Enable submit button
            const submitBtn = document.getElementById('submit-order-btn');
            submitBtn.disabled = false;
            submitBtn.classList.remove('bg-gray-400', 'cursor-not-allowed');
            submitBtn.classList.add('bg-green-600', 'hover:bg-green-700', 'cursor-pointer');
            submitBtn.textContent = 'Créer la Commande SMM';
            
            // Refresh display
            displayServicesList();
            calculateOrderCost();
        }

        // Filter by category
        function filterByCategory(category) {
            currentCategoryFilter = category;
            
            // Update button states
            document.querySelectorAll('.category-filter-btn').forEach(btn => {
                btn.classList.remove('bg-blue-600', 'text-white', 'active');
                btn.classList.add('bg-gray-200');
            });
            
            event.target.classList.remove('bg-gray-200');
            event.target.classList.add('bg-blue-600', 'text-white', 'active');
            
            displayServicesList();
        }


async function deleteCategory(id, name) {
    if (!confirm("Supprimer la catégorie : " + name + " ?")) return;

    const formData = new FormData();
    formData.append("action", "delete_category");
    formData.append("id", id);

    const response = await fetch('../api/shop-dynamic.php', {
        method: 'POST',
        body: formData
    });

    const data = await response.json();

    if (data.success) {
        await loadCategoriesFromDB();
        showNotification("✅ Catégorie supprimée", "success");
    } else {
        showNotification("❌ " + data.message, "error");
    }
}





        // Filter services list (search)
        function filterServicesList() {
            displayServicesList();
        }




        // Calculate order cost
        function calculateOrderCost() {
            if (!currentSelectedService) {
                document.getElementById('order-cost').textContent = '0.00€';
                return;
            }

            const quantity = parseInt(document.getElementById('order-quantity').value) || 0;
            const rate = parseFloat(currentSelectedService.rate);
            const cost = (quantity / 1000) * rate;

            document.getElementById('order-cost').textContent = cost.toFixed(2) + '€';

            // Validate quantity
            const min = parseInt(currentSelectedService.min);
            const max = parseInt(currentSelectedService.max);
            const submitBtn = document.getElementById('submit-order-btn');

            if (quantity < min || quantity > max) {
                submitBtn.disabled = true;
                submitBtn.classList.remove('bg-green-600', 'hover:bg-green-700');
                submitBtn.classList.add('bg-red-400', 'cursor-not-allowed');
                submitBtn.textContent = `Quantité doit être entre ${min} et ${max}`;
            } else if (quantity > 0) {
                submitBtn.disabled = false;
                submitBtn.classList.remove('bg-red-400', 'bg-gray-400', 'cursor-not-allowed');
                submitBtn.classList.add('bg-green-600', 'hover:bg-green-700', 'cursor-pointer');
                submitBtn.textContent = 'Créer la Commande SMM';
            }
        }

        // Populate categories dropdown
        function populateCategoriesDropdown() {
            const categorySelect = document.getElementById('smm-category');
            if (!categorySelect) return;
            
            const categories = new Set();
            smmServices.forEach(service => {
                categories.add(service.category);
            });
            
            categorySelect.innerHTML = '<option value="">Sélectionner une catégorie</option>';
            Array.from(categories).sort().forEach(category => {
                const option = document.createElement('option');
                option.value = category;
                option.textContent = category;
                categorySelect.appendChild(option);
            });
        }

        // Update services dropdown based on selected category
        function updateServicesDropdown() {
            const categorySelect = document.getElementById('smm-category');
            const serviceSelect = document.getElementById('smm-service-select');
            const selectedCategory = categorySelect.value;
            
            if (!serviceSelect) return;
            
            serviceSelect.innerHTML = '<option value="">Sélectionner un service</option>';
            document.getElementById('service-details-simple').classList.add('hidden');
            
            if (!selectedCategory) return;
            
            const filteredServices = smmServices.filter(s => s.category === selectedCategory);
            filteredServices.forEach(service => {
                const option = document.createElement('option');
                option.value = service.service;
                option.textContent = service.name;
                option.dataset.service = JSON.stringify(service);
                serviceSelect.appendChild(option);
            });
        }

        // Update service details when service is selected
        function updateServiceDetails() {
            const serviceSelect = document.getElementById('smm-service-select');
            const selectedOption = serviceSelect.options[serviceSelect.selectedIndex];
            const detailsDiv = document.getElementById('service-details-simple');
            const avgTimeDisplay = document.getElementById('service-avgtime-display');
            const avgTimeValue = document.getElementById('service-avgtime-value');
            
            if (!selectedOption.dataset.service) {
                detailsDiv.classList.add('hidden');
                avgTimeDisplay.classList.add('hidden');
                currentSelectedService = null;
                return;
            }
            
            currentSelectedService = JSON.parse(selectedOption.dataset.service);
            
            document.getElementById('service-rate-simple').textContent = currentSelectedService.rate + '€/1K';
            document.getElementById('service-minmax-simple').textContent = currentSelectedService.min + ' - ' + currentSelectedService.max;
            
            // Display avg time below service dropdown
            const avgTime = currentSelectedService.average_time || 'Non spécifié';
            avgTimeValue.textContent = avgTime;
            avgTimeDisplay.classList.remove('hidden');
            
            detailsDiv.classList.remove('hidden');
            
            // Update quantity input attributes
            const quantityInput = document.getElementById('smm-quantity');
            if (quantityInput) {
                quantityInput.min = currentSelectedService.min;
                quantityInput.max = currentSelectedService.max;
                quantityInput.placeholder = `Min: ${currentSelectedService.min}, Max: ${currentSelectedService.max}`;
            }
            
            calculateSimpleOrderCost();
        }

        // Search services by ID or name with live preview
        function searchServices(searchTerm) {
            const searchResults = document.getElementById('search-results');
            const categorySelect = document.getElementById('smm-category');
            
            if (!searchTerm || searchTerm.trim().length < 2) {
                searchResults.classList.add('hidden');
                return;
            }
            
            searchTerm = searchTerm.toLowerCase().trim();
            
            // Search by ID or name
            const matchingServices = smmServices.filter(service => {
                const serviceId = service.service.toString().toLowerCase();
                const serviceName = service.name.toLowerCase();
                const serviceCategory = service.category.toLowerCase();
                
                return serviceId.includes(searchTerm) || 
                       serviceName.includes(searchTerm) || 
                       serviceCategory.includes(searchTerm);
            });
            
            if (matchingServices.length === 0) {
                searchResults.innerHTML = '<div class="p-3 text-center text-gray-500 text-sm">Aucun service trouvé</div>';
                searchResults.classList.remove('hidden');
                return;
            }
            
            // Show first 10 results
            searchResults.innerHTML = '';
            const resultsToShow = matchingServices.slice(0, 10);
            
            resultsToShow.forEach(service => {
                const resultItem = document.createElement('div');
                resultItem.className = 'p-3 hover:bg-gray-100 cursor-pointer border-b border-gray-100 last:border-0';
                
                const icon = getServiceIcon(service.category);
                
                resultItem.innerHTML = `
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-2 flex-1">
                            <span>${icon}</span>
                            <div class="flex-1">
                                <p class="text-sm font-medium text-gray-800">${service.name}</p>
                                <p class="text-xs text-gray-500">ID: ${service.service} • ${service.category}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="text-sm font-bold text-blue-600">${service.rate}€/1K</p>
                            <p class="text-xs text-gray-500">⏱️ ${service.average_time || 'N/A'}</p>
                        </div>
                    </div>
                `;
                
                resultItem.onclick = () => {
                    selectServiceFromSearch(service);
                };
                
                searchResults.appendChild(resultItem);
            });
            
            if (matchingServices.length > 10) {
                const moreResults = document.createElement('div');
                moreResults.className = 'p-2 text-center text-xs text-gray-500 bg-gray-50';
                moreResults.textContent = `+${matchingServices.length - 10} autres résultats...`;
                searchResults.appendChild(moreResults);
            }
            
            searchResults.classList.remove('hidden');
        }

        // Select service from search results
        function selectServiceFromSearch(service) {
            currentSelectedService = service;
            
            // Update category dropdown
            const categorySelect = document.getElementById('smm-category');
            categorySelect.value = service.category;
            
            // Update services dropdown
            updateServicesDropdown();
            
            // Select the service in dropdown
            const serviceSelect = document.getElementById('smm-service-select');
            serviceSelect.value = service.service;
            
            // Update details
            updateServiceDetails();
            
            // Hide search results
            document.getElementById('search-results').classList.add('hidden');
            
            // Clear search input
            document.getElementById('service-search-input').value = '';
            
            showNotification(`✅ Service sélectionné: ${service.name}`, 'info');
        }

        // Show search results
        function showSearchResults() {
            const searchInput = document.getElementById('service-search-input');
            if (searchInput.value.trim().length >= 2) {
                searchServices(searchInput.value);
            }
        }

        // Hide search results when clicking outside
        document.addEventListener('click', function(e) {
            const searchInput = document.getElementById('service-search-input');
            const searchResults = document.getElementById('search-results');
            
            if (searchResults && !searchResults.contains(e.target) && e.target !== searchInput) {
                searchResults.classList.add('hidden');
            }
        });

        // Calculate cost for simple order form
        function calculateSimpleOrderCost() {
            if (!currentSelectedService) {
                document.getElementById('order-cost-simple').textContent = '0.00€';
                return;
            }
            
            const quantity = parseInt(document.getElementById('smm-quantity').value) || 0;
            const rate = parseFloat(currentSelectedService.rate);
            const cost = (quantity / 1000) * rate;
            
            document.getElementById('order-cost-simple').textContent = cost.toFixed(2) + '€';
        }

        // Create simple SMM order
        async function createSMMOrderSimple(event) {
            event.preventDefault();
            
            if (!smmApiKey) {
                showNotification('❌ Veuillez d\'abord connecter votre clé API', 'error');
                return;
            }

            if (!currentSelectedService) {
                showNotification('❌ Veuillez sélectionner un service', 'error');
                return;
            }

            const quantity = parseInt(document.getElementById('smm-quantity').value);
            const link = document.getElementById('smm-url').value.trim();
            const client = document.getElementById('smm-client').value.trim();

            if (!quantity || !link || !client) {
                showNotification('❌ Veuillez remplir tous les champs', 'error');
                return;
            }

            // Validate quantity
            const min = parseInt(currentSelectedService.min);
            const max = parseInt(currentSelectedService.max);
            
            if (quantity < min || quantity > max) {
                showNotification(`❌ Quantité doit être entre ${min} et ${max}`, 'error');
                return;
            }

            // Calculate cost
            const cost = (quantity / 1000) * parseFloat(currentSelectedService.rate);

            try {
                showNotification('🔄 Création de la commande...', 'info');

                const formData = new FormData();
                formData.append('key', smmApiKey);
                formData.append('action', 'add');
                formData.append('service', currentSelectedService.service);
                formData.append('link', link);
                formData.append('quantity', quantity);

                const response = await fetch(SMM_API_URL, {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.order) {
                    const order = {
                        id: data.order,
                        service: currentSelectedService.name,
                        category: currentSelectedService.category,
                        link: link,
                        quantity: quantity,
                        cost: cost.toFixed(2),
                        client: client,
                        status: 'Pending',
                        date: new Date().toISOString(),
                        serviceId: currentSelectedService.service
                    };

                    smmOrders.push(order);
                    localStorage.setItem('smm_orders', JSON.stringify(smmOrders));
                    
                    // Save to centralized orders
                    const centralizedOrder = {
                        id: `#SMM-${data.order}`,
                        name: currentSelectedService.name,
                        description: `${quantity} unités - ${link}`,
                        client: client,
                        price: cost.toFixed(2),
                        status: 'Pending',
                        date: new Date().toISOString(),
                        type: 'SMM',
                        icon: '📱'
                    };
                    saveOrder(centralizedOrder);

                    showNotification(`✅ Commande #${data.order} créée avec succès!`, 'success');
                    showNotification(`💰 Coût: ${cost.toFixed(2)}€`, 'info');
                    showNotification(`📋 Commande ajoutée à Gestion des Commandes`, 'info');

                    // Reset form
                    event.target.reset();
                    document.getElementById('service-details-simple').classList.add('hidden');
                    document.getElementById('order-cost-simple').textContent = '0.00€';
                    currentSelectedService = null;

                    // Refresh balance and summary
                    await checkAPIStatus();
                    updateBalanceSummary();
                } else {
                    throw new Error(data.error || 'Erreur lors de la création de la commande');
                }
            } catch (error) {
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        }

        // Update balance summary
        function updateBalanceSummary() {
            const balanceSummary = document.getElementById('balance-summary');
            const ordersCountSummary = document.getElementById('orders-count-summary');
            
            if (balanceSummary) {
                const balance = document.getElementById('account-balance').textContent;
                balanceSummary.textContent = balance;
            }
            
            if (ordersCountSummary) {
                ordersCountSummary.textContent = smmOrders.length + ' commandes';
            }
        }

        // Load services and populate dropdowns when showing new-order
        async function loadServicesForSimpleOrder() {
            if (!smmApiKey) {
                showNotification('❌ Veuillez d\'abord configurer votre clé API', 'error');
                return;
            }

            if (smmServices.length === 0) {
                await loadServices();
            }
            
            populateCategoriesDropdown();
            updateBalanceSummary();
        }

        // Add event listener for quantity input
        document.addEventListener('DOMContentLoaded', () => {
            const quantityInput = document.getElementById('smm-quantity');
            if (quantityInput) {
                quantityInput.addEventListener('input', calculateSimpleOrderCost);
            }
        });

        // Create SMM Order (New version for new interface)
        async function createSMMOrderNew(event) {
            event.preventDefault();
            
            if (!smmApiKey) {
                showNotification('❌ Veuillez d\'abord connecter votre clé API', 'error');
                return;
            }

            if (!currentSelectedService) {
                showNotification('❌ Veuillez sélectionner un service', 'error');
                return;
            }

            const link = document.getElementById('order-link').value.trim();
            const quantity = parseInt(document.getElementById('order-quantity').value);
            const client = document.getElementById('order-client').value.trim();

            if (!link || !quantity || !client) {
                showNotification('❌ Veuillez remplir tous les champs', 'error');
                return;
            }

            // Validate quantity
            const min = parseInt(currentSelectedService.min);
            const max = parseInt(currentSelectedService.max);
            
            if (quantity < min || quantity > max) {
                showNotification(`❌ Quantité doit être entre ${min} et ${max}`, 'error');
                return;
            }

            // Calculate cost
            const cost = (quantity / 1000) * parseFloat(currentSelectedService.rate);

            try {
                showNotification('🔄 Création de la commande...', 'info');

                const formData = new FormData();
                formData.append('key', smmApiKey);
                formData.append('action', 'add');
                formData.append('service', currentSelectedService.service);
                formData.append('link', link);
                formData.append('quantity', quantity);

                const response = await fetch(SMM_API_URL, {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.order) {
                    const order = {
                        id: data.order,
                        service: currentSelectedService.name,
                        category: currentSelectedService.category,
                        link: link,
                        quantity: quantity,
                        cost: cost.toFixed(2),
                        client: client,
                        status: 'Pending',
                        date: new Date().toISOString(),
                        serviceId: currentSelectedService.service
                    };

                    smmOrders.push(order);
                    localStorage.setItem('smm_orders', JSON.stringify(smmOrders));

                    showNotification(`✅ Commande #${data.order} créée avec succès!`, 'success');
                    showNotification(`💰 Coût: ${cost.toFixed(2)}€`, 'info');

                    // Reset form
                    document.getElementById('order-form').reset();
                    currentSelectedService = null;
                    document.getElementById('selected-service-info').classList.add('hidden');
                    document.getElementById('order-cost').textContent = '0.00€';
                    
                    const submitBtn = document.getElementById('submit-order-btn');
                    submitBtn.disabled = true;
                    submitBtn.classList.remove('bg-green-600', 'hover:bg-green-700');
                    submitBtn.classList.add('bg-gray-400', 'cursor-not-allowed');
                    submitBtn.textContent = 'Sélectionnez un service';

                    // Refresh display
                    displayServicesList();

                    // Refresh balance
                    await checkAPIStatus();
                } else {
                    throw new Error(data.error || 'Erreur lors de la création de la commande');
                }
            } catch (error) {
                showNotification('❌ Erreur: ' + error.message, 'error');
            }
        }
        
        
        
        // --- helpers globaux (assure qu'ils sont accessibles depuis onclick inline) ---
window.currentProductId = window.currentProductId || null;

window.showNotification = window.showNotification || function(msg, type='info') {
    // Simple fallback si tu n'as pas de showNotification
    console.log('[notif]', type, msg);
    alert(msg);
};

// Mettre à jour max uses
window.updateMaxUses = async function(stockId, newValue) {
    try {
        newValue = parseInt(newValue);
        if (!newValue || newValue < 1) return showNotification('Valeur invalide', 'error');

        const fd = new FormData();
        fd.append('action', 'update_max_uses');
        fd.append('stock_id', stockId);
        fd.append('max_uses', newValue);

        const res = await fetch('../api/shop-dynamic.php', { method: 'POST', body: fd });
        const data = await res.json();
        if (data.success) {
            showNotification('✅ Limite mise à jour', 'success');
            // refresh UI
            if (window.currentProductId) await manageAccounts(window.currentProductId);
            if (typeof loadProductsFromDB === 'function') loadProductsFromDB();
        } else {
            showNotification('❌ ' + (data.message || 'Erreur'), 'error');
        }
    } catch (e) {
        console.error(e);
        showNotification('Erreur réseau', 'error');
    }
};

// Supprimer compte (stockId = id de product_stock)
window.removeAccount = async function(productId, stockId) {
    if (!confirm('Supprimer ce compte ?')) return;
    try {
        const fd = new FormData();
        fd.append('action', 'remove_stock');
        fd.append('stock_id', stockId);

        const res = await fetch('../api/shop-dynamic.php', { method: 'POST', body: fd });
        const data = await res.json();
        if (data.success) {
            showNotification('✅ Supprimé', 'success');
            await manageAccounts(productId);
            if (typeof loadProductsFromDB === 'function') loadProductsFromDB();
        } else {
            showNotification('❌ ' + (data.message || 'Erreur suppression'), 'error');
        }
    } catch (e) {
        console.error(e);
        showNotification('Erreur réseau', 'error');
    }
};

// addNewAccount basic wrapper (si tu n'as pas la version complète déjà)
window.addNewAccount = window.addNewAccount || async function(productId, accountType) {
    // If you already have a more advanced function, keep it.
    const code = prompt('Entrer le code / email:');
    if (!code) return;
    let isReusable = accountType === 'reusable' ? 1 : 0;
    let max_uses = 1;
    if (isReusable) {
        const m = prompt('Nombre de fois utilisable (ex: 5):', '5');
        if (!m || isNaN(m) || m < 1) return showNotification('Nombre invalide','error');
        max_uses = parseInt(m);
    }
    const fd = new FormData();
    fd.append('action','add_stock');
    fd.append('item_id',productId);
    fd.append('product_code',code);
    fd.append('product_key','');
    fd.append('notes','Ajout via UI');
    fd.append('is_reusable', isReusable);
    fd.append('max_uses', max_uses);

    const res = await fetch('../api/shop-dynamic.php', { method: 'POST', body: fd });
    const d = await res.json();
    if (d.success) {
        showNotification('✅ Ajouté', 'success');
        await manageAccounts(productId);
        if (typeof loadProductsFromDB === 'function') loadProductsFromDB();
    } else {
        showNotification('❌ ' + (d.message || 'Erreur'), 'error');
    }
};

    </script>
</body>
</html>
