<?php
/**
 * Page d'accueil - Redirection automatique selon le rôle
 */
session_start();

// Si pas connecté, rediriger vers login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['session_token'])) {
    header('Location: /login.html');
    exit;
}

// Récupérer le rôle de l'utilisateur
require_once 'config/database.php';

try {
    $pdo = getDB();
    
    $stmt = $pdo->prepare("
        SELECT u.*, r.name as role_name
        FROM users u
        LEFT JOIN roles r ON u.role_id = r.id
        WHERE u.id = ? AND u.status = 'active'
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    
    if (!$user) {
        // Utilisateur non trouvé, déconnecter
        session_destroy();
        header('Location: /login.html');
        exit;
    }
    
    // Redirection selon le rôle
    $role = strtolower($user['role_name']);
    
    // Admins et employés → Interface employé (1a.php)
    if (in_array($role, ['super_admin', 'admin', 'employee', 'designer', 'developer', 'marketing'])) {
        header('Location: /html/1a.php');
        exit;
    }
    
    // Clients → Interface client (client-app.php)
    if ($role === 'client' || $role === 'customer' || $role === 'user') {
        header('Location: /html/client-app.php');
        exit;
    }
    
    // Par défaut, rediriger selon l'ID du rôle si le nom n'est pas reconnu
    // Role ID 1 = Super Admin, 2 = Admin, 3 = Client (généralement)
    if ($user['role_id'] <= 2) {
        header('Location: /html/1a.php');
    } else {
        header('Location: /html/client-app.php');
    }
    exit;
    
} catch (PDOException $e) {
    // Erreur DB, rediriger vers login
    error_log("Index.php DB Error: " . $e->getMessage());
    session_destroy();
    header('Location: /login.html');
    exit;
}
