<?php
/**
 * Insertion des catégories et produits en production
 * Basé sur les données fournies par l'utilisateur
 */

require_once 'config/database.php';

try {
    $pdo = getDB();
    $pdo->beginTransaction();
    
    echo "🛍️ Insertion des données de la boutique...\n\n";
    
    // Supprimer les anciennes catégories
    echo "1. Nettoyage des anciennes données...\n";
    $pdo->exec("DELETE FROM shop_items");
    $pdo->exec("DELETE FROM shop_categories");
    $pdo->exec("ALTER TABLE shop_categories AUTO_INCREMENT = 1");
    $pdo->exec("ALTER TABLE shop_items AUTO_INCREMENT = 1");
    echo "   ✅ Tables nettoyées\n\n";
    
    // Catégories principales
    echo "2. Création des catégories principales...\n";
    $categories = [
        ['Streaming', 'streaming', '🎬', 'Services de streaming vidéo'],
        ['Logiciels', 'logiciels', '💻', 'Logiciels et applications professionnelles'],
        ['Formations', 'formations', '🎓', 'Cours et formations en ligne'],
        ['Gift Cards', 'gift-cards', '🎁', 'Cartes cadeaux numériques']
    ];
    
    $stmt = $pdo->prepare("
        INSERT INTO shop_categories (name, slug, type, icon, description, sort_order, is_active)
        VALUES (?, ?, 'product', ?, ?, ?, 1)
    ");
    
    $categoryMap = [];
    foreach ($categories as $index => $cat) {
        $stmt->execute([$cat[0], $cat[1], $cat[2], $cat[3], $index + 1]);
        $id = $pdo->lastInsertId();
        $categoryMap[$cat[0]] = $id;
        echo "   ✅ {$cat[2]} {$cat[0]} (ID: {$id})\n";
    }
    
    echo "\n3. Création des produits...\n";
    
    // Get admin user (assuming ID 1)
    $adminId = 1;
    
    // Produits par catégorie
    $products = [
        // Streaming
        ['Netflix', 'Streaming', 15.99, '🎬', 'Abonnement Netflix Premium - Accès illimité', '1 mois'],
        ['Disney+', 'Streaming', 8.99, '🎬', 'Abonnement Disney Plus - Tout le contenu Disney', '1 mois'],
        ['Prime Video', 'Streaming', 6.99, '🎬', 'Amazon Prime Video - Films et séries', '1 mois'],
        
        // Logiciels
        ['Adobe Creative Cloud', 'Logiciels', 54.99, '💻', 'Suite complète Adobe CC - Photoshop, Illustrator, etc.', 'Accès immédiat'],
        ['Microsoft 365', 'Logiciels', 69.99, '💻', 'Pack Office complet - Word, Excel, PowerPoint', '1 an'],
        
        // Formations
        ['Udemy Premium', 'Formations', 199.99, '🎓', 'Accès illimité à plus de 150,000 cours Udemy', '1 an'],
        ['Coursera Plus', 'Formations', 399.99, '🎓', 'Certificats professionnels et cours universitaires', '1 an'],
        
        // Gift Cards
        ['Amazon Gift Card', 'Gift Cards', 50.00, '🎁', 'Carte cadeau Amazon valable sur tout le site', 'Code numérique'],
        ['Google Play Gift Card', 'Gift Cards', 25.00, '🎁', 'Carte cadeau Google Play pour apps et jeux', 'Code numérique']
    ];
    
    $stmt = $pdo->prepare("
        INSERT INTO shop_items 
        (category_id, type, name, slug, description, short_description, price, icon, delivery_time, status, created_by, is_subscription, sort_order)
        VALUES (?, 'product', ?, ?, ?, ?, ?, ?, ?, 'available', ?, 1, ?)
    ");
    
    foreach ($products as $index => $prod) {
        $catId = $categoryMap[$prod[1]];
        $slug = strtolower(str_replace(' ', '-', $prod[0]));
        
        $stmt->execute([
            $catId,
            $prod[0],  // name
            $slug,
            $prod[4],  // description
            $prod[4],  // short_description
            $prod[2],  // price
            $prod[3],  // icon
            $prod[5],  // delivery_time
            $adminId,
            $index + 1  // sort_order
        ]);
        
        echo "   ✅ {$prod[3]} {$prod[0]} - {$prod[2]}€ (Catégorie: {$prod[1]})\n";
    }
    
    $pdo->commit();
    
    echo "\n✅ DONNÉES INSÉRÉES AVEC SUCCÈS !\n\n";
    echo "📊 Résumé :\n";
    echo "   - " . count($categories) . " catégories créées\n";
    echo "   - " . count($products) . " produits créés\n\n";
    
    echo "🎯 Prochaines étapes :\n";
    echo "   1. Connectez-vous à l'application client\n";
    echo "   2. Allez dans 'Services et Produits'\n";
    echo "   3. Vous verrez maintenant toutes vos catégories et produits !\n\n";
    
} catch (PDOException $e) {
    $pdo->rollBack();
    echo "❌ Erreur : " . $e->getMessage() . "\n";
    exit(1);
}
