-- ============================================
-- Script d'installation pour Produits Digitaux
-- À exécuter dans phpMyAdmin
-- ============================================

-- Table des catégories (Niveau 1 & 2)
CREATE TABLE IF NOT EXISTS `shop_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `type` enum('service','product') DEFAULT 'product' COMMENT 'Type général: service ou produit',
  `icon` varchar(50) DEFAULT '📦',
  `description` text,
  `parent_id` int(11) DEFAULT NULL COMMENT 'Pour sous-catégories',
  `is_active` tinyint(1) DEFAULT '1',
  `sort_order` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_type` (`type`),
  KEY `idx_parent` (`parent_id`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Catégories de PRODUITS par défaut (type='product')
INSERT INTO `shop_categories` (`name`, `slug`, `type`, `icon`, `description`, `is_active`, `sort_order`) VALUES
('Streaming', 'streaming', 'product', '🎬', 'Abonnements streaming (Netflix, Disney+, Spotify, etc.)', 1, 1),
('Logiciels', 'logiciels', 'product', '💻', 'Licences logiciels (Office, Adobe, Antivirus, etc.)', 1, 2),
('Formations', 'formations', 'product', '🎓', 'Cours en ligne et formations', 1, 3),
('Gift Cards', 'gift-cards', 'product', '🎁', 'Cartes cadeaux diverses', 1, 4);

-- Table des produits individuels (Niveau 3)
CREATE TABLE IF NOT EXISTS `shop_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL COMMENT 'Référence à shop_categories',
  `type` enum('service','product') NOT NULL DEFAULT 'product' COMMENT 'Type: service ou product',
  `name` varchar(255) NOT NULL COMMENT 'Ex: Netflix Premium',
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `short_description` varchar(500) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `delivery_time` varchar(100) DEFAULT NULL COMMENT 'Durée/Validité',
  `is_subscription` tinyint(1) DEFAULT 0,
  `subscription_period` enum('monthly','yearly') DEFAULT NULL,
  `status` enum('available','unavailable','coming_soon') DEFAULT 'available',
  `featured` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_category` (`category_id`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  KEY `idx_featured` (`featured`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `shop_items_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `shop_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table du stock (comptes disponibles)
CREATE TABLE IF NOT EXISTS `product_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL COMMENT 'Référence à shop_items',
  `product_code` varchar(255) NOT NULL COMMENT 'Email ou Code',
  `product_key` text COMMENT 'Mot de passe ou Clé',
  `notes` text COMMENT 'Infos supplémentaires',
  `status` enum('available','sold','reserved') DEFAULT 'available',
  `sold_to_user_id` int(11) DEFAULT NULL,
  `sold_at` timestamp NULL DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_item` (`item_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_stock_item` FOREIGN KEY (`item_id`) REFERENCES `shop_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Produits d'exemple (optionnel)
-- ============================================

-- Exemple: Netflix dans Streaming
INSERT INTO `shop_items` (`category_id`, `type`, `name`, `slug`, `description`, `price`, `icon`, `delivery_time`, `status`, `created_by`) 
SELECT id, 'product', 'Netflix Premium', 'netflix-premium', 'Compte Netflix Premium 4K - 4 écrans simultanés', 15.00, '🎬', '1 mois', 'available', 1
FROM `shop_categories` WHERE `slug` = 'streaming' LIMIT 1;

-- Exemple: Office 365 dans Logiciels
INSERT INTO `shop_items` (`category_id`, `type`, `name`, `slug`, `description`, `price`, `icon`, `delivery_time`, `status`, `created_by`) 
SELECT id, 'product', 'Office 365', 'office-365', 'Licence Microsoft Office 365 complète', 35.00, '💻', '1 an', 'available', 1
FROM `shop_categories` WHERE `slug` = 'logiciels' LIMIT 1;

-- ============================================
-- Fin du script
-- ============================================
