<?php
/**
 * Script d'initialisation des rôles par défaut
 * Crée les 4 rôles de base s'ils n'existent pas déjà
 */

require_once 'config/database.php';

try {
    $pdo = getDB();
    
    echo "=== INITIALISATION DES RÔLES PAR DÉFAUT ===\n\n";
    
    // Définir les rôles par défaut
    $defaultRoles = [
        [
            'name' => 'super_admin',
            'display_name' => 'Super Administrateur',
            'description' => 'Accès complet à toutes les fonctionnalités du système',
            'permissions' => json_encode(['all' => true])
        ],
        [
            'name' => 'admin',
            'display_name' => 'Administrateur',
            'description' => 'Gestion complète des utilisateurs, commandes et paramètres',
            'permissions' => json_encode(['all' => true])
        ],
        [
            'name' => 'employee',
            'display_name' => 'Employé',
            'description' => 'Gestion des commandes, projets et clients',
            'permissions' => json_encode([
                'view_users' => true,
                'view_orders' => true,
                'manage_orders' => true,
                'create_orders' => true,
                'view_wallet' => true,
                'manage_projects' => true,
                'upload_files' => true,
                'view_reports' => true
            ])
        ],
        [
            'name' => 'client',
            'display_name' => 'Client',
            'description' => 'Accès client standard avec gestion des commandes et projets personnels',
            'permissions' => json_encode([
                'view_wallet' => true,
                'view_orders' => true,
                'create_orders' => true,
                'upload_files' => true
            ])
        ]
    ];
    
    foreach ($defaultRoles as $role) {
        // Vérifier si le rôle existe déjà
        $stmt = $pdo->prepare("SELECT id FROM roles WHERE name = ?");
        $stmt->execute([$role['name']]);
        $existing = $stmt->fetch();
        
        if ($existing) {
            // Mettre à jour les permissions
            $stmt = $pdo->prepare("
                UPDATE roles 
                SET display_name = ?, description = ?, permissions = ?
                WHERE name = ?
            ");
            $stmt->execute([
                $role['display_name'],
                $role['description'],
                $role['permissions'],
                $role['name']
            ]);
            echo "✓ Rôle mis à jour: {$role['display_name']}\n";
        } else {
            // Créer le nouveau rôle
            $stmt = $pdo->prepare("
                INSERT INTO roles (name, display_name, description, permissions)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([
                $role['name'],
                $role['display_name'],
                $role['description'],
                $role['permissions']
            ]);
            echo "✓ Rôle créé: {$role['display_name']}\n";
        }
    }
    
    // Définir le rôle par défaut pour les nouveaux utilisateurs
    echo "\n📋 Configuration du rôle par défaut:\n";
    echo "   Tous les nouveaux utilisateurs seront automatiquement assignés au rôle 'Client'\n";
    
    // Vérifier les utilisateurs sans rôle et leur assigner le rôle client
    $stmt = $pdo->prepare("SELECT id FROM roles WHERE name = 'client'");
    $stmt->execute();
    $clientRole = $stmt->fetch();
    
    if ($clientRole) {
        $stmt = $pdo->prepare("
            UPDATE users 
            SET role_id = ? 
            WHERE role_id IS NULL OR role_id = 0 OR role_id NOT IN (SELECT id FROM roles)
        ");
        $stmt->execute([$clientRole['id']]);
        $updated = $stmt->rowCount();
        
        if ($updated > 0) {
            echo "   ✓ {$updated} utilisateur(s) sans rôle ont été assignés au rôle 'Client'\n";
        }
    }
    
    echo "\n=== RÉSUMÉ DES RÔLES ===\n\n";
    
    $stmt = $pdo->query("SELECT id, name, display_name, description FROM roles ORDER BY id");
    $roles = $stmt->fetchAll();
    
    foreach ($roles as $role) {
        echo "ID: {$role['id']}\n";
        echo "Nom: {$role['name']}\n";
        echo "Affichage: {$role['display_name']}\n";
        echo "Description: {$role['description']}\n";
        echo "---\n\n";
    }
    
    echo "✅ Initialisation terminée avec succès!\n";
    echo "📌 Les nouveaux utilisateurs seront automatiquement assignés au rôle 'Client'\n";
    echo "📌 Les admins peuvent modifier les rôles via /admin-roles.php\n";
    
} catch (Exception $e) {
    echo "❌ Erreur: " . $e->getMessage() . "\n";
}
