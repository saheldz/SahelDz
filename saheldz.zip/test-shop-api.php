<?php
/**
 * Script de diagnostic pour tester l'API de la boutique
 */

require_once 'config/database.php';

echo "=== DIAGNOSTIC BOUTIQUE ===\n\n";

try {
    $pdo = getDB();
    
    // Test 1: Vérifier les catégories
    echo "1. CATEGORIES:\n";
    $stmt = $pdo->query("SELECT * FROM shop_categories ORDER BY id");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($categories)) {
        echo "   ❌ AUCUNE CATEGORIE trouvée dans la base de données\n";
    } else {
        echo "   ✅ " . count($categories) . " catégorie(s) trouvée(s):\n";
        foreach ($categories as $cat) {
            echo "      - ID: {$cat['id']}, Nom: {$cat['name']}, Type: {$cat['type']}, Actif: " . ($cat['is_active'] ? 'Oui' : 'Non') . "\n";
        }
    }
    
    echo "\n";
    
    // Test 2: Vérifier les items (services/produits)
    echo "2. ITEMS (Services/Produits):\n";
    $stmt = $pdo->query("SELECT * FROM shop_items ORDER BY id");
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($items)) {
        echo "   ❌ AUCUN ITEM trouvé dans la base de données\n";
    } else {
        echo "   ✅ " . count($items) . " item(s) trouvé(s):\n";
        foreach ($items as $item) {
            echo "      - ID: {$item['id']}, Nom: {$item['name']}, Type: {$item['type']}, ";
            echo "Catégorie ID: {$item['category_id']}, Prix: {$item['price']}€, ";
            echo "Status: {$item['status']}\n";
        }
    }
    
    echo "\n";
    
    // Test 3: Vérifier la structure des tables
    echo "3. STRUCTURE DES TABLES:\n";
    
    // shop_categories
    echo "   Table shop_categories:\n";
    $stmt = $pdo->query("DESCRIBE shop_categories");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($columns as $col) {
        echo "      - {$col['Field']} ({$col['Type']})\n";
    }
    
    echo "\n   Table shop_items:\n";
    $stmt = $pdo->query("DESCRIBE shop_items");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($columns as $col) {
        echo "      - {$col['Field']} ({$col['Type']})\n";
    }
    
    echo "\n";
    
    // Test 4: Simuler l'API
    echo "4. TEST API:\n";
    
    // Test get_categories
    echo "   GET categories (type=service):\n";
    $stmt = $pdo->prepare("SELECT * FROM shop_categories WHERE is_active = 1 AND type = ? ORDER BY sort_order ASC, name ASC");
    $stmt->execute(['service']);
    $apiCats = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "      Résultat: " . count($apiCats) . " catégorie(s)\n";
    
    // Test get_items
    echo "   GET items (type=service):\n";
    $stmt = $pdo->prepare("SELECT i.*, c.name as category_name FROM shop_items i JOIN shop_categories c ON i.category_id = c.id WHERE i.type = ? AND i.status != 'unavailable' ORDER BY i.sort_order ASC");
    $stmt->execute(['service']);
    $apiItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "      Résultat: " . count($apiItems) . " item(s)\n";
    
    echo "\n";
    
    // Recommandations
    echo "=== RECOMMANDATIONS ===\n\n";
    
    if (empty($categories)) {
        echo "⚠️  PROBLÈME: Aucune catégorie dans la base de données\n";
        echo "   → Allez dans admin-shop.php et créez des catégories\n\n";
    }
    
    if (empty($items)) {
        echo "⚠️  PROBLÈME: Aucun item dans la base de données\n";
        echo "   → Allez dans admin-shop.php et créez des services/produits\n\n";
    }
    
    if (!empty($categories) && !empty($items)) {
        // Vérifier si les items ont des catégories valides
        $categoryIds = array_column($categories, 'id');
        $orphanItems = [];
        foreach ($items as $item) {
            if (!in_array($item['category_id'], $categoryIds)) {
                $orphanItems[] = $item;
            }
        }
        
        if (!empty($orphanItems)) {
            echo "⚠️  PROBLÈME: " . count($orphanItems) . " item(s) avec catégorie invalide\n";
            foreach ($orphanItems as $item) {
                echo "   - {$item['name']} (catégorie ID: {$item['category_id']} n'existe pas)\n";
            }
            echo "\n";
        }
        
        // Vérifier les items inactifs
        $inactiveItems = array_filter($items, function($item) {
            return $item['status'] === 'unavailable';
        });
        
        if (!empty($inactiveItems)) {
            echo "ℹ️  INFO: " . count($inactiveItems) . " item(s) avec status 'unavailable' (ne s'affichera pas)\n\n";
        }
    }
    
    echo "=== FIN DU DIAGNOSTIC ===\n";
    
} catch (Exception $e) {
    echo "❌ ERREUR: " . $e->getMessage() . "\n";
}
