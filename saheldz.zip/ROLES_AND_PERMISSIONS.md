# Système de Rôles et Permissions - DigiServices

## Vue d'ensemble

Le système comprend 4 rôles principaux avec des interfaces et permissions dédiées.

## Rôles et Interfaces

### 1. Super Admin
- **Interface**: `/admin-dashboard.php`
- **Permissions**: Toutes les permissions (all: true)
- **Accès**:
  - Gestion complète des utilisateurs
  - Gestion des rôles et permissions
  - Gestion des wallets (ajouter/retirer des fonds)
  - Voir tous les rapports et logs
  - Configuration système (SMTP, Addons)
  - Impersonation des utilisateurs

### 2. Admin
- **Interface**: `/admin-dashboard.php`
- **Permissions**: Toutes les permissions (all: true)
- **Accès**: Identique au Super Admin

### 3. Employé (Employee)
- **Interface**: `/employee-dashboard.php`
- **Permissions**:
  - `view_users`: Voir les utilisateurs/clients
  - `view_orders`: Voir les commandes
  - `manage_orders`: Gérer les commandes
  - `create_orders`: Créer des commandes
  - `view_wallet`: Voir son propre wallet
  - `manage_projects`: Gérer les projets
  - `upload_files`: Upload de fichiers
  - `view_reports`: Voir les rapports
- **Accès**:
  - Dashboard employé avec tâches et projets
  - Gestion des commandes assignées
  - Accès aux outils de travail (Branding, Projets)
  - Consultation des clients

### 4. Client
- **Interface**: `/client-dashboard.php`
- **Permissions**:
  - `view_wallet`: Voir son wallet
  - `view_orders`: Voir ses propres commandes
  - `create_orders`: Passer des commandes
  - `upload_files`: Upload dans ses projets
- **Accès**:
  - Dashboard client personnalisé
  - Consultation du solde et transactions
  - Accès aux services (Branding, Développement, etc.)
  - Gestion de ses propres projets

## Flux d'Authentification

```
Connexion (login.html)
    ↓
Authentification (api/auth.php)
    ↓
Redirection (index.php)
    ↓
    ├─→ Admin/Super Admin → /admin-dashboard.php
    ├─→ Employé → /employee-dashboard.php
    └─→ Client → /client-dashboard.php
```

## Installation et Configuration

### 1. Mettre à jour les permissions des rôles

Exécutez ce script pour configurer les permissions appropriées:

```bash
php update-roles-permissions.php
```

Ce script va:
- Définir les permissions complètes pour Super Admin et Admin
- Configurer les permissions de travail pour les Employés
- Configurer les permissions limitées pour les Clients

### 2. Vérifier la configuration

Le script affiche un résumé des permissions après mise à jour.

## Fichiers Modifiés/Créés

### Nouveaux fichiers:
- `/client-dashboard.php` - Interface client
- `/employee-dashboard.php` - Interface employé
- `/update-roles-permissions.php` - Script de configuration des permissions
- `ROLES_AND_PERMISSIONS.md` - Cette documentation

### Fichiers modifiés:
- `/index.php` - Redirection basée sur le rôle
- `/api/admin.php` - Fix pour le bouton "Retour Admin" en mode impersonation

## Fonctionnalités par Interface

### Admin Dashboard (`/admin-dashboard.php`)
- Stats globales (utilisateurs, wallets, transactions, rôles)
- Actions rapides vers toutes les sections admin
- Utilisateurs et transactions récents
- Accès à toutes les fonctionnalités admin

### Employee Dashboard (`/employee-dashboard.php`)
- Stats personnelles (tâches, projets, commandes assignées)
- Actions rapides vers outils de travail
- Tâches récentes et projets en cours
- Accès aux services de production

### Client Dashboard (`/client-dashboard.php`)
- Wallet et solde disponible
- Commandes et projets actifs
- Services disponibles (Branding, Développement, Marketing, Multimédia)
- Historique des transactions
- Bouton de rechargement de compte

## Tests Recommandés

### 1. Tester les redirections

Connectez-vous avec différents types d'utilisateurs:

- **Admin**: Devrait être redirigé vers `/admin-dashboard.php`
- **Employé**: Devrait être redirigé vers `/employee-dashboard.php`
- **Client**: Devrait être redirigé vers `/client-dashboard.php`

### 2. Tester l'impersonation

1. Connectez-vous en tant qu'admin
2. Allez sur `/admin-users.php`
3. Cliquez sur "Se connecter en tant que" pour un client
4. Vérifiez que vous voyez l'interface client
5. Cliquez sur "Retour Admin" dans la bannière orange
6. Vérifiez que vous revenez en mode admin ✓ (Problème corrigé)

### 3. Tester les permissions

Vérifiez que:
- Les clients ne peuvent pas accéder aux pages admin
- Les employés ont accès aux outils de travail mais pas aux fonctions admin critiques
- Les admins ont accès à tout

## Sécurité

- Toutes les pages sont protégées par `config/auth-check.php`
- Les API vérifient les permissions via `isAdmin()` et les permissions JSON
- Le système d'impersonation est sécurisé et traçable
- Les mots de passe sont hashés avec bcrypt

## Support et Maintenance

Pour ajouter un nouveau rôle:
1. Créer le rôle dans la base de données
2. Définir les permissions JSON
3. Créer une interface dédiée si nécessaire
4. Mettre à jour `index.php` pour la redirection
5. Mettre à jour ce document
