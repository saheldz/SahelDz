# Backup du système localhost:8000

**Date de création:** 23 octobre 2025, 06:59 am

## Description

Ce dossier contient une copie complète de tous les fichiers PHP et HTML qui fonctionnaient sur le serveur localhost:8000 depuis `/Users/mac15/`.

## Structure

```
localhost-system-backup/
├── php/           # Fichiers PHP (4 fichiers)
├── html/          # Fichiers HTML (5 fichiers)
├── assets/        # Dossier pour les ressources (CSS, JS, images)
└── README.md      # Ce fichier
```

## Contenu

### Fichiers PHP (php/)
- `api-proxy.php` (981 octets) - Proxy API
- `ddffgg.php` (124 Ko)
- `ddffgghh.php` (20 Ko)
- `index.php` (19 octets) - Fichier phpinfo()

### Fichiers HTML (html/)
- `1.html` (33 Ko)
- `1a.html` (363 Ko)
- `2.html` (107 Ko)
- `2a.html` (51 Ko)
- `<!DOCTYPE html>.html` (269 Ko)

## Notes

- Tous les fichiers ont été copiés sans modification
- Le serveur original fonctionnait sur PHP 8.2.26
- Les fichiers proviennent de `/Users/mac15/`
- Aucune ressource additionnelle (CSS, JS, images) n'a été trouvée à la racine

## Utilisation

Pour utiliser ces fichiers :

1. Placez les fichiers PHP dans un répertoire accessible par votre serveur PHP
2. Configurez votre serveur web pour servir ces fichiers
3. Assurez-vous que PHP 8.2+ est installé et configuré

## Informations du serveur original

- **Système:** macOS Ventura
- **Version PHP:** 8.2.26
- **Port:** 8000
- **Répertoire de travail:** /Users/mac15/
