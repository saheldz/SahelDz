<?php
require_once 'config/auth-check.php';
if (!isAdmin()) { header('Location: /index.php'); exit; }

require_once 'config/database.php';
$pdo = getDB();

// Stats générales
$stmt = $pdo->query("SELECT 
    SUM(balance) as total_balance,
    COUNT(*) as total_wallets,
    AVG(balance) as avg_balance,
    SUM(CASE WHEN balance > 0 THEN 1 ELSE 0 END) as active_wallets
    FROM wallets WHERE status = 'active'");
$stats = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion Wallets - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <nav class="bg-gradient-to-r from-purple-600 to-blue-600 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div class="flex items-center gap-4">
                <a href="/admin-dashboard.php" class="text-white hover:text-purple-200">← Dashboard</a>
                <h1 class="text-2xl font-bold text-white">💰 Gestion Wallets</h1>
            </div>
            <button onclick="logout()" class="bg-white/10 text-white px-4 py-2 rounded-lg">Déconnexion</button>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        
        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
                <h3 class="text-sm text-gray-600 mb-2">Solde Total</h3>
                <p class="text-3xl font-bold text-green-600"><?php echo number_format($stats['total_balance'], 2); ?> €</p>
            </div>
            
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
                <h3 class="text-sm text-gray-600 mb-2">Wallets Totaux</h3>
                <p class="text-3xl font-bold text-blue-600"><?php echo $stats['total_wallets']; ?></p>
            </div>
            
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
                <h3 class="text-sm text-gray-600 mb-2">Solde Moyen</h3>
                <p class="text-3xl font-bold text-purple-600"><?php echo number_format($stats['avg_balance'], 2); ?> €</p>
            </div>
            
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-yellow-500">
                <h3 class="text-sm text-gray-600 mb-2">Wallets Actifs</h3>
                <p class="text-3xl font-bold text-yellow-600"><?php echo $stats['active_wallets']; ?></p>
            </div>
        </div>

        <!-- Liste des wallets -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-xl font-bold">Liste des Wallets</h2>
                <div class="flex gap-2">
                    <input type="text" id="search" placeholder="🔍 Rechercher..." onkeyup="filterWallets()"
                           class="px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500">
                </div>
            </div>
            
            <div class="overflow-x-auto">
                <table class="w-full" id="wallets-table">
                    <thead>
                        <tr class="border-b-2">
                            <th class="text-left p-3">Utilisateur</th>
                            <th class="text-left p-3">Email</th>
                            <th class="text-right p-3">Solde</th>
                            <th class="text-center p-3">Devise</th>
                            <th class="text-center p-3">Statut</th>
                            <th class="text-center p-3">Dernière MAJ</th>
                            <th class="text-right p-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="wallets-tbody">
                        <!-- Chargé via JS -->
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- Modal Ajouter/Retirer Fonds -->
    <div id="funds-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-xl shadow-2xl max-w-md w-full p-6">
            <div class="flex justify-between items-center mb-6">
                <h3 id="modal-title" class="text-2xl font-bold">Gérer les fonds</h3>
                <button onclick="closeFundsModal()" class="text-gray-400 hover:text-gray-600 text-2xl">×</button>
            </div>
            
            <form id="funds-form" onsubmit="manageFunds(event)">
                <input type="hidden" id="wallet-id" name="wallet_id">
                <input type="hidden" id="user-id-hidden" name="user_id">
                
                <div class="mb-4">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Utilisateur</label>
                    <input type="text" id="user-name" readonly
                           class="w-full px-4 py-2 border rounded-lg bg-gray-50 text-gray-700">
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Solde actuel</label>
                    <input type="text" id="current-balance" readonly
                           class="w-full px-4 py-2 border rounded-lg bg-gray-50 text-gray-700 font-bold">
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Action</label>
                    <div class="grid grid-cols-2 gap-2">
                        <button type="button" onclick="setAction('credit')" id="btn-credit"
                                class="px-4 py-2 border-2 border-green-200 text-green-700 rounded-lg hover:bg-green-50">
                            ➕ Ajouter
                        </button>
                        <button type="button" onclick="setAction('debit')" id="btn-debit"
                                class="px-4 py-2 border-2 border-red-200 text-red-700 rounded-lg hover:bg-red-50">
                            ➖ Retirer
                        </button>
                    </div>
                    <input type="hidden" id="transaction-type" name="type" required>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Montant *</label>
                    <input type="number" name="amount" id="amount" step="0.01" min="0.01" required
                           placeholder="0.00"
                           class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500">
                </div>

                <div class="mb-6">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Description</label>
                    <textarea name="description" id="description" rows="3"
                              placeholder="Raison de la transaction..."
                              class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"></textarea>
                </div>

                <div class="flex gap-3">
                    <button type="submit" class="flex-1 bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700">
                        💾 Confirmer
                    </button>
                    <button type="button" onclick="closeFundsModal()" class="px-6 py-3 border rounded-lg hover:bg-gray-50">
                        Annuler
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Notification -->
    <div id="notification" class="hidden fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50"></div>

    <script>
        let allWallets = [];
        window.addEventListener('load', loadWallets);

        async function loadWallets() {
            const response = await fetch('/api/admin.php?action=get_all_users');
            const result = await response.json();
            
            if (result.success) {
                allWallets = result.users;
                displayWallets(allWallets);
            }
        }

        function displayWallets(wallets) {
            const tbody = document.getElementById('wallets-tbody');
            tbody.innerHTML = wallets.map(wallet => `
                <tr class="border-b hover:bg-gray-50">
                    <td class="p-3">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                                <span class="font-bold text-purple-600">${wallet.full_name.charAt(0)}</span>
                            </div>
                            <span class="font-semibold">${wallet.full_name}</span>
                        </div>
                    </td>
                    <td class="p-3 text-gray-600">${wallet.email}</td>
                    <td class="p-3 text-right font-bold text-green-600">${parseFloat(wallet.balance || 0).toFixed(2)} ${wallet.currency}</td>
                    <td class="p-3 text-center">
                        <span class="bg-blue-100 text-blue-700 px-2 py-1 rounded text-sm">${wallet.currency}</span>
                    </td>
                    <td class="p-3 text-center">
                        <span class="bg-green-100 text-green-700 px-2 py-1 rounded text-sm">${wallet.status}</span>
                    </td>
                    <td class="p-3 text-center text-sm text-gray-500">${new Date().toLocaleDateString('fr-FR')}</td>
                    <td class="p-3 text-right">
                        <button onclick='openFundsModal(${JSON.stringify(wallet)})' 
                                class="bg-purple-100 text-purple-700 px-4 py-2 rounded-lg hover:bg-purple-200 font-semibold">
                            💰 Gérer
                        </button>
                    </td>
                </tr>
            `).join('');
        }

        function filterWallets() {
            const search = document.getElementById('search').value.toLowerCase();
            const filtered = allWallets.filter(w => 
                w.full_name.toLowerCase().includes(search) ||
                w.email.toLowerCase().includes(search)
            );
            displayWallets(filtered);
        }

        function openFundsModal(wallet) {
            document.getElementById('wallet-id').value = wallet.id;
            document.getElementById('user-id-hidden').value = wallet.id;
            document.getElementById('user-name').value = wallet.full_name;
            document.getElementById('current-balance').value = parseFloat(wallet.balance || 0).toFixed(2) + ' ' + wallet.currency;
            document.getElementById('amount').value = '';
            document.getElementById('description').value = '';
            document.getElementById('transaction-type').value = '';
            
            // Reset buttons
            document.getElementById('btn-credit').className = 'px-4 py-2 border-2 border-green-200 text-green-700 rounded-lg hover:bg-green-50';
            document.getElementById('btn-debit').className = 'px-4 py-2 border-2 border-red-200 text-red-700 rounded-lg hover:bg-red-50';
            
            document.getElementById('funds-modal').classList.remove('hidden');
        }

        function closeFundsModal() {
            document.getElementById('funds-modal').classList.add('hidden');
        }

        function setAction(type) {
            document.getElementById('transaction-type').value = type;
            
            if (type === 'credit') {
                document.getElementById('btn-credit').className = 'px-4 py-2 border-2 border-green-500 bg-green-100 text-green-700 rounded-lg font-semibold';
                document.getElementById('btn-debit').className = 'px-4 py-2 border-2 border-red-200 text-red-700 rounded-lg hover:bg-red-50';
            } else {
                document.getElementById('btn-debit').className = 'px-4 py-2 border-2 border-red-500 bg-red-100 text-red-700 rounded-lg font-semibold';
                document.getElementById('btn-credit').className = 'px-4 py-2 border-2 border-green-200 text-green-700 rounded-lg hover:bg-green-50';
            }
        }

        async function manageFunds(e) {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            formData.append('action', 'manage_wallet_funds');
            
            const response = await fetch('/api/wallet.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                showNotification('✅ Transaction effectuée avec succès !', 'success');
                closeFundsModal();
                await loadWallets();
                location.reload();
            } else {
                showNotification('❌ ' + result.error, 'error');
            }
        }

        async function logout() {
            const formData = new FormData();
            formData.append('action', 'logout');
            await fetch('/api/auth.php', { method: 'POST', body: formData });
            window.location.href = '/login.html';
        }

        function showNotification(message, type) {
            const notification = document.getElementById('notification');
            const colors = {
                success: 'border-green-500 bg-green-50',
                error: 'border-red-500 bg-red-50',
                info: 'border-blue-500 bg-blue-50'
            };
            
            notification.className = `fixed top-4 right-4 max-w-sm bg-white rounded-lg shadow-2xl p-4 border-l-4 z-50 ${colors[type]}`;
            notification.textContent = message;
            notification.classList.remove('hidden');
            
            setTimeout(() => notification.classList.add('hidden'), 5000);
        }
    </script>
</body>
</html>
