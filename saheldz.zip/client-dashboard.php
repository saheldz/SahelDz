<?php
/**
 * Dashboard Client - Interface pour les clients
 */
require_once 'config/auth-check.php';

// Récupérer les informations du client
require_once 'config/database.php';
$pdo = getDB();

// Stats du client
$stmt = $pdo->prepare("SELECT balance, currency FROM wallets WHERE user_id = ? AND status = 'active'");
$stmt->execute([$GLOBALS['current_user']['id']]);
$wallet = $stmt->fetch();

// Transactions récentes
$stmt = $pdo->prepare("
    SELECT t.* FROM transactions t
    JOIN wallets w ON t.wallet_id = w.id
    WHERE w.user_id = ?
    ORDER BY t.created_at DESC
    LIMIT 10
");
$stmt->execute([$GLOBALS['current_user']['id']]);
$transactions = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Espace Client - DigiServices</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <?php include 'config/impersonation-banner.php'; ?>
    
    <!-- Header Client -->
    <nav class="bg-gradient-to-r from-blue-600 to-purple-600 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <a href="/client-dashboard.php" class="text-2xl font-bold text-white">🚀 DigiServices</a>
                    <span class="text-white/60">|</span>
                    <span class="text-white/90">Mon Espace Client</span>
                </div>
                
                <div class="flex items-center gap-4">
                    <div class="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-lg">
                        <div class="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                            <span class="text-xl">👤</span>
                        </div>
                        <div class="text-white">
                            <p class="font-semibold text-sm"><?php echo htmlspecialchars($GLOBALS['current_user']['full_name']); ?></p>
                            <p class="text-xs text-blue-100">Client</p>
                        </div>
                    </div>
                    
                    <a href="/settings.php" class="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg font-semibold transition-colors">
                        ⚙️ Paramètres
                    </a>
                    
                    <button onclick="logout()" class="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg font-semibold transition-colors">
                        🚪 Déconnexion
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        
        <!-- Bienvenue -->
        <div class="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl shadow-lg p-8 mb-8 text-white">
            <h1 class="text-3xl font-bold mb-2">Bienvenue, <?php echo htmlspecialchars($GLOBALS['current_user']['full_name']); ?> ! 👋</h1>
            <p class="text-blue-100">Gérez vos services digitaux en toute simplicité</p>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <!-- Wallet -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">💰</span>
                    </div>
                </div>
                <h3 class="text-3xl font-bold text-gray-800 mb-1"><?php echo number_format($wallet['balance'] ?? 0, 2); ?> <?php echo $wallet['currency'] ?? 'EUR'; ?></h3>
                <p class="text-gray-600 text-sm">Solde disponible</p>
                <button onclick="showRechargeModal()" class="mt-4 w-full bg-green-500 text-white py-2 rounded-lg hover:bg-green-600 transition-colors">
                    + Recharger
                </button>
            </div>

            <!-- Commandes -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">📦</span>
                    </div>
                </div>
                <h3 class="text-3xl font-bold text-gray-800 mb-1">0</h3>
                <p class="text-gray-600 text-sm">Commandes en cours</p>
                <a href="#commandes" class="mt-4 block w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition-colors text-center">
                    Voir mes commandes
                </a>
            </div>

            <!-- Projets -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">📁</span>
                    </div>
                </div>
                <h3 class="text-3xl font-bold text-gray-800 mb-1">0</h3>
                <p class="text-gray-600 text-sm">Projets actifs</p>
                <a href="#projets" class="mt-4 block w-full bg-purple-500 text-white py-2 rounded-lg hover:bg-purple-600 transition-colors text-center">
                    Mes projets
                </a>
            </div>
        </div>

        <!-- Services disponibles -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-6">🎨 Services Disponibles</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="/html/1a.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-blue-200 hover:border-blue-400">
                    <span class="text-4xl mb-3">🎨</span>
                    <span class="font-semibold text-gray-800">Branding</span>
                    <span class="text-xs text-gray-600 mt-1">Design & Identité</span>
                </a>

                <div class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-purple-200 hover:border-purple-400">
                    <span class="text-4xl mb-3">💻</span>
                    <span class="font-semibold text-gray-800">Développement</span>
                    <span class="text-xs text-gray-600 mt-1">Sites & Apps</span>
                </div>

                <div class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-green-200 hover:border-green-400">
                    <span class="text-4xl mb-3">📱</span>
                    <span class="font-semibold text-gray-800">Marketing</span>
                    <span class="text-xs text-gray-600 mt-1">Digital & Social</span>
                </div>

                <div class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-yellow-200 hover:border-yellow-400">
                    <span class="text-4xl mb-3">🎬</span>
                    <span class="font-semibold text-gray-800">Multimédia</span>
                    <span class="text-xs text-gray-600 mt-1">Vidéo & Audio</span>
                </div>

                <a href="/client-subscriptions.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-indigo-200 hover:border-indigo-400">
                    <span class="text-4xl mb-3">📦</span>
                    <span class="font-semibold text-gray-800">Mes Abonnements</span>
                    <span class="text-xs text-gray-600 mt-1">Plans & Services</span>
                </a>
            </div>
        </div>

        <!-- Transactions récentes -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-lg font-bold text-gray-800 mb-4">💳 Transactions Récentes</h3>
            <div id="recent-transactions" class="space-y-3">
                <?php if (empty($transactions)): ?>
                    <p class="text-gray-500 text-sm text-center py-4">Aucune transaction pour le moment</p>
                <?php else: ?>
                    <?php foreach ($transactions as $trans): 
                        $typeColors = [
                            'credit' => 'text-green-600 bg-green-50',
                            'debit' => 'text-red-600 bg-red-50',
                            'refund' => 'text-blue-600 bg-blue-50'
                        ];
                        $typeIcons = [
                            'credit' => '↑',
                            'debit' => '↓',
                            'refund' => '↩'
                        ];
                    ?>
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 <?php echo $typeColors[$trans['type']]; ?> rounded-full flex items-center justify-center">
                                    <span class="text-lg"><?php echo $typeIcons[$trans['type']]; ?></span>
                                </div>
                                <div>
                                    <p class="font-semibold text-gray-800 text-sm"><?php echo htmlspecialchars($trans['description'] ?? $trans['type']); ?></p>
                                    <p class="text-xs text-gray-500"><?php echo date('d/m/Y H:i', strtotime($trans['created_at'])); ?></p>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="font-bold <?php echo $trans['type'] === 'credit' ? 'text-green-600' : 'text-red-600'; ?> text-sm">
                                    <?php echo $trans['type'] === 'credit' ? '+' : '-'; ?><?php echo number_format($trans['amount'], 2); ?> €
                                </p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal Recharge -->
    <div id="recharge-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-xl shadow-2xl max-w-md w-full mx-4 p-6">
            <h3 class="text-2xl font-bold text-gray-800 mb-4">💰 Recharger mon compte</h3>
            <p class="text-gray-600 mb-6">Contactez un administrateur pour effectuer un rechargement de votre compte.</p>
            <div class="flex gap-3">
                <button onclick="closeRechargeModal()" class="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-300 transition-colors">
                    Fermer
                </button>
                <button class="flex-1 bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors">
                    Contacter Admin
                </button>
            </div>
        </div>
    </div>

    <script>
        async function logout() {
            const formData = new FormData();
            formData.append('action', 'logout');
            await fetch('/api/auth.php', { method: 'POST', body: formData });
            window.location.href = '/login.html';
        }

        function showRechargeModal() {
            document.getElementById('recharge-modal').classList.remove('hidden');
        }

        function closeRechargeModal() {
            document.getElementById('recharge-modal').classList.add('hidden');
        }
    </script>
</body>
</html>
