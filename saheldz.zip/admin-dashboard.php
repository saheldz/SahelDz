<?php
/**
 * Dashboard Administrateur - Accès réservé aux admins
 */
require_once 'config/auth-check.php';

// Vérifier que l'utilisateur est admin
if (!isAdmin()) {
    header('Location: /index.php');
    exit;
}

// Récupérer les statistiques
require_once 'config/database.php';
$pdo = getDB();

// Stats utilisateurs
$stmt = $pdo->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
    SUM(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) as new_week
    FROM users");
$userStats = $stmt->fetch();

// Stats wallets
$stmt = $pdo->query("SELECT 
    SUM(balance) as total_balance,
    COUNT(*) as total_wallets,
    AVG(balance) as avg_balance
    FROM wallets WHERE status = 'active'");
$walletStats = $stmt->fetch();

// Stats transactions récentes
$stmt = $pdo->query("SELECT COUNT(*) as count FROM transactions WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)");
$transToday = $stmt->fetchColumn();

// Stats rôles
$stmt = $pdo->query("SELECT COUNT(*) as count FROM roles");
$rolesCount = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - DigiServices</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    
    <!-- Header Admin -->
    <nav class="bg-gradient-to-r from-purple-600 to-blue-600 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <h1 class="text-2xl font-bold text-white">👑 Dashboard Administrateur</h1>
                </div>
                
                <div class="flex items-center gap-4">
                    <!-- Profil Admin -->
                    <div class="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-lg">
                        <div class="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                            <span class="text-xl">👑</span>
                        </div>
                        <div class="text-white">
                            <p class="font-semibold text-sm"><?php echo htmlspecialchars($GLOBALS['current_user']['full_name']); ?></p>
                            <p class="text-xs text-purple-100">Administrateur</p>
                        </div>
                    </div>
                    
                    <button onclick="logout()" class="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg font-semibold transition-colors">
                        🚪 Déconnexion
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto px-4 py-8">
        
        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <!-- Utilisateurs -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">👥</span>
                    </div>
                    <span class="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-semibold">
                        +<?php echo $userStats['new_week']; ?> cette semaine
                    </span>
                </div>
                <h3 class="text-3xl font-bold text-gray-800 mb-1"><?php echo $userStats['total']; ?></h3>
                <p class="text-gray-600 text-sm">Utilisateurs totaux</p>
                <p class="text-green-600 text-xs mt-2"><?php echo $userStats['active']; ?> actifs</p>
            </div>

            <!-- Wallets -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">💰</span>
                    </div>
                </div>
                <h3 class="text-3xl font-bold text-gray-800 mb-1"><?php echo number_format($walletStats['total_balance'], 2); ?> €</h3>
                <p class="text-gray-600 text-sm">Solde total</p>
                <p class="text-gray-500 text-xs mt-2">Moyenne: <?php echo number_format($walletStats['avg_balance'], 2); ?> €</p>
            </div>

            <!-- Transactions -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-yellow-500">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">💳</span>
                    </div>
                </div>
                <h3 class="text-3xl font-bold text-gray-800 mb-1"><?php echo $transToday; ?></h3>
                <p class="text-gray-600 text-sm">Transactions 24h</p>
            </div>

            <!-- Rôles -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
                <div class="flex items-center justify-between mb-4">
                    <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">🔐</span>
                    </div>
                </div>
                <h3 class="text-3xl font-bold text-gray-800 mb-1"><?php echo $rolesCount; ?></h3>
                <p class="text-gray-600 text-sm">Rôles configurés</p>
            </div>
        </div>

        <!-- Actions rapides -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-6">⚡ Actions rapides</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <a href="/admin-users.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-blue-200 hover:border-blue-400">
                    <span class="text-4xl mb-3">👥</span>
                    <span class="font-semibold text-gray-800">Utilisateurs</span>
                    <span class="text-xs text-gray-600 mt-1">Gérer les comptes</span>
                </a>

                <a href="/admin-permissions.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-purple-200 hover:border-purple-400">
                    <span class="text-4xl mb-3">🔐</span>
                    <span class="font-semibold text-gray-800">Rôles & Permissions</span>
                    <span class="text-xs text-gray-600 mt-1">Gestion complète</span>
                </a>

                <a href="/admin-wallets.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-green-200 hover:border-green-400">
                    <span class="text-4xl mb-3">💰</span>
                    <span class="font-semibold text-gray-800">Wallets</span>
                    <span class="text-xs text-gray-600 mt-1">Gérer les fonds</span>
                </a>

                <a href="/admin-orders.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-yellow-200 hover:border-yellow-400">
                    <span class="text-4xl mb-3">📦</span>
                    <span class="font-semibold text-gray-800">Commandes</span>
                    <span class="text-xs text-gray-600 mt-1">Voir toutes</span>
                </a>

                <a href="/addons/subscriptions/admin/dashboard.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-indigo-200 hover:border-indigo-400">
                    <span class="text-4xl mb-3">📦</span>
                    <span class="font-semibold text-gray-800">Abonnements</span>
                    <span class="text-xs text-gray-600 mt-1">Gestion complète</span>
                </a>

                <a href="/settings.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-gray-200 hover:border-gray-400">
                    <span class="text-4xl mb-3">⚙️</span>
                    <span class="font-semibold text-gray-800">Paramètres</span>
                    <span class="text-xs text-gray-600 mt-1">Mon profil</span>
                </a>

                <a href="/admin-reports.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-indigo-200 hover:border-indigo-400">
                    <span class="text-4xl mb-3">📊</span>
                    <span class="font-semibold text-gray-800">Rapports</span>
                    <span class="text-xs text-gray-600 mt-1">Statistiques</span>
                </a>

                <a href="/admin-logs.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-red-50 to-red-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-red-200 hover:border-red-400">
                    <span class="text-4xl mb-3">📝</span>
                    <span class="font-semibold text-gray-800">Logs</span>
                    <span class="text-xs text-gray-600 mt-1">Activité système</span>
                </a>

                <a href="/html/1a.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-pink-50 to-pink-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-pink-200 hover:border-pink-400">
                    <span class="text-4xl mb-3">🎨</span>
                    <span class="font-semibold text-gray-800">Branding</span>
                    <span class="text-xs text-gray-600 mt-1">Interface client</span>
                </a>

                <a href="/admin-addons.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-orange-200 hover:border-orange-400">
                    <span class="text-4xl mb-3">🧩</span>
                    <span class="font-semibold text-gray-800">Addons</span>
                    <span class="text-xs text-gray-600 mt-1">Extensions modulaires</span>
                </a>

                <a href="/admin-smtp.php" class="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-teal-50 to-teal-100 rounded-xl hover:shadow-md transition-all cursor-pointer border-2 border-teal-200 hover:border-teal-400">
                    <span class="text-4xl mb-3">📧</span>
                    <span class="font-semibold text-gray-800">SMTP</span>
                    <span class="text-xs text-gray-600 mt-1">Configuration email</span>
                </a>
            </div>
        </div>

        <!-- Utilisateurs récents & Transactions récentes -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Utilisateurs récents -->
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4">👥 Utilisateurs récents</h3>
                <div id="recent-users" class="space-y-3">
                    <!-- Chargé via JavaScript -->
                </div>
            </div>

            <!-- Transactions récentes -->
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4">💳 Transactions récentes</h3>
                <div id="recent-transactions" class="space-y-3">
                    <!-- Chargé via JavaScript -->
                </div>
            </div>
        </div>
    </div>

    <script>
        // Charger les données au démarrage
        window.addEventListener('load', () => {
            loadRecentUsers();
            loadRecentTransactions();
        });

        // Charger les utilisateurs récents
        async function loadRecentUsers() {
            const response = await fetch('/api/admin.php?action=get_recent_users&limit=5');
            const result = await response.json();
            
            const container = document.getElementById('recent-users');
            if (result.success && result.users.length > 0) {
                container.innerHTML = result.users.map(user => `
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                                <span class="text-sm font-bold text-purple-600">${user.full_name.charAt(0)}</span>
                            </div>
                            <div>
                                <p class="font-semibold text-gray-800 text-sm">${user.full_name}</p>
                                <p class="text-xs text-gray-500">${user.email}</p>
                            </div>
                        </div>
                        <span class="text-xs text-gray-500">${new Date(user.created_at).toLocaleDateString('fr-FR')}</span>
                    </div>
                `).join('');
            } else {
                container.innerHTML = '<p class="text-gray-500 text-sm text-center py-4">Aucun utilisateur récent</p>';
            }
        }

        // Charger les transactions récentes
        async function loadRecentTransactions() {
            const response = await fetch('/api/admin.php?action=get_recent_transactions&limit=5');
            const result = await response.json();
            
            const container = document.getElementById('recent-transactions');
            if (result.success && result.transactions.length > 0) {
                container.innerHTML = result.transactions.map(trans => {
                    const typeColors = {
                        credit: 'text-green-600 bg-green-50',
                        debit: 'text-red-600 bg-red-50',
                        refund: 'text-blue-600 bg-blue-50'
                    };
                    const typeIcons = {
                        credit: '↑',
                        debit: '↓',
                        refund: '↩'
                    };
                    return `
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 ${typeColors[trans.type]} rounded-full flex items-center justify-center">
                                    <span class="text-lg">${typeIcons[trans.type]}</span>
                                </div>
                                <div>
                                    <p class="font-semibold text-gray-800 text-sm">${trans.description || trans.type}</p>
                                    <p class="text-xs text-gray-500">${trans.user_email}</p>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="font-bold ${trans.type === 'credit' ? 'text-green-600' : 'text-red-600'} text-sm">
                                    ${trans.type === 'credit' ? '+' : '-'}${trans.amount} €
                                </p>
                                <p class="text-xs text-gray-500">${new Date(trans.created_at).toLocaleTimeString('fr-FR')}</p>
                            </div>
                        </div>
                    `;
                }).join('');
            } else {
                container.innerHTML = '<p class="text-gray-500 text-sm text-center py-4">Aucune transaction récente</p>';
            }
        }

        // Déconnexion
        async function logout() {
            const formData = new FormData();
            formData.append('action', 'logout');
            await fetch('/api/auth.php', { method: 'POST', body: formData });
            window.location.href = '/login.html';
        }
    </script>
</body>
</html>
