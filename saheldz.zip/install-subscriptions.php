<?php
/**
 * Script d'installation du module d'abonnements
 * Ce script crée les tables nécessaires pour gérer les plans et abonnements
 */

require_once 'config/database.php';

try {
    $pdo = getDB();
    
    echo "🚀 Installation du module d'abonnements...\n\n";
    
    // Table des plans d'abonnement
    echo "📋 Création de la table subscription_plans...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS subscription_plans (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            description TEXT,
            price DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
            billing_period ENUM('daily', 'weekly', 'monthly', 'quarterly', 'yearly') NOT NULL DEFAULT 'monthly',
            trial_days INT DEFAULT 0,
            features JSON,
            max_users INT DEFAULT NULL,
            max_storage INT DEFAULT NULL COMMENT 'En MB',
            status ENUM('active', 'inactive', 'archived') DEFAULT 'active',
            is_popular BOOLEAN DEFAULT FALSE,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_status (status),
            INDEX idx_price (price)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✅ Table subscription_plans créée\n\n";
    
    // Table des abonnements
    echo "📋 Création de la table subscriptions...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS subscriptions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            plan_id INT NOT NULL,
            status ENUM('trial', 'active', 'suspended', 'cancelled', 'expired') DEFAULT 'active',
            start_date DATE NOT NULL,
            end_date DATE,
            next_billing_date DATE,
            trial_ends_at DATE DEFAULT NULL,
            cancelled_at TIMESTAMP NULL DEFAULT NULL,
            cancel_reason TEXT,
            amount DECIMAL(10, 2) NOT NULL,
            billing_period ENUM('daily', 'weekly', 'monthly', 'quarterly', 'yearly') NOT NULL,
            auto_renew BOOLEAN DEFAULT TRUE,
            payment_method VARCHAR(50) DEFAULT 'wallet',
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (plan_id) REFERENCES subscription_plans(id) ON DELETE RESTRICT,
            INDEX idx_user_id (user_id),
            INDEX idx_plan_id (plan_id),
            INDEX idx_status (status),
            INDEX idx_next_billing (next_billing_date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✅ Table subscriptions créée\n\n";
    
    // Table des items/services d'abonnement
    echo "📋 Création de la table subscription_items...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS subscription_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            subscription_id INT NOT NULL,
            item_type ENUM('service', 'product', 'feature') DEFAULT 'service',
            item_name VARCHAR(255) NOT NULL,
            item_description TEXT,
            quantity INT DEFAULT 1,
            unit_price DECIMAL(10, 2) DEFAULT 0.00,
            total_price DECIMAL(10, 2) DEFAULT 0.00,
            metadata JSON,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE,
            INDEX idx_subscription_id (subscription_id),
            INDEX idx_item_type (item_type)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✅ Table subscription_items créée\n\n";
    
    // Table de l'historique des abonnements
    echo "📋 Création de la table subscription_history...\n";
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS subscription_history (
            id INT AUTO_INCREMENT PRIMARY KEY,
            subscription_id INT NOT NULL,
            action VARCHAR(50) NOT NULL COMMENT 'created, renewed, suspended, cancelled, expired, reactivated',
            old_status VARCHAR(50),
            new_status VARCHAR(50),
            amount DECIMAL(10, 2) DEFAULT 0.00,
            description TEXT,
            created_by INT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (subscription_id) REFERENCES subscriptions(id) ON DELETE CASCADE,
            FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_subscription_id (subscription_id),
            INDEX idx_action (action)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✅ Table subscription_history créée\n\n";
    
    // Insérer des plans d'exemple
    echo "📦 Insertion des plans d'exemple...\n";
    $plans = [
        [
            'name' => 'Plan Starter',
            'description' => 'Parfait pour débuter',
            'price' => 9.99,
            'billing_period' => 'monthly',
            'trial_days' => 7,
            'features' => json_encode([
                'Jusqu\'à 3 utilisateurs',
                '5 GB de stockage',
                'Support par email',
                'Rapports basiques'
            ]),
            'max_users' => 3,
            'max_storage' => 5120,
            'is_popular' => 0,
            'sort_order' => 1
        ],
        [
            'name' => 'Plan Pro',
            'description' => 'Pour les professionnels exigeants',
            'price' => 29.99,
            'billing_period' => 'monthly',
            'trial_days' => 14,
            'features' => json_encode([
                'Jusqu\'à 10 utilisateurs',
                '50 GB de stockage',
                'Support prioritaire',
                'Rapports avancés',
                'API Access',
                'Intégrations tierces'
            ]),
            'max_users' => 10,
            'max_storage' => 51200,
            'is_popular' => 1,
            'sort_order' => 2
        ],
        [
            'name' => 'Plan Enterprise',
            'description' => 'Solution complète pour entreprises',
            'price' => 99.99,
            'billing_period' => 'monthly',
            'trial_days' => 30,
            'features' => json_encode([
                'Utilisateurs illimités',
                'Stockage illimité',
                'Support 24/7',
                'Rapports personnalisés',
                'API illimitée',
                'Intégrations avancées',
                'Manager dédié',
                'SLA garanti'
            ]),
            'max_users' => NULL,
            'max_storage' => NULL,
            'is_popular' => 0,
            'sort_order' => 3
        ]
    ];
    
    $stmt = $pdo->prepare("
        INSERT INTO subscription_plans 
        (name, description, price, billing_period, trial_days, features, max_users, max_storage, is_popular, sort_order)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    foreach ($plans as $plan) {
        $stmt->execute([
            $plan['name'],
            $plan['description'],
            $plan['price'],
            $plan['billing_period'],
            $plan['trial_days'],
            $plan['features'],
            $plan['max_users'],
            $plan['max_storage'],
            $plan['is_popular'],
            $plan['sort_order']
        ]);
    }
    
    echo "✅ Plans d'exemple insérés\n\n";
    
    echo "🎉 Installation terminée avec succès !\n\n";
    echo "📌 Tables créées :\n";
    echo "   - subscription_plans\n";
    echo "   - subscriptions\n";
    echo "   - subscription_items\n";
    echo "   - subscription_history\n\n";
    echo "🔗 Accédez à l'interface d'administration : /admin-subscriptions.php\n\n";
    
} catch (PDOException $e) {
    echo "❌ Erreur lors de l'installation : " . $e->getMessage() . "\n";
    exit(1);
}
